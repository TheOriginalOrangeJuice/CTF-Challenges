# Message Removed maintenance

The deployment commands are in the canonical Description documents. The current review container is `rowdy11-message-removed`, published on port 18111. Stop only this service with `docker stop rowdy11-message-removed`; restart with `docker start rowdy11-message-removed`. The service has no mutable server data or required volumes. A browser tab owns its messages, drafts and call allowance through session storage. Reset discards chat changes after confirmation and retains a consumed incoming-call allowance.

Execution belongs in Condev. Stage the complete folder with the condev-development skill's `stage_tree.ps1`, confirm zero SHA-256 differences, copy the whole stage into a fresh Condev directory, and verify a changed source hash. Copy generated deliverables back and stage again after edits. Do not overwrite the user's source with a stale stage. Do not stop unrelated containers.

The static container uses the Python image digest pinned in `challenge/Dockerfile`. Its public root is `challenge/public`; organizer files and the unencrypted receipt are excluded by construction. There is no account, microphone, external messaging service, or flag-submission endpoint. Players submit to the CTF platform.

Artifact maintenance requires Python 3.12, SQLite 3.46.1, DejaVu Sans 2.37, and the versions in `requirements.txt`. `generate.py` creates the two synthetic legacy-compatible databases through genuine SQLite operations with secure deletion disabled. It freezes archive ordering, timestamps, deterministic fixture-only AES salt, and evidence. The only public evidence download is `skype-backups.zip`: two laptop folders, each containing its Skype database and a Downloads copy of the encrypted receipt. There is no public inventory, verification manifest, standalone receipt download, or history JSON. Organizer reports stay private. Do not use the fixture constants to protect real data. The original receipt is authored evidence, not a capture from a real Skype account. Preserve the frozen bytes when distributing an unchanged release.

Only the narrative belongs in CTFd. The application contains ordinary chats and file transfers, with no CTF objective, directions or backup-history browser. The organizer walkthrough uses external SQLite and hex tools. Incoming calls make one 5% draw every 30 eligible seconds, after deliberate interaction, with the existing visibility/dialog/call gates and one-per-tab allowance. Legacy tabs migrate their starting conversation and leave the removed history mode while preserving player messages and drafts.

From the staged challenge root in Condev:

```sh
python organizer/generate.py
python organizer/acquire_audio.py
node organizer/test_engine.mjs organizer/results/engine.json
python organizer/test_interface.py
python organizer/test_audio_realtime.py
```

Use the configured Python environment with the pinned packages; this workspace used `/tmp/rowdy-ctf-tools/bin/python` and task-only `PYTHONPATH=/tmp/rowdy11-deps`. The generator enforces its SQLite version because page allocation is part of the evidence. The complete evidence and successful prior recovery report are frozen in this release; the latest user-requested pass does not rerun security/shortcut tests or forensic recovery. See `results/release.json` for scope and remaining limitations.

The WAV originals and notices are frozen in `audio-sources/`; `acquire_audio.py` converts those files with FFmpeg 7.1.2 to mono 44.1 kHz PCM. It can also extract exact members from a supplied Skype 4.3 archive without executing that software. Provenance, original hashes and final hashes are in `audio-provenance.json`. Do not replace the actual recordings with synthesized approximations. Artwork and avatars in the interface are original SVG/CSS drawings. Original Skype/Microsoft sounds and trademarks are attributed in About.

The automated browser tests use controlled randomness and a virtual UI clock in test-only instrumentation. `test_audio_realtime.py` additionally runs the full 45-second call with real time and measures the post-volume output graph. Automation does not establish independent human listening or playtesting.

Build the submission pair using the shared `../_documentation/build_description.py` and its original template. In Condev, run `python ../_documentation/build_description.py Description.md --render-dir organizer/document-review`. It uses the local `rowdy-doc-renderer:20261025` image. Inspect every rendered page and refresh the actual screenshots when the interface changes.

The HTML comment marked “Documentation sample only” contains `RCC{sample_not_a_reward}`. It is separate from evidence, accessibility labels, and application behavior. The intended experimental effect is to discourage accepting a flag found by indiscriminate source scanning; its effectiveness has not been independently measured. It adds no player action and does not block tools or scripts.
