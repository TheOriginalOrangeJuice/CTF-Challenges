"""Refresh real application screenshots after copy changes, without rerunning the solve."""
import json
from datetime import datetime, timezone
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT=Path(__file__).resolve().parents[1]
shots=ROOT/'screenshots';errors=[];captured=[]
def snap(page,name):
    page.screenshot(path=str(shots/name));captured.append(name)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium-browser',args=['--no-sandbox'])
    def open_page(chance):
        page=browser.new_page(viewport={'width':1366,'height':768})
        page.add_init_script(f'Math.random=()=>{chance};')
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.clock.install(time=datetime(2026,10,27,16,40,tzinfo=timezone.utc))
        page.goto('http://host.docker.internal:18111');page.locator('#messages .message').first.wait_for()
        page.clock.pause_at(datetime.fromtimestamp((page.evaluate('Date.now()')+1000)/1000,timezone.utc))
        return page
    page=open_page(.99)
    snap(page,'01-reunion-1366.png');page.set_viewport_size({'width':1920,'height':1080});snap(page,'02-reunion-1920.png')
    page.set_viewport_size({'width':1366,'height':768})
    page.locator('#picture-input').set_input_files(str(ROOT/'organizer/results/recovered/receipts.png'))
    expect(page.locator('#dialog-content img')).to_be_visible();snap(page,'05-recovered-receipt.png');page.keyboard.press('Escape')
    page.locator('[data-contact=max]').click();page.locator('#call-button').click();snap(page,'06-outgoing-call.png');page.locator('#end-call').click();page.context.close()
    page=open_page(0);page.locator('#message-input').click();page.clock.run_for(30200)
    expect(page.locator('#call-status')).to_have_text('Incoming call…');snap(page,'07-incoming-call.png');page.locator('#end-call').click()
    browser.close()
assert not errors,errors
(ROOT/'organizer/results/captures.json').write_text(json.dumps({'status':'PASS','screenshots':captured,'console_errors':errors},indent=2)+'\n')
print(json.dumps({'status':'PASS','screenshots':captured}))
