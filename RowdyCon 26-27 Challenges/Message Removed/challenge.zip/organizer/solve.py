"""Recover the shared receipt using ONLY the distributed skype-backups.zip.

No generator imports, private constants, fixed byte offsets, or password guesses.
Usage: python solve.py skype-backups.zip --out recovered
"""
import argparse
import io
import json
import re
import sqlite3
import tempfile
import zipfile
from pathlib import Path
import pyzipper


def varint(raw,at):
    value=0
    for i in range(9):
        b=raw[at+i]
        if i==8:return (value<<8)|b,at+i+1
        value=(value<<7)|(b&127)
        if b<128:return value,at+i+1
    raise ValueError('varint')


def serial_size(t):
    if t in (0,8,9):return 0
    if 1<=t<=7:return (1,2,3,4,6,8,8)[t-1]
    if t>=12:return (t-12)//2
    raise ValueError('reserved serial type')


def original_records(raw,guid):
    """Find surviving table-leaf cells and decode their SQLite record headers."""
    at=0
    while True:
        hit=raw.find(guid,at)
        if hit<0:return
        at=hit+1
        for start in range(max(100,hit-100),hit):
            try:
                payload,h=varint(raw,start);rowid,record=varint(raw,h)
                header_size,h=varint(raw,record)
                if not 9<=header_size<=50 or not header_size<payload<4096:continue
                types=[]
                while h<record+header_size:
                    t,h=varint(raw,h);types.append(t)
                if h!=record+header_size or len(types)!=9 or types[0]!=0 or types[1]!=44:continue
                if payload != header_size+sum(serial_size(t) for t in types):continue
                pos=record+header_size;fields=[];positions=[]
                for t in types:
                    length=serial_size(t);positions.append(pos);fields.append(raw[pos:pos+length]);pos+=length
                if positions[1]!=hit or fields[1]!=guid or types[6]!=8:continue
                if types[2]%2!=1 or types[4]%2!=1 or types[5]%2!=1:continue
                chat=fields[2].decode('utf-8');author=fields[4].decode('utf-8')
                timestamp=int.from_bytes(fields[3],'big',signed=True)
                if not chat.startswith('#') or not 1200000000<timestamp<1600000000:continue
                yield {'cell_offset':start,'rowid':rowid,'guid':guid.hex(),'chatname':chat,
                       'timestamp':timestamp,'author':author,'edited_timestamp':0,
                       'body_offset':positions[5],'body_length':serial_size(types[5]),'serial_types':types}
            except (ValueError,IndexError,UnicodeDecodeError):continue


def recover(bundle,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(bundle) as z:
        profiles={name:z.read(name) for name in z.namelist() if name.endswith('/main.db')}
        if len(profiles)!=2:raise ValueError('Expected two Skype profiles')
        archives=[z.read(name) for name in z.namelist() if name.endswith('/Downloads/receipts.zip')]
        if not archives or len(set(archives))!=1:raise ValueError('Expected matching downloaded receipts')
        archive=archives[0]
    candidates={};current_passwords=set();records=[];tables=[]
    with tempfile.TemporaryDirectory() as temp:
        for i,(name,raw) in enumerate(profiles.items()):
            path=Path(temp)/f'{i}.db';path.write_bytes(raw)
            db=sqlite3.connect(f'file:{path}?mode=ro&immutable=1',uri=True)
            columns=[r[1] for r in db.execute('PRAGMA table_info(Messages)')]
            if columns!=['id','guid','chatname','timestamp','author','body_xml','edited_timestamp','type','convo_id']:
                raise ValueError('Inspect this profile schema before using this record decoder')
            # Establish the sender/chat of the actual shared file from its GUID.
            transfer=db.execute('SELECT M.author,M.chatname,T.filename FROM Transfers T JOIN Messages M ON M.guid=T.chatmsg_guid WHERE T.filename=?',('receipts.zip',)).fetchone()
            if not transfer:raise ValueError('No matching file transfer')
            for guid,author,ts,body,edited,rowid in db.execute('SELECT guid,author,timestamp,body_xml,edited_timestamp,id FROM Messages WHERE author=? AND chatname=?',(transfer[0],transfer[1])):
                if edited:
                    candidates.setdefault(guid,[]).append((name,author,ts,edited,rowid))
                    tables.append({'profile':name,'rowid':rowid,'guid':guid.hex(),'author':author,'timestamp':ts,'edited_timestamp':edited,'body':body})
                    current_passwords.update(re.findall(r'password: ([A-Za-z0-9]+)',body))
            db.close()
    prefixes=[]
    for guid,versions in candidates.items():
        if len({v[0]for v in versions})!=2:continue
        for name,raw in profiles.items():
            for record in original_records(raw,guid):
                if not any(record['author']==v[1] and record['timestamp']==v[2] for v in versions):continue
                body=raw[record['body_offset']:record['body_offset']+record['body_length']]
                match=re.match(rb'receipts\.zip password: ([A-Za-z0-9]+)',body)
                if match:
                    prefix=match.group(1).decode();prefixes.append((name,prefix));records.append({'profile':name,**record,'surviving_prefix':prefix})
    suffixes=[]
    for name,raw in profiles.items():
        for match in re.finditer(rb'([A-Za-z0-9]{10,64})\n<quote>',raw):
            suffixes.append((name,match.group(1).decode(),match.start(1)))
    for pname,prefix in prefixes:
        for sname,suffix,offset in suffixes:
            if pname==sname:continue
            for overlap in range(min(len(prefix),len(suffix)),7,-1):
                if prefix[-overlap:]!=suffix[:overlap]:continue
                password=prefix+suffix[overlap:]
                if password in current_passwords:continue
                try:
                    with pyzipper.AESZipFile(io.BytesIO(archive)) as z:
                        png=z.read('receipts.png',pwd=password.encode())
                    if not png.startswith(b'\x89PNG\r\n\x1a\n'):continue
                except (RuntimeError,ValueError,zipfile.BadZipFile):continue
                (out/'receipts.png').write_bytes(png)
                report={'status':'PASS','inputs':list(profiles),'current_edited_rows':tables,
                        'original_records':records,'prefix':prefix,'suffix':suffix,'suffix_offset':offset,
                        'overlap':overlap,'password':password,'recovered_file':str(out/'receipts.png')}
                (out/'recovery.json').write_text(json.dumps(report,indent=2)+'\n')
                return report
    raise ValueError('No complementary, attributable remnants recovered the archive')


def main():
    ap=argparse.ArgumentParser();ap.add_argument('bundle',type=Path);ap.add_argument('--out',type=Path,default=Path('recovered'));args=ap.parse_args()
    report=recover(args.bundle,args.out)
    print(json.dumps(report,indent=2));print('Open the recovered receipts.png to read the reward.')

if __name__=='__main__':main()
