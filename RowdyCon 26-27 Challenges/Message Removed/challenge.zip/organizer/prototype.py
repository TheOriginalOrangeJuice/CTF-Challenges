"""Prove complementary SQLite remnants using SQL alone; no byte patching."""
import json
import sqlite3
from pathlib import Path

PASSWORD = "H7vQ3mZ8rT2xK6pN9sW4cF5jL1dB0yUa"
SCHEMA = "CREATE TABLE Messages(id INTEGER PRIMARY KEY, guid BLOB, chatname TEXT, timestamp INTEGER, author TEXT, body_xml TEXT, edited_timestamp INTEGER)"


def base():
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA page_size=4096")
    db.execute("PRAGMA secure_delete=OFF")
    db.execute("PRAGMA auto_vacuum=NONE")
    db.execute(SCHEMA)
    # An ordinary long quoted group conversation occupies one leaf page.
    quote = ("Jess: that microphone has more excuses than you do.\n"
             "Ravi: the scoreboard does not have a mute button.\n"
             "Max: ONE bad round and suddenly everyone is a historian.\n")
    body = "receipts.zip password: " + PASSWORD + "\n<quote>" + (quote * 24)[:3300] + "</quote>"
    db.execute("INSERT INTO Messages VALUES(?,?,?,?,?,?,?)", (
        417, bytes.fromhex("11002200330044005500660077008800"),
        "#after-school/$reunion;2013", 1370982300, "max.power.97", body, 0))
    db.commit()
    before = db.serialize()
    at = before.index(PASSWORD.encode())
    db.execute("DELETE FROM Messages")
    db.execute("DROP TABLE Messages")
    db.execute("CREATE TABLE DbMeta(id INTEGER PRIMARY KEY, value)")
    assert db.execute("SELECT rootpage FROM sqlite_master WHERE name='DbMeta'").fetchone()[0] == 2
    return db, at, before


def main():
    found = {}
    for side in ("prefix", "suffix"):
        for n in range(1, 4000):
            db, at, before = base()
            if side == "prefix":
                db.execute("INSERT INTO DbMeta VALUES(1,?)", ("cache:" + "x" * n,))
            else:
                db.executemany("INSERT INTO DbMeta VALUES(?,0)", ((i,) for i in range(1, n + 1)))
            db.commit()
            raw = db.serialize()
            same = [raw[at+i:at+i+1] == bytes([c]) for i,c in enumerate(PASSWORD.encode())]
            if side == "prefix":
                good = all(same[:20]) and not any(same[20:])
            else:
                good = not any(same[:12]) and all(same[12:])
            if good and PASSWORD.encode() not in raw:
                found[side] = {"n": n, "password_offset": at, "relative_offset": at % 4096,
                               "survives": "".join(c if s else "." for c,s in zip(PASSWORD,same)),
                               "integrity": db.execute("PRAGMA integrity_check").fetchone()[0],
                               "database_size": len(raw)}
                print(json.dumps({side: found[side]}), flush=True)
                db.close()
                break
            db.close()
        else:
            print(json.dumps({side: "NOT FOUND"}), flush=True)
    print(json.dumps({"sqlite_version": sqlite3.sqlite_version, "result": found}, indent=2))


if __name__ == "__main__":
    main()
