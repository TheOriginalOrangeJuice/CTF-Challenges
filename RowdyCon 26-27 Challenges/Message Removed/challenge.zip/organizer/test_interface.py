"""Ordinary UI/audio checks only. Run in Condev against the local review service.
Test-only browser instrumentation measures the actual post-volume Web Audio signal.
No vulnerability probing, unauthorized access, or forensic recovery is performed.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time
from datetime import datetime, timezone
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parents[1]
KEY = 'message-removed.skype.v1'
PROBE = r"""(() => {
  const Native = window.AudioContext;
  window.__soundProbe = {contexts:[], sources:[], analysers:[]};
  window.AudioContext = class extends Native {
    constructor(...args) {super(...args);window.__soundProbe.contexts.push(this);}
    createGain() {
      const gain=super.createGain(), analyser=super.createAnalyser();
      analyser.fftSize=2048;gain.connect(analyser);window.__soundProbe.analysers.push(analyser);
      return gain;
    }
    createBufferSource() {
      const source=super.createBufferSource(), record={source,started:false,stopped:false};
      const start=source.start.bind(source),stop=source.stop.bind(source);
      source.start=(...args)=>{record.started=true;start(...args);};
      source.stop=(...args)=>{record.stopped=true;stop(...args);};
      source.addEventListener('ended',()=>record.stopped=true);
      window.__soundProbe.sources.push(record);return source;
    }
  };
})();"""

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--url',default='http://host.docker.internal:18111')
    ap.add_argument('--incoming-only',action='store_true')
    args=ap.parse_args()
    shots=ROOT/'screenshots';shots.mkdir(exist_ok=True)
    results=ROOT/'organizer/results';results.mkdir(exist_ok=True)
    report={'status':'RUNNING','scope':'Normal interface, session, audio, layout and advertised download checks',
            'tests':[], 'audio':{}, 'console_errors':[], 'screenshots':[],
            'security_probing':'excluded by user', 'independent_human_playtesting':False,
            'independent_human_listening':False}
    if args.incoming_only:
        report=json.loads((results/'interface.json').read_text())
        report.pop('failure',None);report['status']='RUNNING'
    def passed(name):
        report['tests'].append(name);print('PASS '+name,flush=True)
    def shot(page,name):
        page.screenshot(path=str(shots/name));report['screenshots'].append('screenshots/'+name)
    def state(page):return page.evaluate('(key)=>JSON.parse(sessionStorage.getItem(key))',KEY)
    def choose(page,who):page.locator(f'#contact-list [data-contact={who}]').click()
    def send(page,text):page.locator('#message-input').fill(text);page.locator('#message-input').press('Enter')
    def menu(page,name,item):page.locator(f'[data-menu={name}]').click();page.locator('#popup').get_by_role('button',name=item,exact=True).click()
    def peak(page):
        values=[]
        for _ in range(35):
            values.append(page.evaluate('''() => Math.max(0,...window.__soundProbe.analysers.map(a=>{
              const b=new Float32Array(a.fftSize);a.getFloatTimeDomainData(b);
              return Math.sqrt(b.reduce((s,x)=>s+x*x,0)/b.length);
            }))'''));time.sleep(.035)
        return max(values)
    def ringing(page,label):
        # Allow network decode and the real AudioContext to run independently of the controlled UI clock.
        for _ in range(40):
            if page.evaluate('() => window.__soundProbe.sources.some(r=>r.started&&!r.stopped&&r.source.loop)'):break
            time.sleep(.05)
        value=peak(page);report['audio'][label]={'peak_window_rms':value};assert value>0.0001,(label,value)
    def silent(page,label):
        time.sleep(.12)
        active=page.evaluate('() => window.__soundProbe.sources.filter(r=>r.started&&!r.stopped&&r.source.loop).length')
        value=peak(page);report['audio'][label]={'active_loop_sources':active,'peak_window_rms':value}
        assert active==0 and value<0.00001,(label,active,value)
    def new_page(browser,random=.99,viewport=None,reduced=False):
        context=browser.new_context(viewport=viewport or {'width':1366,'height':768},reduced_motion='reduce' if reduced else 'no-preference',accept_downloads=True)
        context.add_init_script(PROBE+f'\nMath.random=()=>{random};')
        page=context.new_page()
        page.on('pageerror',lambda e:report['console_errors'].append(str(e)))
        page.on('console',lambda m:report['console_errors'].append(m.text) if m.type=='error' else None)
        page.clock.install(time=datetime(2026,10,27,16,40,tzinfo=timezone.utc))
        page.goto(args.url);page.locator('#messages .message').first.wait_for()
        page.clock.pause_at(datetime.fromtimestamp((page.evaluate('Date.now()')+1000)/1000,timezone.utc))
        return page
    def advance(page,ms):page.clock.run_for(ms)
    def incoming(browser):
        page=new_page(browser,random=0)
        # No incoming call before deliberate interaction, even after eligible-looking wall time.
        advance(page,61000);expect(page.locator('#call-panel')).to_be_hidden()
        page.locator('#message-input').click();advance(page,29900)
        expect(page.locator('#call-panel')).to_be_hidden();advance(page,200)
        expect(page.locator('#call-status')).to_have_text('Incoming call…')
        return page
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium-browser',args=['--no-sandbox'])
            if not args.incoming_only:
                page=new_page(browser)
                health=page.request.get(args.url+'/healthz');assert health.ok
                before={name:hashlib.sha256(page.request.get(args.url+'/evidence/'+name).body()).hexdigest() for name in ['skype-backups.zip']}
                for name,digest in before.items():assert digest==hashlib.sha256((ROOT/'challenge/public/evidence'/name).read_bytes()).hexdigest()
                advance(page,100)
                with page.expect_download() as download:page.locator('.attachment a').first.click()
                assert download.value.suggested_filename=='skype-backups.zip'
                assert page.locator('#saved-link,#history-toolbar,.objective,.desktop-caption').count()==0
                for phrase in ['Save backups','Saved histories','Submit the flag','a little older. still online.']:
                    assert phrase not in page.locator('body').inner_text()
                shot(page,'01-reunion-1366.png');passed('Ordinary group file transfer; removed CTF guidance and embedded history controls')
                page.set_viewport_size({'width':1920,'height':1080});shot(page,'02-reunion-1920.png')
                for size in [{'width':1366,'height':768},{'width':1920,'height':1080}]:
                    page.set_viewport_size(size)
                    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
                    for selector in ['#composer','#sound-toggle','#reset']:
                        b=page.locator(selector).bounding_box();assert b and b['y']>=0 and b['y']+b['height']<=size['height']
                page.set_viewport_size({'width':1366,'height':768});passed('Both desktop sizes keep primary controls within the viewport')
                choose(page,'max');send(page,'hey');advance(page,999);expect(page.locator('#typing')).to_be_empty()
                advance(page,101);expect(page.locator('#typing')).to_have_text('Max is typing…');advance(page,2899)
                assert len(state(page)['conversations']['max'])==2
                advance(page,101);assert len(state(page)['conversations']['max'])==3
                passed('Typing and authored reply appear at one and four seconds')
                # All authored subjects through the actual composer for every responder.
                for person in ['max','jess','ravi']:
                    choose(page,person)
                    for text in ['Saturday reunion','one more game','receipts','interesting']+([] if person=='max' else ['hey']):
                        send(page,text);advance(page,4100)
                        assert state(page)['conversations'][person][-1]['who']==person
                passed('All fifteen responder/topic combinations through the interface')
                choose(page,'jess');send(page,'hi');send(page,'Saturday');send(page,'Max')
                assert len(state(page)['pending'])==1
                advance(page,4100);assert state(page)['conversations']['jess'][-1]['who']=='jess'
                choose(page,'sam');send(page,'hello');choose(page,'ollie');send(page,'hello');advance(page,4100)
                assert not state(page)['pending']
                assert state(page)['conversations']['sam'][-1]['who']=='you' and state(page)['conversations']['ollie'][-1]['who']=='you'
                passed('Burst coalescing and both silent contacts')
                choose(page,'max');send(page,'reunion');choose(page,'ravi')
                page.locator('#message-input').fill('keep this draft');page.locator('#message-input').press('Shift+Enter');page.locator('#message-input').press('a')
                draft=page.locator('#message-input').input_value();assert '\n' in draft
                advance(page,4100);expect(page.locator('#message-input')).to_be_focused()
                expect(page.locator('[data-contact=max] .badge')).to_have_text('1')
                choose(page,'jess');choose(page,'ravi');expect(page.locator('#message-input')).to_have_value(draft)
                page.reload();expect(page.locator('#message-input')).to_have_value(draft)
                expect(page.locator('[data-contact=max] .badge')).to_have_text('1')
                choose(page,'max');expect(page.locator('[data-contact=max] .badge')).to_be_hidden()
                send(page,'game');advance(page,1100);page.reload();advance(page,3100)
                assert state(page)['conversations']['max'][-1]['who']=='max'
                passed('Drafts, Shift+Enter, focus, unread badges and pending replies survive navigation/reload')
                page.locator('#search').fill('router');expect(page.locator('[data-contact=ollie]')).to_be_visible()
                page.locator('#clear-search').click();page.locator('#contacts-tab').click();page.locator('#recent-tab').click()
                choose(page,'jess');page.locator('#header-profile').click();expect(page.locator('#dialog-content')).to_contain_text('jess.flower')
                page.keyboard.press('Escape');expect(page.locator('#header-profile')).to_be_focused()
                page.locator('.message-time').first.click();expect(page.locator('#dialog-title')).to_have_text('Message details');page.keyboard.press('Escape')
                page.locator('#message-input').fill('nice ');page.locator('#emoticons').click();page.locator('#popup').get_by_role('button',name=':)',exact=True).click()
                expect(page.locator('#message-input')).to_have_value('nice :)')
                with page.expect_download() as export:menu(page,'conversation','Save conversation…')
                assert export.value.suggested_filename=='jess-conversation.txt'
                choose(page,'group');page.get_by_role('button',name='Preview',exact=True).click()
                expect(page.locator('#dialog-content img')).to_be_visible();page.keyboard.press('Escape')
                page.locator('#picture-input').set_input_files(str(results/'recovered/receipts.png'))
                expect(page.locator('#dialog-content img')).to_be_visible();shot(page,'05-recovered-receipt.png');page.keyboard.press('Escape')
                passed('Search, tabs, profiles, details, emoticons, chat export and image previews')
                for menu_name in ['skype','contacts','conversation','call','view','tools','help']:
                    page.locator(f'[data-menu={menu_name}]').click();expect(page.locator('#popup')).to_be_visible();page.keyboard.press('ArrowDown');page.keyboard.press('Escape')
                menu(page,'help','About Skype');expect(page.locator('#dialog-content')).to_contain_text('Skype/Microsoft');page.keyboard.press('Escape')
                page.locator('#minimize').click();expect(page.locator('#window')).to_be_hidden();page.locator('#restore-window').click()
                page.locator('#maximize').click();assert 'maximized' in page.locator('#window').get_attribute('class');page.locator('#maximize').click()
                page.keyboard.press('Control+f');expect(page.locator('#search')).to_be_focused()
                assert page.locator('.search-box').evaluate('(e)=>getComputedStyle(e).borderTopColor')=='rgb(5, 156, 218)'
                passed('Menus, window controls, keyboard navigation and visible focus')
                # Every contact accepts an outgoing call; none answers.
                for person in ['max','jess','ravi','sam','ollie']:
                    choose(page,person);page.locator('#call-button').click();expect(page.locator('#call-status')).to_have_text('Calling…')
                    expect(page.locator('#call-button')).to_be_disabled()
                    if person=='max':
                        ringing(page,'outgoing');shot(page,'06-outgoing-call.png')
                        choose(page,'jess');expect(page.locator('#call-person')).to_have_text('Max')
                        page.locator('#sound-toggle').click();time.sleep(.1);assert peak(page)<0.00001
                        page.locator('#sound-toggle').click();ringing(page,'outgoing_unmuted')
                        page.locator('#volume').fill('0');time.sleep(.12);assert peak(page)<0.00001
                        page.locator('#volume').fill('40')
                    page.locator('#end-call').click();expect(page.locator('#call-status')).to_have_text('Call canceled')
                    silent(page,'hangup_'+person);page.locator('#dismiss-call').click()
                passed('All five outgoing calls, one-call rule, navigation, mute, volume and immediate hang-up silence')
                choose(page,'max');page.locator('#call-button').click();advance(page,44900)
                expect(page.locator('#call-status')).to_have_text('Calling…');ringing(page,'outgoing_at_44_9_seconds')
                advance(page,100);expect(page.locator('#call-status')).to_have_text('No answer');silent(page,'outgoing_timeout')
                menu(page,'call','Call history');expect(page.locator('#dialog-content')).to_contain_text('No answer');page.keyboard.press('Escape')
                page.locator('#dismiss-call').click();page.locator('#call-button').click();page.reload();expect(page.locator('#call-panel')).to_be_hidden();silent(page,'reload')
                assert state(page)['callLog'][-1]['result']=='Call interrupted'
                page.locator('#call-button').click();page.locator('#close-window').click();silent(page,'window_close');page.locator('#restore-window').click()
                page.locator('#reset').click();expect(page.locator('#dialog-title')).to_have_text('Reset this session?')
                page.get_by_role('button',name='Keep chatting',exact=True).click();assert state(page)['hasChanges']
                page.locator('#reset').click();page.locator('#dialog-actions').get_by_role('button',name='Reset session',exact=True).click();assert not state(page)['hasChanges']
                passed('45-second no-answer, call history, reload interruption, window close and reset confirmation')
                # Measure the short message cue from the actual output graph.
                choose(page,'jess');send(page,'hey');advance(page,4000)
                value=peak(page);report['audio']['message']={'peak_window_rms':value};assert value>0.0001
                passed('Message notification produces a real non-silent output signal')
                # Eligible minutes with a losing random draw produce no incoming calls.
                advance(page,180000);assert not state(page)['incomingUsed'];passed('Nonoccurrence with controlled randomness over three eligible minutes')
                after={name:hashlib.sha256(page.request.get(args.url+'/evidence/'+name).body()).hexdigest() for name in before}
                assert after==before;report['evidence_hashes']=after;passed('Normal interactions leave downloadable evidence bytes unchanged')
                page.context.close()
            page=incoming(browser);ringing(page,'incoming');shot(page,'07-incoming-call.png')
            page.locator('#answer-call').click();expect(page.locator('#call-status')).to_have_text('Connected');silent(page,'answer')
            advance(page,249);expect(page.locator('#call-status')).to_have_text('Connected');advance(page,1)
            expect(page.locator('#call-status')).to_have_text('Call dropped');silent(page,'drop')
            assert 'Incoming call from Max' in state(page)['conversations']['group'][-1]['text']
            advance(page,180000);assert len(state(page)['callLog'])==1
            page.reload();page.locator('#message-input').click();advance(page,180000);assert len(state(page)['callLog'])==1
            page.locator('#reset').click();page.locator('#dialog-actions').get_by_role('button',name='Reset session',exact=True).click()
            page.locator('#message-input').click();advance(page,61000);assert state(page)['incomingUsed'] and not state(page)['callLog']
            passed('Incoming answer/drop at 250ms; current-chat event; one-call allowance survives reload and reset')
            page.context.close()
            page=incoming(browser);page.locator('#end-call').click();expect(page.locator('#call-status')).to_have_text('Call declined');silent(page,'decline');page.context.close()
            page=incoming(browser);remaining=state(page)['call']['deadline']-page.evaluate('Date.now()')
            advance(page,remaining-1);expect(page.locator('#call-status')).to_have_text('Incoming call…');advance(page,101)
            expect(page.locator('#call-status')).to_have_text('Missed call');silent(page,'missed');page.context.close()
            page=incoming(browser);page.locator('#reset').click();page.locator('#dialog-actions').get_by_role('button',name='Reset session',exact=True).click();silent(page,'reset');page.context.close()
            page=incoming(browser);page.goto('about:blank');assert page.url=='about:blank';page.context.close()
            passed('Incoming decline, 20-second missed timeout, reset and page disposal')
            page=new_page(browser,random=0,reduced=True)
            menu(page,'help','About Skype');advance(page,120000);expect(page.locator('#call-panel')).to_be_hidden();page.keyboard.press('Escape')
            advance(page,29900);expect(page.locator('#call-panel')).to_be_hidden();advance(page,200);expect(page.locator('#call-panel')).to_be_visible()
            assert page.evaluate("matchMedia('(prefers-reduced-motion: reduce)').matches")
            assert page.locator('#window').evaluate('(e)=>getComputedStyle(e).animationName')=='none'
            passed('Blocking dialogs pause eligible time; reduced-motion setting is respected')
            page.context.close();browser.close()
        assert not report['console_errors'],report['console_errors']
        report['status']='PASS'
    except Exception as exc:
        report['status']='FAIL';report['failure']=str(exc)
        raise
    finally:
        (results/'interface.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()
