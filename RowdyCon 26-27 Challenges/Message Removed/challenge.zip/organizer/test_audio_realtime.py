"""Actual 45-second browser playback check, with no clock acceleration."""
import json
import argparse
import time
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
from test_interface import PROBE

ROOT=Path(__file__).resolve().parents[1]
MEASURE='''() => ({active:window.__soundProbe.sources.filter(r=>r.started&&!r.stopped&&r.source.loop).length,
 rms:Math.max(0,...window.__soundProbe.analysers.map(a=>{const b=new Float32Array(a.fftSize);a.getFloatTimeDomainData(b);return Math.sqrt(b.reduce((s,x)=>s+x*x,0)/b.length);})),
 state:window.__soundProbe.contexts.map(c=>c.state)})'''
DISPOSAL='''() => addEventListener('pagehide',()=>sessionStorage.setItem('__audio_disposal',JSON.stringify({
 active:window.__soundProbe.sources.filter(r=>r.started&&!r.stopped&&r.source.loop).length
})))'''

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--disposal-only',action='store_true');args=ap.parse_args()
    report={'status':'RUNNING','clock':'real wall time; no accelerated or mocked timers',
            'five_second_windows':[], 'disposal':[], 'human_listening':False}
    if args.disposal_only:
        report=json.loads((ROOT/'organizer/results/audio-realtime.json').read_text())
        assert len(report['five_second_windows'])==9 and 'timeout' in report
        report.pop('failure',None);report['status']='RUNNING';report['disposal']=[]
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path='/usr/bin/chromium-browser',args=['--no-sandbox'])
            page=browser.new_page(viewport={'width':1366,'height':768})
            page.add_init_script(PROBE+'\nMath.random=()=>0.99;')
            page.goto('http://host.docker.internal:18111')
            page.locator('[data-contact=max]').click();page.locator('#call-button').click()
            started=time.monotonic();buckets=[0.0]*9
            while not args.disposal_only and time.monotonic()-started<45:
                elapsed=time.monotonic()-started;sample=page.evaluate(MEASURE)
                if elapsed<44.8:assert page.locator('#call-status').inner_text()=='Calling…'
                buckets[min(8,int(elapsed//5))]=max(buckets[min(8,int(elapsed//5))],sample['rms'])
                time.sleep(.08)
            if not args.disposal_only:
                expect(page.locator('#call-status')).to_have_text('No answer',timeout=2000)
                time.sleep(.15);end=page.evaluate(MEASURE)
                for i,value in enumerate(buckets):
                    report['five_second_windows'].append({'start_s':i*5,'end_s':(i+1)*5,'maximum_rms':value})
                    assert value>0.0001,(i,value)
                assert end['active']==0 and end['rms']<0.00001,end
                log=page.evaluate("JSON.parse(sessionStorage.getItem('message-removed.skype.v1')).callLog.at(-1)")
                assert 45000<=log['ringingMs']<45500,log
                report['timeout']={'logged_ringing_ms':log['ringingMs'],'wall_elapsed_seconds':time.monotonic()-started,'signal_after_timeout':end}
                print('PASS real outgoing sound over all nine five-second windows and no-answer silence',flush=True)
                page.locator('#dismiss-call').click();page.locator('#call-button').click()
            time.sleep(.4)
            assert page.evaluate(MEASURE)['active']==1
            page.evaluate(DISPOSAL);page.reload()
            report['disposal'].append(page.evaluate("JSON.parse(sessionStorage.getItem('__audio_disposal'))"));assert report['disposal'][-1]['active']==0
            page.locator('#call-button').click();time.sleep(.4);assert page.evaluate(MEASURE)['active']==1
            page.evaluate(DISPOSAL);page.goto('http://host.docker.internal:18111/wallpaper.svg')
            report['disposal'].append(page.evaluate("JSON.parse(sessionStorage.getItem('__audio_disposal'))"));assert report['disposal'][-1]['active']==0
            print('PASS source stops during reload and page disposal',flush=True)
            browser.close()
        report['status']='PASS'
    except Exception as e:
        report['status']='FAIL';report['failure']=str(e);raise
    finally:(ROOT/'organizer/results/audio-realtime.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()
