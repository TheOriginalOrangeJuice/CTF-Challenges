"""Packaging/document parity and normal asset fetches; no security probes."""
import hashlib
import json
from pathlib import Path
import urllib.request
import zipfile
from docx import Document

ROOT=Path(__file__).resolve().parents[1]
sha=lambda data:hashlib.sha256(data).hexdigest()
public=ROOT/'challenge/public'
assets={}
for file in sorted(public.rglob('*')):
    if not file.is_file():continue
    relative=file.relative_to(public).as_posix()
    path='/' if relative=='index.html' else '/'+relative
    raw=urllib.request.urlopen('http://host.docker.internal:18111'+path).read()
    assert sha(raw)==sha(file.read_bytes()),relative
    assets[relative]=sha(raw)
with zipfile.ZipFile(public/'evidence/skype-backups.zip') as z:
    expected=json.loads((ROOT/'organizer/results/profile-packaging.json').read_text())['members']
    assert set(z.namelist())==set(expected)
    for name,digest in expected.items():assert sha(z.read(name))==digest
    assert {name.split('/')[0] for name in z.namelist()}=={'Jess-laptop','Ravi-netbook'}
doc=Document(ROOT/'Description.docx')
assert len(doc.tables)==1
labels=[row.cells[0].text for row in doc.tables[0].rows]
assert labels==['Description','Files','Hint(s)','Walkthrough','Flag'],labels
assert doc.tables[0].rows[2].cells[1].text.strip()=='None'
docreport=json.loads((ROOT/'organizer/document-review/document-check.json').read_text())
with zipfile.ZipFile(ROOT/'Description.docx') as z:
    embedded={sha(z.read(name)) for name in z.namelist() if name.startswith('word/media/')}
assert embedded=={sha((ROOT/name).read_bytes()) for name in docreport['images']}
manifest={file.relative_to(ROOT).as_posix():sha(file.read_bytes()) for file in sorted(ROOT.rglob('*'))
          if file.is_file() and '__pycache__' not in file.parts and file.name not in ('handoff.json','final-manifest.json','source-parity.json')}
(ROOT/'organizer/results/final-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
report={'status':'PASS','scope':'Normal public asset byte parity, two-profile bundle contents, document structure and embedded screenshot parity',
        'public_assets':assets,'manifest_files':len(manifest),'document_pages':docreport['pages'],
        'document_sections':labels,'security_checks':'excluded by user; no unadvertised paths requested',
        'forensic_recovery':'not rerun in this pass'}
(ROOT/'organizer/results/handoff.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','public_assets':len(assets),'manifest_files':len(manifest),'document_pages':docreport['pages']},indent=2))
