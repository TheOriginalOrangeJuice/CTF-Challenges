"""Acquire and freeze the user-requested classic Skype sounds inside Condev."""
import hashlib
import json
import subprocess
import argparse
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE_URL = "https://mtm.ufsc.br/~krukoski/pub/linux/skype-4.3.0.37.tar"
SOURCES = {"outgoing":"CallRingingOut.wav", "incoming":"CallRingingIn.wav", "message":"ChatIncoming.wav"}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--archive",type=Path)
    args=ap.parse_args()
    originals=ROOT/"organizer"/"audio-sources"; originals.mkdir(parents=True,exist_ok=True)
    public=ROOT/"challenge"/"public"/"audio"; public.mkdir(parents=True,exist_ok=True)
    result=[]
    archive=tarfile.open(args.archive) if args.archive else None
    for name,member in SOURCES.items():
        source=originals/member
        if not source.exists():
            if archive is None: raise RuntimeError("Supply --archive or retain the frozen original WAV files")
            source.write_bytes(archive.extractfile("skype-4.3.0.37/sounds/"+member).read())
        dest=public/(name+".wav")
        subprocess.run(["ffmpeg","-v","error","-y","-i",str(source),"-map_metadata","-1","-ac","1","-ar","44100","-c:a","pcm_s16le",str(dest)],check=True)
        probe=json.loads(subprocess.check_output(["ffprobe","-v","error","-show_format","-of","json",str(dest)]))
        result.append({"name":name,"source_url":SOURCE_URL,"archive_member":"skype-4.3.0.37/sounds/"+member,
                       "original_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),
                       "frozen_sha256":hashlib.sha256(dest.read_bytes()).hexdigest(),
                       "duration":float(probe["format"]["duration"]),"bytes":dest.stat().st_size})
    if archive:
        for filename in ("LICENSE","third-party_attributions.txt"):
            (originals/filename).write_bytes(archive.extractfile("skype-4.3.0.37/"+filename).read())
        archive.close()
    report={"assets":result,"transformation":"Convert original Skype 4.3 WAV assets to mono 44100 Hz PCM WAV; remove container metadata; no compositional substitution.",
            "ownership":"Skype/Microsoft UI recordings, extracted without executing the original software, at the user's request. Original notices retained. No open-source license is asserted.",
            "transport_note":"The public mirror's certificate chain was untrusted by Condev; this credential-free acquisition used curl --insecure. Exact original and final hashes are recorded. Full software is not distributed.",
            "independent_human_listening":False,"acquisition_status":"complete"}
    (ROOT/"organizer"/"audio-provenance.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps(result,indent=2))

if __name__=="__main__": main()
