"""Test-only visibility transitions; does not claim a physical background-tab test."""
import json
from datetime import datetime, timezone
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium-browser',args=['--no-sandbox'])
    page=browser.new_page()
    page.add_init_script("Math.random=()=>0;window.__hidden=false;Object.defineProperty(document,'hidden',{get:()=>window.__hidden});")
    page.clock.install(time=datetime(2026,10,27,16,40,tzinfo=timezone.utc))
    page.goto('http://host.docker.internal:18111');page.locator('#message-input').wait_for()
    page.clock.pause_at(datetime.fromtimestamp((page.evaluate('Date.now()')+1000)/1000,timezone.utc))
    page.locator('#message-input').click();page.clock.run_for(15000)
    page.evaluate("window.__hidden=true;document.dispatchEvent(new Event('visibilitychange'))")
    before=page.evaluate("JSON.parse(sessionStorage.getItem('message-removed.skype.v1')).eligibleMs")
    page.clock.run_for(180000)
    during=page.evaluate("JSON.parse(sessionStorage.getItem('message-removed.skype.v1')).eligibleMs")
    assert before==during and 14000<before<=15000,(before,during)
    expect(page.locator('#call-panel')).to_be_hidden()
    page.evaluate("window.__hidden=false;document.dispatchEvent(new Event('visibilitychange'))")
    page.clock.run_for(14900);expect(page.locator('#call-panel')).to_be_hidden()
    page.clock.run_for(300);expect(page.locator('#call-status')).to_have_text('Incoming call…')
    browser.close()
report={'status':'PASS','method':'Test-only document.hidden override and visibilitychange events with controlled clock/randomness',
        'eligible_ms_before_hidden':before,'eligible_ms_after_180s_hidden':during,
        'background_backlog':False,'physical_background_tab_test':False}
(ROOT/'organizer/results/visibility.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
