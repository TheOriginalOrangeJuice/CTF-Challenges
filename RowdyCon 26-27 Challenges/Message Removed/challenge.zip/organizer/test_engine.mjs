import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {freshState,send,tick,beginCall,endCall,answerCall,recoverState,REPLIES,topic} from '../challenge/public/engine.js';
const passed=[];
function test(name,fn){fn();passed.push(name);}
test('Responding contacts, each topic, one-second typing and four-second replies',()=>{
  for(const person of ['max','jess','ravi'])for(const [text,branch]of [['hey','greeting'],['Saturday reunion','reunion'],['one more game','gaming'],['receipts','dispute'],['interesting','fallback']]){
    const s=freshState();s.selected=person;const count=s.conversations[person].length;
    send(s,person,text,1000);tick(s,1999,0,false);assert.equal(s.pending[person].typing,false);
    tick(s,2000,0,false);assert.equal(s.pending[person].typing,true);tick(s,4999,0,false);assert.equal(s.conversations[person].length,count+1);
    tick(s,5000,0,false);assert.equal(s.conversations[person].at(-1).text,REPLIES[person][branch][0]);assert.equal(Object.keys(s.pending).length,0);
  }
});
test('Burst messages coalesce without extending the deadline or duplicating replies',()=>{
  const s=freshState();send(s,'jess','hello',0);send(s,'jess','reunion',2000);send(s,'jess','Max',3000);
  assert.equal(s.pending.jess.due,4000);tick(s,4000,0,false);assert.equal(s.conversations.jess.at(-1).text,REPLIES.jess.dispute[0]);
  const count=s.conversations.jess.length;tick(s,9000,0,false);assert.equal(s.conversations.jess.length,count);
});
test('Silent contacts remain silent; authored response pools never repeat',()=>{
  const s=freshState();send(s,'sam','hello',0);send(s,'ollie','hello',0);assert.equal(Object.keys(s.pending).length,0);
  const replies=[];for(let i=0;i<5;i++){send(s,'ravi','hello',i*5000);tick(s,i*5000+4000,0,false);const m=s.conversations.ravi.at(-1);if(m.who==='ravi')replies.push(m.text);}
  assert.deepEqual(replies,REPLIES.ravi.greeting);
});
test('Outgoing calls never connect and end exactly at 45 seconds',()=>{
  const s=freshState();beginCall(s,'max','outgoing',1000);assert.equal(beginCall(s,'jess','outgoing',2000),false);
  tick(s,45999,0,false);assert.equal(s.call.phase,'ringing');tick(s,46000,0,false);assert.equal(s.call.result,'No answer');assert.equal(s.callLog.length,1);
  tick(s,49000,0,false);assert.equal(s.callLog.length,1);
});
test('Answering an incoming call drops after exactly 250ms',()=>{
  const s=freshState();beginCall(s,'max','incoming',0);assert.equal(s.incomingUsed,true);answerCall(s,1000);
  tick(s,1249,0,false);assert.equal(s.call.phase,'connected');tick(s,1250,0,false);assert.equal(s.call.result,'Call dropped');assert.equal(s.callLog[0].duration,0);
});
test('Incoming decline and twenty-second missed-call timeout',()=>{
  const s=freshState();beginCall(s,'max','incoming',0);tick(s,19999,0,false);assert.equal(s.call.phase,'ringing');tick(s,20000,0,false);assert.equal(s.call.result,'Missed call');
  const t=freshState();beginCall(t,'max','incoming',0);endCall(t,'Call declined',4000);assert.equal(t.callLog[0].result,'Call declined');
});
test('Five percent draw per thirty eligible seconds and one-call allowance',()=>{
  const s=freshState();for(let i=0;i<60;i++)tick(s,i*1000,1000,false,()=>0);assert.equal(s.eligibleMs,0);
  for(let i=0;i<30;i++)tick(s,i*1000,1000,true,()=>0.05);assert.equal(s.call,null);
  for(let i=0;i<29;i++)tick(s,i*1000,1000,true,()=>0.049);assert.equal(s.call,null);
  tick(s,59000,1000,true,()=>0.049);assert.equal(s.call.kind,'incoming');
  endCall(s,'Call declined',60000);for(let i=0;i<600;i++)tick(s,61000+i*1000,1000,true,()=>0);assert.equal(s.callLog.length,1);
});
test('Reload preserves drafts, pending replies and consumed incoming allowance; interrupts calls',()=>{
  const s=freshState();s.drafts.jess='unfinished';send(s,'max','hello',1000);beginCall(s,'max','incoming',1200);
  const restored=recoverState(JSON.stringify(s),2000);assert.equal(restored.drafts.jess,'unfinished');assert.equal(restored.incomingUsed,true);assert.equal(restored.call,null);assert.equal(restored.callLog[0].result,'Call interrupted');
  tick(restored,5000,0,false);assert.equal(restored.conversations.max.at(-1).text,REPLIES.max.greeting[0]);
});
test('Corrupt saved state recovers; literal message content and empty sends',()=>{
  const s=recoverState('broken',0);assert.equal(s.selected,'group');assert.equal(send(s,'max','   ',0),false);
  send(s,'max','<b>literal text</b>',0);assert.equal(s.conversations.max.at(-1).text,'<b>literal text</b>');
});
test('Jess has one pending reply across group and private messages',()=>{
  const s=freshState();send(s,'group','hello',0);send(s,'jess','reunion',1000);
  assert.equal(Object.keys(s.pending).length,1);assert.equal(s.pending.jess.due,4000);
  tick(s,4000,0,false);assert.equal(s.conversations.jess.at(-1).text,REPLIES.jess.reunion[0]);
});
test('Incoming calls are recorded in the conversation open when they arrive',()=>{
  const s=freshState();s.selected='ravi';beginCall(s,'max','incoming',0);s.selected='jess';
  endCall(s,'Missed call',20000);assert.match(s.conversations.ravi.at(-1).text,/Max/);assert.equal(s.unread.ravi,1);
});
test('Legacy sessions lose retired history mode without discarding player drafts or messages',()=>{
  const s=freshState();s.version=1;s.mode='history';s.history='ravi';s.drafts.max='unfinished';s.incomingUsed=true;
  s.conversations.group=[...Array.from({length:9},()=>({who:'jess',text:'retired starting copy',at:0})),{who:'you',text:'my message',at:1}];
  const restored=recoverState(JSON.stringify(s),1000);
  assert.equal(restored.version,2);assert.equal(restored.mode,'live');assert.equal(restored.history,undefined);
  assert.equal(restored.drafts.max,'unfinished');assert.equal(restored.incomingUsed,true);assert.equal(restored.conversations.group.at(-1).text,'my message');
  assert.ok(!restored.conversations.group.some(m=>m.text==='retired starting copy'));
});
const report={status:'PASS',scope:'Authored conversation and call state logic, revised probability and legacy-session migration',tests:passed};
if(process.argv[2])writeFileSync(process.argv[2],JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
