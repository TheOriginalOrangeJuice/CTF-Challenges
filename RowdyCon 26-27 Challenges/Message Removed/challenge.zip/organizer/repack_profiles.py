"""Repackage the frozen evidence as two laptop folders, with no public inventory.

Only ZIP paths and packaging change. Database and encrypted receipt bytes remain
identical. This maintenance step does not regenerate or recover forensic records.
"""
import hashlib
import io
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parents[1]
bundle=ROOT/'challenge/public/evidence/skype-backups.zip'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
before=sha(bundle.read_bytes())
with zipfile.ZipFile(bundle) as z:
    databases={name:z.read(name) for name in z.namelist() if name.endswith('/main.db')}
    archive=z.read(next(name for name in z.namelist() if name.endswith('/receipts.zip')))
assert set(databases)=={'Jess-laptop/Skype/jess.flower/main.db','Ravi-netbook/Skype/ravi.exe/main.db'}
members={**databases,'Jess-laptop/Downloads/receipts.zip':archive,'Ravi-netbook/Downloads/receipts.zip':archive}
out=io.BytesIO()
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,raw in sorted(members.items()):
        item=zipfile.ZipInfo(name,(2026,10,27,12,0,0));item.compress_type=zipfile.ZIP_DEFLATED;item.external_attr=0o100644<<16
        z.writestr(item,raw)
bundle.write_bytes(out.getvalue())
with zipfile.ZipFile(bundle) as z:
    for name,raw in members.items():assert z.read(name)==raw
report={'status':'PASS','scope':'Packaging only; frozen database and encrypted receipt bytes preserved',
        'before_sha256':before,'after_sha256':sha(bundle.read_bytes()),
        'members':{name:sha(raw) for name,raw in members.items()},'inventory_in_download':False}
(ROOT/'organizer/results/profile-packaging.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
