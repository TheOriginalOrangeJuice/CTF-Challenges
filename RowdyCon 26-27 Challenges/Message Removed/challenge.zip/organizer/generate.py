"""Deterministic synthetic Skype evidence. Execute with Python 3.12 / SQLite 3.46.1.

All remnant damage is caused by real SQLite table deletion and page allocation.
The database files are never patched. This models a profile rebuild; it does not
claim these files were acquired from a running Microsoft Skype installation.
"""
from __future__ import annotations
import argparse
import hashlib
import io
import json
import sqlite3
import struct
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

import pyzipper
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
PASSWORD = "H7vQ3mZ8rT2xK6pN9sW4cF5jL1dB0yUa"
EDITED = "u4B8jN2cT6sZ9qP3r7F1kV5dH0mX8aWe"
FLAG = "RCC{skype_kept_the_receipts_74a9c2e6}"
GUID = bytes.fromhex("c42db5a60e894f779ead1ff0671b9413")
CHAT = "#jess.flower/$after-school;57a42e1c"
STAMP = int(datetime(2013, 6, 11, 21, 14, 22, tzinfo=timezone.utc).timestamp())
SCHEMA = """CREATE TABLE Messages(
 id INTEGER PRIMARY KEY, guid BLOB, chatname TEXT, timestamp INTEGER,
 author TEXT, body_xml TEXT, edited_timestamp INTEGER, type INTEGER, convo_id INTEGER)"""
PEOPLE = {
    "max": ("max.power.97", "Max", "My mic wasn't even on."),
    "jess": ("jess.flower", "Jess", "same people, worse sleep schedules"),
    "ravi": ("ravi.exe", "Ravi", "have you tried turning Max off and on again"),
    "sam": ("sam.bits", "Sam", "probably at work"),
    "ollie": ("ollie.wav", "Ollie", "BRB. since 2013."),
}
QUOTE = """[21:02:01] Jess: Before anyone asks, yes, the lobby is up. Same name as yesterday. Please don't invite your entire friends list this time.
[21:02:19] Ravi: Ollie has joined the lobby, left the lobby, joined the lobby. A compelling three-act structure.
[21:02:48] Ollie: router is on the other side of the house. if I disappear, avenge me. Or tell my brother to stop downloading movies.
[21:03:14] Max: We are winning this one. I have a new mouse and I cleaned the sensor with a cotton bud. Basically a professional now.
[21:03:51] Sam: You also changed your name to xX_MAXIMUM_DAMAGE_Xx and then forgot which account had the game on it.
[21:04:06] Max: That was a branding exercise. Also can everyone hear me? Skype keeps choosing the webcam microphone instead of my headset.
[21:04:37] Jess: I can hear your keyboard through two closed doors. The microphone is doing its job. We can also hear the television.
[21:05:12] Ravi: New rule. If you shout LAG after standing completely still, you have to make the next lobby. We are keeping a spreadsheet.
[21:05:44] Ollie: Please don't make a spreadsheet. Last time you made a spreadsheet we spent forty minutes discussing the font.
[21:06:03] Jess: It was Calibri and it was fine. Sam, you're muted. The little crossed-out microphone. No, the one next to your own name.
[21:06:42] Sam: Can you hear me now? Great. My headset cable has to sit at exactly this angle so nobody make me laugh or move the chair.
[21:07:21] Max: I have never rage-quit. Sometimes I leave a match strategically to protect the integrity of the team. Entirely different thing.
[21:07:50] Ravi: Strategic desktop visits. Excellent. We'll put that in the spreadsheet underneath tactical unplugging of the Ethernet cable.
[21:08:11] Jess: Do not unplug anything. I made tea and I am sitting down. I would like one ordinary game where nobody needs tech support.
[21:08:49] Ollie: One ordinary game? In this economy? Max is already explaining why the map is unfair and we haven't picked the map yet.
[21:09:17] Max: I am just saying the blue team has better lighting. Also the scoreboard is delayed. It hasn't counted some of my points.
[21:09:52] Sam: It counted mine. It also counted the time you fell off the bridge while explaining your mouse settings to all of us.
[21:10:25] Jess: Somebody take a picture of this chat before Max edits all of his messages again. I'm keeping these for the reunion.
[21:10:57] Ravi: If we have a reunion in thirteen years I expect the router to be working by then. Ollie is allowed to join by post.
[21:11:33] Ollie: Mum says stop shouting at the computer. I explained that none of you can hear me and she said that sounded like a benefit.
[21:12:04] Max: Everyone gets one embarrassing screenshot and then we're deleting the group. This is becoming an archive of personal attacks.
[21:12:39] Jess: You sent the screenshot yourself! You can't send evidence and then complain that we have evidence. That's not how files work.
[21:13:06] Sam: Put it in an archive so my little brother doesn't find it in Downloads. He already thinks all my friends live inside Skype.
[21:13:42] Ravi: Send it now, before your password becomes another editorial decision. I'm putting the kettle on while this transfer finishes.
"""

def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def connection():
    db = sqlite3.connect(":memory:")
    db.executescript("PRAGMA page_size=4096; PRAGMA secure_delete=OFF; PRAGMA auto_vacuum=NONE;")
    return db


def remnant(side):
    """Search a bounded SQL page-reuse layout, then retain that valid database."""
    body = "receipts.zip password: " + PASSWORD + "\n<quote>" + QUOTE[:3300] + "</quote>"
    source = connection()
    source.execute(SCHEMA)
    source.execute("INSERT INTO Messages VALUES(?,?,?,?,?,?,?,?,?)",
                   (417 if side == "prefix" else 7301, GUID, CHAT, STAMP,
                    "max.power.97", body, 0, 61, 42 if side == "prefix" else 91))
    source.commit()
    original = source.serialize()
    at = original.index(PASSWORD.encode())
    # A profile rebuild frees the old Messages root page. SQLite reuses it for
    # ordinary database metadata; different subsequent writes damage each copy.
    source.executescript("DELETE FROM Messages; DROP TABLE Messages; CREATE TABLE DbMeta(id INTEGER PRIMARY KEY, value);")
    empty = source.serialize()
    source.close()
    candidates = range(3200, 3550) if side == "prefix" else range(250, 650)
    for size in candidates:
        db = connection()
        db.deserialize(empty)
        db.execute("PRAGMA secure_delete=OFF")
        if side == "prefix":
            payload = hashlib.shake_256(b"rowdy11 profile cache").digest(size)
            db.execute("INSERT INTO DbMeta VALUES(1,?)", (payload,))
        else:
            db.executemany("INSERT INTO DbMeta VALUES(?,0)", ((i,) for i in range(1, size + 1)))
        db.commit()
        raw = db.serialize()
        same = [raw[at+i] == c for i, c in enumerate(PASSWORD.encode())]
        valid = (all(same[:20]) and not any(same[20:])) if side == "prefix" else (not any(same[:12]) and all(same[12:]))
        if valid and PASSWORD.encode() not in raw:
            assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
            assert len(original) == 8192, "The historical message must not require overflow pages"
            return db, {"method": "SQL page reuse", "allocation": size, "offset": at,
                        "page": 2, "survivor": PASSWORD[:20] if side == "prefix" else PASSWORD[12:],
                        "original_message_guid": GUID.hex(), "original_timestamp": STAMP}
        db.close()
    raise RuntimeError(f"No real SQLite page-reuse layout found for {side}; do not patch bytes")


def make_profile(side, archive_size):
    db, details = remnant(side)
    convo = 42 if side == "prefix" else 91
    base_id = 1000 if side == "prefix" else 8000
    db.executescript(SCHEMA + ";" + """
      CREATE TABLE Accounts(id INTEGER PRIMARY KEY, skypename TEXT, fullname TEXT);
      CREATE TABLE Contacts(id INTEGER PRIMARY KEY, skypename TEXT, displayname TEXT, mood_text TEXT);
      CREATE TABLE Conversations(id INTEGER PRIMARY KEY, identity TEXT, displayname TEXT, type INTEGER);
      CREATE TABLE Transfers(id INTEGER PRIMARY KEY, chatmsg_guid BLOB, partner_handle TEXT,
          filename TEXT, filepath TEXT, filesize INTEGER, bytestransferred INTEGER,
          starttime INTEGER, finishtime INTEGER, status INTEGER);
    """)
    me = "jess" if side == "prefix" else "ravi"
    db.execute("INSERT INTO Accounts VALUES(1,?,?)", PEOPLE[me][:2])
    db.executemany("INSERT INTO Contacts VALUES(?,?,?,?)", [(n, *v) for n, v in enumerate(PEOPLE.values(), 1)])
    db.execute("INSERT INTO Conversations VALUES(?,?,?,2)", (convo, CHAT, "after school (don't add teachers)"))
    rows = [
      ("jess", -480, "everyone in? Ollie, that means you too.", 61),
      ("ravi", -435, "He has been reconnecting since Tuesday.", 61),
      ("max", -360, "I have never rage-quit. Sometimes I leave a match strategically.", 61),
      ("sam", -320, "Your mum just called you downstairs. We all heard it.", 61),
      ("max", -280, "That was the TV. My mic wasn't even on.", 61),
      ("jess", -260, "Max. You sent us a screenshot of the other conversation.", 61),
      ("ollie", -230, "saving that for the reunion :D", 61),
      ("max", -60, '<files><file size="%d" index="0">receipts.zip</file></files>' % archive_size, 68),
      ("ravi", 45, "Got the file. I am absolutely keeping this laptop.", 61),
      ("max", 165, "Nothing to see here. Can we play another round now?", 61),
      ("jess", 188, "The edit pencil isn't an undo button for our memories.", 61),
    ]
    for i, (who, delta, body, kind) in enumerate(rows):
        guid = hashlib.md5(f"rowdy11-message-{i}".encode()).digest()
        db.execute("INSERT INTO Messages VALUES(?,?,?,?,?,?,?,?,?)", (
            base_id+i, guid, CHAT, STAMP+delta, PEOPLE[who][0], body, 0, kind, convo))
        if kind == 68:
            db.execute("INSERT INTO Transfers VALUES(?,?,?,?,?,?,?,?,?,?)", (
              17 if side == "prefix" else 203, guid, PEOPLE["max"][0], "receipts.zip",
              "C:\\Users\\"+PEOPLE[me][1]+"\\Downloads\\receipts.zip", archive_size, archive_size,
              STAMP-60, STAMP-49, 8))
    current_body = "receipts.zip password: " + EDITED if side == "prefix" else ""
    db.execute("INSERT INTO Messages VALUES(?,?,?,?,?,?,?,?,?)", (
        base_id+90, GUID, CHAT, STAMP, PEOPLE["max"][0], current_body,
        STAMP+120 if side == "prefix" else STAMP+149, 61, convo))
    db.commit()
    raw = db.serialize()
    assert PASSWORD.encode() not in raw
    assert details["survivor"].encode() in raw
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    names = {v[0]: v[1] for v in PEOPLE.values()}
    history = []
    for row in db.execute("SELECT id,hex(guid),timestamp,author,body_xml,edited_timestamp,type FROM Messages ORDER BY timestamp,id"):
        rid,guid,ts,author,body,edited,kind = row
        history.append({"id":rid,"guid":guid.lower(),"timestamp":ts,"author":author,
                        "name":names[author],"text":body,"edited":edited,"type":kind})
    db.close()
    return raw, history, details


def receipt():
    """Original authored challenge evidence, not a purported real user screenshot."""
    im = Image.new("RGB", (1040, 760), "#eef5f9")
    d = ImageDraw.Draw(im)
    font_dir = Path("/usr/share/fonts/dejavu-sans-fonts")
    if not font_dir.exists(): font_dir = Path("/usr/share/fonts/truetype/dejavu")
    def f(size, bold=False):
        return ImageFont.truetype(str(font_dir / ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")),size)
    d.rounded_rectangle((12,12,1028,748), radius=12, fill="#ffffff", outline="#5f9ab2", width=2)
    d.rounded_rectangle((14,14,1026,56), radius=10, fill="#71c7e8")
    d.text((30,23),"Skype - Max",font=f(19,True),fill="#143849")
    d.text((30,69),"Skype    Contacts    Conversation    Call    View    Tools    Help",font=f(13),fill="#405d6d")
    d.rectangle((15,98,235,746),fill="#eaf3f8")
    d.rounded_rectangle((32,117,88,173),radius=7,fill="#395d8b")
    d.text((44,127),"M",font=f(29,True),fill="white")
    d.text((101,121),"Max",font=f(20,True),fill="#204f67")
    d.text((101,152),"Online",font=f(13),fill="#478824")
    d.text((32,207),"CONTACTS",font=f(12,True),fill="#748f9f")
    for y,name in [(240,"Jess"),(289,"Ravi"),(338,"Sam"),(387,"Ollie"),(436,"Mum")]:
        if name=="Mum": d.rectangle((17,y-9,233,y+34), fill="#cdeafa")
        d.ellipse((34,y+2,44,y+12), fill="#64ab36")
        d.text((58,y),name,font=f(17),fill="#254d63")
    d.text((267,119),"Mum",font=f(27,True),fill="#284e65")
    d.text((267,157),"Dinner is getting cold.",font=f(15),fill="#7b8e99")
    d.line((255,190,1004,190),fill="#d8e4ea",width=1)
    d.text((267,208),"11 June 2013",font=f(13),fill="#8899a1")
    messages = [
      (252,"Mum","Max. Computer off. Now.","21:07"),
      (320,"Max","one more round please we are literally winning", "21:08"),
      (388,"Mum","You have been saying that since half past seven.","21:08"),
      (456,"Max","can i at least tell them my internet died", "21:09"),
      (524,"Mum","Your microphone is still on, sweetheart.","21:09"),
    ]
    for y,name,body,t in messages:
        d.text((267,y),name,font=f(14,True),fill="#007ca8" if name=="Max" else "#46616e")
        d.text((922,y),t,font=f(12),fill="#98a5ad")
        d.text((267,y+25),body,font=f(17),fill="#304650")
    d.rounded_rectangle((260,610,1004,711),radius=7,fill="#eef8df",outline="#c4dba3")
    d.text((279,624),"LAN GOBLINS   /   RECEIPT NO. 001",font=f(12,True),fill="#688445")
    d.text((279,652),FLAG,font=f(19,True),fill="#325523")
    out=io.BytesIO(); im.save(out,format="PNG",compress_level=9)
    return out.getvalue()


def encrypted_zip(png):
    out=io.BytesIO()
    salt=hashlib.sha256(b"rowdy11-receipt-only-salt-v1").digest()[:16]
    # Fixture-only deterministic salt for this one frozen member. Never reuse
    # this generator's constants for protecting real information.
    with patch("pyzipper.zipfile_aes.Random.get_random_bytes", side_effect=lambda n:salt[:n]):
        with pyzipper.AESZipFile(out,"w",compression=pyzipper.ZIP_DEFLATED,encryption=pyzipper.WZ_AES) as z:
            z.setpassword(PASSWORD.encode()); z.setencryption(pyzipper.WZ_AES,nbits=256)
            item=pyzipper.zipfile_aes.AESZipInfo("receipts.png",date_time=(2013,6,11,21,13,22))
            item.compress_type=pyzipper.ZIP_DEFLATED; item.external_attr=0o100644 << 16
            z.writestr(item,png)
    return out.getvalue()


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--output",type=Path,default=ROOT/"challenge"/"public")
    ap.add_argument("--report",type=Path,default=ROOT/"organizer"/"results"/"generation.json")
    args=ap.parse_args()
    if sqlite3.sqlite_version != "3.46.1":
        raise SystemExit("Use SQLite 3.46.1 to preserve the documented page-reuse layout.")
    png=receipt(); archive=encrypted_zip(png)
    jess,_,jproof=make_profile("prefix",len(archive))
    ravi,_,rproof=make_profile("suffix",len(archive))
    members={"Jess-laptop/Skype/jess.flower/main.db":jess,
             "Ravi-netbook/Skype/ravi.exe/main.db":ravi,
             "Jess-laptop/Downloads/receipts.zip":archive,
             "Ravi-netbook/Downloads/receipts.zip":archive}
    out=io.BytesIO()
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(members.items()):
            info=zipfile.ZipInfo(name,(2026,10,27,12,0,0)); info.compress_type=zipfile.ZIP_DEFLATED; info.external_attr=0o100644 << 16
            z.writestr(info,raw)
    evidence=args.output/"evidence"; evidence.mkdir(parents=True,exist_ok=True)
    (evidence/"skype-backups.zip").write_bytes(out.getvalue())
    for retired in (evidence/"receipts.zip",args.output/"history.json"):
        if retired.exists():retired.unlink()
    report={"status":"PASS","sqlite_version":sqlite3.sqlite_version,"synthetic_evidence":True,
      "raw_database_byte_patching":False,"original_message_has_overflow":False,
      "profiles":{"Jess-laptop":jproof,"Ravi-netbook":rproof},
      "members":[{"path":k,"bytes":len(v),"sha256":sha(v)} for k,v in members.items()],
      "public_files":{str(p.relative_to(args.output)):sha(p.read_bytes()) for p in sorted(args.output.rglob("*")) if p.is_file() and p.suffix in (".zip",".json")},
      "receipt_sha256":sha(png),"flag":FLAG,"password":PASSWORD,"edited_password":EDITED}
    args.report.parent.mkdir(parents=True,exist_ok=True); args.report.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({"status":"PASS","backup_bytes":len(out.getvalue()),"sqlite":sqlite3.sqlite_version,"profiles":report["profiles"]},indent=2))


if __name__=="__main__": main()
