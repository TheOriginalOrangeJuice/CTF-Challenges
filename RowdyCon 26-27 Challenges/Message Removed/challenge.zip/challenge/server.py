"""Static-only public-root server for Message Removed."""
import json
import mimetypes
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT=Path(__file__).resolve().parent/"public"
FILES={"/"+p.relative_to(ROOT).as_posix():p for p in ROOT.rglob("*") if p.is_file() and not p.is_symlink()}
FILES["/"]=ROOT/"index.html"
MIMES={".js":"text/javascript; charset=utf-8",".svg":"image/svg+xml",".css":"text/css; charset=utf-8",".html":"text/html; charset=utf-8",".json":"application/json; charset=utf-8",".wav":"audio/wav",".zip":"application/zip"}
CSP="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' blob: data:; media-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'none'"

class Handler(BaseHTTPRequestHandler):
    server_version="SkypeHistory/1.0"
    def serve(self,head=False):
        path=unquote(urlsplit(self.path).path)
        if path=="/healthz":
            raw=b'{"status":"ok"}\n'; kind="application/json"
        else:
            file=FILES.get(path)
            if not file:
                self.send_error(404);return
            raw=file.read_bytes();kind=MIMES.get(file.suffix,mimetypes.guess_type(file.name)[0] or "application/octet-stream")
        self.send_response(200);self.send_header("Content-Type",kind);self.send_header("Content-Length",str(len(raw)))
        self.send_header("Content-Security-Policy",CSP);self.send_header("X-Content-Type-Options","nosniff")
        self.send_header("Referrer-Policy","no-referrer");self.send_header("Cache-Control","no-cache")
        if path.startswith("/evidence/"):self.send_header("Content-Disposition",'attachment; filename="'+Path(path).name+'"')
        self.end_headers()
        if not head:self.wfile.write(raw)
    def do_GET(self):self.serve()
    def do_HEAD(self):self.serve(True)
    def do_POST(self):self.send_error(405,"This application serves files only")

if __name__=="__main__":
    ThreadingHTTPServer(("0.0.0.0",int(os.environ.get("PORT","18111"))),Handler).serve_forever()
