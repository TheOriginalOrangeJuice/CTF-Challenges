export class SkypeAudio {
  constructor(onError){this.onError=onError;this.enabled=true;this.volume=.4;this.context=null;this.master=null;this.buffers={};this.ring=null;this.notice=null;this.wanted=null;this.loading=null;}
  async unlock(){
    try{
      if(!this.context){this.context=new AudioContext();this.master=this.context.createGain();this.master.connect(this.context.destination);this.applyVolume();}
      await this.context.resume();
      if(!this.loading){
        this.loading=Promise.all(['incoming','outgoing','message'].map(async name=>{
          const r=await fetch('/audio/'+name+'.wav');if(!r.ok)throw Error('Missing '+name+' sound');
          this.buffers[name]=await this.context.decodeAudioData(await r.arrayBuffer());
        })).then(()=>this.ensureRing()).catch(e=>{this.loading=null;this.onError('Call sounds could not load. Use Sound to try again.');});
      }
      await this.loading;
    }catch{this.onError('Sound needs a click to start. Use the Sound button.');}
  }
  applyVolume(){if(this.master)this.master.gain.value=this.enabled?this.volume:0;}
  settings(on,volume){this.enabled=on;this.volume=volume/100;this.applyVolume();}
  ensureRing(){
    if(!this.wanted||!this.context||!this.buffers[this.wanted.kind]||this.ring)return;
    this.stopNotice();
    const src=this.context.createBufferSource();src.buffer=this.buffers[this.wanted.kind];src.loop=true;src.connect(this.master);src.start();this.ring=src;
  }
  sync(call){
    const wanted=call?.phase==='ringing'?{id:call.id,kind:call.kind}:null;
    if(this.wanted?.id!==wanted?.id||this.wanted?.kind!==wanted?.kind){this.stopRing();this.wanted=wanted;}
    this.ensureRing();
  }
  stopRing(){if(this.ring){try{this.ring.stop();}catch{}this.ring.disconnect();this.ring=null;}}
  stopNotice(){if(this.notice){try{this.notice.stop();}catch{}this.notice.disconnect();this.notice=null;}}
  message(){
    if(!this.context||!this.buffers.message||this.wanted||!this.enabled)return;
    this.stopNotice();const src=this.context.createBufferSource();src.buffer=this.buffers.message;src.connect(this.master);src.start();this.notice=src;
    src.onended=()=>{if(this.notice===src){src.disconnect();this.notice=null;}};
  }
  stop(){this.wanted=null;this.stopRing();this.stopNotice();}
}
