/* Authored present-day activity. Historical evidence is never mutated here. */
export const CONTACTS = {
  group:{name:'LAN goblins',handle:'6 participants',mood:'Max, Jess, Ravi, Sam, Ollie & you',presence:'online'},
  max:{name:'Max',handle:'max.power.97',mood:"My mic wasn't even on.",presence:'online'},
  jess:{name:'Jess',handle:'jess.flower',mood:'same people, worse sleep schedules',presence:'online'},
  ravi:{name:'Ravi',handle:'ravi.exe',mood:'have you tried turning Max off and on again',presence:'online'},
  sam:{name:'Sam',handle:'sam.bits',mood:'probably at work',presence:'away'},
  ollie:{name:'Ollie',handle:'ollie.wav',mood:'BRB. since 2013.',presence:'offline'},
  you:{name:'You',handle:'you.again',mood:'',presence:'online'}
};
const START = Date.UTC(2026,9,27,16,24);
const message = (who,text,minute=0,extra={}) => ({who,text,at:START+minute*60000,...extra});
const INITIAL = {
  group:[
    message('jess',"found the laptop folders",0,{attachment:'backup'}),
    message('max',"you still have those?",1),
    message('ravi',"She still has your old profile picture too.",2),
    message('max',"please don't",3),
    message('jess',"Saturday at seven?",4),
    message('ollie',"can someone send me the wallpaper again",5,{attachment:'photo'}),
    message('max',"yeah seven works",6)
  ],
  max:[message('max',"For the record, I remember everything differently.",4)],
  jess:[message('jess',"heyy, you coming Saturday?",3)],
  ravi:[message('ravi',"yeah?",2)],
  sam:[message('sam',"On a shift. Read everything later. Please don't change the group name again.",1)],
  ollie:[message('ollie',"brb router",0)]
};
export const REPLIES = {
  max:{
    greeting:["oh hey", "I'm here. Unfortunately so is Ravi."],
    reunion:["I'll come if we agree not to do a slideshow.","Normal reunion. Food. Conversation. No evidence presentations."],
    gaming:["I was carrying that team. Nobody remembers the good rounds.","the mouse was broken. ask Sam."],
    dispute:["you lot are still going on about this?", "A screenshot can't convey tone.", "not talking about this again"],
    fallback:["yeah I saw", "Can this wait until after I've had dinner?"]
  },
  jess:{
    greeting:["heyyy :)", "give me a sec, kettle's on"],
    reunion:["Saturday, takeaway, old games. We can argue about the playlist when everyone gets here.","Sam said they're coming after work. Ollie said 'probably', which is practically a signed contract."],
    gaming:["we spent half the night asking if Sam was muted", "Max spent twenty minutes explaining his mouse settings"],
    dispute:["He's been arguing with me about this since Tuesday.","He was exactly like this at school.","I promise he's always been this dramatic."],
    fallback:["what do you mean?", "sorry, making tea"]
  },
  ravi:{
    greeting:["hey", "was wondering when you'd show up"],
    reunion:["Saturday then. I'll bring snacks.", "Jess can bring the organisation. Max can bring a lawyer."],
    gaming:["one more round means 3am with you lot", "Ollie's wifi beat us more than the other team did"],
    dispute:["Max has a different version every time he tells it.", "now he's saying 'out of context' lmao", "ask him again on Saturday, it'll be a new story"],
    fallback:["right", "I'm not getting involved"]
  }
};

export function freshState(){return {version:2,selected:'group',mode:'live',tab:'recent',conversations:structuredClone(INITIAL),drafts:{},unread:{},replyProgress:{},pending:{},call:null,callLog:[],incomingUsed:false,eligibleMs:0,sound:true,volume:40,seq:100,hasChanges:false};}
export function topic(text){
  if(/max|receipt|password|archive|delet|edit|mum|mom|screenshot|rage|evidence|flag|hint/i.test(text)) return 'dispute';
  if(/reunion|saturday|meet|party|food|snack|weekend/i.test(text)) return 'reunion';
  if(/gam[eis]|play|round|lag|mic|mouse|score|wifi|wi-fi|router/i.test(text)) return 'gaming';
  if(/\b(hi|hey|hello|yo|sup|morning|evening)\b/i.test(text)) return 'greeting';
  return 'fallback';
}
export function send(state,conversation,text,now){
  text=text.trim().slice(0,2000); if(!text || !state.conversations[conversation]) return false;
  state.conversations[conversation].push({id:++state.seq,who:'you',text,at:now});
  state.drafts[conversation]=''; state.hasChanges=true;
  const contact=conversation==='group'?'jess':conversation;
  if(REPLIES[contact]){
    const previous=Object.keys(state.pending).find(key=>state.pending[key].contact===contact);
    const p=previous===undefined?null:state.pending[previous];
    if(p){p.text=text;delete state.pending[previous];state.pending[conversation]=p;}
    else state.pending[conversation]={contact,text,typingAt:now+1000,due:now+4000,typing:false};
  }
  return true;
}
export const activeCall = state => Boolean(state.call && state.call.phase!=='ended');
export function beginCall(state,contact,kind,now){
  if(activeCall(state)||!CONTACTS[contact]||contact==='group'||contact==='you') return false;
  state.call={id:++state.seq,contact,conversation:kind==='incoming'?state.selected:contact,kind,phase:'ringing',started:now,deadline:now+(kind==='incoming'?20000:45000)};
  if(kind==='incoming')state.incomingUsed=true;
  state.hasChanges=true; return true;
}
export function endCall(state,result,now){
  if(!activeCall(state))return false;
  const call=state.call;
  call.phase='ended';call.result=result;call.ended=now;
  state.callLog.push({id:call.id,contact:call.contact,kind:call.kind,result,at:call.started,duration:0,ringingMs:Math.max(0,now-call.started)});
  const conversation=call.conversation||call.contact;
  state.conversations[conversation].push({id:++state.seq,who:'system',text:result+(call.kind==='incoming'?' · Incoming call from '+CONTACTS[call.contact].name:' · Outgoing call'),at:now});
  if(state.mode!=='live'||state.selected!==conversation) state.unread[conversation]=(state.unread[conversation]||0)+1;
  return true;
}
export function answerCall(state,now){
  if(state.call?.kind!=='incoming'||state.call.phase!=='ringing')return false;
  state.call.phase='connected';state.call.deadline=now+250;return true;
}
export function tick(state,now,elapsed,eligible,random=Math.random){
  const changes={render:false,replies:[],callChanged:false};
  for(const [conv,p] of Object.entries(state.pending)){
    if(!p.typing&&now>=p.typingAt){p.typing=true;changes.render=true;}
    if(now>=p.due){
      const branch=topic(p.text), key=p.contact+':'+branch, pool=REPLIES[p.contact][branch];
      const used=state.replyProgress[key]||0;
      if(used<pool.length){
        state.replyProgress[key]=used+1;
        state.conversations[conv].push({id:++state.seq,who:p.contact,text:pool[used],at:p.due});
        if(state.mode!=='live'||state.selected!==conv)state.unread[conv]=(state.unread[conv]||0)+1;
        changes.replies.push(conv);
      }
      delete state.pending[conv];changes.render=true;
    }
  }
  if(activeCall(state)&&now>=state.call.deadline){
    const result=state.call.phase==='connected'?'Call dropped':state.call.kind==='incoming'?'Missed call':'No answer';
    endCall(state,result,now);changes.render=changes.callChanged=true;
  } else if(state.call?.phase==='ended'&&now-state.call.ended>=5000){state.call=null;changes.render=changes.callChanged=true;}
  if(eligible&&!activeCall(state)&&!state.incomingUsed){
    state.eligibleMs+=Math.max(0,Math.min(elapsed,1000));
    if(state.eligibleMs>=30000){
      state.eligibleMs-=30000;
      if(random()<0.05){beginCall(state,'max','incoming',now);changes.render=changes.callChanged=true;}
    }
  }
  return changes;
}
export function recoverState(raw,now){
  try{
    const s=JSON.parse(raw);
    if(![1,2].includes(s.version)||!s.conversations||!s.pending||!s.replyProgress||!s.callLog||!s.drafts||!s.unread)throw Error('version');
    for(const key of Object.keys(INITIAL))if(!Array.isArray(s.conversations[key]))throw Error('conversation');
    if(s.version===1){
      s.conversations.group=[...structuredClone(INITIAL.group),...s.conversations.group.slice(9)];
      const oldReplies={"He sent us that file himself. That's the part that still makes me laugh.":REPLIES.jess.dispute[0],"I just want to see his face when someone finally opens it.":REPLIES.jess.dispute[1]};
      for(const messages of Object.values(s.conversations))for(const m of messages)if(m.who==='jess'&&oldReplies[m.text])m.text=oldReplies[m.text];
      s.version=2;
    }
    for(const key of ['jess','ravi'])if(s.conversations[key][0]?.id===undefined&&s.conversations[key][0]?.who===key)s.conversations[key][0]=structuredClone(INITIAL[key][0]);
    if(!(s.selected in INITIAL))s.selected='group';
    s.mode='live';delete s.history;
    s.volume=Math.max(0,Math.min(100,Number(s.volume)||0));
    s.eligibleMs=Math.max(0,Math.min(29999,Number(s.eligibleMs)||0));
    if(activeCall(s))endCall(s,'Call interrupted',now);
    s.call=null;
    return s;
  }catch{return freshState();}
}
