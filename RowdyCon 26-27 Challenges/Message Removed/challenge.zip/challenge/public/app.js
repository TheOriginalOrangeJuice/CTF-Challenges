import {CONTACTS,freshState,recoverState,send,beginCall,endCall,answerCall,activeCall,tick} from './engine.js';
import {SkypeAudio} from './audio.js';

const $=id=>document.getElementById(id), KEY='message-removed.skype.v1';
const icon=name=>`<svg class="icon" aria-hidden="true"><use href="/icons.svg#${name}"/></svg>`;
const avatar=name=>`<svg aria-hidden="true"><use href="/icons.svg#avatar-${name}"/></svg>`;
function node(tag,cls,text){const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el;}
let storageWorks=true;
let state;
try{state=recoverState(sessionStorage.getItem(KEY),Date.now());}catch{state=freshState();storageWorks=false;}
let activated=false,previousTime=performance.now(),lastSaved=0;
let renderedKey='',renderedMessages='',popupOpener=null,dialogOpener=null,previewUrl=null,toastTimer;
const sound=new SkypeAudio(toast);

function save(){
  if(!storageWorks)return;
  try{sessionStorage.setItem(KEY,JSON.stringify(state));}catch{storageWorks=false;toast('This browser cannot save the session. Keep this tab open to retain your messages.');}
}
function toast(text){clearTimeout(toastTimer);$('toast').textContent=text;$('toast').hidden=false;toastTimer=setTimeout(()=>{$('toast').hidden=true;},4500);}
function activate(){if(!activated){activated=true;previousTime=performance.now();sound.unlock();}}
document.addEventListener('pointerdown',activate,{capture:true});
document.addEventListener('keydown',activate,{capture:true});
const time=ms=>new Date(ms).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',timeZone:'UTC'});

function buildContacts(){
  const list=$('contact-list');
  for(const key of ['group','jess','max','ravi','sam','ollie']){
    const c=CONTACTS[key],b=node('button','contact');b.dataset.contact=key;
    const av=node('span','avatar');av.innerHTML=avatar(key);av.append(node('i','presence '+c.presence));
    const copy=node('span','contact-copy');copy.append(node('span','contact-name',c.name),node('span','contact-preview',c.mood));
    const badge=node('span','badge');badge.hidden=true;b.append(av,copy,badge);b.addEventListener('click',()=>select(key));list.append(b);
  }
}
function select(key){
  closePopup();state.selected=key;state.mode='live';state.unread[key]=0;
  $('message-input').value=state.drafts[key]||'';renderedKey='';render();save();
}
function updateSidebar(){
  const query=$('search').value.trim().toLowerCase();let visible=0;
  for(const b of $('contact-list').children){
    const key=b.dataset.contact,c=CONTACTS[key],messages=state.conversations[key];
    const match=!query||[c.name,c.handle,c.mood,...messages.map(m=>m.text)].some(t=>t.toLowerCase().includes(query));
    b.hidden=!match;if(match)visible++;
    b.classList.toggle('selected',state.mode==='live'&&state.selected===key);b.setAttribute('aria-current',state.mode==='live'&&state.selected===key?'true':'false');
    const count=state.unread[key]||0,badge=b.querySelector('.badge');badge.hidden=!count;badge.textContent=count;
    const last=messages.at(-1);b.querySelector('.contact-preview').textContent=state.tab==='contacts'?c.mood:(last?.who==='you'?'You: ':'')+(last?.text||c.mood);
  }
  $('no-contacts').hidden=visible>0;
  $('contacts-tab').setAttribute('aria-selected',String(state.tab==='contacts'));
  $('recent-tab').setAttribute('aria-selected',String(state.tab==='recent'));
  $('list-label').textContent=state.tab==='contacts'?'ALL CONTACTS':'FAVOURITES';
  const total=Object.values(state.unread).reduce((a,b)=>a+b,0);
  $('total-unread').textContent=total;$('total-unread').hidden=!total;$('task-unread').textContent=total||'';
  document.title=(total?'('+total+') ':'')+'Skype';
  $('clear-search').hidden=!query;
}
function currentMessages(){
  return state.conversations[state.selected];
}
function appendText(el,text){
  const query=$('search').value.trim();
  if(!query){el.textContent=text;return;}
  let cursor=0,at;const low=text.toLowerCase(),needle=query.toLowerCase();
  while((at=low.indexOf(needle,cursor))>=0){el.append(document.createTextNode(text.slice(cursor,at)),node('mark','',text.slice(at,at+query.length)));cursor=at+query.length;}
  el.append(document.createTextNode(text.slice(cursor)));
}
function fileCard(kind){
  const card=node('div','attachment'+(kind==='photo'?' photo':''));
  const copy=node('span','attachment-copy'),actions=node('span','attachment-actions');
  if(kind==='photo'){
    const img=node('img','photo-thumb');img.src='/wallpaper.svg';img.alt='A blue sky over green hills';card.append(img);
    copy.append(node('strong','','desktop-again.svg'),node('small','','Ollie’s favourite wallpaper'));
    const preview=node('button','','Preview');preview.addEventListener('click',()=>showPicture('/wallpaper.svg','desktop-again.svg'));
    const a=node('a','','Save');a.href='/wallpaper.svg';a.download='desktop-again.svg';actions.append(preview,a);
  }else{
    const file=node('span','attachment-icon zip');file.innerHTML=icon('file');card.append(file);
    const name='skype-backups.zip';
    copy.append(node('strong','',name),node('small','','ZIP file'));
    const a=node('a','','Save file');a.href='/evidence/'+name;a.download=name;actions.append(a);
  }
  copy.append(actions);card.append(copy);return card;
}
function renderMessages(forceBottom=false){
  const key=state.selected,query=$('search').value.trim().toLowerCase();
  const source=currentMessages(),signature=JSON.stringify([key,query,source]);
  if(signature===renderedMessages&&!forceBottom)return;
  const scroll=$('message-scroll'),atBottom=scroll.scrollHeight-scroll.clientHeight-scroll.scrollTop<65,changed=key!==renderedKey;
  const previousScroll=scroll.scrollTop;
  const target=$('messages');target.replaceChildren();let shown=0;
  $('day-label').firstElementChild.textContent='27 October 2026';
  for(const m of source){
    const name=CONTACTS[m.who]?.name||m.name||m.who;
    if(query&&![(m.text||''),name].some(t=>t.toLowerCase().includes(query)))continue;
    shown++;
    if(m.who==='system'){const row=node('div','message system');row.innerHTML=icon('phone');row.append(document.createTextNode(m.text+' · '+time(m.at)));target.append(row);continue;}
    const row=node('article','message'+(m.who==='you'?' mine':'')+(m.removed?' removed':''));
    const av=node('span','avatar');av.innerHTML=avatar(m.who||'you');
    const content=node('div','message-content'),heading=node('div','message-heading');
    const sender=node('span','message-name',name);if(m.edited)sender.append(node('span','edited',m.removed?'removed':'edited'));
    const stamp=node('button','message-time',time(m.at));stamp.title='Message details';stamp.setAttribute('aria-label','Message details: '+name+' at '+time(m.at));stamp.addEventListener('click',()=>messageDetails(m));heading.append(sender,stamp);
    const text=node('p','message-body');appendText(text,m.text);
    content.append(heading,text);if(m.attachment)content.append(fileCard(m.attachment));row.append(av,content);target.append(row);
  }
  $('no-messages').hidden=shown>0;
  if(changed||forceBottom||atBottom){scroll.scrollTop=changed&&state.mode==='live'&&state.selected==='group'&&!state.hasChanges?0:scroll.scrollHeight;$('new-messages').hidden=true;}else{scroll.scrollTop=previousScroll;$('new-messages').hidden=false;}
  renderedMessages=signature;renderedKey=key;
}
function renderCall(){
  const call=state.call;$('call-panel').hidden=!call;if(!call)return;
  $('call-avatar').innerHTML=avatar(call.contact);$('call-person').textContent=CONTACTS[call.contact].name;
  $('call-status').textContent=call.phase==='ended'?call.result:call.phase==='connected'?'Connected':call.kind==='incoming'?'Incoming call…':'Calling…';
  $('call-time').textContent=call.phase==='ended'?(call.result==='Call dropped'?'00:00 · Connection lost':''):call.phase==='connected'?'00:00':call.kind==='incoming'?'Would you like to answer?':'Waiting for an answer';
  $('answer-call').hidden=call.kind!=='incoming'||call.phase!=='ringing';
  $('end-call').hidden=call.phase!=='ringing';$('end-call').querySelector('span').textContent=call.kind==='incoming'?'Decline':'Hang up';
  $('dismiss-call').hidden=call.phase!=='ended';sound.sync(call);
}
function render(forceBottom=false){
  const key=state.selected,c=CONTACTS[key];
  $('conversation-title').textContent=c.name;
  $('conversation-subtitle').textContent=key==='group'?c.handle:c.mood;
  $('participants').textContent=key==='group'?c.mood:c.handle;
  $('header-avatar').innerHTML=avatar(key);$('header-profile').setAttribute('aria-label',key==='group'?'View group members':'View '+c.name+'’s profile');
  $('call-button').disabled=activeCall(state);$('call-button').querySelector('span').textContent=key==='group'?'Call a friend':'Call';
  const typing=state.pending[state.selected];
  $('typing').textContent=typing?.typing?CONTACTS[typing.contact].name+' is typing…':'';
  $('message-input').placeholder='Send a message to '+(key==='group'?'the group':c.name)+'…';
  $('send').disabled=!$('message-input').value.trim();
  $('sound-toggle').innerHTML=icon(state.sound?'sound':'mute')+'<span>Sound '+(state.sound?'on':'off')+'</span>';
  $('sound-toggle').setAttribute('aria-pressed',String(state.sound));$('sound-toggle').setAttribute('aria-label','Sound '+(state.sound?'on':'off'));
  $('volume').value=state.volume;sound.settings(state.sound,state.volume);
  updateSidebar();renderMessages(forceBottom);renderCall();
}
function closePopup(){
  $('popup').hidden=true;$('popup').replaceChildren();$('popup').className='popup';
  document.querySelectorAll('[data-menu]').forEach(b=>b.setAttribute('aria-expanded','false'));
}
function popup(anchor,items,emotes=false){
  closePopup();popupOpener=anchor;const menu=$('popup');menu.classList.toggle('emote-popup',emotes);
  const rect=anchor.getBoundingClientRect();
  for(const [label,action]of items){const b=node('button','',label);b.addEventListener('click',()=>{closePopup();action();});menu.append(b);}
  menu.hidden=false;const bounds=menu.getBoundingClientRect();menu.style.left=Math.min(rect.left,innerWidth-bounds.width-12)+'px';
  menu.style.top=(rect.bottom+bounds.height<innerHeight-45?rect.bottom+3:rect.top-bounds.height-3)+'px';
  anchor.setAttribute('aria-expanded','true');menu.firstElementChild?.focus();
}
function openDialog(title,content,actions){
  closePopup();dialogOpener=document.activeElement;$('dialog-title').textContent=title;$('dialog-content').replaceChildren(content);
  $('dialog-actions').replaceChildren();
  const entries=actions||[['Close',closeDialog]];
  for(const [label,fn]of entries){const b=node('button','glossy',label);b.addEventListener('click',fn);$('dialog-actions').append(b);}
  if(!$('dialog').open)$('dialog').showModal();
}
function closeDialog(){
  $('dialog').close();if(previewUrl){URL.revokeObjectURL(previewUrl);previewUrl=null;}
  if(dialogOpener?.isConnected)dialogOpener.focus();
}
$('dialog').addEventListener('cancel',e=>{e.preventDefault();closeDialog();});$('dialog-close').onclick=closeDialog;
function profile(key){
  const c=CONTACTS[key],content=node('div');
  const top=node('div','profile-card'),av=node('span','avatar');av.innerHTML=avatar(key);const names=node('div');names.append(node('h3','',c.name),node('small','',c.handle));top.append(av,names);content.append(top,node('p','',c.mood));
  if(key==='group'){
    const list=node('div');for(const who of ['jess','max','ravi','sam','ollie']){const b=node('button','contact');const a=node('span','avatar');a.innerHTML=avatar(who);b.append(a,node('span','',CONTACTS[who].name),node('small','',CONTACTS[who].presence));b.onclick=()=>{closeDialog();select(who);};list.append(b);}content.append(list);
    openDialog('LAN goblins · Members',content);return;
  }
  content.append(node('p','','Skype name: '+c.handle));
  const actions=key==='you'?[['Close',closeDialog]]:[['Message',()=>{closeDialog();select(key);$('message-input').focus();}],['Call',()=>{closeDialog();call(key);}],['Close',closeDialog]];
  openDialog('Profile',content,actions);
}
function messageDetails(m){
  const dl=node('dl','details'),values=[['From',m.author||CONTACTS[m.who]?.handle||m.who],['Sent (UTC)',new Date(m.at).toISOString()],['Message',m.text]];
  for(const[label,value]of values)dl.append(node('dt','',label),node('dd','',value));
  openDialog('Message details',dl,[['Copy details',()=>copy(values.map(([k,v])=>k+': '+v).join('\n'))],['Close',closeDialog]]);
}
async function copy(text){try{await navigator.clipboard.writeText(text);toast('Copied to clipboard.');}catch{const field=node('textarea');field.value=text;$('dialog-content').append(field);field.select();toast('Select and copy the text below.');}}
function showPicture(url,title){const img=node('img');img.src=url;img.alt=title;openDialog(title,img);}
function exportConversation(){
  const content=currentMessages().map(m=>'['+new Date(m.at).toISOString()+'] '+(CONTACTS[m.who]?.name||m.who)+': '+m.text).join('\n\n');
  const url=URL.createObjectURL(new Blob([content],{type:'text/plain;charset=utf-8'}));const a=node('a');a.href=url;a.download=state.selected+'-conversation.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Conversation saved.');
}
function call(key){
  if(activeCall(state)){toast('End the current call first.');return;}
  if(beginCall(state,key,'outgoing',Date.now())){sound.unlock();render();save();$('end-call').focus();}
}
function callPicker(){const list=node('div');for(const who of ['max','jess','ravi','sam','ollie']){const b=node('button','contact');const a=node('span','avatar');a.innerHTML=avatar(who);b.append(a,node('span','',CONTACTS[who].name));b.onclick=()=>{closeDialog();call(who);};list.append(b);}openDialog('Call a friend',list);}
function callHistory(){
  const content=node('div');if(!state.callLog.length)content.append(node('p','','Your recent calls will appear here.'));
  else{const table=node('table','dialog-table');const head=node('tr');['Contact','Call','Result','Time (UTC)'].forEach(s=>head.append(node('th','',s)));table.append(head);for(const c of [...state.callLog].reverse()){const row=node('tr');[CONTACTS[c.contact].name,c.kind,c.result,time(c.at)].forEach(s=>row.append(node('td','',s)));table.append(row);}content.append(table);}openDialog('Call history',content);
}
function reset(){
  const perform=()=>{sound.stop();const incomingUsed=state.incomingUsed;state=freshState();state.incomingUsed=incomingUsed;activated=false;previousTime=performance.now();$('message-input').value='';$('search').value='';renderedKey=renderedMessages='';closeDialog();render();save();toast('Session reset.');};
  if(state.hasChanges||Object.values(state.drafts).some(Boolean)||activeCall(state))openDialog('Reset this session?',node('p','','This will clear your new messages, drafts and calls.'),[['Keep chatting',closeDialog],['Reset session',perform]]);
  else perform();
}
function about(){const d=node('div');const logo=node('div','profile-card');const a=node('span','avatar');a.innerHTML=icon('logo');logo.append(a,node('h3','','Skype'));d.append(logo,node('p','','Original Skype interface sounds © Skype/Microsoft. Skype is a trademark of Microsoft.'));openDialog('About Skype',d);}
function toggleSound(){state.sound=!state.sound;sound.settings(state.sound,state.volume);if(state.sound)sound.unlock();render();save();}
const MENU={
  skype:[['My profile',()=>profile('you')],['Toggle sound',toggleSound],['Reset session…',reset]],
  contacts:[['All contacts',()=>{state.tab='contacts';render();save();}],['Group members',()=>profile('group')]],
  conversation:[['Find a message',()=>{$('search').focus();$('search').select();}],['Save conversation…',exportConversation],['View profile',()=>profile(state.selected)]],
  call:[['Call a friend…',callPicker],['Call history',callHistory]],
  view:[['Maximize / restore',()=>$('window').classList.toggle('maximized')],['Show desktop',()=>{$('window').hidden=true;}]],
  tools:[['Open a picture…',()=>$('picture-input').click()]],
  help:[['About Skype',about]]
};
document.querySelectorAll('[data-menu]').forEach(b=>b.addEventListener('click',()=>popup(b,MENU[b.dataset.menu])));
$('more-button').onclick=()=>popup($('more-button'),MENU.conversation);
$('desktop-menu').onclick=()=>popup($('desktop-menu'),[['Open Skype',()=>{$('window').hidden=false;}]]);
$('header-profile').onclick=()=>profile(state.selected);$('self-profile').onclick=()=>profile('you');
$('contacts-tab').onclick=()=>{state.tab='contacts';render();save();};$('recent-tab').onclick=()=>{state.tab='recent';render();save();};
$('search').oninput=()=>render();$('clear-search').onclick=()=>{$('search').value='';render();$('search').focus();};
$('call-button').onclick=()=>state.selected==='group'?callPicker():call(state.selected);
$('answer-call').onclick=()=>{if(answerCall(state,Date.now())){const id=state.call.id;sound.sync(state.call);render();save();setTimeout(()=>{if(state.call?.id===id&&state.call.phase==='connected'){endCall(state,'Call dropped',Date.now());render();save();}},250);}};
$('end-call').onclick=()=>{if(endCall(state,state.call?.kind==='incoming'?'Call declined':'Call canceled',Date.now())){sound.sync(state.call);render();save();}};
$('dismiss-call').onclick=()=>{state.call=null;render();save();};
$('message-input').oninput=e=>{state.drafts[state.selected]=e.target.value;save();$('send').disabled=!e.target.value.trim();};
$('composer').onsubmit=e=>{e.preventDefault();if(state.mode!=='live')return;if(send(state,state.selected,$('message-input').value,Date.now())){$('message-input').value='';render(true);save();$('message-input').focus();}};
$('message-input').onkeydown=e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing){e.preventDefault();$('composer').requestSubmit();}};
$('emoticons').onclick=()=>popup($('emoticons'),[[':)',':)'],[':D',':D'],[';)', ';)'],['<3','<3'],['(y)','(y)'],[':P',':P'],[':(',':('],['(coffee)','(coffee)']].map(([label,text])=>[label,()=>{const input=$('message-input');input.setRangeText(text,input.selectionStart,input.selectionEnd,'end');input.dispatchEvent(new Event('input'));input.focus();}]),true);
$('open-picture').onclick=()=>$('picture-input').click();
$('picture-input').onchange=e=>{const file=e.target.files[0];if(!file)return;if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>10*1024*1024){toast('Choose a PNG, JPEG or WebP picture smaller than 10 MB.');e.target.value='';return;}const url=URL.createObjectURL(file);showPicture(url,file.name);previewUrl=url;e.target.value='';};
$('new-messages').onclick=()=>{$('message-scroll').scrollTop=$('message-scroll').scrollHeight;$('new-messages').hidden=true;};
$('message-scroll').onscroll=()=>{const s=$('message-scroll');if(s.scrollHeight-s.scrollTop-s.clientHeight<65)$('new-messages').hidden=true;};
$('sound-toggle').onclick=toggleSound;$('volume').oninput=e=>{state.volume=Number(e.target.value);sound.settings(state.sound,state.volume);save();};$('reset').onclick=reset;
$('minimize').onclick=()=>{$('window').hidden=true;};$('show-desktop').onclick=()=>{$('window').hidden=!$('window').hidden;};$('restore-window').onclick=()=>{$('window').hidden=false;};
$('maximize').onclick=()=>$('window').classList.toggle('maximized');
$('close-window').onclick=()=>{if(activeCall(state)){endCall(state,'Call canceled',Date.now());sound.stop();renderCall();}$('window').hidden=true;save();};
document.addEventListener('pointerdown',e=>{if(!$('popup').contains(e.target)&&e.target!==popupOpener)closePopup();});
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&!$('popup').hidden){closePopup();popupOpener?.focus();}
  if(!$('popup').hidden&&['ArrowDown','ArrowUp'].includes(e.key)){e.preventDefault();const items=[...$('popup').children],i=items.indexOf(document.activeElement);items[(i+(e.key==='ArrowDown'?1:items.length-1))%items.length]?.focus();}
  if((e.ctrlKey||e.metaKey)&&e.key==='f'&&!$('dialog').open){e.preventDefault();$('search').focus();$('search').select();}
});
document.addEventListener('visibilitychange',()=>{previousTime=performance.now();save();});
window.addEventListener('pagehide',()=>{if(activeCall(state))endCall(state,'Call interrupted',Date.now());sound.stop();save();});
buildContacts();$('message-input').value=state.drafts[state.selected]||'';render();save();
if(!storageWorks)toast('Session storage is unavailable. Messages will last while this page stays open.');
setInterval(()=>{
  const now=Date.now(),perf=performance.now(),elapsed=perf-previousTime;previousTime=perf;
  const eligible=activated&&!document.hidden&&!$('dialog').open&&!$('window').hidden;
  const changes=tick(state,now,elapsed,eligible);
  if(changes.render){render();save();}
  if(changes.replies.length)sound.message();
  if(changes.callChanged)sound.sync(state.call);
  if(perf-lastSaved>5000){save();lastSaved=perf;}
  const d=new Date(now);$('desktop-clock').textContent=d.toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'})+'\n'+d.toLocaleDateString('en-US',{month:'numeric',day:'numeric',year:'numeric'});
},100);
