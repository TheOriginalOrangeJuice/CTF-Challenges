#include "OdWorldEntities.h"
#include "presentation/OdPresentation.h"
#include "Graphics.h"
#include "TexturePack.h"
#include "Block.h"
#include "Lighting.h"
#include <math.h>

#define OD_RENDER_VERTICES 32768
#define PI 3.14159265358979323846f
#define RGB(r,g,b) PackedCol_Make(r,g,b,255)
static GfxResourceID colour_vb,texture_vb;
static struct VertexColoured vertices[OD_RENDER_VERTICES];
static int vertex_count;
static OdVec3 origin;
static float yaw_sin,yaw_cos;
static PackedCol illumination;
static int hurt,flash;
static const int faces[6][4]={{0,4,6,2},{1,3,7,5},{0,2,3,1},{4,5,7,6},{0,1,5,4},{2,6,7,3}};
static const float shade[6]={0.70f,0.70f,0.82f,0.82f,0.55f,1.0f};

static void Flush(void) {
    if(!vertex_count)return;
    if(!colour_vb)colour_vb=Gfx_CreateScratchVb(VERTEX_FORMAT_COLOURED,OD_RENDER_VERTICES);
    Gfx_SetVertexFormat(VERTEX_FORMAT_COLOURED);Gfx_SetScratchVbData(colour_vb,vertices,vertex_count);
    Gfx_DrawVb_IndexedTris(vertex_count);vertex_count=0;
}
static PackedCol LightAt(OdVec3 p) {
    int x=(int)floorf(p.x),y=(int)floorf(p.y+1),z=(int)floorf(p.z);
    if(x<0||y<0||z<0||x>=64||y>=64||z>=64||!Lighting.Color)return PACKEDCOL_WHITE;
    return Lighting.Color(x,y,z);
}
static void Pose(OdVec3 p,float yaw) {origin=p;yaw_sin=sinf(yaw*PI/180);yaw_cos=cosf(yaw*PI/180);illumination=LightAt(p);hurt=flash=0;}
static OdVec3 Transform(OdVec3 v) {
    OdVec3 p={origin.x+v.x*yaw_cos-v.z*yaw_sin,origin.y+v.y,origin.z+v.x*yaw_sin+v.z*yaw_cos};return p;
}
static void Solid(OdVec3 p[8],PackedCol colour) {
    int f,j;OdVec3 world[8];PackedCol col;
    if(vertex_count+24>OD_RENDER_VERTICES)Flush();
    if(hurt)colour=PackedCol_Lerp(colour,RGB(255,70,70),0.55f);
    if(flash)colour=PackedCol_Lerp(colour,PACKEDCOL_WHITE,0.8f);
    colour=PackedCol_Tint(colour,illumination);
    for(j=0;j<8;j++)world[j]=Transform(p[j]);
    for(f=0;f<6;f++) {
        col=PackedCol_Scale(colour,shade[f]);
        for(j=0;j<4;j++) {
            struct VertexColoured* v=&vertices[vertex_count++];OdVec3 pnt=world[faces[f][j]];
            v->x=pnt.x;v->y=pnt.y;v->z=pnt.z;v->Col=col;
        }
    }
}
static void Box(float x,float y,float z,float w,float h,float d,PackedCol col,float pitch) {
    int i;OdVec3 p[8];float s=sinf(pitch),c=cosf(pitch);
    for(i=0;i<8;i++) {
        float yy=(i&2)?0:-h,zz=(i&4)?d*0.5f:-d*0.5f;
        p[i].x=x+((i&1)?w*0.5f:-w*0.5f);
        p[i].y=y+h+yy*c-zz*s;p[i].z=z+yy*s+zz*c;
    }
    Solid(p,col);
}
static void Beam(float ax,float ay,float az,float bx,float by,float bz,float thick,PackedCol col) {
    OdVec3 a={ax,ay,az},b={bx,by,bz},p[8],r,u,d={bx-ax,by-ay,bz-az};
    float len=sqrtf(d.x*d.x+d.y*d.y+d.z*d.z),flat;int i;
    if(len<0.001f)return;
    d.x/=len;d.y/=len;d.z/=len;flat=sqrtf(d.x*d.x+d.z*d.z);
    if(flat<0.01f) {r.x=1;r.y=0;r.z=0;}else {r.x=-d.z/flat;r.y=0;r.z=d.x/flat;}
    u.x=d.y*r.z-d.z*r.y;u.y=d.z*r.x-d.x*r.z;u.z=d.x*r.y-d.y*r.x;
    for(i=0;i<8;i++) {
        OdVec3 end=(i&2)?b:a;float rr=(i&1)?thick*0.5f:-thick*0.5f,uu=(i&4)?thick*0.5f:-thick*0.5f;
        p[i].x=end.x+r.x*rr+u.x*uu;p[i].y=end.y+r.y*rr+u.y*uu;p[i].z=end.z+r.z*rr+u.z*uu;
    }
    Solid(p,col);
}
static void Eyes(float y,float z,float spacing,float size,PackedCol white) {
    Box(-spacing,y,z,size,size,0.018f,white,0);Box(spacing,y,z,size,size,0.018f,white,0);
    Box(-spacing+size*0.15f,y,z-0.012f,size*0.5f,size*0.8f,0.012f,RGB(22,20,20),0);
    Box(spacing-size*0.15f,y,z-0.012f,size*0.5f,size*0.8f,0.012f,RGB(22,20,20),0);
}
static void FourLegs(float width,float front,float back,float height,float thick,PackedCol col,float walk) {
    Box(-width,0,front,thick,height,thick,col,walk);Box(width,0,front,thick,height,thick,col,-walk);
    Box(-width,0,back,thick,height,thick,col,-walk);Box(width,0,back,thick,height,thick,col,walk);
}
static void Pig(float walk) {
    PackedCol pink=RGB(229,155,159);FourLegs(0.23f,-0.32f,0.32f,0.38f,0.22f,pink,walk);
    Box(0,0.35f,0,0.68f,0.53f,1.00f,pink,0);Box(0,0.49f,-0.57f,0.50f,0.50f,0.50f,pink,0);
    Box(0,0.57f,-0.86f,0.30f,0.19f,0.12f,RGB(244,174,174),0);Eyes(0.80f,-0.827f,0.17f,0.075f,RGB(242,240,232));
    Box(-0.08f,0.63f,-0.927f,0.055f,0.055f,0.014f,RGB(150,91,103),0);Box(0.08f,0.63f,-0.927f,0.055f,0.055f,0.014f,RGB(150,91,103),0);
    Box(0,0.68f,0.56f,0.09f,0.10f,0.16f,RGB(204,126,138),0);
}
static void Cow(float walk) {
    PackedCol brown=RGB(83,62,51),white=RGB(228,225,211);FourLegs(0.25f,-0.37f,0.37f,0.52f,0.22f,brown,walk);
    Box(0,0.48f,0,0.76f,0.77f,1.12f,brown,0);Box(0,0.92f,-0.65f,0.51f,0.51f,0.48f,brown,0);
    Box(0,0.96f,-0.94f,0.48f,0.20f,0.13f,RGB(185,162,151),0);Eyes(1.25f,-0.897f,0.16f,0.09f,white);
    Box(-0.28f,1.38f,-0.60f,0.08f,0.21f,0.08f,RGB(199,190,160),0);Box(0.28f,1.38f,-0.60f,0.08f,0.21f,0.08f,RGB(199,190,160),0);
    Box(-0.385f,0.84f,-0.22f,0.014f,0.34f,0.45f,white,0);Box(0.385f,0.54f,0.22f,0.014f,0.47f,0.43f,white,0);
    Box(0.13f,1.253f,0.18f,0.37f,0.013f,0.38f,white,0);Box(-0.1f,0.51f,0.57f,0.34f,0.35f,0.014f,white,0);
    Box(0,0.35f,0.22f,0.30f,0.15f,0.36f,RGB(211,155,153),0);
}
static void Sheep(float walk,int sheared) {
    PackedCol face=RGB(173,159,141),wool=RGB(226,225,216);FourLegs(0.26f,-0.37f,0.37f,0.55f,0.19f,face,walk);
    Box(0,0.5f,0,sheared?0.65f:0.89f,sheared?0.52f:0.77f,sheared?1.0f:1.15f,sheared?face:wool,0);
    Box(0,0.78f,-0.70f,0.44f,0.50f,0.48f,face,0);Eyes(1.08f,-0.947f,0.15f,0.075f,RGB(243,242,230));
    Box(0,0.84f,-0.957f,0.15f,0.10f,0.025f,RGB(107,93,85),0);
    if(!sheared) {
        Box(0,1.22f,-0.64f,0.51f,0.15f,0.48f,wool,0);
        Box(-0.45f,0.73f,-0.18f,0.04f,0.25f,0.34f,RGB(204,205,197),0);
        Box(0.45f,0.61f,0.22f,0.04f,0.31f,0.27f,RGB(215,215,204),0);
    }
}
static void Chicken(float walk) {
    PackedCol white=RGB(232,232,222),gold=RGB(216,169,55);
    Box(-0.10f,0,-0.02f,0.06f,0.29f,0.06f,gold,walk);Box(0.10f,0,-0.02f,0.06f,0.29f,0.06f,gold,-walk);
    Box(-0.10f,0,-0.08f,0.13f,0.05f,0.21f,gold,0);Box(0.10f,0,-0.08f,0.13f,0.05f,0.21f,gold,0);
    Box(0,0.28f,0.03f,0.43f,0.42f,0.51f,white,0);Box(0,0.57f,-0.24f,0.31f,0.39f,0.30f,white,0);
    Box(-0.25f,0.37f,0.03f,0.09f,0.29f,0.38f,RGB(207,208,198),walk*0.3f);
    Box(0.25f,0.37f,0.03f,0.09f,0.29f,0.38f,RGB(207,208,198),-walk*0.3f);
    Box(0,0.67f,-0.44f,0.25f,0.10f,0.17f,gold,0);Box(0,0.55f,-0.41f,0.11f,0.13f,0.07f,RGB(187,42,32),0);
    Eyes(0.82f,-0.397f,0.105f,0.045f,white);
}
static void Zombie(float walk) {
    PackedCol skin=RGB(102,139,67),shirt=RGB(39,135,142),pants=RGB(61,62,133);
    Box(-0.13f,0,0,0.23f,0.70f,0.25f,pants,walk);Box(0.13f,0,0,0.23f,0.70f,0.25f,pants,-walk);
    Box(0,0.7f,0,0.52f,0.73f,0.28f,shirt,0);Box(0,1.43f,0,0.50f,0.50f,0.50f,skin,0);
    Box(-0.37f,1.12f,-0.28f,0.22f,0.23f,0.70f,skin,0);Box(0.37f,1.12f,-0.28f,0.22f,0.23f,0.70f,skin,0);
    Box(-0.37f,1.12f,0.02f,0.225f,0.235f,0.18f,shirt,0);Box(0.37f,1.12f,0.02f,0.225f,0.235f,0.18f,shirt,0);
    Eyes(1.70f,-0.258f,0.14f,0.09f,RGB(75,88,55));Box(0,1.51f,-0.26f,0.22f,0.08f,0.018f,RGB(56,77,43),0);
    Box(-0.12f,1.83f,-0.257f,0.12f,0.06f,0.018f,RGB(125,153,80),0);Box(0.12f,0.75f,-0.149f,0.12f,0.15f,0.018f,RGB(61,111,116),0);
}
static void Skeleton(float walk) {
    PackedCol bone=RGB(197,198,188),shadow=RGB(126,128,125);int i;
    Box(-0.13f,0,0,0.12f,0.78f,0.12f,bone,walk);Box(0.13f,0,0,0.12f,0.78f,0.12f,bone,-walk);
    Box(0,0.79f,0,0.11f,0.67f,0.11f,shadow,0);
    for(i=0;i<4;i++)Box(0,0.91f+i*0.13f,0,0.46f,0.07f,0.20f,bone,0);
    Box(0,0.78f,0,0.35f,0.10f,0.16f,bone,0);Box(0,1.45f,0,0.50f,0.50f,0.48f,bone,0);
    Beam(-0.29f,1.36f,0,-0.29f,1.05f,-0.55f,0.12f,bone);Beam(0.29f,1.36f,0,0.10f,1.07f,-0.45f,0.12f,bone);
    Box(-0.13f,1.71f,-0.247f,0.13f,0.13f,0.018f,RGB(48,51,48),0);Box(0.13f,1.71f,-0.247f,0.13f,0.13f,0.018f,RGB(48,51,48),0);
    Box(0,1.59f,-0.247f,0.07f,0.10f,0.018f,RGB(72,72,65),0);Box(0,1.51f,-0.247f,0.30f,0.045f,0.018f,RGB(66,68,65),0);
    Beam(-0.29f,0.70f,-0.58f,-0.29f,1.09f,-0.72f,0.055f,RGB(130,93,52));
    Beam(-0.29f,1.09f,-0.72f,-0.29f,1.48f,-0.58f,0.055f,RGB(130,93,52));
    Beam(-0.29f,0.70f,-0.58f,-0.29f,1.48f,-0.58f,0.018f,RGB(220,216,193));
}
static void Spider(float walk) {
    PackedCol dark=RGB(55,44,40),leg=RGB(45,36,32);int i,s;
    Box(0,0.25f,0.35f,0.80f,0.48f,0.87f,dark,0);Box(0,0.25f,-0.17f,0.50f,0.35f,0.45f,leg,0);
    Box(0,0.22f,-0.53f,0.56f,0.42f,0.45f,dark,0);
    for(s=-1;s<=1;s+=2)for(i=0;i<4;i++) {
        float z=-0.40f+i*0.24f,kick=sinf(walk*2+i)*0.06f;
        float endz=z+(i-1.5f)*0.35f;
        Beam(s*0.23f,0.43f,z,s*0.82f,0.58f+kick,endz,0.09f,leg);
        Beam(s*0.82f,0.58f+kick,endz,s*1.1f,0.06f,endz+(i-1.5f)*0.11f,0.08f,leg);
    }
    for(i=0;i<4;i++)Box(-0.19f+i*0.125f,0.43f,-0.763f,0.07f,0.07f,0.018f,RGB(211,28,23),0);
    Box(-0.14f,0.33f,-0.765f,0.06f,0.06f,0.018f,RGB(174,19,18),0);Box(0.14f,0.33f,-0.765f,0.06f,0.06f,0.018f,RGB(174,19,18),0);
}
static void Creeper(float walk) {
    PackedCol green=RGB(97,157,57),patch=RGB(59,111,40),black=RGB(25,42,24);
    FourLegs(0.19f,-0.21f,0.21f,0.48f,0.25f,green,walk);
    Box(0,0.48f,0,0.43f,0.76f,0.28f,green,0);Box(0,1.24f,0,0.52f,0.52f,0.52f,green,0);
    Box(-0.13f,1.54f,-0.269f,0.13f,0.13f,0.018f,black,0);Box(0.13f,1.54f,-0.269f,0.13f,0.13f,0.018f,black,0);
    Box(0,1.43f,-0.269f,0.13f,0.13f,0.018f,black,0);Box(0,1.34f,-0.269f,0.26f,0.13f,0.018f,black,0);
    Box(-0.097f,1.27f,-0.269f,0.065f,0.10f,0.018f,black,0);Box(0.097f,1.27f,-0.269f,0.065f,0.10f,0.018f,black,0);
    Box(-0.14f,1.68f,-0.268f,0.12f,0.07f,0.017f,RGB(139,183,94),0);
    Box(0.13f,0.80f,-0.148f,0.12f,0.19f,0.017f,patch,0);Box(-0.12f,1.08f,-0.148f,0.12f,0.12f,0.017f,RGB(153,187,108),0);
    Box(0.222f,0.56f,0,0.017f,0.15f,0.13f,patch,0);Box(-0.269f,1.37f,0.10f,0.017f,0.20f,0.14f,patch,0);
}
static void Mob(const OdMob* m) {
    float walk=sinf(m->animation*2.2f)*0.55f;
    Pose(m->position,m->yaw);hurt=m->hurt_time>0;flash=m->kind==OD_MOB_CREEPER&&m->fuse>0&&((int)(m->fuse*9)&1);
    switch(m->kind) {
    case OD_MOB_PIG:Pig(walk);break;case OD_MOB_COW:Cow(walk);break;case OD_MOB_SHEEP:Sheep(walk,m->sheared);break;
    case OD_MOB_CHICKEN:Chicken(walk);break;case OD_MOB_ZOMBIE:Zombie(walk);break;case OD_MOB_SKELETON:Skeleton(walk);break;
    case OD_MOB_SPIDER:Spider(walk);break;case OD_MOB_CREEPER:Creeper(walk);break;
    }
    if(m->burn_time>0) {
        int i;illumination=PACKEDCOL_WHITE;hurt=flash=0;
        for(i=0;i<6;i++) {
            float angle=i*PI/3,x=cosf(angle)*0.29f,z=sinf(angle)*0.29f;
            float height=0.50f+0.20f*sinf(m->burn_clock*PI*2+i);
            Box(x,0.12f,z,0.15f,height,0.13f,RGB(244,107,16),0);
            Box(x,0.14f,z,0.085f,height*0.65f,0.15f,RGB(255,211,55),0);
            Box(x,0.12f+height,z,0.065f,0.18f,0.06f,RGB(255,154,24),0);
        }
    }
}

static void DrawTextured(struct VertexTextured* v,int count,GfxResourceID tex) {
    if(!texture_vb)texture_vb=Gfx_CreateScratchVb(VERTEX_FORMAT_TEXTURED,24);
    Gfx_SetVertexFormat(VERTEX_FORMAT_TEXTURED);Gfx_BindTexture(tex);Gfx_SetScratchVbData(texture_vb,v,count);Gfx_DrawVb_IndexedTris(count);
}
static void TexturedFace(OdVec3 p[8],int face,TextureRec uv,GfxResourceID texture,PackedCol color) {
    struct VertexTextured v[4];int j;
    for(j=0;j<4;j++) {
        OdVec3 local=p[faces[face][j]],pt=Transform(local);v[j].x=pt.x;v[j].y=pt.y;v[j].z=pt.z;v[j].Col=color;
        if(face==FACE_XMIN||face==FACE_XMAX) {
            v[j].U=local.z==p[0].z?uv.u1:uv.u2;
            v[j].V=local.y==p[0].y?uv.v2:uv.v1;
        } else if(face==FACE_YMIN||face==FACE_YMAX) {
            v[j].U=local.x==p[0].x?uv.u1:uv.u2;
            v[j].V=local.z==p[0].z?uv.v1:uv.v2;
        } else {
            v[j].U=local.x==p[0].x?uv.u1:uv.u2;
            v[j].V=local.y==p[0].y?uv.v2:uv.v1;
        }
    }
    DrawTextured(v,4,texture);
}
static void Drop(const OdDrop* d,double time) {
    int j,id=d->stack.item_id;OdVec3 p=d->position,corners[8];TextureRec uv;GfxResourceID tex;PackedCol light;
    p.y+=0.12f+sinf((float)time*2+(float)id)*0.05f;Pose(p,(float)time*55);light=illumination;
    if(id>0&&id<256) {
        float half=0.17f;
        for(j=0;j<8;j++) {corners[j].x=(j&1)?half:-half;corners[j].y=(j&2)?half*2:0;corners[j].z=(j&4)?half:-half;}
        if(Blocks.Draw[id]==DRAW_SPRITE) {
            int atlas;uv=Atlas1D_TexRec(Block_Tex(id,FACE_ZMIN),1,&atlas);tex=Atlas1D.TexIds[atlas];
            corners[0].z=corners[1].z=corners[2].z=corners[3].z=0;TexturedFace(corners,FACE_ZMIN,uv,tex,light);
        } else for(j=0;j<6;j++) {
            int atlas;uv=Atlas1D_TexRec(Block_Tex(id,j),1,&atlas);tex=Atlas1D.TexIds[atlas];
            TexturedFace(corners,j,uv,tex,PackedCol_Scale(light,shade[j]));
        }
    } else if(OdPresentation_GetItemTexture(id,&tex,&uv)) {
        for(j=0;j<8;j++) {corners[j].x=(j&1)?0.22f:-0.22f;corners[j].y=(j&2)?0.44f:0;corners[j].z=0;}
        TexturedFace(corners,FACE_ZMIN,uv,tex,light);
    }
}
static void Cracks(const OdGameSnapshot* g) {
    int i,f,tile,atlas;OdVec3 p[8],at={(float)g->mining_x,(float)g->mining_y,(float)g->mining_z};TextureRec uv;
    if(g->mining_x<0||g->mining_progress<=0)return;
    tile=240+(int)(g->mining_progress*10);if(tile>249)tile=249;
    uv=Atlas1D_TexRec(tile,1,&atlas);Pose(at,0);
    for(i=0;i<8;i++) {p[i].x=(i&1)?1.003f:-0.003f;p[i].y=(i&2)?1.003f:-0.003f;p[i].z=(i&4)?1.003f:-0.003f;}
    for(f=0;f<6;f++)TexturedFace(p,f,uv,Atlas1D.TexIds[atlas],PACKEDCOL_WHITE);
}
void OdWorldEntities_Render(const OdGameSnapshot* g) {
    int i;
    if(!g||Gfx.LostContext)return;
    Gfx_SetDepthTest(true);Gfx_SetDepthWrite(true);Gfx_SetFaceCulling(false);Gfx_SetAlphaBlending(false);Gfx_SetAlphaTest(false);
    vertex_count=0;
    for(i=0;i<OD_MAX_MOBS;i++)if(g->mobs[i].active)Mob(&g->mobs[i]);
    for(i=0;i<OD_MAX_PROJECTILES;i++)if(g->projectiles[i].active) {
        const OdProjectile* a=&g->projectiles[i];float len=sqrtf(a->velocity.x*a->velocity.x+a->velocity.y*a->velocity.y+a->velocity.z*a->velocity.z);
        Pose(a->position,0);
        if(len>0.01f) {
            float x=-a->velocity.x/len*0.62f,y=-a->velocity.y/len*0.62f,z=-a->velocity.z/len*0.62f;
            Beam(0,0,0,x,y,z,0.035f,RGB(155,111,58));Box(0,-0.04f,0,0.08f,0.08f,0.08f,RGB(174,177,178),0);
            Beam(x,y,z,x*0.75f,y*0.75f,z*0.75f,0.09f,RGB(225,225,212));
        }
    }
    Flush();Gfx_SetAlphaTest(true);
    if(Atlas1D.Count>0) {
        for(i=0;i<OD_MAX_DROPS;i++)if(g->drops[i].active)Drop(&g->drops[i],g->elapsed);
        Cracks(g);
    }
    Gfx_SetAlphaTest(false);Gfx_SetVertexFormat(VERTEX_FORMAT_TEXTURED);
}
void OdWorldEntities_Free(void) {Gfx_DeleteScratchVb(&colour_vb);Gfx_DeleteScratchVb(&texture_vb);vertex_count=0;}
