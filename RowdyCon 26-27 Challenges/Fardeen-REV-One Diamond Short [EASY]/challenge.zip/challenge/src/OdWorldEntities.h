#ifndef OD_WORLD_ENTITIES_H
#define OD_WORLD_ENTITIES_H
#include "game/OdGame.h"
/* World-space pass with depth testing/writes enabled. Call before terrain;
 * terrain then occludes entities and fills the transparent mining-crack gaps. */
void OdWorldEntities_Render(const OdGameSnapshot* game);
void OdWorldEntities_Free(void);
#endif
