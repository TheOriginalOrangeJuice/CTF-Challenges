#ifndef OD_TYPES_H
#define OD_TYPES_H
#include <stdint.h>
#define OD_INVENTORY_SLOTS 36
#define OD_CRAFT_SLOTS 9
/* Actual authoritative signed 32-bit count. Naturally aligned at offset four. */
typedef struct OdStack { int32_t item_id; volatile int32_t count; int32_t damage; } OdStack;
typedef struct OdCarried { OdStack inventory[36]; OdStack cursor; OdStack craft[9]; } OdCarried;
#endif
