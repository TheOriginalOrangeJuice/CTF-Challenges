#ifndef OD_AUDIO_MIXER_H
#define OD_AUDIO_MIXER_H
#include <stddef.h>
#include <stdint.h>
#define OD_AUDIO_VOICES 16
#define OD_AUDIO_CLIPS 14
#define OD_AUDIO_RATE 22050
typedef struct { const int16_t* samples; size_t count; } OdAudioClip;
typedef struct {
    const OdAudioClip* clip;
    size_t position;
    uint64_t serial;
    int priority, gain;
} OdAudioVoice;
typedef struct {
    OdAudioVoice voices[OD_AUDIO_VOICES];
    uint64_t serial;
    unsigned accepted, dropped, peak_voices;
    int enabled;
} OdAudioMixer;
void OdAudioMixer_Init(OdAudioMixer* mixer);
void OdAudioMixer_Enable(OdAudioMixer* mixer, int enabled);
int OdAudioMixer_Play(OdAudioMixer* mixer, const OdAudioClip* clip, int priority, int gain);
void OdAudioMixer_Render(OdAudioMixer* mixer, int16_t* output, size_t count);
unsigned OdAudioMixer_Active(const OdAudioMixer* mixer);
int OdAudioMixer_Priority(int kind);
int OdAudioMixer_Gain(int kind);
#endif
