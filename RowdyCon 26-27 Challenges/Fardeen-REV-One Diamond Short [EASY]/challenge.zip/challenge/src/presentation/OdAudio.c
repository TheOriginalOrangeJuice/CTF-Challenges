/* One WinMM stream mixes independent PCM voices. No effect restarts another. */
#include "OdAudio.h"
#include "OdAudioMixer.h"
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <mmsystem.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_COUNT 4
#define BUFFER_SAMPLES 256
static HWAVEOUT device;
static HANDLE wakeEvent, stopEvent, worker;
static CRITICAL_SECTION lock;
static int initialized;
static WAVEHDR headers[BUFFER_COUNT];
static int queued[BUFFER_COUNT];
static int16_t pcm[BUFFER_COUNT][BUFFER_SAMPLES];
static OdAudioClip clips[OD_AUDIO_CLIPS];
static OdAudioMixer mixer;
static OdAudioStats stats;

static unsigned u16(const unsigned char* p) { return p[0]|((unsigned)p[1]<<8); }
static unsigned u32(const unsigned char* p) { return u16(p)|(u16(p+2)<<16); }
static int loadClip(int kind,const char* name) {
    char path[128]; unsigned char riff[12],chunk[8],fmt[16];
    FILE* file; int formatOK=0,loaded=0;
    snprintf(path,sizeof path,"assets/sounds/%s.wav",name);
    file=fopen(path,"rb"); if(!file)return 0;
    if(fread(riff,1,12,file)!=12||memcmp(riff,"RIFF",4)||memcmp(riff+8,"WAVE",4))goto done;
    while(fread(chunk,1,8,file)==8) {
        unsigned size=u32(chunk+4);
        if(size>OD_AUDIO_RATE*2*10)break;
        if(!memcmp(chunk,"fmt ",4)) {
            if(size<16||fread(fmt,1,16,file)!=16)break;
            formatOK=u16(fmt)==1&&u16(fmt+2)==1&&u32(fmt+4)==OD_AUDIO_RATE&&u16(fmt+12)==2&&u16(fmt+14)==16;
            if(fseek(file,(long)(size-16+(size&1)),SEEK_CUR))break;
        } else if(!memcmp(chunk,"data",4)) {
            int16_t* samples;
            if(!formatOK||!size||(size&1))break;
            samples=(int16_t*)malloc(size); if(!samples)break;
            if(fread(samples,1,size,file)!=size) { free(samples); break; }
            clips[kind].samples=samples; clips[kind].count=size/2; loaded=1; break;
        } else if(fseek(file,(long)(size+(size&1)),SEEK_CUR))break;
    }
done:
    fclose(file); return loaded;
}
static DWORD WINAPI outputThread(void* unused) {
    HANDLE events[2]={stopEvent,wakeEvent}; int i,j; (void)unused;
    for(;;) {
        EnterCriticalSection(&lock);
        for(i=0;i<BUFFER_COUNT;i++) {
            MMRESULT result;
            if(queued[i]&&!(headers[i].dwFlags&WHDR_DONE))continue;
            if(queued[i]) { stats.completed_buffers++; queued[i]=0; }
            OdAudioMixer_Render(&mixer,pcm[i],BUFFER_SAMPLES);
            for(j=0;j<BUFFER_SAMPLES;j++)stats.nonzero_samples+=pcm[i][j]!=0;
            result=waveOutWrite(device,&headers[i],sizeof headers[i]);
            if(result) { stats.device_result=result; LeaveCriticalSection(&lock); return 1; }
            queued[i]=1; stats.submitted_buffers++;
        }
        LeaveCriticalSection(&lock);
        if(WaitForMultipleObjects(2,events,FALSE,INFINITE)!=WAIT_OBJECT_0+1)break;
    }
    return 0;
}
int OdAudio_Init(void) {
    static const char* names[OD_AUDIO_CLIPS]={"step","dig","break","place","pickup","hurt","eat","swing","mob_hurt","bow","fuse","explode","craft","death"};
    WAVEFORMATEX format; MMRESULT result; int i;
    if(initialized)return device!=NULL;
    memset(&stats,0,sizeof stats); memset(headers,0,sizeof headers); memset(queued,0,sizeof queued);
    OdAudioMixer_Init(&mixer); InitializeCriticalSection(&lock); initialized=1;
    for(i=0;i<OD_AUDIO_CLIPS;i++)stats.loaded_clips+=loadClip(i,names[i]);
    wakeEvent=CreateEventW(NULL,FALSE,FALSE,NULL); stopEvent=CreateEventW(NULL,TRUE,FALSE,NULL);
    if(!wakeEvent||!stopEvent) { stats.device_result=MMSYSERR_NOMEM; goto fail; }
    memset(&format,0,sizeof format); format.wFormatTag=WAVE_FORMAT_PCM; format.nChannels=1;
    format.nSamplesPerSec=OD_AUDIO_RATE; format.wBitsPerSample=16; format.nBlockAlign=2; format.nAvgBytesPerSec=OD_AUDIO_RATE*2;
    result=waveOutOpen(&device,WAVE_MAPPER,&format,(DWORD_PTR)wakeEvent,0,CALLBACK_EVENT);
    if(result) { device=NULL; stats.device_result=result; goto fail; }
    for(i=0;i<BUFFER_COUNT;i++) {
        headers[i].lpData=(LPSTR)pcm[i]; headers[i].dwBufferLength=sizeof pcm[i];
        result=waveOutPrepareHeader(device,&headers[i],sizeof headers[i]);
        if(result) { stats.device_result=result; goto fail; }
    }
    worker=CreateThread(NULL,0,outputThread,NULL,0,NULL);
    if(!worker) { stats.device_result=MMSYSERR_NOMEM; goto fail; }
    return 1;
fail:
    OdAudio_Free(); return 0;
}
void OdAudio_Free(void) {
    int i;
    if(!initialized)return;
    if(worker) { SetEvent(stopEvent); WaitForSingleObject(worker,INFINITE); CloseHandle(worker); worker=NULL; }
    if(device) {
        waveOutReset(device);
        for(i=0;i<BUFFER_COUNT;i++)if(headers[i].dwFlags&WHDR_PREPARED)waveOutUnprepareHeader(device,&headers[i],sizeof headers[i]);
        waveOutClose(device); device=NULL;
    }
    if(wakeEvent) { CloseHandle(wakeEvent); wakeEvent=NULL; }
    if(stopEvent) { CloseHandle(stopEvent); stopEvent=NULL; }
    for(i=0;i<OD_AUDIO_CLIPS;i++) { free((void*)clips[i].samples); memset(&clips[i],0,sizeof clips[i]); }
    DeleteCriticalSection(&lock); initialized=0;
}
void OdAudio_Play(int kind) { OdAudio_PlayVolume(kind,256); }
void OdAudio_PlayVolume(int kind,int volume) {
    if(!initialized||!device||kind<0||kind>=OD_AUDIO_CLIPS)return;
    if(volume<=0)return;
    if(volume>256)volume=256;
    EnterCriticalSection(&lock);
    OdAudioMixer_Play(&mixer,&clips[kind],OdAudioMixer_Priority(kind),OdAudioMixer_Gain(kind)*volume/256);
    LeaveCriticalSection(&lock);
}
void OdAudio_SetEnabled(int enabled) {
    if(!initialized)return;
    EnterCriticalSection(&lock);
    OdAudioMixer_Enable(&mixer,enabled);
    /* Reset queued PCM too, so mute never leaves a long effect playing. */
    if(!enabled&&device) { MMRESULT result=waveOutReset(device); if(result)stats.device_result=result; }
    LeaveCriticalSection(&lock);
}
void OdAudio_GetStats(OdAudioStats* out) {
    if(initialized)EnterCriticalSection(&lock);
    *out=stats; out->accepted=mixer.accepted; out->dropped=mixer.dropped;
    out->peak_voices=mixer.peak_voices; out->active_voices=OdAudioMixer_Active(&mixer);
    if(initialized)LeaveCriticalSection(&lock);
}
