#include "OdPresentation.h"
#include "Graphics.h"
#include "Bitmap.h"
#include "Stream.h"
#include "String_.h"
#include "Platform.h"
#include "Input.h"
#include "Camera.h"
#include "IsometricDrawer.h"
#include "TexturePack.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

void OdCloudClock_Update(int seconds,int active);
void OdCloudClock_Free(void);

static OdGameSnapshot game;
static OdTrial trial;
static OdReward reward;
static OdUiCallback action;
static GfxResourceID font_tex,item_tex,terrain_tex,iso_vb,tool_vb;
static unsigned char glyph_width[256];
static int loaded,scale=2,ww,hh,mx,my,menu,settings_parent,focus=-1;
static int sound_on=1,reduced_motion,fullscreen,sensitivity=100;
enum { MENU_NONE,MENU_PAUSE,MENU_SETTINGS };
enum { UI_RESUME=100,UI_OPTIONS,UI_DONE };
typedef struct UiButton {int x,y,w,h,id,value;} UiButton;
typedef struct UiSlot {int x,y,area,index;const OdStack* stack;} UiSlot;
static UiButton buttons[16];
static UiSlot slots[80];
static int button_count,slot_count,hover_item;

static PackedCol rgb(int r,int g,int b) {return PackedCol_Make(r,g,b,255);}
static void rect(int x,int y,int w,int h,PackedCol col) {
    Gfx_Draw2DFlat(x*scale,y*scale,w*scale,h*scale,col);
}
static void texture(GfxResourceID id,int tw,int th,int sx,int sy,int sw,int sh,
                    int x,int y,int w,int h,PackedCol col) {
    struct Texture t;
    if(!id)return;
    t.ID=id;t.x=x*scale;t.y=y*scale;t.width=w*scale;t.height=h*scale;
    t.uv.u1=(float)sx/tw;t.uv.v1=(float)sy/th;
    t.uv.u2=(float)(sx+sw)/tw;t.uv.v2=(float)(sy+sh)/th;
    Gfx_BindTexture(id);Gfx_Draw2DTexture(&t,col);
}
static int text_width(const char* s,int size) {
    int n=0;
    for(;*s;s++)n+=(glyph_width[(unsigned char)*s]+1)*size;
    return n? n-size:0;
}
static void text(int x,int y,const char* s,PackedCol col,int size,int shadow) {
    int pass;const unsigned char* c;
    for(pass=shadow?1:0;pass>=0;pass--) {
        int left=x+pass*size;
        PackedCol color=pass?rgb(35,35,35):col;
        for(c=(const unsigned char*)s;*c;c++) {
            texture(font_tex,128,128,(*c%16)*8,(*c/16)*8,8,8,
                    left,y+pass*size,8*size,8*size,color);
            left+=(glyph_width[*c]+1)*size;
        }
    }
}
static void centered(int y,const char* s,PackedCol col,int size) {
    text((ww-text_width(s,size))/2,y,s,col,size,1);
}
static int wrap(int x,int y,const char* message,int max_width,PackedCol col) {
    char line[160];int n=0,i=0,lastspace=-1;
    while(message[i]) {
        char c=message[i++];
        if(c=='\n') {line[n]=0;text(x,y,line,col,1,1);y+=12;n=0;lastspace=-1;continue;}
        if(n<158)line[n++]=c;
        line[n]=0;
        if(c==' ')lastspace=n-1;
        if(text_width(line,1)>max_width||n>=158) {
            int cut=lastspace>0?lastspace:n-1;
            i-=n-cut-1;
            line[cut]=0;text(x,y,line,col,1,1);y+=12;n=0;lastspace=-1;
        }
    }
    if(n){line[n]=0;text(x,y,line,col,1,1);y+=12;}
    return y;
}
static GfxResourceID load_png(const char* path,int font) {
    struct Stream stream;struct Bitmap bmp;
    GfxResourceID id;cc_string name=String_FromReadonly(path);
    int c,x,y,last;
    if(Stream_OpenFile(&stream,&name))return 0;
    if(Png_Decode(&bmp,&stream)){stream.Close(&stream);return 0;}
    stream.Close(&stream);
    if(font&&bmp.width==128&&bmp.height==128) {
        for(c=0;c<256;c++) {
            last=-1;
            for(y=0;y<8;y++)for(x=0;x<8;x++)
                if(BitmapCol_A(bmp.scan0[((c/16)*8+y)*128+(c%16)*8+x])>127&&x>last)last=x;
            glyph_width[c]=(unsigned char)(last<0?3:last+1);
        }
        glyph_width[32]=3;
    }
    id=Gfx_CreateTexture(&bmp,TEXTURE_FLAG_MANAGED,false);
    Mem_Free(bmp.scan0);return id;
}
static void assets(void) {
    if(loaded||Gfx.LostContext)return;
    if(!font_tex)font_tex=load_png("assets/default.png",1);
    if(!item_tex)item_tex=load_png("assets/items.png",0);
    if(!terrain_tex)terrain_tex=load_png("assets/terrain.png",0);
    loaded=font_tex&&item_tex&&terrain_tex;
}
int OdPresentation_GetItemTexture(int item_id,GfxResourceID* texture_id,TextureRec* uv) {
    int tile=item_id-256;
    if(tile<0||tile>=256)return 0;
    assets();if(!item_tex)return 0;
    *texture_id=item_tex;uv->u1=(tile%16)/16.0f;uv->v1=(tile/16)/16.0f;
    uv->u2=uv->u1+1/16.0f;uv->v2=uv->v1+1/16.0f;return 1;
}
void OdPresentation_Init(OdUiCallback callback) {
    int i;action=callback;memset(&game,0,sizeof(game));memset(&trial,0,sizeof(trial));
    memset(&reward,0,sizeof(reward));trial.remaining_seconds=900;
    for(i=0;i<256;i++)glyph_width[i]=5;
    sensitivity=Camera.Sensitivity;assets();
}
void OdPresentation_ContextLost(void) {
    Gfx_DeleteTexture(&font_tex);Gfx_DeleteTexture(&item_tex);Gfx_DeleteTexture(&terrain_tex);
    Gfx_DeleteDynamicVb(&iso_vb);Gfx_DeleteDynamicVb(&tool_vb);
    loaded=0;OdCloudClock_Free();
}
void OdPresentation_Free(void) {OdPresentation_ContextLost();}
void OdPresentation_Update(const OdGameSnapshot* g,const OdTrial* t,const OdReward* r) {
    if(g)game=*g;if(t)trial=*t;if(r)reward=*r;
    if(trial.state==OD_TRIAL_MENU)menu=menu==MENU_SETTINGS?MENU_SETTINGS:MENU_NONE;
    OdCloudClock_Update(trial.remaining_seconds,trial.state!=OD_TRIAL_MENU);
}
static void bevel(int x,int y,int w,int h,int hover) {
    rect(x,y,w,h,rgb(0,0,0));rect(x+1,y+1,w-2,h-2,hover?rgb(117,132,174):rgb(111,111,111));
    rect(x+1,y+1,w-2,1,hover?rgb(184,196,226):rgb(180,180,180));
    rect(x+1,y+1,1,h-2,rgb(160,160,160));
    rect(x+1,y+h-2,w-2,1,rgb(54,54,54));rect(x+w-2,y+1,1,h-2,rgb(54,54,54));
}
static void button(int x,int y,int w,const char* label,int id,int value) {
    int hover=(mx>=x&&mx<x+w&&my>=y&&my<y+20)||focus==button_count;
    UiButton* b;
    if(button_count>=16)return;b=&buttons[button_count++];
    b->x=x;b->y=y;b->w=w;b->h=20;b->id=id;b->value=value;
    bevel(x,y,w,20,hover);
    text(x+(w-text_width(label,1))/2,y+6,label,hover?rgb(255,255,160):rgb(235,235,235),1,1);
}
static void icon(const OdStack* stack,int x,int y,int size) {
    int item,count;float pct;char count_text[24];
    if(!stack||(count=stack->count)<=0||(item=stack->item_id)<=0)return;
    if(item<256) {
        struct VertexTextured v[ISOMETRICDRAWER_MAXVERTICES];
        int state[3],n;
        IsometricDrawer_BeginBatch(v,state);
        /* IsometricDrawer's size is the projected half-width; its cube is
         * slightly taller than wide. Fit the complete cube in the 16px slot. */
        IsometricDrawer_AddBatch((BlockID)item,(float)(size*scale)*.43f,(float)((x+size/2)*scale),(float)((y+size/2)*scale));
        n=IsometricDrawer_EndBatch();
        if(n) {
            if(!iso_vb)iso_vb=Gfx_CreateDynamicVb(VERTEX_FORMAT_TEXTURED,12);
            Gfx_SetVertexFormat(VERTEX_FORMAT_TEXTURED);
            Gfx_SetDynamicVbData(iso_vb,v,n);Gfx_BindDynamicVb(iso_vb);
            Gfx_SetAlphaTest(true);IsometricDrawer_Render(n,0,state);Gfx_SetAlphaTest(false);
        }
    } else if(item<512) {
        item-=256;
        texture(item_tex,256,256,(item%16)*16,(item/16)*16,16,16,x,y,size,size,PACKEDCOL_WHITE);
    }
    if(stack->damage>0&&OdGame_ItemDurability(stack->item_id)>0) {
        pct=1-(float)stack->damage/OdGame_ItemDurability(stack->item_id);
        if(pct<0)pct=0;
        rect(x,y+size-2,size,2,rgb(0,0,0));
        rect(x,y+size-2,(int)((size-1)*pct),1,rgb((int)(255*(1-pct)),(int)(255*pct),0));
    }
    if(count!=1) {
        snprintf(count_text,sizeof(count_text),"%d",count);
        text(x+size-text_width(count_text,1)+1,y+size-7,count_text,PACKEDCOL_WHITE,1,1);
    }
}
static void slot(int x,int y,const OdStack* s,int area,int index) {
    UiSlot* sl;int hover;
    if(slot_count>=80)return;
    sl=&slots[slot_count++];sl->x=x;sl->y=y;sl->area=area;sl->index=index;sl->stack=s;
    rect(x,y,18,18,rgb(55,55,55));rect(x+1,y+1,17,17,rgb(255,255,255));
    rect(x+1,y+1,16,16,rgb(139,139,139));
    hover=mx>=x&&mx<x+18&&my>=y&&my<y+18;
    if(hover) {rect(x+1,y+1,16,16,rgb(183,183,183));if(s&&s->count>0)hover_item=s->item_id;}
    icon(s,x+1,y+1,16);
}
static void heart(int x,int y,int amount) {
    static const unsigned char mask[8]={0x36,0x7f,0x7f,0x7f,0x3e,0x1c,0x08,0};
    int px,py;
    for(py=0;py<7;py++)for(px=0;px<7;px++)if(mask[py]&(1<<(6-px))) {
        int filled=amount==2||(amount==1&&px<3);
        rect(x+px,y+py,1,1,filled?rgb(180,18,25):rgb(48,24,25));
    }
    if(amount){rect(x+1,y+1,1,1,rgb(255,180,180));if(amount==2)rect(x+4,y+1,1,1,rgb(255,180,180));}
}
static void held_item(void) {
    struct VertexTextured v[4];
    const OdStack* s;
    float size,cx,cy,angle,cs,sn;int i,item;
    const float corner[4][2]={{-1,-1},{-1,1},{1,1},{1,-1}};
    if(!game.inventory||OdPresentation_BlocksInput())return;
    s=&game.inventory[game.selected];item=s->item_id;
    if(item<256||item>=512||s->count<=0)return;
    item-=256;
    size=hh*.23f;cx=ww*.81f;cy=hh*.83f;
    angle=-.38f;
    if(!reduced_motion&&game.swing_time>0) {
        float swing=sinf(fminf(1,game.swing_time/.3f)*3.14159265f);
        angle-=swing*.8f;cx-=swing*ww*.06f;cy+=swing*hh*.05f;
    }
    cs=cosf(angle);sn=sinf(angle);
    for(i=0;i<4;i++) {
        float x=corner[i][0]*size,y=corner[i][1]*size;
        v[i].x=(cx+x*cs-y*sn)*scale;v[i].y=(cy+x*sn+y*cs)*scale;v[i].z=0;
        v[i].Col=PACKEDCOL_WHITE;
        v[i].U=((item%16)*16+(corner[i][0]>0?16:0))/256.0f;
        v[i].V=((item/16)*16+(corner[i][1]>0?16:0))/256.0f;
    }
    if(!tool_vb)tool_vb=Gfx_CreateDynamicVb(VERTEX_FORMAT_TEXTURED,4);
    Gfx_SetVertexFormat(VERTEX_FORMAT_TEXTURED);Gfx_SetDynamicVbData(tool_vb,v,4);
    Gfx_BindDynamicVb(tool_vb);Gfx_BindTexture(item_tex);
    Gfx_SetAlphaTest(true);Gfx_DrawVb_IndexedTris(4);Gfx_SetAlphaTest(false);
}
static void hud(void) {
    int x=(ww-182)/2,y=hh-24,i;char status[64];
    held_item();
    if(!game.inventory)return;
    rect(x,y,182,22,rgb(18,18,18));rect(x+1,y+1,180,20,rgb(99,99,99));
    for(i=0;i<9;i++) {
        int xx=x+2+i*20;
        rect(xx,y+2,18,18,rgb(46,46,46));rect(xx+1,y+3,16,16,rgb(78,78,78));
        if(i==game.selected) {
            rect(xx-2,y,22,2,rgb(226,226,226));rect(xx-2,y+20,22,2,rgb(226,226,226));
            rect(xx-2,y,2,22,rgb(226,226,226));rect(xx+18,y,2,22,rgb(226,226,226));
        }
        icon(&game.inventory[i],xx+1,y+3,16);
    }
    for(i=0;i<10;i++)heart(x+2+i*8,y-10,game.health>=2*i+2?2:(game.health>2*i?1:0));
    if(game.air<300)for(i=0;i<(game.air+29)/30&&i<10;i++) {
        rect(x+94+i*8,y-10,5,5,rgb(150,207,255));rect(x+95+i*8,y-9,3,3,rgb(38,89,185));
    }
    snprintf(status,sizeof(status),"Diamonds: %lld / 10",(long long)trial.carried_diamonds);
    text(7,7,status,PACKEDCOL_WHITE,1,1);
    if(!OdPresentation_BlocksInput()) {
        rect(ww/2-3,hh/2,7,1,rgb(245,245,245));
        rect(ww/2,hh/2-3,1,7,rgb(245,245,245));
    }
}
static void background(void) {
    int x,y;
    for(y=0;y<hh;y+=32)for(x=0;x<ww;x+=32)
        texture(terrain_tex,256,256,32,0,16,16,x,y,32,32,rgb(89,89,89));
    rect(0,0,ww,hh,PackedCol_Make(0,0,0,40));
}
static void main_menu(void) {
    int y=hh/2-6;
    background();
    centered(hh/2-80,"ONE DIAMOND",rgb(207,207,207),3);
    centered(hh/2-53,"SHORT",rgb(207,207,207),3);
    centered(hh/2-22,"Fifteen minutes. Ten diamonds.",rgb(255,241,96),1);
    button((ww-200)/2,y,200,"Play Demo",OD_UI_PLAY,0);
    button((ww-200)/2,y+24,200,"README",OD_UI_OPEN_README,0);
    button((ww-200)/2,y+48,200,"Options...",UI_OPTIONS,0);
    button((ww-200)/2,y+72,200,"Quit Game",OD_UI_QUIT,0);
    text(4,hh-12,"One Diamond Short",rgb(180,180,180),1,1);
}
static void options(void) {
    int x=(ww-200)/2,y=hh/2-48;char label[64];
    if(trial.state==OD_TRIAL_MENU)background();
    else rect(0,0,ww,hh,PackedCol_Make(0,0,0,165));
    centered(y-32,"Options",PACKEDCOL_WHITE,2);
    snprintf(label,sizeof(label),"Sound: %s",sound_on?"ON":"OFF");
    button(x,y,200,label,OD_UI_SOUND,!sound_on);
    snprintf(label,sizeof(label),"Reduced motion: %s",reduced_motion?"ON":"OFF");
    button(x,y+24,200,label,OD_UI_REDUCED_MOTION,!reduced_motion);
    snprintf(label,sizeof(label),"Mouse sensitivity: %d%%",sensitivity);
    button(x,y+48,200,label,OD_UI_SENSITIVITY,sensitivity>=200?25:sensitivity+25);
    snprintf(label,sizeof(label),"Display: %s",fullscreen?"Fullscreen":"Windowed");
    button(x,y+72,200,label,OD_UI_FULLSCREEN,!fullscreen);
    button(x,y+108,200,"Done",UI_DONE,0);
}
static void paused(void) {
    int x=(ww-200)/2,y=hh/2-34;
    rect(0,0,ww,hh,PackedCol_Make(0,0,0,150));
    centered(y-42,"Game menu",PACKEDCOL_WHITE,2);
    button(x,y,200,"Back to game",UI_RESUME,0);
    button(x,y+24,200,"Options...",UI_OPTIONS,0);
    button(x,y+48,200,"README",OD_UI_OPEN_README,0);
    button(x,y+84,200,"Quit Game",OD_UI_QUIT,0);
}
static void terminal(void) {
    int y=hh/2-74,x=(ww-240)/2;
    rect(0,0,ww,hh,PackedCol_Make(0,0,0,180));
    if(trial.state==OD_TRIAL_WON) {
        centered(y,"Demo complete!",rgb(255,240,120),2);
        if(reward.earned) {
            centered(y+44,"Your code:",PACKEDCOL_WHITE,1);
            centered(y+60,reward.flag,PACKEDCOL_WHITE,1);
            y=wrap(x,y+80,reward.message,240,rgb(205,205,205));
        } else {
            y=wrap(x,y+44,reward.message[0]?reward.message:"The code could not be opened.",240,rgb(255,140,130));
        }
        if(reward.save_status==OD_SAVE_ERROR)
            button((ww-200)/2,y+6,200,"Retry Save",OD_UI_RETRY_SAVE,0),y+=24;
        button((ww-200)/2,y+6,200,"Open README",OD_UI_OPEN_README,0);
        button((ww-200)/2,y+30,200,"Return to title",OD_UI_TITLE,0);
    } else {
        centered(y,"Demo time is up!",PACKEDCOL_WHITE,2);
        centered(y+53,"The fifteen-minute demo has ended.",rgb(220,220,220),1);
        button((ww-200)/2,y+85,200,"Return to title",OD_UI_TITLE,0);
        button((ww-200)/2,y+109,200,"Quit Game",OD_UI_QUIT,0);
    }
}
static void death(void) {
    int y=hh/2-40;
    rect(0,0,ww,hh,PackedCol_Make(94,0,0,145));
    centered(y-24,"You died!",PACKEDCOL_WHITE,3);
    button((ww-200)/2,y+40,200,"Respawn",OD_UI_RESPAWN,0);
    button((ww-200)/2,y+64,200,"Quit Game",OD_UI_QUIT,0);
}
static void panel(int x,int y,int w,int h) {
    rect(x-1,y-1,w+2,h+2,rgb(0,0,0));
    rect(x,y,w,h,rgb(198,198,198));rect(x,y,w,2,rgb(255,255,255));
    rect(x,y,2,h,rgb(255,255,255));rect(x+2,y+h-2,w-2,2,rgb(85,85,85));
    rect(x+w-2,y+2,2,h-2,rgb(85,85,85));
}
static void inventory(void) {
    int x=(ww-176)/2,y=(hh-166)/2,i,j;
    OdStack output=OdGame_GetCraftOutput();
    const char* title=game.screen==OD_SCREEN_CHEST?"Chest":game.screen==OD_SCREEN_FURNACE?"Furnace":"Crafting";
    rect(0,0,ww,hh,PackedCol_Make(0,0,0,150));panel(x,y,176,166);
    text(x+(game.screen==OD_SCREEN_INVENTORY?87:game.screen==OD_SCREEN_FURNACE?60:8),
         y+(game.screen==OD_SCREEN_INVENTORY?16:6),title,rgb(64,64,64),1,0);
    if(game.screen==OD_SCREEN_CHEST&&game.chest) {
        for(i=0;i<27;i++)slot(x+7+(i%9)*18,y+17+(i/9)*18,&game.chest[i],OD_AREA_CHEST,i);
    } else if(game.screen==OD_SCREEN_FURNACE&&game.furnace) {
        slot(x+55,y+17,&game.furnace[0],OD_AREA_FURNACE,0);
        slot(x+55,y+53,&game.furnace[1],OD_AREA_FURNACE,1);
        slot(x+115,y+35,&game.furnace[2],OD_AREA_FURNACE,2);
        rect(x+80,y+39,22,10,rgb(105,105,105));
        rect(x+80,y+39,(int)(22*fminf(1,game.furnace_progress)),10,rgb(238,238,238));
        rect(x+99,y+36,3,16,rgb(198,198,198));
        text(x+100,y+39,">",rgb(85,85,85),1,0);
        if(game.furnace_fuel>0) {
            rect(x+60,y+40,7,10,rgb(239,119,24));rect(x+62,y+38,3,12,rgb(255,214,41));
        }
    } else {
        int cw=game.craft_width==3?3:2;
        int gx=cw==3?x+29:x+87,gy=cw==3?y+17:y+26;
        if(cw==2) {
            rect(x+16,y+18,55,54,rgb(25,25,25));
            /* Small native model portrait: square head, shirt, sleeves, legs. */
            rect(x+35,y+23,16,16,rgb(172,119,82));rect(x+35,y+23,16,4,rgb(66,44,27));
            rect(x+48,y+27,3,12,rgb(137,89,59));rect(x+35,y+27,2,12,rgb(189,137,96));
            rect(x+37,y+30,3,2,rgb(230,230,230));rect(x+46,y+30,3,2,rgb(230,230,230));
            rect(x+39,y+30,1,2,rgb(65,66,139));rect(x+46,y+30,1,2,rgb(65,66,139));
            rect(x+41,y+33,4,2,rgb(138,81,47));rect(x+40,y+36,6,1,rgb(84,48,30));
            rect(x+32,y+39,22,20,rgb(40,158,166));rect(x+27,y+40,5,18,rgb(172,119,82));
            rect(x+54,y+40,5,18,rgb(172,119,82));rect(x+33,y+59,9,12,rgb(67,57,140));
            rect(x+44,y+59,9,12,rgb(67,57,140));
            rect(x+32,y+39,3,20,rgb(24,124,133));rect(x+51,y+39,3,20,rgb(26,112,124));
            rect(x+27,y+40,5,6,rgb(29,139,150));rect(x+54,y+40,5,6,rgb(24,113,126));
            rect(x+38,y+41,3,12,rgb(33,143,152));rect(x+47,y+42,2,13,rgb(33,143,152));
            rect(x+33,y+69,9,2,rgb(49,45,67));rect(x+44,y+69,9,2,rgb(49,45,67));
        }
        for(j=0;j<cw;j++)for(i=0;i<cw;i++)
            slot(gx+i*18,gy+j*18,&game.crafting[j*cw+i],OD_AREA_CRAFT,j*cw+i);
        text(cw==3?x+92:x+126,y+35,">",rgb(85,85,85),2,0);
        slot(cw==3?x+123:x+145,cw==3?y+30:y+35,&output,OD_AREA_CRAFT_OUTPUT,0);
    }
    text(x+8,y+74,"Inventory",rgb(64,64,64),1,0);
    for(i=9;i<36;i++)slot(x+7+((i-9)%9)*18,y+83+((i-9)/9)*18,&game.inventory[i],OD_AREA_INVENTORY,i);
    for(i=0;i<9;i++)slot(x+7+i*18,y+141,&game.inventory[i],OD_AREA_INVENTORY,i);
    if(hover_item&&(!game.cursor||game.cursor->count<=0)) {
        const char* name=OdGame_ItemName(hover_item);
        int tw=text_width(name,1),tx=mx+9,ty=my-12;
        if(tx+tw+6>ww)tx=ww-tw-6;
        rect(tx-3,ty-3,tw+6,14,PackedCol_Make(20,9,28,240));
        text(tx,ty,name,PACKEDCOL_WHITE,1,1);
    }
    icon(game.cursor,mx-8,my-8,16);
}
void OdPresentation_RenderUI(int width,int height) {
    int s=width/480,t=height/270;
    scale=s<t?s:t;if(scale<1)scale=1;if(scale>4)scale=4;
    ww=width/scale;hh=height/scale;
    button_count=slot_count=hover_item=0;assets();
    if(trial.state!=OD_TRIAL_MENU)hud();
    if(menu==MENU_SETTINGS)options();
    else if(trial.state==OD_TRIAL_MENU)main_menu();
    else if(trial.state==OD_TRIAL_WON||trial.state==OD_TRIAL_EXPIRED)terminal();
    else if(game.dead)death();
    else if(menu==MENU_PAUSE)paused();
    else if(game.screen!=OD_SCREEN_NONE&&game.inventory&&game.crafting)inventory();
}
static void activate(int id,int value) {
    focus=-1;
    if(id==UI_RESUME){menu=MENU_NONE;return;}
    if(id==UI_OPTIONS){settings_parent=menu;menu=MENU_SETTINGS;return;}
    if(id==UI_DONE){menu=settings_parent;return;}
    if(id==OD_UI_SOUND)sound_on=value;
    if(id==OD_UI_REDUCED_MOTION)reduced_motion=value;
    if(id==OD_UI_SENSITIVITY)sensitivity=value;
    if(id==OD_UI_FULLSCREEN)fullscreen=value;
    if(id==OD_UI_PLAY||id==OD_UI_TITLE||id==OD_UI_RESPAWN)menu=MENU_NONE;
    if(action)action(id,value);
}
int OdPresentation_BlocksInput(void) {
    return trial.state!=OD_TRIAL_ACTIVE||menu!=MENU_NONE||game.dead||game.screen!=OD_SCREEN_NONE;
}
int OdPresentation_ReducedMotion(void){return reduced_motion;}
void OdPresentation_ShowPause(void) {
    if(trial.state==OD_TRIAL_ACTIVE&&!game.dead){OdGame_CloseScreen();menu=MENU_PAUSE;focus=-1;}
}
int OdPresentation_KeyDown(int key,int repeat) {
    int blocked=OdPresentation_BlocksInput();
    if(repeat)return blocked;
    if(key==CCKEY_F11){activate(OD_UI_FULLSCREEN,!fullscreen);return 1;}
    if(key==CCKEY_ESCAPE) {
        if(menu==MENU_SETTINGS)menu=settings_parent;
        else if(menu==MENU_PAUSE)menu=MENU_NONE;
        else if(game.screen!=OD_SCREEN_NONE&&!game.dead)OdGame_CloseScreen();
        else if(trial.state==OD_TRIAL_ACTIVE&&!game.dead)menu=MENU_PAUSE;
        return 1;
    }
    if(key==CCKEY_TAB&&blocked&&button_count){focus=(focus+1)%button_count;return 1;}
    if((key==CCKEY_ENTER||key==CCKEY_SPACE)&&blocked&&button_count) {
        int selected=focus>=0&&focus<button_count?focus:0;
        activate(buttons[selected].id,buttons[selected].value);return 1;
    }
    if(key==CCKEY_E&&trial.state==OD_TRIAL_ACTIVE&&!game.dead&&menu==MENU_NONE) {
        if(game.screen==OD_SCREEN_NONE)OdGame_OpenInventory();else OdGame_CloseScreen();return 1;
    }
    if(blocked)return 1;
    if(key>=CCKEY_1&&key<=CCKEY_9){OdGame_SelectSlot(key-CCKEY_1);return 1;}
    if(key==CCKEY_Q){OdGame_DropSelected(Input_IsCtrlPressed());return 1;}
    return 0;
}
void OdPresentation_PointerMove(int x,int y){mx=x/scale;my=y/scale;focus=-1;}
int OdPresentation_PointerDown(int x,int y,int button_num,int shift) {
    int i;OdPresentation_PointerMove(x,y);
    if(!OdPresentation_BlocksInput())return 0;
    if(button_num==0)for(i=0;i<button_count;i++) {
        UiButton* b=&buttons[i];
        if(mx>=b->x&&mx<b->x+b->w&&my>=b->y&&my<b->y+b->h) {
            activate(b->id,b->value);return 1;
        }
    }
    for(i=0;i<slot_count;i++) {
        UiSlot* s=&slots[i];
        if(mx>=s->x&&mx<s->x+18&&my>=s->y&&my<s->y+18) {
            OdGame_ClickSlot(s->area,s->index,button_num,shift);return 1;
        }
    }
    return 1;
}
int OdPresentation_Wheel(float amount) {
    if(OdPresentation_BlocksInput())return 1;
    OdGame_SelectSlot((game.selected+(amount>0?8:1))%9);return 1;
}

