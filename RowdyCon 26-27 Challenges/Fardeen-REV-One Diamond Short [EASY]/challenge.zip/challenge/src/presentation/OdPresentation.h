#ifndef OD_PRESENTATION_H
#define OD_PRESENTATION_H
#include "../game/OdGame.h"
#include "../trial/OdTrial.h"
#include "../trial/OdReward.h"
#include "Graphics.h"

enum OdUiAction {
    OD_UI_PLAY, OD_UI_QUIT, OD_UI_OPEN_README, OD_UI_RETRY_SAVE,
    OD_UI_SOUND, OD_UI_REDUCED_MOTION, OD_UI_SENSITIVITY, OD_UI_FULLSCREEN,
    OD_UI_RESPAWN, OD_UI_TITLE
};
typedef void (*OdUiCallback)(int action, int value);

/* Init after the graphics context exists. Update snapshots once per frame;
 * the integration layer owns clocks, world lifecycle and platform actions. */
void OdPresentation_Init(OdUiCallback callback);
void OdPresentation_Free(void);
void OdPresentation_ContextLost(void);
void OdPresentation_Update(const OdGameSnapshot* game,
                           const OdTrial* trial,
                           const OdReward* reward);
/* Called inside the engine's 2D pass, after suppressing the vanilla GUI. */
void OdPresentation_RenderUI(int width, int height);
/* Called before opaque world geometry. Keeps depth writes/test on so roofs,
 * leaves and terrain occlude it. Independent of ordinary cloud settings. */
void OdPresentation_RenderCloudClock(void);
/* Ordinary, sparse native cloud patches; respects normal cloud-off settings. */
void OdPresentation_RenderClouds(void);
/* Ordinary cloud fragments inside this world-XZ rectangle should be omitted. */
int OdPresentation_CloudCutout(float x, float z);
void OdPresentation_CloudBounds(float* x1, float* z1, float* x2, float* z2);
int OdPresentation_KeyDown(int key, int repeat);
int OdPresentation_PointerDown(int x, int y, int button, int shift);
void OdPresentation_PointerMove(int x, int y);
int OdPresentation_Wheel(float amount);
int OdPresentation_BlocksInput(void);
void OdPresentation_ShowPause(void);
int OdPresentation_ReducedMotion(void);
/* Native world/drop renderer reuses the exact HUD item art. Blocks use Atlas1D. */
int OdPresentation_GetItemTexture(int item_id,GfxResourceID* texture,TextureRec* uv);

#endif
