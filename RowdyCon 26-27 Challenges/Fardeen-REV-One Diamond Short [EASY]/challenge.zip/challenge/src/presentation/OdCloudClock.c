#include "OdPresentation.h"
#include "Graphics.h"
#include "Camera.h"
#include "Game.h"
#include "World.h"
#include "EnvRenderer.h"
#include <math.h>

/* Local geometry is rebuilt only when the shared rounded second changes.
 * Camera following is a model transform, never a second clock. */
static const unsigned char digits[10][5] = {
 {7,5,5,5,7},{2,6,2,2,7},{7,1,7,4,7},{7,1,7,1,7},{5,5,7,1,1},
 {7,4,7,1,7},{7,4,7,5,7},{7,1,1,1,1},{7,5,7,5,7},{7,5,7,1,7}
};
static GfxResourceID clock_vb;
static GfxResourceID ordinary_vb;
static int clock_count, clock_second=-1, clock_active;
static float bx1,bx2,bz1,bz2;
static struct Matrix model;

void OdCloudClock_Update(int seconds,int active) {
    clock_active=active;
    if(seconds!=clock_second) { clock_second=seconds; Gfx_DeleteVb(&clock_vb); }
}
void OdCloudClock_Free(void) { Gfx_DeleteVb(&clock_vb);Gfx_DeleteDynamicVb(&ordinary_vb); }

static void vertex(struct VertexColoured** v,float x,float y,float z,PackedCol col) {
    (*v)->x=x;(*v)->y=y;(*v)->z=z;(*v)->Col=col;(*v)++;
}
static void cell(struct VertexColoured** v,float x,float y) {
    float a=x-8.5f,b=y-2.5f,c=a+1,d=b+1,h=.12f;
    PackedCol white=PackedCol_Make(248,250,255,255);
    PackedCol edge=PackedCol_Make(143,158,180,255);
    PackedCol side=PackedCol_Make(193,205,222,255);
    /* z=0 is the underside; local y is up in the readable face. */
    vertex(v,a,b,0,white);vertex(v,a,d,0,white);vertex(v,c,d,0,white);vertex(v,c,b,0,white);
    vertex(v,a,b,h,white);vertex(v,c,b,h,white);vertex(v,c,d,h,white);vertex(v,a,d,h,white);
    vertex(v,a,b,0,edge);vertex(v,c,b,0,edge);vertex(v,c,b,h,edge);vertex(v,a,b,h,edge);
    vertex(v,a,d,0,side);vertex(v,a,d,h,side);vertex(v,c,d,h,side);vertex(v,c,d,0,side);
    vertex(v,a,b,0,edge);vertex(v,a,b,h,edge);vertex(v,a,d,h,edge);vertex(v,a,d,0,edge);
    vertex(v,c,b,0,side);vertex(v,c,d,0,side);vertex(v,c,d,h,side);vertex(v,c,b,h,side);
}
static void build(void) {
    struct VertexColoured data[2200],*v=data,*dst;
    int values[4],i,x,y,left,seconds=clock_second;
    if(seconds<0)seconds=0;if(seconds>5999)seconds=5999;
    values[0]=seconds/600;values[1]=(seconds/60)%10;
    values[2]=(seconds%60)/10;values[3]=seconds%10;
    for(i=0;i<4;i++) {
        left=i<2?i*4:10+(i-2)*4;
        for(y=0;y<5;y++)for(x=0;x<3;x++)
            if(digits[values[i]][y]&(4>>x))cell(&v,(float)(left+x),(float)(4-y));
    }
    cell(&v,8,1);cell(&v,8,3);
    clock_count=(int)(v-data);
    clock_vb=Gfx_CreateVb(VERTEX_FORMAT_COLOURED,clock_count);
    dst=(struct VertexColoured*)Gfx_LockVb(clock_vb,VERTEX_FORMAT_COLOURED,clock_count);
    for(i=0;i<clock_count;i++)dst[i]=data[i];
    Gfx_UnlockVb(clock_vb);
}
static void prepare(void) {
    const float pi=3.14159265358979323846f;
    Vec2 orientation=Camera.Active->GetOrientation();
    Vec3 p=Camera.CurrentPos;
    float yaw=orientation.x, elevation=asinf(-sinf(orientation.y));
    float center=fmaxf(22*pi/180,elevation+10*pi/180);
    float fov=Camera.Fov*pi/180,aspect=(float)Game.Width/(float)Game.Height;
    float vfov=fminf(8*pi/180,fov*.25f);
    float hfov=2*atanf(tanf(fov*.5f)*aspect);
    float aw=fminf(28*pi/180,hfov*.78f);
    float y=fmaxf(92.0f,p.y+24.0f),height=y-p.y;
    float distance,wide,deep,hx=sinf(yaw),hz=-cosf(yaw);
    float cx,cz,pad,plane,up_h,up_y,normal_h,normal_y;
    int a,b;
    /* When zoomed, keep the complete digits in the supported frustum. */
    center=fminf(center,elevation+fov*.5f-vfov*.65f);
    /* Looking down never pulls the slab down into the 64-high world. */
    center=fmaxf(center,pi/12);center=fminf(center,pi*.5f);
    distance=height/sinf(center);
    wide=distance*tanf(aw*.5f)*2;
    /* At shallow pitch, a flat horizontal slab has extreme projective taper.
     * Tilt the cloud face toward the viewer, easing continuously to an actual
     * horizontal underside at zenith. Every vertex still has world depth. */
    plane=fmaxf(center,50*pi/180);
    up_h=-sinf(plane);up_y=cosf(plane);
    normal_h=cosf(plane);normal_y=sinf(plane);
    deep=distance*tanf(vfov*.5f)*2/cosf(plane-center);
    cx=p.x+hx*height/tanf(center);cz=p.z+hz*height/tanf(center);
    model=Matrix_Identity;
    /* Stable stored yaw supplies right even at zenith. Horizontal screen-up
     * points back toward the camera, preventing an underside mirror. */
    model.row1.x=cosf(yaw)*wide/17;model.row1.y=0;model.row1.z=sinf(yaw)*wide/17;
    model.row2.x=hx*up_h*deep/5;model.row2.y=up_y*deep/5;model.row2.z=hz*up_h*deep/5;
    model.row3.x=hx*normal_h*fminf(wide/17,deep/5);
    model.row3.y=normal_y*fminf(wide/17,deep/5);
    model.row3.z=hz*normal_h*fminf(wide/17,deep/5);
    model.row4.x=cx;model.row4.y=y;model.row4.z=cz;
    /* Reserve the camera rays through the digits at the ordinary cloud layer.
     * Sparse cloud groups are omitted whole, producing natural patch edges. */
    bx1=bz1=1e9f;bx2=bz2=-1e9f;
    for(a=-1;a<=1;a+=2)for(b=-1;b<=1;b+=2) {
        float px=cx+a*model.row1.x*8.5f+b*model.row2.x*2.5f;
        float py=y+b*model.row2.y*2.5f;
        float pz=cz+a*model.row1.z*8.5f+b*model.row2.z*2.5f;
        float t=(92-p.y)/(py-p.y);
        px=p.x+(px-p.x)*t;pz=p.z+(pz-p.z)*t;
        bx1=fminf(bx1,px);bx2=fmaxf(bx2,px);bz1=fminf(bz1,pz);bz2=fmaxf(bz2,pz);
    }
    pad=5;bx1-=pad;bx2+=pad;bz1-=pad;bz2+=pad;
}
void OdPresentation_CloudBounds(float* x1,float* z1,float* x2,float* z2) {
    if(clock_active&&Camera.Active)prepare();
    *x1=bx1;*x2=bx2;*z1=bz1;*z2=bz2;
}
int OdPresentation_CloudCutout(float x,float z) {
    return clock_active&&x>=bx1&&x<=bx2&&z>=bz1&&z<=bz2;
}
void OdPresentation_RenderCloudClock(void) {
    struct Matrix mv;cc_bool fog;
    if(!clock_active||Gfx.LostContext||!Camera.Active)return;
    prepare();if(!clock_vb)build();
    Matrix_Mul(&mv,&model,&Gfx.View);
    fog=Gfx_GetFog();Gfx_SetFog(false);
    Gfx_SetAlphaTest(false);Gfx_SetAlphaBlending(false);Gfx_SetFaceCulling(false);
    Gfx_SetDepthTest(true);Gfx_SetDepthWrite(true);
    Gfx_LoadMatrix(MATRIX_VIEW,&mv);Gfx_SetVertexFormat(VERTEX_FORMAT_COLOURED);
    Gfx_BindVb(clock_vb);Gfx_DrawVb_IndexedTris(clock_count);
    Gfx_LoadMatrix(MATRIX_VIEW,&Gfx.View);Gfx_SetFog(fog);
}

static void cloud_box(struct VertexColoured** v,float x,float y,float z,float w,float d) {
    PackedCol base=Env.CloudsCol,edge=PackedCol_Scale(base,.80f),side=PackedCol_Scale(base,.91f);
    float xx=x+w,yy=y+1.6f,zz=z+d;
    vertex(v,x,y,z,base);vertex(v,xx,y,z,base);vertex(v,xx,y,zz,base);vertex(v,x,y,zz,base);
    vertex(v,x,yy,z,base);vertex(v,x,yy,zz,base);vertex(v,xx,yy,zz,base);vertex(v,xx,yy,z,base);
    vertex(v,x,y,z,edge);vertex(v,x,yy,z,edge);vertex(v,xx,yy,z,edge);vertex(v,xx,y,z,edge);
    vertex(v,x,y,zz,side);vertex(v,xx,y,zz,side);vertex(v,xx,yy,zz,side);vertex(v,x,yy,zz,side);
    vertex(v,x,y,z,edge);vertex(v,x,y,zz,edge);vertex(v,x,yy,zz,edge);vertex(v,x,yy,z,edge);
    vertex(v,xx,y,z,side);vertex(v,xx,yy,z,side);vertex(v,xx,yy,zz,side);vertex(v,xx,y,zz,side);
}
void OdPresentation_RenderClouds(void) {
    static struct VertexColoured vertices[24576];
    struct VertexColoured* v=vertices;
    int x,z,gx,gz,count;float drift,y;
    if(Gfx.LostContext||!World.Loaded||EnvRenderer_Minimal||Env.CloudsHeight<-2000)return;
    if(clock_active&&Camera.Active)prepare();
    drift=OdPresentation_ReducedMotion()?0:(float)fmod(Game.Time*.18,4096.0);
    gx=(int)floorf((Camera.CurrentPos.x-drift)/40);gz=(int)floorf(Camera.CurrentPos.z/40);
    y=(float)Env.CloudsHeight;
    for(z=gz-8;z<=gz+8;z++)for(x=gx-8;x<=gx+8;x++) {
        unsigned int seed=(unsigned int)x*374761393u+(unsigned int)z*668265263u+0x1D1A2026u;
        float px,pz;
        seed=(seed^(seed>>13))*1274126177u;seed^=seed>>16;
        if((seed&3u)>1u)continue;
        px=x*40+drift+(float)((seed>>3)&7);pz=z*40+(float)((seed>>6)&7);
        if(clock_active&&px+31>=bx1&&px<=bx2&&pz+27>=bz1&&pz<=bz2)continue;
        cloud_box(&v,px,y,pz+7,24,13);
        cloud_box(&v,px+6,y,pz,12,7);
        cloud_box(&v,px+10,y,pz+20,21,7);
    }
    count=(int)(v-vertices);if(!count)return;
    if(!ordinary_vb)ordinary_vb=Gfx_CreateDynamicVb(VERTEX_FORMAT_COLOURED,24576);
    Gfx_LoadMatrix(MATRIX_VIEW,&Gfx.View);
    Gfx_SetAlphaTest(false);Gfx_SetAlphaBlending(false);Gfx_SetFaceCulling(false);
    Gfx_SetDepthTest(true);Gfx_SetDepthWrite(true);Gfx_SetVertexFormat(VERTEX_FORMAT_COLOURED);
    Gfx_SetDynamicVbData(ordinary_vb,vertices,count);Gfx_BindDynamicVb(ordinary_vb);
    Gfx_DrawVb_IndexedTris(count);
}
