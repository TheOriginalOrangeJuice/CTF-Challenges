#include "OdAudioMixer.h"
#include <string.h>

void OdAudioMixer_Init(OdAudioMixer* m) { memset(m,0,sizeof *m); m->enabled=1; }
void OdAudioMixer_Enable(OdAudioMixer* m,int enabled) {
    m->enabled=!!enabled;
    if (!m->enabled) memset(m->voices,0,sizeof m->voices);
}
unsigned OdAudioMixer_Active(const OdAudioMixer* m) {
    unsigned n=0; int i;
    for(i=0;i<OD_AUDIO_VOICES;i++) n+=m->voices[i].clip!=NULL;
    return n;
}
int OdAudioMixer_Priority(int kind) {
    static const int priorities[OD_AUDIO_CLIPS]={0,1,3,2,2,4,2,1,3,3,3,5,2,6};
    return kind>=0&&kind<OD_AUDIO_CLIPS?priorities[kind]:0;
}
int OdAudioMixer_Gain(int kind) {
    /* A long footstep or repeated mining tap should not mask the impact. */
    static const int gains[OD_AUDIO_CLIPS]={128,192,256,224,256,256,224,160,256,256,224,256,224,256};
    return kind>=0&&kind<OD_AUDIO_CLIPS?gains[kind]:0;
}
int OdAudioMixer_Play(OdAudioMixer* m,const OdAudioClip* clip,int priority,int gain) {
    int i, slot=-1; unsigned active;
    if (!m->enabled||!clip||!clip->samples||!clip->count||gain<=0) return 0;
    if (gain>256) gain=256;
    for(i=0;i<OD_AUDIO_VOICES;i++) {
        OdAudioVoice* v=&m->voices[i];
        if (!v->clip) { slot=i; break; }
        /* Only a strictly more important effect may truncate an occupied voice. */
        if (v->priority<priority && (slot<0 || v->priority<m->voices[slot].priority ||
            (v->priority==m->voices[slot].priority && v->serial<m->voices[slot].serial))) slot=i;
    }
    if (slot<0) { m->dropped++; return 0; }
    m->voices[slot].clip=clip; m->voices[slot].position=0;
    m->voices[slot].priority=priority; m->voices[slot].gain=gain;
    m->voices[slot].serial=++m->serial; m->accepted++;
    active=OdAudioMixer_Active(m); if(active>m->peak_voices)m->peak_voices=active;
    return 1;
}
void OdAudioMixer_Render(OdAudioMixer* m,int16_t* output,size_t count) {
    size_t frame; int i;
    for(frame=0;frame<count;frame++) {
        int32_t sum=0;
        if(m->enabled) for(i=0;i<OD_AUDIO_VOICES;i++) {
            OdAudioVoice* v=&m->voices[i];
            if(!v->clip)continue;
            sum+=(int32_t)v->clip->samples[v->position++]*v->gain/256;
            if(v->position==v->clip->count)v->clip=NULL;
        }
        if(sum>32767)sum=32767;
        if(sum<-32768)sum=-32768;
        output[frame]=(int16_t)sum;
    }
}
