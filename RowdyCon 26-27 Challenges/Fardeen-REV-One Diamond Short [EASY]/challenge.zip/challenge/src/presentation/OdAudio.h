#ifndef OD_AUDIO_H
#define OD_AUDIO_H
#include <stdint.h>
typedef struct {
    unsigned device_result, loaded_clips, submitted_buffers, completed_buffers;
    unsigned accepted, dropped, peak_voices, active_voices;
    uint64_t nonzero_samples;
} OdAudioStats;
int OdAudio_Init(void);
void OdAudio_Free(void);
void OdAudio_Play(int kind);
void OdAudio_PlayVolume(int kind, int volume);
void OdAudio_SetEnabled(int enabled);
void OdAudio_GetStats(OdAudioStats* stats);
#endif
