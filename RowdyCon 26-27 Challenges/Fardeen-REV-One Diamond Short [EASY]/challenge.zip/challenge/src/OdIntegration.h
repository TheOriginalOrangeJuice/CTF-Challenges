#ifndef OD_INTEGRATION_H
#define OD_INTEGRATION_H
void OdIntegration_Init(void);
void OdIntegration_Free(void);
void OdIntegration_Poll(void);
void OdIntegration_Tick(float delta);
void OdIntegration_Interact(float delta);
void OdIntegration_RenderWorld(void);
void OdIntegration_RenderUI(void);
int OdIntegration_KeyDown(int key, int repeat);
int OdIntegration_BlocksMovement(void);
int OdIntegration_BlocksPhysics(void);
int OdIntegration_ShowHeldBlock(void);
void OdIntegration_Pause(void);
void OdIntegration_PointerMove(int x, int y);
void OdIntegration_Wheel(float amount);
void OdIntegration_StepSound(void);
#endif
