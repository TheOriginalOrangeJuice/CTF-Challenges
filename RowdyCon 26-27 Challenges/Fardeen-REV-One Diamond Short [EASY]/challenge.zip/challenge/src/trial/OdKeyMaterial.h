#ifndef OD_KEY_MATERIAL_H
#define OD_KEY_MATERIAL_H
#include <stdint.h>
#include "../../vendor/monocypher/monocypher.h"

/* This is an offline executable, not a secret-keeping boundary. These fragments
 * make the normal reward an authenticated encrypted payload rather than a
 * searchable plaintext. Static reverse engineering remains a valid approach. */
static const uint8_t od_part_a[8] = {0x81,0xd2,0x39,0xae,0x72,0x04,0xc1,0x65};
static const uint8_t od_part_b[8] = {0x29,0xb0,0x56,0xe7,0xfa,0x13,0x48,0x9d};
static const uint8_t od_part_c[8] = {0xa3,0x66,0x0b,0xd5,0x9c,0x3f,0xe0,0x17};
static const uint8_t od_part_d[8] = {0x54,0xcf,0x98,0x21,0x6d,0xb8,0x40,0xf3};
static const uint8_t od_reward_ad[] = "One Diamond Short: reward:v1";

static void OdReward_DeriveKey(uint8_t key[32], int32_t count) {
    uint8_t material[36];
    uint32_t value = (uint32_t)count;
    int i;
    for (i = 0; i < 8; ++i) {
        material[4*i    ] = od_part_a[i];
        material[4*i + 1] = od_part_b[i];
        material[4*i + 2] = od_part_c[i];
        material[4*i + 3] = od_part_d[i];
    }
    for (i = 0; i < 4; ++i) material[32+i] = (uint8_t)(value >> (8*i));
    crypto_blake2b(key, 32, material, sizeof(material));
    crypto_wipe(material, sizeof(material));
}
#endif
