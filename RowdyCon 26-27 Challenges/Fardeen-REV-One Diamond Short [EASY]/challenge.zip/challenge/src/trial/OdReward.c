#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include "OdReward.h"

#define OD_PATH_CAP 32768
#define OD_README_LIMIT (1024u * 1024u)
static const char initial_readme[] =
    "Collect 10 diamonds to win a copy of Minecraft!\r\n"
    "\r\nOne Diamond Short - Demo\r\n"
    "You have 15 minutes. The demo clock keeps running while paused.\r\n"
    "\r\nControls\r\n"
    "W A S D: Move\r\nSpace: Jump\r\nMouse: Look\r\n"
    "Left mouse: Mine / attack\r\nRight mouse: Place / use\r\n"
    "1-9 / mouse wheel: Select hotbar slot\r\nE: Inventory\r\n"
    "Q: Drop one item\r\nEscape: Pause menu / close inventory\r\n"
    "Inventory left click: Pick up / place / swap stack\r\n"
    "Inventory right click: Split stack / place one\r\n"
    "Shift + click: Quick transfer\r\nF11: Fullscreen\r\n";
static const char expiry_note[] =
    "\r\n--- Demo time expired ---\r\n"
    "Time is up! Start a new demo and collect 10 diamonds before the clock runs out.\r\n";

#ifdef OD_REWARD_TEST
static const wchar_t *test_path;
void OdReward_TestPath(const wchar_t *path) { test_path = path; }
#endif

static int ReadmePath(wchar_t *path) {
    DWORD length;
    wchar_t *slash;
#ifdef OD_REWARD_TEST
    if (test_path) {
        if (wcslen(test_path) >= OD_PATH_CAP) {
            SetLastError(ERROR_FILENAME_EXCED_RANGE); return 0;
        }
        wcscpy(path, test_path); return 1;
    }
#endif
    length = GetModuleFileNameW(NULL, path, OD_PATH_CAP);
    if (!length || length >= OD_PATH_CAP) {
        SetLastError(ERROR_FILENAME_EXCED_RANGE); return 0;
    }
    slash = wcsrchr(path, L'\\');
    if (!slash || (size_t)(slash-path) + 12 >= OD_PATH_CAP) {
        SetLastError(ERROR_BAD_PATHNAME); return 0;
    }
    wcscpy(slash + 1, L"README.txt");
    return 1;
}

static int SaveError(OdReward *reward, DWORD error) {
    reward->save_status = OD_SAVE_ERROR;
    reward->system_error = error;
    snprintf(reward->message, sizeof(reward->message),
             "Could not save README.txt (Windows error %lu). Close programs using it, check folder permissions, then choose Retry Save.",
             (unsigned long)error);
    return 0;
}

/* Returns existing bytes verbatim, including an already earned reward. The
 * contents never influence trial state, key derivation, or earned status. */
static int ReadExisting(const wchar_t *path, char **contents, size_t *length) {
    HANDLE file;
    LARGE_INTEGER size;
    DWORD received, error;
    char *buffer;
    file = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING,
                       FILE_ATTRIBUTE_NORMAL, NULL);
    if (file == INVALID_HANDLE_VALUE) {
        error = GetLastError();
        if (error != ERROR_FILE_NOT_FOUND) return 0;
        *length = sizeof(initial_readme)-1;
        *contents = (char*)malloc(*length + 1);
        if (!*contents) { SetLastError(ERROR_OUTOFMEMORY); return 0; }
        memcpy(*contents, initial_readme, *length + 1);
        return 1;
    }
    if (!GetFileSizeEx(file, &size)) {
        error = GetLastError(); CloseHandle(file); SetLastError(error); return 0;
    }
    if (size.QuadPart < 0 || size.QuadPart > OD_README_LIMIT) {
        CloseHandle(file); SetLastError(ERROR_FILE_TOO_LARGE); return 0;
    }
    buffer = (char*)malloc((size_t)size.QuadPart + 1);
    if (!buffer) { CloseHandle(file); SetLastError(ERROR_OUTOFMEMORY); return 0; }
    if (!ReadFile(file, buffer, (DWORD)size.QuadPart, &received, NULL) ||
        received != (DWORD)size.QuadPart) {
        error = GetLastError();
        free(buffer); CloseHandle(file);
        SetLastError(error ? error : ERROR_READ_FAULT); return 0;
    }
    if (!CloseHandle(file)) { error = GetLastError(); free(buffer); SetLastError(error); return 0; }
    buffer[received] = 0;
    *contents = buffer; *length = received;
    return 1;
}

static int AtomicReplace(const wchar_t *path, const char *bytes, size_t length,
                         int replace_existing) {
    wchar_t temporary[OD_PATH_CAP];
    HANDLE file = INVALID_HANDLE_VALUE;
    DWORD wrote, error = 0;
    static LONG sequence;
    int attempt;
    if (wcslen(path) + 48 >= OD_PATH_CAP) { SetLastError(ERROR_FILENAME_EXCED_RANGE); return 0; }
    for (attempt=0; attempt<32; ++attempt) {
        _snwprintf(temporary, OD_PATH_CAP, L"%ls.%lu.%lu.tmp", path,
                   (unsigned long)GetCurrentProcessId(),
                   (unsigned long)InterlockedIncrement(&sequence));
        file = CreateFileW(temporary, GENERIC_WRITE, 0, NULL, CREATE_NEW,
                           FILE_ATTRIBUTE_NORMAL, NULL);
        if (file != INVALID_HANDLE_VALUE) break;
        if (GetLastError() != ERROR_FILE_EXISTS) return 0;
    }
    if (file == INVALID_HANDLE_VALUE) return 0;
    if (!WriteFile(file, bytes, (DWORD)length, &wrote, NULL) || wrote != length)
        error = GetLastError() ? GetLastError() : ERROR_WRITE_FAULT;
    if (!error && !FlushFileBuffers(file)) error = GetLastError();
    if (!CloseHandle(file) && !error) error = GetLastError();
    if (!error && !MoveFileExW(temporary, path, MOVEFILE_WRITE_THROUGH |
                              (replace_existing ? MOVEFILE_REPLACE_EXISTING : 0)))
        error = GetLastError();
    if (error) {
        DeleteFileW(temporary);
        SetLastError(error); return 0;
    }
    return 1;
}

void OdReward_Init(OdReward *reward) {
    wchar_t path[OD_PATH_CAP];
    DWORD attributes, error;
    memset(reward, 0, sizeof(*reward));
    if (!ReadmePath(path)) { SaveError(reward, GetLastError()); return; }
    attributes = GetFileAttributesW(path);
    if (attributes != INVALID_FILE_ATTRIBUTES) {
        if (attributes & FILE_ATTRIBUTE_DIRECTORY) SaveError(reward, ERROR_ACCESS_DENIED);
        return;
    }
    error = GetLastError();
    if (error != ERROR_FILE_NOT_FOUND) { SaveError(reward, error); return; }
    if (!AtomicReplace(path, initial_readme, sizeof(initial_readme)-1, 0)) {
        error = GetLastError();
        /* Another instance may have created the file. Never overwrite it. */
        if (error != ERROR_ALREADY_EXISTS && error != ERROR_FILE_EXISTS)
            SaveError(reward, error);
    }
}

int OdReward_RetrySave(OdReward *reward, const OdTrial *trial) {
    wchar_t path[OD_PATH_CAP];
    char note[256], *existing = NULL, *combined;
    const char *addition;
    size_t length = 0, addition_length;
    int success;
    DWORD error;
    if (trial->state != OD_TRIAL_WON && trial->state != OD_TRIAL_EXPIRED) return 0;
    if (trial->state == OD_TRIAL_WON && !reward->earned) return 0;
    if (!ReadmePath(path)) return SaveError(reward, GetLastError());
    if (!ReadExisting(path, &existing, &length)) return SaveError(reward, GetLastError());
    if (trial->state == OD_TRIAL_WON) {
        snprintf(note, sizeof(note),
            "\r\n--- Congratulations! ---\r\nYou collected 10 diamonds!\r\n"
            "Your Minecraft gift code: %s\r\nYour flag: %s\r\n", reward->code, reward->flag);
        addition = strstr(existing, reward->flag) ? "" : note;
    } else {
        addition = strstr(existing, "--- Demo time expired ---") ? "" : expiry_note;
    }
    addition_length = strlen(addition);
    combined = (char*)malloc(length + addition_length + 1);
    if (!combined) { free(existing); return SaveError(reward, ERROR_OUTOFMEMORY); }
    memcpy(combined, existing, length);
    memcpy(combined + length, addition, addition_length + 1);
    free(existing);
    success = AtomicReplace(path, combined, length + addition_length, 1);
    error = GetLastError();
    free(combined);
    if (!success) return SaveError(reward, error);
    reward->save_status = OD_SAVE_OK;
    reward->system_error = 0;
    snprintf(reward->message, sizeof(reward->message), "%s",
        trial->state == OD_TRIAL_WON ? "Your reward was saved to README.txt." :
                                      "Demo reminder saved to README.txt.");
    return 1;
}

void OdReward_HandleTerminal(OdReward *reward, const OdTrial *trial) {
    if (reward->terminal_handled ||
        (trial->state != OD_TRIAL_WON && trial->state != OD_TRIAL_EXPIRED)) return;
    reward->terminal_handled = 1;
    if (trial->state == OD_TRIAL_WON) {
        if (trial->winning_count != OD_TRIAL_TARGET ||
            !OdReward_Decode(trial->winning_count, reward->code)) {
            reward->save_status = OD_SAVE_AUTH_ERROR;
            snprintf(reward->message, sizeof(reward->message),
                     "Reward verification failed. Restore the original game files and try a fresh demo.");
            return;
        }
        reward->earned = 1;
        snprintf(reward->flag, sizeof(reward->flag), "RCC{%s}", reward->code);
    }
    OdReward_RetrySave(reward, trial);
}

int OdReward_OpenReadme(OdReward *reward) {
    wchar_t path[OD_PATH_CAP];
    INT_PTR result;
    if (!ReadmePath(path)) return SaveError(reward, GetLastError());
    result = (INT_PTR)ShellExecuteW(NULL, L"open", path, NULL, NULL, SW_SHOWNORMAL);
    if (result <= 32) {
        snprintf(reward->message, sizeof(reward->message),
                 "Could not open README.txt (Windows error %ld). Open it from the game folder.", (long)result);
        reward->system_error = (unsigned long)result;
        return 0;
    }
    return 1;
}
