#include "OdTrial.h"
#include <string.h>

static int CountStack(const OdStack *stack, int64_t *total) {
    /* The volatile 32-bit load is also the deliberate memory-editor target.
     * Validate every carried stack, including items other than diamonds. */
    int32_t count = stack->count;
    if (count < 0 || count > 64) return 0;
    if (stack->item_id == OD_TRIAL_DIAMOND_ID) *total += count;
    return 1;
}

int OdTrial_CountDiamonds(const OdCarried *carried, int64_t *total) {
    int i;
    int64_t sum = 0;
    if (!carried || !total) return 0;
    for (i = 0; i < 36; ++i) {
        if (!CountStack(&carried->inventory[i], &sum)) return 0;
    }
    if (!CountStack(&carried->cursor, &sum)) return 0;
    for (i = 0; i < 9; ++i) {
        if (!CountStack(&carried->craft[i], &sum)) return 0;
    }
    *total = sum;
    return 1;
}

void OdTrial_Init(OdTrial *trial) {
    memset(trial, 0, sizeof(*trial));
    trial->state = OD_TRIAL_MENU;
    trial->remaining_seconds = 900;
}

int OdTrial_Start(OdTrial *trial, uint64_t now_ms) {
    if (trial->state != OD_TRIAL_MENU) return 0;
    trial->started_ms = now_ms;
    trial->elapsed_ms = 0;
    trial->remaining_seconds = 900;
    trial->state = OD_TRIAL_ACTIVE;
    return 1;
}

OdTrialState OdTrial_Tick(OdTrial *trial, uint64_t now_ms,
                         const OdCarried *carried) {
    uint64_t elapsed;
    int64_t total = 0;
    if (trial->state != OD_TRIAL_ACTIVE) return trial->state;
    elapsed = now_ms >= trial->started_ms ? now_ms - trial->started_ms : 0;
    /* Even an unexpected backwards source jump cannot buy extra play time. */
    if (elapsed < trial->elapsed_ms) elapsed = trial->elapsed_ms;
    trial->elapsed_ms = elapsed;
    /* Deadline always precedes inventory. At exactly 900 s there is no win. */
    if (elapsed >= OD_TRIAL_DURATION_MS) {
        trial->remaining_seconds = 0;
        trial->state = OD_TRIAL_EXPIRED;
        return trial->state;
    }
    trial->remaining_seconds = (int)((OD_TRIAL_DURATION_MS - elapsed + 999) / 1000);
    trial->inventory_valid = OdTrial_CountDiamonds(carried, &total);
    trial->carried_diamonds = trial->inventory_valid ? total : 0;
    if (trial->inventory_valid && total == OD_TRIAL_TARGET) {
        trial->winning_count = (int32_t)total;
        trial->state = OD_TRIAL_WON;
    }
    return trial->state;
}
