#include "OdReward.h"
#include "OdKeyMaterial.h"
#include "OdRewardBlob.h"
#include <string.h>

/* Kept separate for deterministic crypto tests; the game calls only Decode. */
int OdReward_DecodePayload(int32_t winning_count, const uint8_t cipher[16],
                          const uint8_t tag[16], const uint8_t nonce[24],
                          char code[17]) {
    uint8_t key[32], plaintext[16];
    int i, result;
    memset(code, 0, 17);
    OdReward_DeriveKey(key, winning_count);
    result = crypto_aead_unlock(plaintext, tag, key, nonce, od_reward_ad,
                               sizeof(od_reward_ad)-1, cipher, 16);
    crypto_wipe(key, sizeof(key));
    if (result != 0) {
        crypto_wipe(plaintext, sizeof(plaintext));
        return 0;
    }
    for (i = 0; i < 16; ++i) {
        if (!((plaintext[i] >= 'A' && plaintext[i] <= 'Z') ||
              (plaintext[i] >= '0' && plaintext[i] <= '9'))) {
            crypto_wipe(plaintext, sizeof(plaintext));
            return 0;
        }
    }
    memcpy(code, plaintext, 16);
    crypto_wipe(plaintext, sizeof(plaintext));
    return 1;
}

int OdReward_Decode(int32_t winning_count, char code[17]) {
    return OdReward_DecodePayload(winning_count, od_reward_cipher,
                                 od_reward_tag, od_reward_nonce, code);
}
