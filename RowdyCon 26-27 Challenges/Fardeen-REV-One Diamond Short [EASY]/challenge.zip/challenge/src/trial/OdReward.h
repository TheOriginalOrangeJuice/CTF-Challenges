#ifndef OD_REWARD_H
#define OD_REWARD_H

#include "OdTrial.h"

typedef enum OdSaveStatus {
    OD_SAVE_NONE = 0, OD_SAVE_OK, OD_SAVE_ERROR, OD_SAVE_AUTH_ERROR
} OdSaveStatus;

typedef struct OdReward {
    OdSaveStatus save_status;
    int earned;
    int terminal_handled;
    unsigned long system_error;
    char code[17];
    char flag[22];
    char message[192];
} OdReward;

/* Init creates a missing README beside the executable; an existing file is
 * retained and NEVER used as evidence of a win. All paths use UTF-16 on Windows.
 * HandleTerminal is idempotent. UI can retain/dismiss its terminal screen and
 * call RetrySave or OpenReadme after a save error. */
void OdReward_Init(OdReward *reward);
void OdReward_HandleTerminal(OdReward *reward, const OdTrial *trial);
int OdReward_RetrySave(OdReward *reward, const OdTrial *trial);
int OdReward_OpenReadme(OdReward *reward);

/* Authenticated payload decode, exposed for corruption/boundary unit tests.
 * A successful call requires the actual latched count and verified AEAD tag. */
int OdReward_Decode(int32_t winning_count, char code[17]);

#endif
