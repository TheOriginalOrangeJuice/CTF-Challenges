#ifndef OD_TRIAL_H
#define OD_TRIAL_H

#include <stdint.h>
#include "../shared/OdTypes.h"

#define OD_TRIAL_DURATION_MS UINT64_C(900000)
#define OD_TRIAL_DIAMOND_ID 264
#define OD_TRIAL_TARGET 10

typedef enum OdTrialState {
    OD_TRIAL_MENU = 0, OD_TRIAL_ACTIVE, OD_TRIAL_WON, OD_TRIAL_EXPIRED
} OdTrialState;

typedef struct OdTrial {
    OdTrialState state;
    uint64_t started_ms;
    uint64_t elapsed_ms;
    int remaining_seconds;
    int inventory_valid;
    int64_t carried_diamonds;
    int32_t winning_count;
} OdTrial;

/* Milliseconds from one monotonic time source for the lifetime of a trial.
 * No pause/focus/death hook exists: call Tick on EVERY active application loop.
 * A terminal state is immutable until a fresh Init/Start pair. */
void OdTrial_Init(OdTrial *trial);
int OdTrial_Start(OdTrial *trial, uint64_t now_ms);
OdTrialState OdTrial_Tick(OdTrial *trial, uint64_t now_ms,
                         const OdCarried *carried);
int OdTrial_CountDiamonds(const OdCarried *carried, int64_t *total);

#endif
