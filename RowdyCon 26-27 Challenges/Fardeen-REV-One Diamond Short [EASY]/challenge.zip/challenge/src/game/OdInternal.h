#ifndef OD_INTERNAL_H
#define OD_INTERNAL_H
#include "OdGame.h"
#include <math.h>
#include <string.h>
#include <stdlib.h>
#define OD_STATIONS 64
#define OD_PI 3.14159265358979323846f
typedef struct OdStation {
    int active, x, y, z, type;
    OdStack slots[27];
    float burn, burn_total, cook;
} OdStation;
typedef struct OdState {
    OdGameHooks hooks;
    OdCarried carried;
    OdStation stations[OD_STATIONS];
    OdMob mobs[OD_MAX_MOBS];
    OdDrop drops[OD_MAX_DROPS];
    OdProjectile projectiles[OD_MAX_PROJECTILES];
    OdPlayerFrame player;
    int selected, screen, station, craft_width, health, air, dead;
    int mining_x, mining_y, mining_z, mining_block;
    int was_grounded, initialized;
    float mining, hurt, swing, attack, air_clock, hazard_clock, fall_top;
    double elapsed;
    uint64_t world_time_ms;
    int external_world_time;
    uint32_t rng;
} OdState;
extern OdState od;
int Od_Block(int x, int y, int z);
void Od_SetBlock(int x, int y, int z, int block);
int Od_Solid(int block);
void Od_Sound(int sound, OdVec3 where);
void Od_Message(const char* text);
uint32_t Od_Random(void);
void Od_StackClear(OdStack* stack);
int Od_StackValid(const OdStack* stack);
int Od_AddStack(OdStack* slots, int count, OdStack* stack);
int Od_Give(int item, int count, int damage);
void Od_SpawnDrop(int item, int count, int damage, OdVec3 position, float delay);
void Od_DropStack(OdStack* stack, OdVec3 position, float delay);
void Od_ToolDamage(int amount);
void Od_InventoryInit(void);
void Od_InventoryTick(float dt);
void Od_DeathDrops(void);
int Od_OpenStation(int x, int y, int z, int type);
void Od_BreakStation(int x, int y, int z);
void Od_Recipe(OdStack* result, int used[9]);
void Od_WorldGenerate(void);
void Od_EntitiesInit(void);
void Od_EntitiesTick(float dt);
void Od_DamagePlayer(int amount, OdVec3 from);
int Od_DamageMob(int index, int amount, OdVec3 from);
void Od_Explode(OdVec3 position);
int Od_Shoot(OdVec3 position, OdVec3 direction, int friendly);
float Od_DistanceSquared(OdVec3 a, OdVec3 b);
int Od_LineClear(OdVec3 a, OdVec3 b);
float Od_Daylight(void);
#endif
