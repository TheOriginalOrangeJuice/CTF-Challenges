#include "OdInternal.h"

void Od_StackClear(OdStack* s) { s->item_id=0; s->count=0; s->damage=0; }
int Od_StackValid(const OdStack* s) { return s->item_id>0 && s->count>0; }
static int Same(const OdStack* a,const OdStack* b) {
    return a->item_id==b->item_id && a->damage==b->damage;
}
static void Move(OdStack* to,OdStack* from,int amount) {
    if(amount<=0)return;
    if(!Od_StackValid(to)) { to->item_id=from->item_id;to->damage=from->damage;to->count=0; }
    to->count+=amount;from->count-=amount;
    if(from->count<=0)Od_StackClear(from);
}
int OdGame_ItemDurability(int id) {
    if(id==256||id==257||id==258||id==267) return 251;
    if(id>=268&&id<=271)return 60;
    if(id>=272&&id<=275)return 132;
    if(id>=276&&id<=279)return 1562;
    if(id>=283&&id<=286)return 33;
    return 0;
}
int OdGame_StackLimit(int id) {
    if(OdGame_ItemDurability(id)||id==261||id==282||id==319||id==320||id==260||id==297)return 1;
    return 64;
}
int Od_AddStack(OdStack* slots,int count,OdStack* stack) {
    int pass,i,limit=OdGame_StackLimit(stack->item_id);
    for(pass=0;pass<2;pass++)for(i=0;i<count&&Od_StackValid(stack);i++) {
        OdStack* to=&slots[i];int room,n;
        if(pass==0 && (!Od_StackValid(to)||!Same(to,stack)))continue;
        if(pass==1 && Od_StackValid(to))continue;
        room=limit-(Od_StackValid(to)?to->count:0);
        if(room<=0)continue;
        n=stack->count<room?stack->count:room;
        Move(to,stack,n);
    }
    return !Od_StackValid(stack);
}
static int CanAdd(const OdStack* slots,int count,const OdStack* stack) {
    int i,room=0,limit=OdGame_StackLimit(stack->item_id);
    for(i=0;i<count;i++) {
        if(!Od_StackValid(&slots[i]))room+=limit;
        else if(Same(&slots[i],stack)&&slots[i].count<limit)room+=limit-slots[i].count;
        if(room>=stack->count)return 1;
    }
    return 0;
}
int Od_Give(int id,int count,int damage) {
    OdStack s; s.item_id=id;s.count=count;s.damage=damage;
    Od_AddStack(od.carried.inventory,36,&s);
    return s.count;
}
void Od_ToolDamage(int amount) {
    OdStack* s=&od.carried.inventory[od.selected];int max=OdGame_ItemDurability(s->item_id);
    if(!max||!Od_StackValid(s))return;
    s->damage+=amount;
    if(s->damage>=max) { Od_StackClear(s);Od_Sound(OD_SOUND_BREAK,od.player.position); }
}
void Od_InventoryInit(void) {
    memset(&od.carried,0,sizeof(od.carried));
    memset(od.stations,0,sizeof(od.stations));
    od.selected=0;od.station=-1;od.screen=OD_SCREEN_NONE;od.craft_width=2;
    Od_Give(257,1,0);Od_Give(258,1,0);Od_Give(256,1,0);Od_Give(267,1,0);
    Od_Give(50,16,0);Od_Give(320,4,0);
}
void OdGame_SelectSlot(int slot) { if(slot>=0&&slot<9)od.selected=slot; }
const OdCarried* OdGame_GetCarriedState(void) { return &od.carried; }
void OdGame_GetCarried(const OdStack** inv,int* n,const OdStack** cursor,const OdStack** craft,int* cn) {
    if(inv)*inv=od.carried.inventory;
    if(n)*n=36;
    if(cursor)*cursor=&od.carried.cursor;
    if(craft)*craft=od.carried.craft;
    if(cn)*cn=9;
}
void OdGame_CloseScreen(void) {
    int i;if(od.dead)return;
    for(i=0;i<9;i++) {
        OdStack* s=&od.carried.craft[i];
        if(!Od_StackValid(s))continue;
        Od_AddStack(od.carried.inventory,36,s);
        if(Od_StackValid(s))Od_DropStack(s,od.player.position,0.5f);
    }
    if(Od_StackValid(&od.carried.cursor)) {
        Od_AddStack(od.carried.inventory,36,&od.carried.cursor);
        if(Od_StackValid(&od.carried.cursor))Od_DropStack(&od.carried.cursor,od.player.position,0.5f);
    }
    od.screen=OD_SCREEN_NONE;od.station=-1;od.craft_width=2;
}
void OdGame_OpenInventory(void) {
    if(od.dead)return;
    if(od.screen!=OD_SCREEN_NONE)OdGame_CloseScreen();
    od.screen=OD_SCREEN_INVENTORY;od.craft_width=2;
}
int Od_OpenStation(int x,int y,int z,int type) {
    int i,free_slot=-1;
    if(od.dead)return 0;
    OdGame_CloseScreen();
    if(type==58) {od.screen=OD_SCREEN_CRAFTING;od.craft_width=3;return 1;}
    for(i=0;i<OD_STATIONS;i++) {
        OdStation* s=&od.stations[i];
        if(!s->active) {if(free_slot<0)free_slot=i;continue;}
        if(s->x==x&&s->y==y&&s->z==z) {free_slot=i;break;}
    }
    if(free_slot<0) {Od_Message("There is no room for another container.");return 0;}
    {
        OdStation* s=&od.stations[free_slot];
        if(!s->active) {memset(s,0,sizeof(*s));s->active=1;s->x=x;s->y=y;s->z=z;s->type=type==54?54:61;}
    }
    od.station=free_slot;od.screen=type==54?OD_SCREEN_CHEST:OD_SCREEN_FURNACE;
    return 1;
}
void Od_BreakStation(int x,int y,int z) {
    int i,j;OdVec3 p={(float)x+0.5f,(float)y+0.5f,(float)z+0.5f};
    for(i=0;i<OD_STATIONS;i++) {
        OdStation* s=&od.stations[i];
        if(!s->active||s->x!=x||s->y!=y||s->z!=z)continue;
        if(od.station==i)OdGame_CloseScreen();
        for(j=0;j<27;j++)if(Od_StackValid(&s->slots[j]))Od_DropStack(&s->slots[j],p,0.3f);
        memset(s,0,sizeof(*s));
    }
}
static int Smelts(int id) {
    switch(id) {case 4:return 1;case 12:return 20;case 15:return 265;case 14:return 266;
    case 319:return 320;case 337:return 336;default:return 0;}
}
static float Fuel(int id) {
    switch(id) {case 263:return 80;case 17:case 5:case 54:case 58:return 15;
    case 280:case 6:return 5;default:return 0;}
}
void Od_InventoryTick(float dt) {
    int i;
    for(i=0;i<OD_STATIONS;i++) {
        OdStation* s=&od.stations[i];OdStack *in,*fuel,*out;int product,can;
        if(!s->active||s->type!=61)continue;
        in=&s->slots[0];fuel=&s->slots[1];out=&s->slots[2];
        product=Od_StackValid(in)?Smelts(in->item_id):0;
        can=product&&(!Od_StackValid(out)||(out->item_id==product&&out->count<OdGame_StackLimit(product)));
        if(s->burn>0)s->burn-=dt;
        if(s->burn<0)s->burn=0;
        if(s->burn<=0 && can && Od_StackValid(fuel) && Fuel(fuel->item_id)>0) {
            s->burn=s->burn_total=Fuel(fuel->item_id);
            fuel->count--;if(!fuel->count)Od_StackClear(fuel);
        }
        if(s->burn>0&&can) {
            s->cook+=dt;
            if(s->cook>=10.0f) {
                s->cook-=10.0f;
                if(!Od_StackValid(out)) {out->item_id=product;out->count=0;out->damage=0;}
                out->count++;in->count--;if(!in->count)Od_StackClear(in);
            }
        } else s->cook=0;
        if(Od_Block(s->x,s->y,s->z)!=(s->burn>0?62:61))Od_SetBlock(s->x,s->y,s->z,s->burn>0?62:61);
    }
}
OdStack OdGame_GetCraftOutput(void) { OdStack s;int used[9];Od_Recipe(&s,used);return s; }
static int Craft(int shift) {
    int used[9],i,done=0,iterations=0;
    for(;;) {
        OdStack product;Od_Recipe(&product,used);
        if(!Od_StackValid(&product))break;
        if(shift) {
            if(!CanAdd(od.carried.inventory,36,&product))break;
        } else {
            OdStack* cur=&od.carried.cursor;
            if(Od_StackValid(cur)&&(!Same(cur,&product)||cur->count>OdGame_StackLimit(product.item_id)-product.count))break;
        }
        for(i=0;i<9;i++)if(used[i]) {
            OdStack* s=&od.carried.craft[i];s->count--;if(!s->count)Od_StackClear(s);
        }
        if(shift)Od_AddStack(od.carried.inventory,36,&product);
        else Move(&od.carried.cursor,&product,product.count);
        done=1;if(!shift||++iterations>=64)break;
    }
    if(done)Od_Sound(OD_SOUND_CRAFT,od.player.position);
    return done;
}
int OdGame_ClickSlot(int area,int index,int button,int shift) {
    OdStack *s=NULL,*cur=&od.carried.cursor;int take_only=0,limit,n,before;
    if(od.dead||od.screen==OD_SCREEN_NONE||button<0||button>1)return 0;
    if(area==OD_AREA_CRAFT_OUTPUT) {
        if(od.screen!=OD_SCREEN_INVENTORY&&od.screen!=OD_SCREEN_CRAFTING)return 0;
        return Craft(shift);
    }
    if(area==OD_AREA_INVENTORY && index>=0&&index<36)s=&od.carried.inventory[index];
    if(area==OD_AREA_CRAFT && index>=0&&index<od.craft_width*od.craft_width &&
       (od.screen==OD_SCREEN_INVENTORY||od.screen==OD_SCREEN_CRAFTING))s=&od.carried.craft[index];
    if(area==OD_AREA_CHEST&&od.screen==OD_SCREEN_CHEST&&od.station>=0&&index>=0&&index<27)s=&od.stations[od.station].slots[index];
    if(area==OD_AREA_FURNACE&&od.screen==OD_SCREEN_FURNACE&&od.station>=0&&index>=0&&index<3) {
        s=&od.stations[od.station].slots[index];take_only=index==2;
    }
    if(!s)return 0;
    if(shift) {
        if(!Od_StackValid(s))return 0;
        before=s->count;
        if(area==OD_AREA_INVENTORY) {
            if(od.screen==OD_SCREEN_CHEST)Od_AddStack(od.stations[od.station].slots,27,s);
            else if(od.screen==OD_SCREEN_FURNACE) {
                if(Smelts(s->item_id))Od_AddStack(&od.stations[od.station].slots[0],1,s);
                else if(Fuel(s->item_id)>0)Od_AddStack(&od.stations[od.station].slots[1],1,s);
            } else if(index<9)Od_AddStack(&od.carried.inventory[9],27,s);
            else Od_AddStack(od.carried.inventory,9,s);
        } else Od_AddStack(od.carried.inventory,36,s);
        return s->count!=before;
    }
    if(!Od_StackValid(cur)) {
        if(!Od_StackValid(s))return 0;
        n=button?(s->count/2+s->count%2):s->count;
        Move(cur,s,n);return 1;
    }
    if(take_only) {
        if(!Od_StackValid(s)||!Same(s,cur))return 0;
        n=OdGame_StackLimit(cur->item_id)-cur->count;if(n>s->count)n=s->count;
        if(n<=0)return 0;
        Move(cur,s,n);return 1;
    }
    if(area==OD_AREA_FURNACE&&((index==0&&!Smelts(cur->item_id))||(index==1&&Fuel(cur->item_id)<=0)))return 0;
    if(!Od_StackValid(s)||Same(cur,s)) {
        limit=OdGame_StackLimit(cur->item_id);n=limit-(Od_StackValid(s)?s->count:0);
        if(button&&n>1)n=1;
        if(n>cur->count)n=cur->count;
        if(n<=0)return 0;
        Move(s,cur,n);return 1;
    }
    if(button)return 0;
    {OdStack tmp=*s;*s=*cur;*cur=tmp;} return 1;
}
void Od_DeathDrops(void) {
    int i;OdVec3 p=od.player.position;p.y+=0.5f;
    for(i=0;i<36;i++)if(Od_StackValid(&od.carried.inventory[i]))Od_DropStack(&od.carried.inventory[i],p,1.5f);
    for(i=0;i<9;i++)if(Od_StackValid(&od.carried.craft[i]))Od_DropStack(&od.carried.craft[i],p,1.5f);
    if(Od_StackValid(&od.carried.cursor))Od_DropStack(&od.carried.cursor,p,1.5f);
}

const char* OdGame_ItemName(int id) {
    switch(id) {
    case 0:return "";case 1:return "Stone";case 2:return "Grass";case 3:return "Dirt";
    case 4:return "Cobblestone";case 5:return "Wooden Planks";case 6:return "Sapling";
    case 7:return "Bedrock";case 12:return "Sand";case 13:return "Gravel";
    case 14:return "Gold Ore";case 15:return "Iron Ore";case 16:return "Coal Ore";
    case 17:return "Wood";case 18:return "Leaves";case 20:return "Glass";case 35:return "Wool";
    case 37:return "Dandelion";case 38:return "Rose";case 39:return "Brown Mushroom";case 40:return "Red Mushroom";
    case 41:return "Block of Gold";case 42:return "Block of Iron";case 44:return "Stone Slab";
    case 45:return "Bricks";case 47:return "Bookshelf";case 48:return "Moss Stone";
    case 49:return "Obsidian";case 50:return "Torch";case 54:return "Chest";
    case 56:return "Diamond Ore";case 57:return "Block of Diamond";case 58:return "Crafting Table";
    case 61:case 62:return "Furnace";
    case 256:return "Iron Shovel";case 257:return "Iron Pickaxe";case 258:return "Iron Axe";
    case 260:return "Apple";case 261:return "Bow";case 262:return "Arrow";case 263:return "Coal";
    case 264:return "Diamond";case 265:return "Iron Ingot";case 266:return "Gold Ingot";
    case 267:return "Iron Sword";case 268:return "Wooden Sword";case 269:return "Wooden Shovel";
    case 270:return "Wooden Pickaxe";case 271:return "Wooden Axe";case 272:return "Stone Sword";
    case 273:return "Stone Shovel";case 274:return "Stone Pickaxe";case 275:return "Stone Axe";
    case 276:return "Diamond Sword";case 277:return "Diamond Shovel";case 278:return "Diamond Pickaxe";
    case 279:return "Diamond Axe";case 280:return "Stick";case 281:return "Bowl";case 282:return "Mushroom Stew";
    case 283:return "Golden Sword";case 284:return "Golden Shovel";case 285:return "Golden Pickaxe";case 286:return "Golden Axe";
    case 287:return "String";case 288:return "Feather";case 289:return "Gunpowder";
    case 296:return "Wheat";case 297:return "Bread";case 318:return "Flint";
    case 319:return "Raw Porkchop";case 320:return "Cooked Porkchop";
    case 334:return "Leather";case 336:return "Clay Brick";case 337:return "Clay";
    default:return "Block";
    }
}
