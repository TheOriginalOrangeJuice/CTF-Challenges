#include "OdInternal.h"

static int Height(int x,int z) {
    int h=20;
    /* A low, continuous ridge frames the entrance without hiding it. */
    if(z>=19&&z<=49&&x>=16&&x<=39) {
        int edge=x-16;if(39-x<edge)edge=39-x;if(z-18<edge)edge=z-18;
        if(50-z<edge)edge=50-z;
        h+=edge<6?edge:6;
    }
    if(x>41&&z>26)h+=(int)(2.0f+sinf(x*0.25f)*sinf(z*0.21f)*2.0f);
    return h;
}
static void Tree(int x,int z,int tall) {
    int y,h=Height(x,z),xx,zz,yy;
    for(y=1;y<=tall;y++)Od_SetBlock(x,h+y,z,17);
    for(yy=h+tall-2;yy<=h+tall+1;yy++) {
        int r=yy==h+tall+1?1:2;
        for(xx=x-r;xx<=x+r;xx++)for(zz=z-r;zz<=z+r;zz++) {
            if(abs(xx-x)==r&&abs(zz-z)==r&&yy>=h+tall)continue;
            if(Od_Block(xx,yy,zz)==0)Od_SetBlock(xx,yy,zz,18);
        }
    }
}
void Od_WorldGenerate(void) {
    int x,y,z,h,f,i;
    static const int trees[][3]={{9,10,5},{14,7,5},{35,10,6},{39,18,5},{8,35,5},
        {15,45,6},{36,52,5},{51,15,6},{52,29,5},{54,49,6},{9,54,5},{44,55,5}};
    static const int ore[9][3]={{21,20,25},{21,20,26},{21,21,26},
        {27,19,32},{27,19,33},{27,20,33},{23,17,43},{24,17,43},{25,17,43}};
    for(z=0;z<64;z++)for(x=0;x<64;x++) {
        h=Height(x,z);
        for(y=0;y<64;y++)Od_SetBlock(x,y,z,y==0?7:y<h-3?1:y<h?3:y==h?2:0);
    }
    /* Single shallow route: descend one block every five blocks walked. */
    for(z=17;z<=42;z++) {
        f=20-(z>18?(z-18)/5:0);
        for(x=22;x<=26;x++) {
            for(y=f+1;y<=f+4;y++)Od_SetBlock(x,y,z,0);
            Od_SetBlock(x,f,z,z<20?2:1);
        }
    }
    /* Coal and iron are visible alongside the route, never extra diamond ore. */
    for(i=0;i<4;i++) {Od_SetBlock(21,21+(i%2),21+i/2,16);Od_SetBlock(27,18+i%2,35+i/2,15);}
    for(i=0;i<9;i++)Od_SetBlock(ore[i][0],ore[i][1],ore[i][2],56);
    /* Optional east-facing shelter for hostile mobs. A five-block rock wall
     * separates it from the diamond route; its opening faces away from spawn. */
    for(x=32;x<=39;x++)for(z=36;z<=42;z++) {
        Od_SetBlock(x,20,z,1);
        for(y=21;y<=23;y++)Od_SetBlock(x,y,z,0);
        if(x<39)Od_SetBlock(x,24,z,1);
    }
    Od_SetBlock(23,21,18,50);Od_SetBlock(25,19,29,50);Od_SetBlock(24,17,41,50);
    /* The entrance has two exposed stone shoulders visible from spawn. */
    for(y=21;y<=24;y++) {Od_SetBlock(21,y,19,1);Od_SetBlock(27,y,19,1);}
    /* Small lake, deep enough to swim and test the air supply. */
    for(x=7;x<=15;x++)for(z=21;z<=29;z++) {
        int dx=x-11,dz=z-25;if(dx*dx+dz*dz>21)continue;
        Od_SetBlock(x,16,z,12);
        for(y=17;y<=20;y++)Od_SetBlock(x,y,z,9);
    }
    for(i=0;i<(int)(sizeof(trees)/sizeof(trees[0]));i++)Tree(trees[i][0],trees[i][1],trees[i][2]);
    for(i=0;i<30;i++) {
        x=5+(i*13)%54;z=5+(i*23)%54;
        if(x>=19&&x<=29&&z>=10&&z<=45)continue;
        h=Height(x,z);if(Od_Block(x,h,z)==2&&Od_Block(x,h+1,z)==0)Od_SetBlock(x,h+1,z,i%3?37:38);
    }
    Od_SetBlock(20,21,13,58);Od_SetBlock(21,21,13,61);Od_SetBlock(22,21,13,54);
    Od_SetBlock(19,21,13,50);
    Od_SetBlock(23,17,40,39);Od_SetBlock(25,17,40,40);
}
