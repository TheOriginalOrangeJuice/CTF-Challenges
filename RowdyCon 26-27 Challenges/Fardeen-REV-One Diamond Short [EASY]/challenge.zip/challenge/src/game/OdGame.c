#include "OdInternal.h"

OdState od;
int Od_Block(int x,int y,int z) {
    if(x<0||y<0||z<0||x>=64||y>=64||z>=64)return y>=64?0:7;
    return od.hooks.get_block?od.hooks.get_block(x,y,z):0;
}
void Od_SetBlock(int x,int y,int z,int block) {
    if(x>=0&&y>=0&&z>=0&&x<64&&y<64&&z<64&&od.hooks.set_block)od.hooks.set_block(x,y,z,block);
}
int Od_Solid(int b) {return b!=0&&b!=6&&b!=8&&b!=9&&b!=10&&b!=11&&b!=37&&b!=38&&b!=39&&b!=40&&b!=50;}
void Od_Sound(int s,OdVec3 p) {if(od.hooks.sound)od.hooks.sound(s,p.x,p.y,p.z);}
void Od_Message(const char* s) {if(od.hooks.message)od.hooks.message(s);}
uint32_t Od_Random(void) {od.rng=od.rng*1664525u+1013904223u;return od.rng;}
float Od_DistanceSquared(OdVec3 a,OdVec3 b) {float x=a.x-b.x,y=a.y-b.y,z=a.z-b.z;return x*x+y*y+z*z;}
int Od_LineClear(OdVec3 a,OdVec3 b) {
    float len=sqrtf(Od_DistanceSquared(a,b));int steps=(int)(len*8)+1,i;
    for(i=1;i<steps;i++) {
        float t=(float)i/steps;
        if(Od_Solid(Od_Block((int)floorf(a.x+(b.x-a.x)*t),(int)floorf(a.y+(b.y-a.y)*t),(int)floorf(a.z+(b.z-a.z)*t))))return 0;
    }
    return 1;
}
void OdGame_Init(const OdGameHooks* hooks) {
    memset(&od,0,sizeof(od));if(hooks)od.hooks=*hooks;od.initialized=1;
}
void OdGame_GenerateWorld(void) {
    OdGameHooks hooks=od.hooks;
    memset(&od,0,sizeof(od));od.hooks=hooks;od.initialized=1;
    od.health=20;od.air=300;od.rng=0x1D1A2026u;od.mining_x=-1;
    od.player.position.x=24.5f;od.player.position.y=21.05f;od.player.position.z=11.5f;
    od.player.look.z=1;od.player.on_ground=1;od.was_grounded=1;od.fall_top=21.05f;
    Od_InventoryInit();Od_WorldGenerate();Od_EntitiesInit();
    if(od.hooks.teleport)od.hooks.teleport(24.5f,21.05f,11.5f,180,0);
}
void OdGame_GetSnapshot(OdGameSnapshot* o) {
    if(!o)return;
    memset(o,0,sizeof(*o));o->inventory=od.carried.inventory;o->cursor=&od.carried.cursor;o->crafting=od.carried.craft;
    o->mobs=od.mobs;o->drops=od.drops;o->projectiles=od.projectiles;
    o->selected=od.selected;o->screen=od.screen;o->craft_width=od.craft_width;
    o->health=od.health;o->air=od.air>0?od.air:0;o->dead=od.dead;o->elapsed=od.elapsed;
    o->mining_x=od.mining_x;o->mining_y=od.mining_y;o->mining_z=od.mining_z;
    o->mining_progress=od.mining;o->hurt_time=od.hurt;o->swing_time=od.swing;
    if(od.station>=0) {
        OdStation* s=&od.stations[od.station];
        if(od.screen==OD_SCREEN_CHEST)o->chest=s->slots;
        if(od.screen==OD_SCREEN_FURNACE) {
            o->furnace=s->slots;o->furnace_progress=s->cook/10;
            o->furnace_fuel=s->burn_total>0?s->burn/s->burn_total:0;
        }
    }
}
void Od_DamagePlayer(int amount,OdVec3 from) {
    float x,z,d;
    if(od.dead||od.hurt>0||amount<=0)return;
    od.health-=amount;od.hurt=0.5f;
    Od_Sound(OD_SOUND_HURT,od.player.position);
    x=od.player.position.x-from.x;z=od.player.position.z-from.z;d=sqrtf(x*x+z*z);
    if(d>0.01f&&od.hooks.knockback)od.hooks.knockback(x/d*0.24f,0.20f,z/d*0.24f);
    if(od.health<=0) {
        od.health=0;Od_DeathDrops();od.dead=1;od.screen=OD_SCREEN_DEATH;od.station=-1;
        od.mining=0;Od_Sound(OD_SOUND_DEATH,od.player.position);
    }
}
int OdGame_IsDead(void) {return od.dead;}
void OdGame_SetWorldTime(uint64_t elapsed_ms) {
    od.world_time_ms=elapsed_ms;od.external_world_time=1;
}
float Od_Daylight(void) {
    double ms=od.external_world_time?(double)od.world_time_ms:od.elapsed*1000.0;
    return (float)(0.55+0.45*cos(ms/900000.0*6.283185307));
}
void OdGame_Respawn(void) {
    if(!od.dead)return;
    od.dead=0;od.health=20;od.air=300;od.hurt=1;od.screen=OD_SCREEN_NONE;od.station=-1;
    od.air_clock=0;od.hazard_clock=0;od.fall_top=21.05f;od.was_grounded=1;
    od.player.position.x=24.5f;od.player.position.y=21.05f;od.player.position.z=11.5f;
    if(od.hooks.teleport)od.hooks.teleport(24.5f,21.05f,11.5f,180,0);
}
void OdGame_Tick(float dt,const OdPlayerFrame* player) {
    if(!od.initialized||dt<=0||!isfinite(dt))return;
    if(dt>0.25f)dt=0.25f;
    if(player)od.player=*player;
    od.elapsed+=dt;
    if(od.hurt>0)od.hurt-=dt;
    if(od.swing>0)od.swing-=dt;
    if(od.attack>0)od.attack-=dt;
    Od_InventoryTick(dt);Od_EntitiesTick(dt);
    if(od.dead)return;
    if(od.player.head_in_water) {
        od.air_clock+=dt;
        while(od.air_clock>=0.05f) {
            od.air_clock-=0.05f;od.air--;
            if(od.air<=-20) {od.air=0;Od_DamagePlayer(2,od.player.position);}
        }
    } else {od.air=300;od.air_clock=0;}
    if(od.player.in_lava||Od_Solid(Od_Block((int)floorf(od.player.position.x),(int)floorf(od.player.position.y+1.6f),(int)floorf(od.player.position.z)))) {
        od.hazard_clock+=dt;
        if(od.hazard_clock>=0.55f) {od.hazard_clock=0;Od_DamagePlayer(od.player.in_lava?4:1,od.player.position);}
    } else od.hazard_clock=0;
    if(od.player.position.y>od.fall_top)od.fall_top=od.player.position.y;
    if(od.player.head_in_water)od.fall_top=od.player.position.y;
    if(od.player.on_ground) {
        if(!od.was_grounded && od.fall_top-od.player.position.y>3.5f)
            Od_DamagePlayer((int)floorf(od.fall_top-od.player.position.y-3),od.player.position);
        od.fall_top=od.player.position.y;
    }
    od.was_grounded=od.player.on_ground;
    if(od.player.position.y<0)Od_DamagePlayer(20,od.player.position);
}

static int PickTier(int id) {switch(id){case 270:case 285:return 1;case 274:return 2;case 257:return 3;case 278:return 4;default:return 0;}}
static int Axe(int id) {return id==258||id==271||id==275||id==279||id==286;}
static int Shovel(int id) {return id==256||id==269||id==273||id==277||id==284;}
static int Sword(int id) {return id==267||id==268||id==272||id==276||id==283;}
static int Stone(int b) {return b==1||b==4||b==14||b==15||b==16||b==41||b==42||b==43||b==44||b==45||b==48||b==49||b==56||b==57||b==61||b==62;}
static int Wood(int b) {return b==5||b==17||b==47||b==54||b==58;}
static int Earth(int b) {return b==2||b==3||b==12||b==13;}
static float Hardness(int b) {
    switch(b) {case 7:return 1000000;case 49:return 50;case 56:case 14:case 15:case 16:return 3;
    case 41:case 42:case 57:return 5;case 61:case 62:return 3.5f;
    case 1:return 1.5f;case 4:case 17:case 5:case 45:return 2;case 54:case 58:return 2.5f;
    case 18:case 20:return 0.3f;case 50:case 37:case 38:case 39:case 40:case 6:return 0.05f;
    case 35:return 0.8f;default:return 0.6f;}
}
static int Harvest(int block,int tool) {
    int tier=PickTier(tool);
    if(block==49)return tier==4;
    if(block==56||block==14||block==41||block==57)return tier>=3;
    if(block==15||block==42)return tier>=2;
    if(Stone(block))return tier>0;
    return 1;
}
static float ToolSpeed(int block,int tool) {
    float speed=1;
    if((Stone(block)&&PickTier(tool))||(Wood(block)&&Axe(tool))||(Earth(block)&&Shovel(tool))) {
        if(tool==256||tool==257||tool==258)speed=6;
        else if(tool>=277&&tool<=279)speed=8;
        else if(tool>=284&&tool<=286)speed=12;
        else if(tool>=273&&tool<=275)speed=4;
        else speed=2;
    }
    if(block==18&&Sword(tool))speed=1.5f;
    if(od.player.head_in_water)speed/=5;
    if(!od.player.on_ground)speed/=5;
    return speed;
}
static int DropFor(int b) {
    switch(b) {case 1:return 4;case 2:return 3;case 16:return 263;case 56:return 264;
    case 20:return 0;case 18:return Od_Random()%20==0?6:0;
    case 13:return Od_Random()%10==0?318:13;case 62:return 61;default:return b;}
}
void OdGame_Mine(int x,int y,int z,int valid,float dt) {
    int b,tool,drop;OdVec3 p={(float)x+0.5f,(float)y+0.5f,(float)z+0.5f},eye=od.player.position;
    eye.y+=1.62f;
    if(od.dead||od.screen!=OD_SCREEN_NONE||!valid||dt<=0||!isfinite(dt)||Od_DistanceSquared(eye,p)>28) {
        od.mining=0;od.mining_x=-1;return;
    }
    b=Od_Block(x,y,z);
    if(b==0||b==7||b==8||b==9||b==10||b==11) {od.mining=0;return;}
    if(x!=od.mining_x||y!=od.mining_y||z!=od.mining_z||b!=od.mining_block) {
        od.mining=0;od.mining_x=x;od.mining_y=y;od.mining_z=z;od.mining_block=b;
    }
    tool=Od_StackValid(&od.carried.inventory[od.selected])?od.carried.inventory[od.selected].item_id:0;
    if(dt>0.25f)dt=0.25f;
    od.mining+=dt*ToolSpeed(b,tool)/(Hardness(b)*(Harvest(b,tool)?1.5f:5));
    if(od.swing<=0) {od.swing=0.22f;Od_Sound(OD_SOUND_DIG,p);}
    if(od.mining<1)return;
    Od_BreakStation(x,y,z);Od_SetBlock(x,y,z,0);Od_Sound(OD_SOUND_BREAK,p);
    drop=Harvest(b,tool)?DropFor(b):0;
    if(drop)Od_SpawnDrop(drop,1,0,p,0.2f);
    if(OdGame_ItemDurability(tool))Od_ToolDamage(Sword(tool)?2:1);
    od.mining=0;od.mining_x=-1;
    /* Unsupported torches and flowers drop when their floor is removed. */
    b=Od_Block(x,y+1,z);
    if(b==50||b==6||(b>=37&&b<=40)) {Od_SetBlock(x,y+1,z,0);p.y++;Od_SpawnDrop(b,1,0,p,0.2f);}
}
static int Placeable(int id) {
    return (id>=1&&id<=6)||(id>=12&&id<=18)||id==20||id==35||(id>=37&&id<=45)||id==47||id==48||id==49||id==50||id==54||id==56||id==57||id==58||id==61;
}
int OdGame_Use(int x,int y,int z,int fx,int fy,int fz,int valid) {
    OdStack* held=&od.carried.inventory[od.selected];int id=Od_StackValid(held)?held->item_id:0,b,healing,i;
    OdVec3 eye=od.player.position,p={(float)x+0.5f,(float)y+0.5f,(float)z+0.5f};eye.y+=1.62f;
    if(od.dead||od.screen!=OD_SCREEN_NONE)return 0;
    healing=id==320?8:id==319?3:id==260?4:id==297?5:id==282?10:0;
    if(healing && od.health<20) {
        od.health+=healing;if(od.health>20)od.health=20;
        held->count--;if(!held->count)Od_StackClear(held);
        if(id==282) {int left=Od_Give(281,1,0);if(left)Od_SpawnDrop(281,left,0,od.player.position,0.5f);}
        Od_Sound(OD_SOUND_EAT,od.player.position);od.swing=0.3f;return 1;
    }
    if(id==261 && od.attack<=0) {
        for(i=0;i<36;i++) {
            OdStack* arrows=&od.carried.inventory[i];
            if(arrows->item_id!=262||arrows->count<=0)continue;
            if(!Od_Shoot(eye,od.player.look,1))return 0;
            arrows->count--;if(!arrows->count)Od_StackClear(arrows);od.attack=0.35f;return 1;
        }
    }
    if(!valid||Od_DistanceSquared(eye,p)>28)return 0;
    b=Od_Block(x,y,z);if(b==54||b==58||b==61||b==62)return Od_OpenStation(x,y,z,b);
    if(!Placeable(id))return 0;
    if(abs(fx)+abs(fy)+abs(fz)!=1)return 0;
    if(b!=6&&b!=50&&(b<37||b>40)) {x+=fx;y+=fy;z+=fz;}
    if(x<1||x>62||y<1||y>62||z<1||z>62)return 0;
    b=Od_Block(x,y,z);if(Od_Solid(b))return 0;
    if(id==50&&!Od_Solid(Od_Block(x,y-1,z))&&!Od_Solid(Od_Block(x-fx,y-fy,z-fz)))return 0;
    if(Od_Solid(id)) {
        if(od.player.position.x+0.3f>x&&od.player.position.x-0.3f<x+1&&
           od.player.position.z+0.3f>z&&od.player.position.z-0.3f<z+1&&
           od.player.position.y+1.8f>y&&od.player.position.y<y+1)return 0;
        for(i=0;i<OD_MAX_MOBS;i++) {
            OdMob* m=&od.mobs[i];if(!m->active)continue;
            if(fabsf(m->position.x-x-0.5f)<0.8f&&fabsf(m->position.z-z-0.5f)<0.8f&&m->position.y<y+1&&m->position.y+1.5f>y)return 0;
        }
    }
    if(b==50||b==6||(b>=37&&b<=40)) {p.x=x+0.5f;p.y=y+0.5f;p.z=z+0.5f;Od_SpawnDrop(b,1,0,p,0.2f);}
    Od_SetBlock(x,y,z,id);held->count--;if(!held->count)Od_StackClear(held);
    p.x=x+0.5f;p.y=y+0.5f;p.z=z+0.5f;Od_Sound(OD_SOUND_PLACE,p);od.swing=0.2f;return 1;
}
int OdGame_Attack(void) {
    int i,best=-1;float nearest=3.4f;OdVec3 eye=od.player.position;eye.y+=1.62f;
    if(od.dead||od.screen!=OD_SCREEN_NONE)return 0;
    for(i=0;i<OD_MAX_MOBS;i++) {
        OdMob* m=&od.mobs[i];OdVec3 c;float x,y,z,t,perp,r;
        if(!m->active)continue;
        c=m->position;c.y+=m->kind==OD_MOB_CHICKEN?0.5f:m->kind==OD_MOB_SPIDER?0.45f:0.9f;
        x=c.x-eye.x;y=c.y-eye.y;z=c.z-eye.z;t=x*od.player.look.x+y*od.player.look.y+z*od.player.look.z;
        r=m->kind==OD_MOB_SPIDER?1.0f:0.75f;perp=x*x+y*y+z*z-t*t;
        if(t>=0&&t<nearest&&perp<r*r&&Od_LineClear(eye,c)) {nearest=t;best=i;}
    }
    if(best<0)return 0;
    if(od.attack<=0&&od.mobs[best].hurt_time<=0) {
        int id=od.carried.inventory[od.selected].item_id,damage=1;
        if(id==267)damage=7;else if(id==276)damage=8;else if(id==272)damage=6;else if(id==268||id==283)damage=5;
        else if(Axe(id))damage=4;else if(PickTier(id))damage=3;else if(Shovel(id))damage=2;
        /* A strike may land every half second, after the target's 0.45-second
         * hurt immunity. Rejected attempts neither hit nor wear the tool. */
        Od_Sound(OD_SOUND_SWING,od.player.position);
        if(Od_DamageMob(best,damage,od.player.position)) {
            Od_ToolDamage(Sword(id)?1:2);
            od.attack=0.50f;od.swing=0.25f;
        }
    }
    return 1;
}
void OdGame_DropSelected(int whole) {
    OdStack* s=&od.carried.inventory[od.selected];int n;OdVec3 p=od.player.position;
    if(od.dead||od.screen!=OD_SCREEN_NONE||!Od_StackValid(s))return;
    n=whole?s->count:1;p.y+=1.2f;p.x+=od.player.look.x*0.7f;p.z+=od.player.look.z*0.7f;
    Od_SpawnDrop(s->item_id,n,s->damage,p,1.0f);s->count-=n;if(!s->count)Od_StackClear(s);
}
