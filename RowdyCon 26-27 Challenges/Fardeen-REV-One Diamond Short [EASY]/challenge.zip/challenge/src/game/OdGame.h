#ifndef OD_GAME_H
#define OD_GAME_H

#include "../shared/OdTypes.h"

#define OD_WORLD_SIZE 64
#define OD_CHEST_SLOTS 27
#define OD_MAX_MOBS 24
#define OD_MAX_DROPS 256
#define OD_MAX_PROJECTILES 32

/* Stable, naturally four-byte-aligned slots. The actual signed 32-bit count is
 * deliberately writable by an external process; never shadow it with a ledger. */
typedef struct OdVec3 { float x, y, z; } OdVec3;
enum OdScreen { OD_SCREEN_NONE, OD_SCREEN_INVENTORY, OD_SCREEN_CRAFTING,
    OD_SCREEN_FURNACE, OD_SCREEN_CHEST, OD_SCREEN_DEATH };
enum OdSlotArea { OD_AREA_INVENTORY, OD_AREA_CURSOR, OD_AREA_CRAFT,
    OD_AREA_CRAFT_OUTPUT, OD_AREA_CHEST, OD_AREA_FURNACE };
enum OdMobKind { OD_MOB_PIG, OD_MOB_COW, OD_MOB_SHEEP, OD_MOB_CHICKEN,
    OD_MOB_ZOMBIE, OD_MOB_SKELETON, OD_MOB_SPIDER, OD_MOB_CREEPER };
enum OdSound { OD_SOUND_STEP, OD_SOUND_DIG, OD_SOUND_BREAK, OD_SOUND_PLACE,
    OD_SOUND_PICKUP, OD_SOUND_HURT, OD_SOUND_EAT, OD_SOUND_SWING,
    OD_SOUND_MOB_HURT, OD_SOUND_BOW, OD_SOUND_FUSE, OD_SOUND_EXPLODE,
    OD_SOUND_CRAFT, OD_SOUND_DEATH };

typedef struct OdMob {
    int active, kind, health, sheared;
    OdVec3 position, velocity;
    float yaw, animation, hurt_time, attack_time, fuse;
    float burn_time, burn_clock, anger_time;
} OdMob;
typedef struct OdDrop {
    int active;
    OdStack stack;
    OdVec3 position, velocity;
    float age, pickup_delay;
} OdDrop;
typedef struct OdProjectile {
    int active;
    OdVec3 position, velocity;
    float age;
} OdProjectile;

/* Coordinates are feet position in block units. look is a normalized camera
 * direction. The engine owns player collision/movement; survival owns health. */
typedef struct OdPlayerFrame {
    OdVec3 position, velocity, look;
    int on_ground, head_in_water, in_lava;
} OdPlayerFrame;
typedef struct OdGameHooks {
    int (*get_block)(int x, int y, int z);
    void (*set_block)(int x, int y, int z, int block);
    void (*teleport)(float x, float y, float z, float yaw, float pitch);
    void (*knockback)(float x, float y, float z);
    void (*sound)(int sound, float x, float y, float z);
    void (*message)(const char* text);
} OdGameHooks;

typedef struct OdGameSnapshot {
    const OdStack* inventory; /* 0..8 hotbar, 9..35 main inventory */
    const OdStack* cursor;
    const OdStack* crafting; /* row-major, stride = craft_width */
    const OdStack* chest; /* NULL unless a chest screen is open */
    const OdStack* furnace; /* input=0, fuel=1, output=2; NULL when closed */
    const OdMob* mobs;
    const OdDrop* drops;
    const OdProjectile* projectiles;
    int selected, screen, craft_width, health, air, dead;
    int mining_x, mining_y, mining_z;
    float mining_progress, hurt_time, swing_time;
    float furnace_progress, furnace_fuel;
    double elapsed;
} OdGameSnapshot;

/* Call Init once, then GenerateWorld after engine world storage is allocated.
 * GenerateWorld resets the fixed authored run and supplies the starter kit once.
 * Respawn never calls GenerateWorld and never awards another starter kit. */
void OdGame_Init(const OdGameHooks* hooks);
void OdGame_GenerateWorld(void);
void OdGame_Tick(float dt, const OdPlayerFrame* player);
/* Feed the trial's authoritative elapsed clock even while simulation is paused.
 * This keeps sunlight and mob behaviour synchronized with the rendered sky. */
void OdGame_SetWorldTime(uint64_t elapsed_ms);
void OdGame_GetSnapshot(OdGameSnapshot* out);
const OdCarried* OdGame_GetCarriedState(void);
void OdGame_GetCarried(const OdStack** inventory, int* inventory_count,
                       const OdStack** cursor, const OdStack** crafting, int* crafting_count);
void OdGame_SelectSlot(int slot);
void OdGame_OpenInventory(void);
void OdGame_CloseScreen(void);
/* button: 0 left, 1 right; shift: fast transfer; all actions operate true slots. */
int OdGame_ClickSlot(int area, int index, int button, int shift);
OdStack OdGame_GetCraftOutput(void);
/* Held primary button: call every simulation tick. Pass valid=0 on release or
 * while aiming into air. Successful breaking is handled entirely here. */
void OdGame_Mine(int x, int y, int z, int valid, float dt);
/* Secondary click at selected block and adjacent face; valid=0 still eats food. */
int OdGame_Use(int x, int y, int z, int face_x, int face_y, int face_z, int valid);
int OdGame_Attack(void);
void OdGame_DropSelected(int whole_stack);
void OdGame_Respawn(void);
int OdGame_IsDead(void);
int OdGame_StackLimit(int item_id);
int OdGame_ItemDurability(int item_id);
const char* OdGame_ItemName(int item_id);

#endif
