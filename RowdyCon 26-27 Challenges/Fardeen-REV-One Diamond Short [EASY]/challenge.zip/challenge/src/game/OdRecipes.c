#include "OdInternal.h"

/* Translation and horizontal reflection are accepted; extra occupied cells
 * invalidate a recipe. Every output is derived afresh from the actual slots. */
static int Match(const int* pattern, int w, int h, int used[9]) {
    int minx=3,miny=3,maxx=-1,maxy=-1,x,y,k,flip,ok;
    int width=od.craft_width;
    for(y=0;y<width;y++) for(x=0;x<width;x++) {
        k=y*width+x;
        if(!Od_StackValid(&od.carried.craft[k])) continue;
        if(x<minx)minx=x;
        if(x>maxx)maxx=x;
        if(y<miny)miny=y;
        if(y>maxy)maxy=y;
    }
    if(maxx-minx+1!=w || maxy-miny+1!=h) return 0;
    for(flip=0;flip<2;flip++) {
        ok=1;
        for(y=0;y<h;y++) for(x=0;x<w;x++) {
            int want=pattern[y*w+(flip?w-1-x:x)];
            OdStack* s=&od.carried.craft[(y+miny)*width+x+minx];
            int got=Od_StackValid(s)?s->item_id:0;
            if(got!=want) ok=0;
        }
        if(ok) {
            memset(used,0,9*sizeof(int));
            for(y=0;y<h;y++) for(x=0;x<w;x++) {
                if(pattern[y*w+(flip?w-1-x:x)]) used[(y+miny)*width+x+minx]=1;
            }
            return 1;
        }
    }
    return 0;
}

static int Recipe(OdStack* out, int used[9], int id, int amount,
                  int w,int h,int a,int b,int c,int d,int e,int f,int g,int j,int k) {
    int p[9]={a,b,c,d,e,f,g,j,k};
    if(!Match(p,w,h,used))return 0;
    out->item_id=id; out->count=amount; out->damage=0;
    return 1;
}

void Od_Recipe(OdStack* out,int used[9]) {
    int tier;
    static const int mats[5]={5,4,265,264,266};
    static const int pick[5]={270,274,257,278,285};
    static const int axe[5]={271,275,258,279,286};
    static const int spade[5]={269,273,256,277,284};
    static const int sword[5]={268,272,267,276,283};
    Od_StackClear(out); memset(used,0,9*sizeof(int));
#define R(id,n,w,h,a,b,c,d,e,f,g,j,k) if(Recipe(out,used,id,n,w,h,a,b,c,d,e,f,g,j,k))return
    R(5,4,1,1,17,0,0,0,0,0,0,0,0);
    R(280,4,1,2,5,5,0,0,0,0,0,0,0);
    R(58,1,2,2,5,5,5,5,0,0,0,0,0);
    R(50,4,1,2,263,280,0,0,0,0,0,0,0);
    R(61,1,3,3,4,4,4,4,0,4,4,4,4);
    R(54,1,3,3,5,5,5,5,0,5,5,5,5);
    R(281,4,3,2,5,0,5,0,5,0,0,0,0);
    R(44,3,3,1,1,1,1,0,0,0,0,0,0);
    R(45,1,2,2,336,336,336,336,0,0,0,0,0);
    R(297,1,3,1,296,296,296,0,0,0,0,0,0);
    R(35,1,3,3,287,287,287,287,287,287,287,287,287);
    for(tier=0;tier<5;tier++) {
        int m=mats[tier];
        R(pick[tier],1,3,3,m,m,m,0,280,0,0,280,0);
        R(axe[tier],1,2,3,m,m,m,280,0,280,0,0,0);
        R(spade[tier],1,1,3,m,280,280,0,0,0,0,0,0);
        R(sword[tier],1,1,3,m,m,280,0,0,0,0,0,0);
    }
    R(41,1,3,3,266,266,266,266,266,266,266,266,266);
    R(42,1,3,3,265,265,265,265,265,265,265,265,265);
    R(57,1,3,3,264,264,264,264,264,264,264,264,264);
    R(266,9,1,1,41,0,0,0,0,0,0,0,0);
    R(265,9,1,1,42,0,0,0,0,0,0,0,0);
    R(264,9,1,1,57,0,0,0,0,0,0,0,0);
    R(261,1,3,3,0,280,287,280,0,287,0,280,287);
    R(262,4,1,3,318,280,288,0,0,0,0,0,0);
    /* Mushroom stew is shapeless. */
    {
        int i,mask=0,n=0;
        for(i=0;i<od.craft_width*od.craft_width;i++) {
            OdStack* s=&od.carried.craft[i]; int bit;
            if(!Od_StackValid(s))continue;
            bit=s->item_id==39?1:s->item_id==40?2:s->item_id==281?4:0;
            if(!bit || (mask&bit))return;
            mask|=bit; used[i]=1; n++;
        }
        if(mask==7 && n==3) {out->item_id=282;out->count=1;}
    }
#undef R
}
