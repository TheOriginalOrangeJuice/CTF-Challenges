#include "OdInternal.h"

static float MobHeight(int kind) {return kind==OD_MOB_CHICKEN?0.7f:kind==OD_MOB_SPIDER?0.8f:kind==OD_MOB_PIG?0.9f:kind==OD_MOB_COW?1.4f:kind==OD_MOB_SHEEP?1.3f:1.8f;}
static float MobRadius(int kind) {return kind==OD_MOB_SPIDER?0.65f:kind==OD_MOB_CHICKEN?0.25f:0.35f;}
static int BodyFree(OdVec3 p,float radius,float height) {
    int x,y,z;
    for(x=(int)floorf(p.x-radius);x<=(int)floorf(p.x+radius);x++)
    for(y=(int)floorf(p.y+0.02f);y<=(int)floorf(p.y+height-0.02f);y++)
    for(z=(int)floorf(p.z-radius);z<=(int)floorf(p.z+radius);z++)
        if(Od_Solid(Od_Block(x,y,z)))return 0;
    return 1;
}
static int OnGround(OdVec3 p,float radius) {p.y-=0.08f;return !BodyFree(p,radius,0.1f);}
static int MoveBody(OdVec3* p,OdVec3* v,float radius,float height,float dt,int step) {
    OdVec3 test=*p;int blocked=0;float target;
    test.x+=v->x*dt;
    if(BodyFree(test,radius,height))p->x=test.x;
    else {
        test.y+=1.01f;
        if(step&&OnGround(*p,radius)&&BodyFree(test,radius,height)) {p->x=test.x;p->y=test.y;}
        else {v->x=0;blocked=1;}
    }
    test=*p;test.z+=v->z*dt;
    if(BodyFree(test,radius,height))p->z=test.z;
    else {
        test.y+=1.01f;
        if(step&&OnGround(*p,radius)&&BodyFree(test,radius,height)) {p->z=test.z;p->y=test.y;}
        else {v->z=0;blocked=1;}
    }
    target=p->y+v->y*dt;test=*p;test.y=target;
    if(BodyFree(test,radius,height))p->y=target;
    else {
        /* Binary search the last free position avoids tunnelling through floors. */
        float low=0,high=1;int i;
        for(i=0;i<10;i++) {float t=(low+high)*0.5f;test=*p;test.y=p->y+(target-p->y)*t;if(BodyFree(test,radius,height))low=t;else high=t;}
        p->y+=(target-p->y)*low;v->y=0;
    }
    return blocked;
}
void Od_SpawnDrop(int item,int count,int damage,OdVec3 p,float delay) {
    int i,n,limit=OdGame_StackLimit(item);
    if(item<=0||count<=0)return;
    /* Invalid external counts must not turn a drop action into an unbounded
     * allocation loop. Ordinary callers never supply more than one full stack. */
    if(count>64)count=64;
    /* Merge only with world entities; a pickup moves their true stack into the
     * carried array and subtracts exactly what fit. */
    for(i=0;i<OD_MAX_DROPS&&count>0;i++) {
        OdDrop* d=&od.drops[i];int room;
        if(!d->active||d->stack.item_id!=item||d->stack.damage!=damage||Od_DistanceSquared(d->position,p)>2.25f)continue;
        room=limit-d->stack.count;if(room<=0)continue;n=count<room?count:room;
        d->stack.count+=n;count-=n;d->age=0;if(delay>d->pickup_delay)d->pickup_delay=delay;
    }
    for(i=0;i<OD_MAX_DROPS&&count>0;i++) {
        OdDrop* d=&od.drops[i];if(d->active)continue;
        memset(d,0,sizeof(*d));d->active=1;d->stack.item_id=item;d->stack.damage=damage;
        n=count<limit?count:limit;d->stack.count=n;count-=n;d->position=p;d->pickup_delay=delay;
        d->velocity.x=((int)(Od_Random()%100)-50)*0.018f;
        d->velocity.z=((int)(Od_Random()%100)-50)*0.018f;d->velocity.y=2.5f;
    }
    /* The bounded pool can be filled only by leaving hundreds of separate
     * stacks uncollected. Reclaim the oldest non-diamond drop before losing a
     * newly mined item, preserving the challenge's scarce resource. */
    if(count>0) {
        int oldest=-1;float age=-1;
        for(i=0;i<OD_MAX_DROPS;i++)if(od.drops[i].stack.item_id!=264&&od.drops[i].age>age) {age=od.drops[i].age;oldest=i;}
        if(oldest>=0) {od.drops[oldest].active=0;Od_SpawnDrop(item,count,damage,p,delay);}
    }
}
void Od_DropStack(OdStack* stack,OdVec3 p,float delay) {
    if(!Od_StackValid(stack))return;
    Od_SpawnDrop(stack->item_id,stack->count,stack->damage,p,delay);Od_StackClear(stack);
}
static void Spawn(int i,int kind,float x,float y,float z) {
    OdMob* m=&od.mobs[i];memset(m,0,sizeof(*m));m->active=1;m->kind=kind;
    m->health=kind>=OD_MOB_ZOMBIE?20:kind==OD_MOB_CHICKEN?4:10;
    m->position.x=x;m->position.y=y;m->position.z=z;m->yaw=(float)(i*47%360);m->attack_time=(float)(i%3)*0.4f;
}
static float Surface(float x,float z) {int y;for(y=62;y>0;y--)if(Od_Solid(Od_Block((int)x,y,(int)z)))return y+1.05f;return 21;}
void Od_EntitiesInit(void) {
    memset(od.mobs,0,sizeof(od.mobs));memset(od.drops,0,sizeof(od.drops));memset(od.projectiles,0,sizeof(od.projectiles));
    Spawn(0,OD_MOB_PIG,17.5f,21.05f,12.5f);Spawn(1,OD_MOB_PIG,13.5f,21.05f,15.5f);
    Spawn(2,OD_MOB_COW,32.5f,21.05f,12.5f);Spawn(3,OD_MOB_COW,36.5f,21.05f,8.5f);
    Spawn(4,OD_MOB_SHEEP,18.5f,21.05f,7.5f);Spawn(5,OD_MOB_SHEEP,29.5f,21.05f,7.5f);
    Spawn(6,OD_MOB_CHICKEN,26.5f,21.05f,15.5f);Spawn(7,OD_MOB_CHICKEN,30.5f,21.05f,17.5f);
    Spawn(8,OD_MOB_ZOMBIE,33.5f,21.05f,38.5f);
    Spawn(9,OD_MOB_SPIDER,34.5f,21.05f,41.5f);
    Spawn(10,OD_MOB_SKELETON,36.5f,21.05f,37.5f);
    Spawn(11,OD_MOB_CREEPER,46.5f,Surface(46.5f,42.5f),42.5f);
    Spawn(12,OD_MOB_ZOMBIE,49.5f,Surface(49.5f,40.5f),40.5f);
    Spawn(13,OD_MOB_SPIDER,47.5f,Surface(47.5f,45.5f),45.5f);
}
int Od_DamageMob(int index,int amount,OdVec3 from) {
    OdMob* m;float x,z,d;int item=0,count=2;
    if(index<0||index>=OD_MAX_MOBS||amount<=0)return 0;
    m=&od.mobs[index];
    if(!m->active||m->hurt_time>0)return 0;
    m->health-=amount;m->hurt_time=0.45f;Od_Sound(OD_SOUND_MOB_HURT,m->position);
    if(m->kind==OD_MOB_SPIDER&&Od_DistanceSquared(from,od.player.position)<0.01f)m->anger_time=30;
    x=m->position.x-from.x;z=m->position.z-from.z;d=sqrtf(x*x+z*z);
    if(d>0.01f) {m->velocity.x=x/d*5;m->velocity.z=z/d*5;m->velocity.y=4;}
    if(m->kind==OD_MOB_SHEEP&&!m->sheared) {m->sheared=1;Od_SpawnDrop(35,2,0,m->position,0.3f);}
    if(m->health>0)return 1;
    switch(m->kind) {case OD_MOB_PIG:item=319;break;case OD_MOB_COW:item=334;break;
    case OD_MOB_CHICKEN:case OD_MOB_ZOMBIE:item=288;break;case OD_MOB_SKELETON:item=262;break;
    case OD_MOB_SPIDER:item=287;break;case OD_MOB_CREEPER:item=289;break;default:break;}
    if(item)Od_SpawnDrop(item,count,0,m->position,0.3f);
    m->active=0;
    return 1;
}
int Od_Shoot(OdVec3 p,OdVec3 dir,int friendly) {
    int i;float len=sqrtf(dir.x*dir.x+dir.y*dir.y+dir.z*dir.z);
    if(len<0.01f)return 0;
    for(i=0;i<OD_MAX_PROJECTILES;i++) {
        OdProjectile* a=&od.projectiles[i];if(a->active)continue;
        memset(a,0,sizeof(*a));a->active=friendly?2:1;a->position=p;
        a->velocity.x=dir.x/len*20;a->velocity.y=dir.y/len*20;a->velocity.z=dir.z/len*20;
        Od_Sound(OD_SOUND_BOW,p);return 1;
    }
    return 0;
}
void Od_Explode(OdVec3 p) {
    int x,y,z,i;float d;OdVec3 q=od.player.position;q.y+=0.7f;
    d=sqrtf(Od_DistanceSquared(p,q));
    if(d<5&&Od_LineClear(p,q))Od_DamagePlayer((int)(19*(1-d/5))+1,p);
    for(i=0;i<OD_MAX_MOBS;i++)if(od.mobs[i].active) {
        d=sqrtf(Od_DistanceSquared(p,od.mobs[i].position));if(d<5)Od_DamageMob(i,(int)(20*(1-d/5))+1,p);
    }
    for(x=(int)p.x-3;x<=(int)p.x+3;x++)for(y=(int)p.y-3;y<=(int)p.y+3;y++)for(z=(int)p.z-3;z<=(int)p.z+3;z++) {
        int b;OdVec3 c={(float)x+0.5f,(float)y+0.5f,(float)z+0.5f};
        if(Od_DistanceSquared(c,p)>7)continue;
        b=Od_Block(x,y,z);
        if(!b||b==7||b==49||b==8||b==9||b==10||b==11)continue;
        Od_BreakStation(x,y,z);Od_SetBlock(x,y,z,0);
        /* Ore remains one recoverable ore block when blasted; breaking it with
         * the proper tool still yields exactly one diamond. */
        if(b==56||b==57||Od_Random()%3==0)Od_SpawnDrop(b==2?3:b==62?61:b,1,0,c,0.4f);
    }
    Od_Sound(OD_SOUND_EXPLODE,p);
}
static int SkyExposed(const OdMob* m) {
    int x=(int)floorf(m->position.x),z=(int)floorf(m->position.z);
    int y=(int)floorf(m->position.y+MobHeight(m->kind));
    for(;y<64;y++)if(Od_Solid(Od_Block(x,y,z)))return 0;
    return 1;
}
static int InWater(const OdMob* m) {
    int b=Od_Block((int)floorf(m->position.x),(int)floorf(m->position.y+0.2f),(int)floorf(m->position.z));
    return b==8||b==9;
}
static int Sunlight(int index,float dt,int exposed) {
    OdMob* m=&od.mobs[index];
    if(m->anger_time>0)m->anger_time-=dt;
    if(m->kind!=OD_MOB_ZOMBIE&&m->kind!=OD_MOB_SKELETON)return 1;
    if(InWater(m)) {m->burn_time=0;m->burn_clock=0;return 1;}
    if(exposed&&Od_Daylight()>0.55f)m->burn_time=8;
    else if(m->burn_time>0)m->burn_time-=dt;
    if(m->burn_time<=0) {m->burn_time=0;m->burn_clock=0;return 1;}
    m->burn_clock+=dt;
    if(m->burn_clock>=1) {
        m->burn_clock-=1;Od_DamageMob(index,1,m->position);
        if(!m->active)return 0;
    }
    return 1;
}
static void TickMob(int i,float dt) {
    OdMob* m=&od.mobs[i];float dx,dz,dist,speed,desired_x=0,desired_z=0;OdVec3 eye,target;
    int hostile,ground,blocked,see,exposed;
    if(!m->active)return;
    if(m->hurt_time>0)m->hurt_time-=dt;
    exposed=SkyExposed(m);
    if(!Sunlight(i,dt,exposed))return;
    m->attack_time-=dt;
    m->animation+=dt*(fabsf(m->velocity.x)+fabsf(m->velocity.z));
    ground=OnGround(m->position,MobRadius(m->kind));hostile=m->kind>=OD_MOB_ZOMBIE;
    if(m->kind==OD_MOB_SPIDER&&exposed&&Od_Daylight()>0.55f&&m->anger_time<=0)hostile=0;
    dx=od.player.position.x-m->position.x;dz=od.player.position.z-m->position.z;dist=sqrtf(dx*dx+dz*dz);
    eye=m->position;eye.y+=MobHeight(m->kind)*0.8f;target=od.player.position;target.y+=1;
    see=hostile&&!od.dead&&dist<16&&fabsf(target.y-eye.y)<8&&Od_LineClear(eye,target);
    if(see) {
        speed=m->kind==OD_MOB_SPIDER?3.3f:2.1f;m->yaw=atan2f(dx,-dz)*180/OD_PI;
        if(dist>1.3f) {desired_x=dx/(dist+0.001f)*speed;desired_z=dz/(dist+0.001f)*speed;}
        if(m->kind==OD_MOB_SKELETON) {
            if(dist<8) {desired_x=0;desired_z=0;}
            if(dist<3) {desired_x=-dx/(dist+0.001f)*1.8f;desired_z=-dz/(dist+0.001f)*1.8f;}
            if(m->attack_time<=0&&dist<14) {
                OdVec3 dir={target.x-eye.x,target.y-eye.y+dist*0.10f,target.z-eye.z};
                Od_Shoot(eye,dir,0);m->attack_time=2.4f;
            }
        } else if(m->kind==OD_MOB_CREEPER) {
            if(dist<2.7f) {
                if(m->fuse<=0)Od_Sound(OD_SOUND_FUSE,m->position);
                m->fuse+=dt;desired_x=desired_z=0;
                if(m->fuse>=1.5f) {OdVec3 p=m->position;p.y+=0.7f;m->active=0;Od_Explode(p);return;}
            } else {m->fuse-=dt*2;if(m->fuse<0)m->fuse=0;}
        } else {
            if(m->kind==OD_MOB_SPIDER&&ground&&dist>2&&dist<5&&m->attack_time<=0) {
                m->velocity.y=7;desired_x*=1.6f;desired_z*=1.6f;m->attack_time=0.7f;
            }
            if(dist<(m->kind==OD_MOB_SPIDER?1.8f:1.4f)&&fabsf(od.player.position.y-m->position.y)<1.8f&&m->attack_time<=0) {
                Od_DamagePlayer(m->kind==OD_MOB_ZOMBIE?3:2,m->position);m->attack_time=1.0f;
            }
        }
    } else {
        if(m->fuse>0) {m->fuse-=dt*2;if(m->fuse<0)m->fuse=0;}
        /* Seeded wandering uses no wall clock or per-player random seed. */
        if(m->attack_time<=-2) {m->yaw=(float)(Od_Random()%360);m->attack_time=1.0f+(Od_Random()%300)*0.01f;}
        if(m->attack_time>0.7f) {desired_x=sinf(m->yaw*OD_PI/180)*0.8f;desired_z=-cosf(m->yaw*OD_PI/180)*0.8f;}
    }
    if(m->hurt_time>0.1f) {m->velocity.x*=1-dt*2;m->velocity.z*=1-dt*2;}
    else {m->velocity.x=desired_x;m->velocity.z=desired_z;}
    m->velocity.y-=18*dt;
    if(m->kind==OD_MOB_CHICKEN&&m->velocity.y<-2)m->velocity.y=-2;
    if(Od_Block((int)m->position.x,(int)m->position.y,(int)m->position.z)==9)m->velocity.y=2;
    blocked=MoveBody(&m->position,&m->velocity,MobRadius(m->kind),MobHeight(m->kind),dt,1);
    if(blocked&&m->kind==OD_MOB_SPIDER&&see)m->velocity.y=3.5f;
    if(m->position.y<0)m->active=0;
}
static void TickDrops(float dt) {
    int i,j;
    for(i=0;i<OD_MAX_DROPS;i++) {
        OdDrop* d=&od.drops[i];OdVec3 player=od.player.position;
        if(!d->active)continue;
        d->age+=dt;d->pickup_delay-=dt;
        if(d->age>=300) {d->active=0;continue;}
        d->velocity.y-=12*dt;MoveBody(&d->position,&d->velocity,0.1f,0.2f,dt,0);
        d->velocity.x*=1-dt*3;d->velocity.z*=1-dt*3;
        player.y+=0.7f;
        if(!od.dead&&d->pickup_delay<=0&&Od_DistanceSquared(d->position,player)<2.8f) {
            int before=d->stack.count;Od_AddStack(od.carried.inventory,36,&d->stack);
            if(d->stack.count!=before)Od_Sound(OD_SOUND_PICKUP,d->position);
            if(!Od_StackValid(&d->stack))d->active=0;
        }
        if(!d->active)continue;
        for(j=i+1;j<OD_MAX_DROPS;j++) {
            OdDrop* b=&od.drops[j];int room,n;
            if(!b->active||b->stack.item_id!=d->stack.item_id||b->stack.damage!=d->stack.damage||Od_DistanceSquared(b->position,d->position)>0.5f)continue;
            room=OdGame_StackLimit(d->stack.item_id)-d->stack.count;if(room<=0)break;
            n=b->stack.count<room?b->stack.count:room;d->stack.count+=n;b->stack.count-=n;
            if(b->pickup_delay>d->pickup_delay)d->pickup_delay=b->pickup_delay;
            if(b->age<d->age)d->age=b->age;
            if(!b->stack.count)b->active=0;
        }
    }
}
static void TickArrows(float dt) {
    int i,j,k;
    for(i=0;i<OD_MAX_PROJECTILES;i++) {
        OdProjectile* a=&od.projectiles[i];int steps;
        if(!a->active)continue;
        a->age+=dt;
        if(a->age>8) {a->active=0;continue;}
        a->velocity.y-=9.8f*dt;steps=(int)(dt*40)+1;
        for(k=0;k<steps&&a->active;k++) {
            float slice=dt/steps;a->position.x+=a->velocity.x*slice;a->position.y+=a->velocity.y*slice;a->position.z+=a->velocity.z*slice;
            if(Od_Solid(Od_Block((int)floorf(a->position.x),(int)floorf(a->position.y),(int)floorf(a->position.z)))) {
                /* Hostile arrows cannot be farmed into a new reward source. */
                a->active=0;break;
            }
            if(a->active==1&&!od.dead&&fabsf(a->position.x-od.player.position.x)<0.4f&&fabsf(a->position.z-od.player.position.z)<0.4f&&a->position.y>od.player.position.y&&a->position.y<od.player.position.y+1.8f) {
                OdVec3 from=a->position;from.x-=a->velocity.x;from.z-=a->velocity.z;
                Od_DamagePlayer(4,from);a->active=0;break;
            }
            if(a->active==2)for(j=0;j<OD_MAX_MOBS;j++) {
                OdMob* m=&od.mobs[j];
                if(m->active&&fabsf(a->position.x-m->position.x)<MobRadius(m->kind)+0.1f&&fabsf(a->position.z-m->position.z)<MobRadius(m->kind)+0.1f&&a->position.y>m->position.y&&a->position.y<m->position.y+MobHeight(m->kind)) {
                    Od_DamageMob(j,5,od.player.position);a->active=0;break;
                }
            }
        }
    }
}
void Od_EntitiesTick(float dt) {int i;for(i=0;i<OD_MAX_MOBS;i++)TickMob(i,dt);TickDrops(dt);TickArrows(dt);}
