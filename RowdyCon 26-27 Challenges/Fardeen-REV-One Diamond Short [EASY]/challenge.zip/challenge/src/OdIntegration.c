#include "OdIntegration.h"
#include "OdWorldEntities.h"
#include "game/OdGame.h"
#include "trial/OdTrial.h"
#include "trial/OdReward.h"
#include "presentation/OdPresentation.h"
#include "presentation/OdAudio.h"
#include "Game.h"
#include "World.h"
#include "Entity.h"
#include "Camera.h"
#include "Block.h"
#include "Gui.h"
#include "Input.h"
#include "InputHandler.h"
#include "Inventory.h"
#include "Platform.h"
#include "Window.h"
#include "Audio.h"
#include "Lighting.h"
#include "Constants.h"
#include "ExtMath.h"
#include "String_.h"
#include "Picking.h"
#include "Graphics.h"
#include "Event.h"
#include <math.h>
#include <string.h>
#define WIN32_LEAN_AND_MEAN
#include <windows.h>

static OdTrial trial;
static OdReward reward;
static OdGameSnapshot game;
static struct Screen inputGrab;
static int ready, generating, soundEnabled = 1;
static BlockRaw* generationBlocks;
static float spawnX, spawnY, spawnZ, spawnYaw, spawnPitch;
static int lastSky = -1;
static void contextLost(void* obj) { (void)obj; OdPresentation_ContextLost(); OdWorldEntities_Free(); }

static uint64_t nowMs(void) { return GetTickCount64(); }
static int getBlock(int x, int y, int z) {
    if (x < 0 || x >= 64 || y < 0 || y >= 64 || z < 0 || z >= 64) return 7;
    return generating ? generationBlocks[(y * 64 + z) * 64 + x] : World_GetBlock(x,y,z);
}
static void setBlock(int x, int y, int z, int block) {
    if (x < 0 || x >= 64 || y < 0 || y >= 64 || z < 0 || z >= 64) return;
    if (generating) generationBlocks[(y * 64 + z) * 64 + x] = (BlockRaw)block;
    else Game_UpdateBlock(x,y,z,(BlockID)block);
}
static void teleport(float x, float y, float z, float yaw, float pitch) {
    struct LocationUpdate update;
    spawnX=x; spawnY=y; spawnZ=z; spawnYaw=yaw; spawnPitch=pitch;
    if (generating) return;
    memset(&update,0,sizeof update);
    Vec3_Set(update.pos,x,y,z); update.yaw=yaw; update.pitch=pitch;
    update.flags=LU_HAS_POS|LU_HAS_YAW|LU_HAS_PITCH;
    Entities.CurPlayer->Base.VTABLE->SetLocation(&Entities.CurPlayer->Base,&update);
    Vec3_Set(Entities.CurPlayer->Base.Velocity,0,0,0);
}
static void knockback(float x,float y,float z) {
    Entities.CurPlayer->Base.Velocity.x += x;
    Entities.CurPlayer->Base.Velocity.y += y;
    Entities.CurPlayer->Base.Velocity.z += z;
}
static void sound(int kind,float x,float y,float z) {
    int volume=256;
    if (!soundEnabled) return;
    if(kind!=OD_SOUND_STEP && Entities.CurPlayer) {
        Vec3 p=Entities.CurPlayer->Base.Position;
        float dx=x-p.x,dy=y-p.y,dz=z-p.z,distance=sqrtf(dx*dx+dy*dy+dz*dz);
        if(distance>=24)return;
        if(distance>4)volume=(int)((24-distance)*(256.0f/20.0f));
    }
    OdAudio_PlayVolume(kind,volume);
}
static void message(const char* text) { (void)text; }

static void defineBlock(int id,int side,int top,int bottom,int collide,int draw,int light) {
    int f;
    Block_ResetProps(id);
    for (f=0;f<FACE_COUNT;f++) Block_Tex(id,f)=side;
    Block_Tex(id,FACE_YMAX)=top; Block_Tex(id,FACE_YMIN)=bottom;
    Blocks.Collide[id]=collide; Blocks.ExtendedCollide[id]=collide;
    Blocks.Draw[id]=draw; Blocks.IsLiquid[id]=0; Blocks.Tinted[id]=0;
    Blocks.SpeedMultiplier[id]=1; Blocks.BlocksLight[id]=(draw==DRAW_OPAQUE);
    Blocks.Brightness[id]=light; Blocks.FogDensity[id]=0;
    Vec3_Set(Blocks.MinBB[id],0,0,0); Vec3_Set(Blocks.MaxBB[id],1,1,1);
    Block_DefineCustom(id,false);
}
static void defineBlocks(void) {
    defineBlock(35,79,79,79,COLLIDE_SOLID,DRAW_OPAQUE,0);
    defineBlock(50,80,80,80,COLLIDE_NONE,DRAW_SPRITE,14);
    defineBlock(54,27,26,26,COLLIDE_SOLID,DRAW_OPAQUE,0);
    defineBlock(56,50,50,50,COLLIDE_SOLID,DRAW_OPAQUE,0);
    defineBlock(57,51,51,51,COLLIDE_SOLID,DRAW_OPAQUE,0);
    defineBlock(58,58,43,4,COLLIDE_SOLID,DRAW_OPAQUE,0);
    Block_Tex(58,FACE_ZMIN)=59; Block_Tex(58,FACE_ZMAX)=59;
    defineBlock(61,45,60,60,COLLIDE_SOLID,DRAW_OPAQUE,0);
    Block_Tex(61,FACE_ZMIN)=44;
    defineBlock(62,45,60,60,COLLIDE_SOLID,DRAW_OPAQUE,13);
    Block_Tex(62,FACE_ZMIN)=61;
    /* The inherited classic terrain atlas differs on these four blocks. */
    defineBlock(2,3,0,2,COLLIDE_SOLID,DRAW_OPAQUE,0);
    defineBlock(17,20,21,21,COLLIDE_SOLID,DRAW_OPAQUE,0);
    defineBlock(18,22,22,22,COLLIDE_SOLID,DRAW_TRANSPARENT_THICK,0);
    defineBlock(20,49,49,49,COLLIDE_SOLID,DRAW_TRANSPARENT,0);
}
static void loadWorld(void) {
    World_NewMap();
    defineBlocks();
    generationBlocks=Mem_Alloc(64*64*64,1,"fixed demo world");
    memset(generationBlocks,0,64*64*64);
    generating=1; OdGame_GenerateWorld(); generating=0;
    World_SetNewMap(generationBlocks,64,64,64);
    World.Seed=5012010; memset(World.Uuid,5,sizeof World.Uuid);
    teleport(spawnX,spawnY,spawnZ,spawnYaw,spawnPitch);
    Entities.CurPlayer->Hacks.Enabled=false;
    Entities.CurPlayer->Hacks.CanFly=false;
    Entities.CurPlayer->Hacks.CanNoclip=false;
    Entities.CurPlayer->Hacks.CanSpeed=false;
    Entities.CurPlayer->Hacks.Flying=false;
    Entities.CurPlayer->Hacks.Noclip=false;
    Entities.CurPlayer->ReachDistance=4.5f;
    Env_SetCloudsHeight(92); Env_SetCloudsSpeed(.3f);
    Env_SetEdgeHeight(18); Env_SetEdgeBlock(8); Env_SetSidesBlock(7);
    Lighting_SetMode(LIGHTING_MODE_FANCY,false);
    lastSky=-1;
}
static void updateInput(void) {
    struct Screen* next=OdIntegration_BlocksMovement()?&inputGrab:NULL;
    if (Gui.InputGrab!=next) { Gui.InputGrab=next; Camera_CheckFocus(); }
}
static void action(int act,int value) {
    switch(act) {
    case OD_UI_PLAY:
        if (trial.state==OD_TRIAL_ACTIVE) break;
        loadWorld(); OdTrial_Init(&trial); OdTrial_Start(&trial,nowMs());
        /* README is display-only; only this run's count can grant a reward. */
        OdReward_Init(&reward); break;
    case OD_UI_QUIT: Window_RequestClose(); break;
    case OD_UI_OPEN_README: OdReward_OpenReadme(&reward); break;
    case OD_UI_RETRY_SAVE: OdReward_RetrySave(&reward,&trial); break;
    case OD_UI_SOUND: soundEnabled=value; OdAudio_SetEnabled(value); Audio_SetSounds(value?100:0); break;
    case OD_UI_REDUCED_MOTION: Game_ViewBobbing=!value; break;
    case OD_UI_SENSITIVITY: Camera.Sensitivity=value; break;
    case OD_UI_FULLSCREEN:
        if (Window_GetWindowState()==WINDOW_STATE_FULLSCREEN) Window_ExitFullscreen(); else Window_EnterFullscreen(); break;
    case OD_UI_RESPAWN: if (trial.state==OD_TRIAL_ACTIVE) OdGame_Respawn(); break;
    case OD_UI_TITLE:
        if (trial.state!=OD_TRIAL_ACTIVE) { OdGame_CloseScreen(); OdTrial_Init(&trial); }
        break;
    }
    OdGame_GetSnapshot(&game); OdPresentation_Update(&game,&trial,&reward); updateInput();
}
void OdIntegration_Init(void) {
    OdGameHooks hooks={getBlock,setBlock,teleport,knockback,sound,message};
    cc_string title=String_FromConst("Minecraft Alpha - One Diamond Short");
    while (Gui.ScreensCount) Gui_Remove(Gui_Screens[0]);
    Window_SetTitle(&title);
    Game_SetViewDistance(512); Game_ViewBobbing=true; Game_SetFpsLimit(FPS_LIMIT_60);
    Audio_SetMusic(0); OdAudio_Init(); OdAudio_SetEnabled(soundEnabled); OdTrial_Init(&trial); OdReward_Init(&reward);
    OdGame_Init(&hooks); loadWorld(); OdPresentation_Init(action);
    Event_Register_(&GfxEvents.ContextLost,NULL,contextLost);
    ready=1; OdIntegration_Tick(0); updateInput();
}
void OdIntegration_Free(void) {
    if (!ready) return;
    ready=0; Gui.InputGrab=NULL;
    Event_Unregister_(&GfxEvents.ContextLost,NULL,contextLost);
    OdPresentation_Free(); OdWorldEntities_Free(); OdAudio_Free();
}
int OdIntegration_BlocksMovement(void) {
    return !ready || trial.state!=OD_TRIAL_ACTIVE || OdGame_IsDead() || OdPresentation_BlocksInput();
}
int OdIntegration_BlocksPhysics(void) {
    return OdIntegration_BlocksMovement() && (game.screen==OD_SCREEN_NONE || game.dead || trial.state!=OD_TRIAL_ACTIVE);
}
void OdIntegration_Poll(void) {
    if (!ready) return;
    OdTrial_Tick(&trial,nowMs(),OdGame_GetCarriedState());
    OdReward_HandleTerminal(&reward,&trial);
    if (trial.state==OD_TRIAL_EXPIRED) Window_RequestClose();
    OdGame_GetSnapshot(&game); OdPresentation_Update(&game,&trial,&reward); updateInput();
}
void OdIntegration_Tick(float delta) {
    struct Entity* e;
    OdPlayerFrame frame;
    Vec3 look,eye;
    int sky,i;
    float daylight;
    if (!ready) return;
    e=&Entities.CurPlayer->Base;
    look=Vec3_GetDirVector(e->Yaw*MATH_DEG2RAD,e->Pitch*MATH_DEG2RAD);
    eye=Entity_GetEyePosition(e);
    frame.position=(OdVec3){e->Position.x,e->Position.y,e->Position.z};
    frame.velocity=(OdVec3){e->Velocity.x,e->Velocity.y,e->Velocity.z};
    frame.look=(OdVec3){look.x,look.y,look.z};
    frame.on_ground=e->OnGround;
    frame.head_in_water=(World_SafeGetBlock((int)eye.x,(int)eye.y,(int)eye.z)==8 || World_SafeGetBlock((int)eye.x,(int)eye.y,(int)eye.z)==9);
    frame.in_lava=Entity_TouchesAnyLava(e);
    if (trial.state==OD_TRIAL_ACTIVE) {
        int simulate=!OdIntegration_BlocksMovement() || (game.screen!=OD_SCREEN_NONE && !game.dead);
        OdGame_SetWorldTime(trial.elapsed_ms);
        OdGame_Tick(simulate?delta:0,&frame);
    }
    OdGame_GetSnapshot(&game);
    Inventory.SelectedIndex=game.selected;
    for (i=0;i<9;i++) Inventory_Set(i,game.inventory[i].count>0 && game.inventory[i].item_id<256?game.inventory[i].item_id:0);
    daylight=(float)(.55+.45*cos((double)trial.elapsed_ms/900000.0*6.283185307));
    sky=(int)(daylight*24);
    if (sky!=lastSky) {
        lastSky=sky;
        Env_SetSkyCol(PackedCol_Make(18+(int)(92*daylight),25+(int)(139*daylight),48+(int)(207*daylight),255));
        Env_SetFogCol(PackedCol_Make(20+(int)(159*daylight),28+(int)(185*daylight),48+(int)(207*daylight),255));
        Env_SetCloudsCol(PackedCol_Make(90+(int)(165*daylight),95+(int)(160*daylight),115+(int)(140*daylight),255));
        Env_SetSunCol(PackedCol_Make(50+(int)(205*daylight),55+(int)(200*daylight),75+(int)(180*daylight),255));
        Env_SetShadowCol(PackedCol_Make(35+(int)(120*daylight),38+(int)(117*daylight),52+(int)(103*daylight),255));
    }
    OdIntegration_Poll();
}
void OdIntegration_Interact(float delta) {
    struct RayTracer* p=&Game_SelectedPos;
    if (!ready) return;
    { int held=!OdIntegration_BlocksMovement()&&Input.Pressed[CCMOUSE_L];
      int attacked=held?OdGame_Attack():0;
      OdGame_Mine(p->pos.x,p->pos.y,p->pos.z,held&&!attacked&&p->valid,delta); }
    OdIntegration_Poll();
}
int OdIntegration_KeyDown(int key,int repeat) {
    struct RayTracer* p=&Game_SelectedPos;
    if (!ready) return 1;
    if (key==CCKEY_F4 && Input_IsAltPressed()) { Window_RequestClose(); return 1; }
    if (key==CCKEY_F2 && !repeat) { Game_ScreenshotRequested=true; return 1; }
    if (key==CCMOUSE_L || key==CCMOUSE_R) {
        if (repeat) return 1;
        if (OdPresentation_BlocksInput() || trial.state!=OD_TRIAL_ACTIVE || OdGame_IsDead()) {
            OdPresentation_PointerDown(Pointers[0].x,Pointers[0].y,key==CCMOUSE_L?0:1,Input_IsShiftPressed());
        } else if (key==CCMOUSE_R) OdGame_Use(p->pos.x,p->pos.y,p->pos.z,p->translatedPos.x-p->pos.x,p->translatedPos.y-p->pos.y,p->translatedPos.z-p->pos.z,p->valid);
        else OdGame_Attack();
        OdIntegration_Poll(); return 1;
    }
    if (OdPresentation_KeyDown(key,repeat)) { updateInput(); return 1; }
    if (OdIntegration_BlocksMovement()) return 1;
    if (key==CCKEY_E && !repeat) { OdGame_OpenInventory(); OdIntegration_Poll(); return 1; }
    if (key==CCKEY_Q && !repeat) { OdGame_DropSelected(Input_IsCtrlPressed()); return 1; }
    if (key>=CCKEY_1 && key<=CCKEY_9 && !repeat) { OdGame_SelectSlot(key-CCKEY_1); return 1; }
    return !(key==CCKEY_W||key==CCKEY_A||key==CCKEY_S||key==CCKEY_D||key==CCKEY_SPACE||key==CCKEY_LSHIFT||key==CCKEY_RSHIFT);
}
void OdIntegration_Pause(void) { if (ready) { OdPresentation_ShowPause(); updateInput(); } }
void OdIntegration_PointerMove(int x,int y) { if(ready) OdPresentation_PointerMove(x,y); }
void OdIntegration_Wheel(float amount) { if(ready) OdPresentation_Wheel(amount); }
void OdIntegration_StepSound(void) { if(ready&&!OdIntegration_BlocksMovement()) sound(OD_SOUND_STEP,0,0,0); }
int OdIntegration_ShowHeldBlock(void) { return ready && !OdIntegration_BlocksMovement() && game.inventory[game.selected].item_id<256; }
void OdIntegration_RenderUI(void) { if(ready) OdPresentation_RenderUI(Game.Width,Game.Height); }
void OdIntegration_RenderWorld(void) { if(ready) { OdPresentation_RenderCloudClock(); OdWorldEntities_Render(&game); } }
