<#
Reference solver for the organizer's own released OneDiamondShort.exe only.
No symbols, private fixture, item identifiers, or known addresses are used.
Read an actual diamond quantity in the game, scan it, change that quantity
through normal inventory play, then refine. Repeat to narrow the candidates.
If UI copies retain the same value, test the remaining observed candidates one
at a time with -Address; only the actual carried stack grants a win.
Only patch the remaining actual stack when the sum of other carried diamonds is
zero; otherwise choose NewValue so the entire carried inventory totals ten.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)][ValidateRange(1,2147483647)][int]$TargetPid,
    [Parameter(Mandatory=$true)][string]$ReleasedExe,
    [Parameter(Mandatory=$true)][ValidateSet('Scan','Refine','Patch')][string]$Mode,
    [Parameter(Mandatory=$true)][ValidateRange(0,64)][int]$Value,
    [ValidateRange(1,64)][int]$NewValue = 10,
    [string]$StatePath = (Join-Path $PSScriptRoot 'memory-candidates.json'),
    [string]$Address
)
$ErrorActionPreference = 'Stop'
if ($Mode -eq 'Scan' -and $Value -eq 0) { throw 'Start with a nonzero observed stack. Zero is supported for subsequent refinement.' }
if ([IntPtr]::Size -ne 8) { throw 'Run this organizer script in 64-bit PowerShell.' }
$resolvedExe = (Resolve-Path -LiteralPath $ReleasedExe).ProviderPath
if ([IO.Path]::GetFileName($resolvedExe) -cne 'OneDiamondShort.exe') {
    throw 'ReleasedExe must name the distributed OneDiamondShort.exe.'
}
$target = Get-Process -Id $TargetPid
if (-not [String]::Equals($target.MainModule.FileName, $resolvedExe, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'The explicit PID does not run the explicitly supplied game executable.'
}
$started = $target.StartTime.ToUniversalTime().Ticks.ToString()
$hash = (Get-FileHash -LiteralPath $resolvedExe -Algorithm SHA256).Hash
if (-not ('OdsMemoryScanner' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
public static class OdsMemoryScanner {
    [StructLayout(LayoutKind.Sequential)] struct Region {
        public IntPtr BaseAddress, AllocationBase;
        public uint AllocationProtect;
        public UIntPtr RegionSize;
        public uint State, Protect, Type;
    }
    [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool CloseHandle(IntPtr handle);
    [DllImport("kernel32.dll", SetLastError=true)] static extern UIntPtr VirtualQueryEx(IntPtr handle, IntPtr address, out Region region, UIntPtr length);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool ReadProcessMemory(IntPtr handle, IntPtr address, byte[] buffer, UIntPtr size, out UIntPtr read);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool WriteProcessMemory(IntPtr handle, IntPtr address, byte[] buffer, UIntPtr size, out UIntPtr written);
    static IntPtr Open(int pid, bool write) {
        IntPtr result=OpenProcess(0x0400|0x0010|(write ? 0x0028u : 0u),false,pid);
        if(result==IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
        return result;
    }
    public static ulong[] Scan(int pid, int value) {
        IntPtr handle=Open(pid,false);
        var found=new List<ulong>();
        byte[] buffer=new byte[1024*1024];
        try {
            ulong address=0;
            Region region;
            while(VirtualQueryEx(handle,new IntPtr((long)address),out region,new UIntPtr((uint)Marshal.SizeOf(typeof(Region)))).ToUInt64()!=0) {
                ulong first=(ulong)region.BaseAddress.ToInt64(), size=region.RegionSize.ToUInt64();
                ulong end=first+size;
                if(end<=address || end>0x7fffffffffffffffUL) break;
                uint permission=region.Protect & 0xff;
                bool writable=permission==4 || permission==8 || permission==0x40 || permission==0x80;
                if(region.State==0x1000 && (region.Protect & 0x100)==0 && writable) {
                    for(ulong offset=0; offset<size; offset+=(ulong)buffer.Length) {
                        int length=(int)Math.Min((ulong)buffer.Length,size-offset);
                        UIntPtr read;
                        bool ok=ReadProcessMemory(handle,new IntPtr((long)(first+offset)),buffer,new UIntPtr((uint)length),out read);
                        if(!ok && read.ToUInt64()==0) continue;
                        int valid=(int)Math.Min(read.ToUInt64(),(ulong)length);
                        for(int i=0;i+4<=valid;i+=4) {
                            if(BitConverter.ToInt32(buffer,i)==value) {
                                found.Add(first+offset+(ulong)i);
                                if(found.Count>250000) throw new InvalidOperationException("Too many candidates. Observe a larger inventory quantity and start a new scan.");
                            }
                        }
                    }
                }
                address=end;
            }
            return found.ToArray();
        } finally { CloseHandle(handle); }
    }
    public static ulong[] Refine(int pid, ulong[] candidates, int value) {
        IntPtr handle=Open(pid,false);
        var found=new List<ulong>();
        byte[] buffer=new byte[4];
        try {
            foreach(ulong address in candidates) {
                UIntPtr read;
                if(ReadProcessMemory(handle,new IntPtr((long)address),buffer,new UIntPtr(4),out read) && read.ToUInt64()==4 && BitConverter.ToInt32(buffer,0)==value) found.Add(address);
            }
            return found.ToArray();
        } finally { CloseHandle(handle); }
    }
    public static void Patch(int pid, ulong address, int expected, int replacement) {
        IntPtr handle=Open(pid,true);
        byte[] buffer=new byte[4];
        try {
            UIntPtr read,written;
            if(!ReadProcessMemory(handle,new IntPtr((long)address),buffer,new UIntPtr(4),out read) || read.ToUInt64()!=4) throw new Win32Exception(Marshal.GetLastWin32Error());
            if(BitConverter.ToInt32(buffer,0)!=expected) throw new InvalidOperationException("The candidate changed since refinement; scan again.");
            if(!WriteProcessMemory(handle,new IntPtr((long)address),BitConverter.GetBytes(replacement),new UIntPtr(4),out written) || written.ToUInt64()!=4) throw new Win32Exception(Marshal.GetLastWin32Error());
        } finally { CloseHandle(handle); }
    }
}
'@
}
if ($Mode -eq 'Scan') {
    [UInt64[]]$candidates = [OdsMemoryScanner]::Scan($TargetPid, $Value)
} else {
    $state = Get-Content -LiteralPath $StatePath -Raw | ConvertFrom-Json
    if ($state.pid -ne $TargetPid -or $state.started -cne $started -or $state.sha256 -cne $hash) {
        throw 'Candidate state belongs to another process lifetime or executable. Start a fresh Scan.'
    }
    [UInt64[]]$candidates = @($state.candidates | ForEach-Object { [Convert]::ToUInt64($_, 16) })
    if ($Mode -eq 'Refine') {
        $candidates = [OdsMemoryScanner]::Refine($TargetPid, $candidates, $Value)
    } else {
        if ($Address) {
            $chosen = [Convert]::ToUInt64(($Address -replace '^0x',''),16)
            if ($candidates -notcontains $chosen) { throw 'Address must be one of the observed and refined candidates.' }
        } elseif ($candidates.Count -eq 1) {
            $chosen = $candidates[0]
        } else {
            throw 'Refine to one candidate, or explicitly select a verified candidate with -Address.'
        }
        [OdsMemoryScanner]::Patch($TargetPid, $chosen, $Value, $NewValue)
        [pscustomobject]@{ mode='Patch'; pid=$TargetPid; address=('{0:X}' -f $chosen); before=$Value; after=$NewValue; result='write_succeeded'; note='Verify the actual game result and README; a successful write alone does not prove a solve.' } | ConvertTo-Json
        return
    }
}
$result = [ordered]@{
    pid=$TargetPid; started=$started; sha256=$hash; executable=$resolvedExe;
    value=$Value; candidates=@($candidates | ForEach-Object { '{0:X}' -f $_ })
}
$result | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $StatePath -Encoding UTF8
[pscustomobject]@{ mode=$Mode; pid=$TargetPid; observed_value=$Value; candidate_count=$candidates.Count; state=$StatePath; first_candidates=@($result.candidates | Select-Object -First 12) } | ConvertTo-Json
