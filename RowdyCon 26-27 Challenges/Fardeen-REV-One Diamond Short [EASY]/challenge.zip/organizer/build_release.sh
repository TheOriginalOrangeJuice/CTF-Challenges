#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
: "${TOOLCHAIN:?Set TOOLCHAIN to the verified llvm-mingw-20261020-ucrt-ubuntu-22.04-x86_64 directory}"
python3 organizer/assets/build_assets.py > /tmp/od05-assets.log
python3 organizer/assets/build_sounds.py > /tmp/od05-sounds.log
bash organizer/tests/run_trial_tests.sh
gcc -std=c99 -Wall -Wextra -I challenge/src/game organizer/tests/game_conservation.c challenge/src/game/*.c -lm -o /tmp/od05-game-tests
/tmp/od05-game-tests
gcc -std=c99 -Wall -Wextra -Werror -I challenge/src/presentation organizer/tests/audio_mixer.c challenge/src/presentation/OdAudioMixer.c -o /tmp/od05-audio-tests
/tmp/od05-audio-tests
make -s -C challenge -j4 TOOLCHAIN="$TOOLCHAIN"
python3 organizer/package_release.py
