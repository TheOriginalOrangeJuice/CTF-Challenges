# Organizer maintenance

Distribute only `artifacts/OneDiamondShort.zip`. The source tree, Description documents, scanner, and reports contain answers. The ZIP is an offline x64 Windows application; extracting it to a writable folder lets the game update its adjacent `README.txt`. Existing earned README text is retained across launches but never authorizes a new win.

To repackage user edits to `artifacts/OneDiamondShort/`, run `python3 organizer/repackage_artifacts.py` in Condev after staging. This preserves the folder's current contents, validates archive parity, and updates `public-manifest.json`. The full rebuild script instead restores its source-defined README and license files.

Build the pinned environment from the challenge directory with `docker build -f organizer/Dockerfile.build -t one-diamond-short-build:20261025 .`. Use `organizer/condev-clean.yaml` to run that image through Condev. Stage the **complete challenge directory** with the Condev skill's `stage_tree.ps1`, verify SHA-256 parity, and copy that complete stage into the workspace. Inside the staged challenge directory, run:

```sh
make -C challenge clean
TOOLCHAIN=/opt/llvm-mingw-20261020-ucrt-ubuntu-22.04-x86_64 bash organizer/build_release.sh
python3 organizer/audit_public.py
```

`toolchain.lock.json` pins the compiler and imported revisions. Asset/source licenses and original provenance are retained locally. `package_release.py` allows only the public executable, assets, sounds, licenses, and initial README, with fixed archive ordering and timestamps. Compare every entry in `public-manifest.json`, including the ZIP hash, after rebuilding. The expected reward is frozen; do not regenerate per-player keys, maps, or codes.

Native Windows execution of the game, UI harnesses, file tests, and public memory scanner is covered by the user's explicit QA exception. Other project execution remains in Condev. Run QA against a separate extracted copy so a successful solve cannot put earned text into the distributed README. The scanner requires an observed ordinary inventory change; its walkthrough is in `Description.md`.

Technical, human, and deterrent evidence are separate. `technical-report.json` identifies the release and its checks; `tests/trial_human_observations.json` contains the user's actual feedback; `anti-agent-assessment.json` records the deterrent exception and its limits. Old captures and failed attempts are retained as versioned diagnostic evidence, not represented as final acceptance.

On this development host, new Docker container startup stalled while an existing isolated Condev workspace remained usable. The independent rebuild therefore exported the pinned build image and used its complete filesystem as a chroot inside that workspace. Only the task's copied build files were cleaned. No unrelated containers or services were stopped. The clean build's public-file manifest and ZIP were compared byte for byte.
