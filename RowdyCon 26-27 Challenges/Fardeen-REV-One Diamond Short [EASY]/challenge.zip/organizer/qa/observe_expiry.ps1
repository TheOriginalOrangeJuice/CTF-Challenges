param([Parameter(Mandatory=$true)][int]$TargetPid,
      [Parameter(Mandatory=$true)][string]$StartedUtc,
      [Parameter(Mandatory=$true)][string]$OutputPath)
$ErrorActionPreference='Stop'
$odStarted=[DateTime]::Parse($StartedUtc).ToUniversalTime()
$odTarget=Get-Process -Id $TargetPid
if($odTarget.ProcessName -ne 'OneDiamondShort'){throw 'Only challenge game monitoring is supported.'}
$odImage=$odTarget.Path
$odHash=(Get-FileHash -LiteralPath $odImage -Algorithm SHA256).Hash.ToLowerInvariant()
$odBorn=$odTarget.StartTime.ToUniversalTime()
$odSamples=New-Object System.Collections.Generic.List[object]
while($true) {
    $odNow=[DateTime]::UtcNow
    $odLive=Get-Process -Id $TargetPid -ErrorAction SilentlyContinue
    $odAlive=$null -ne $odLive -and $odLive.StartTime.ToUniversalTime() -eq $odBorn
    $odElapsed=($odNow-$odStarted).TotalSeconds
    $odSamples.Add(@{utc=$odNow.ToString('o');elapsed_seconds=$odElapsed;alive=$odAlive})
    if(-not $odAlive -or $odElapsed -gt 930) {break}
    Start-Sleep -Seconds 1
}
$odRecord=@{test='actual_native_900_second_expiry';pid=$TargetPid;exe_sha256=$odHash;
    play_gesture_utc=$odStarted.ToString('o');observed_end_utc=$odNow.ToString('o');elapsed_seconds=$odElapsed;
    timestamp_uncertainty_seconds=1;exited=$(-not $odAlive);forced_close=$false;
    monitoring_began_after_play=$true;samples=$odSamples;
    result=$(if(-not $odAlive -and $odElapsed -ge 898 -and $odElapsed -le 903){'passed'}else{'failed'})}
$odRecord | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
[pscustomobject]$odRecord | Select-Object test,result,elapsed_seconds,exited,exe_sha256 | ConvertTo-Json -Compress
