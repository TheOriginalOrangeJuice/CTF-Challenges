Collect 10 diamonds to win a copy of Minecraft!

One Diamond Short - Demo
You have 15 minutes. The demo clock keeps running while paused.

W A S D: Move   Space: Jump   Mouse: Look
Left mouse: Mine / attack   Right mouse: Place / use
1-9 / mouse wheel: Select hotbar slot   E: Inventory
Q: Drop one item   Escape: Pause / close inventory   F11: Fullscreen
Inventory: left click stacks; right click splits or places one; Shift+click transfers.

This is a CTF recreation. The purchase code is a challenge reward.
Open source credits and asset licenses are in the licenses folder.

--- Demo time expired ---
Time is up! Start a new demo and collect 10 diamonds before the clock runs out.
