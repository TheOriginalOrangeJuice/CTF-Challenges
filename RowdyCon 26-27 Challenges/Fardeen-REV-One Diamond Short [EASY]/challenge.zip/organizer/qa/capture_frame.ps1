param([Parameter(Mandatory=$true)][int]$TargetPid,
      [Parameter(Mandatory=$true)][ValidatePattern('^[a-z0-9][a-z0-9-]{0,63}$')][string]$Scenario)
$ErrorActionPreference='Stop'
$odProcess=Get-Process -Id $TargetPid
if($odProcess.ProcessName -ne 'OneDiamondShort'){throw 'Only the challenge game may be captured.'}
$odRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../..'))
$odCaptureDir=Join-Path ([IO.Path]::GetDirectoryName($odProcess.Path)) 'screenshots'
$odStarted=[DateTime]::UtcNow
& (Join-Path $PSScriptRoot 'control_native.ps1') -TargetPid $TargetPid -Action Key -Key 113 | Out-Null
$odFrame=$null
for($odAttempt=0;$odAttempt -lt 30;$odAttempt++) {
 $odFrame=Get-ChildItem -LiteralPath $odCaptureDir -Filter '*.png' -ErrorAction SilentlyContinue |
  Where-Object {$_.LastWriteTimeUtc -ge $odStarted} | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
 if($odFrame){break}
 Start-Sleep -Milliseconds 100
}
if(-not $odFrame){throw 'The game did not create a new framebuffer screenshot.'}
$odDestination=Join-Path $odRoot ('screenshots/'+$Scenario+'.png')
Copy-Item -LiteralPath $odFrame.FullName -Destination $odDestination
@{scenario=$Scenario;process_id=$TargetPid;executable_path=$odProcess.Path;
 exe_sha256=(Get-FileHash -LiteralPath $odProcess.Path).Hash.ToLowerInvariant();
 captured_utc=$odFrame.LastWriteTimeUtc.ToString('o');
 image_sha256=(Get-FileHash -LiteralPath $odDestination).Hash.ToLowerInvariant();
 source_frame=$odFrame.FullName;
 capture_method='Unmodified game framebuffer PNG saved by the public executable through normal F2 input after rendering the UI. No desktop compositing or image editing.'} |
 ConvertTo-Json | Set-Content -LiteralPath (Join-Path $odRoot ('screenshots/'+$Scenario+'.json')) -Encoding UTF8
Write-Output $odDestination
