param([Parameter(Mandatory=$true)][int]$TargetPid,
      [ValidateSet('Focus','Key','Mouse','Click','Resize','Cursor')][string]$Action='Focus',
      [int]$Key=13,[int]$Milliseconds=80,[int]$X=0,[int]$Y=0,[int]$Button=0)
$ErrorActionPreference='Stop'
Add-Type -TypeDefinition @'
using System; using System.Runtime.InteropServices;
public static class OdNativeControl {
 public delegate bool EnumWindow(IntPtr w,IntPtr context);
 [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindow callback,IntPtr context);
 [DllImport("user32.dll")] public static extern int GetWindowTextLengthW(IntPtr w);
 [StructLayout(LayoutKind.Sequential)] public struct Point {public int X,Y;}
 [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr w,ref Point p);
 [DllImport("user32.dll")] public static extern bool ScreenToClient(IntPtr w,ref Point p);
 [DllImport("user32.dll")] public static extern bool GetCursorPos(out Point p);
 [DllImport("user32.dll")] public static extern bool PostMessageW(IntPtr w,uint message,UIntPtr wparam,IntPtr lparam);
 [DllImport("user32.dll")] public static extern bool SetCursorPos(int x,int y);
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr w);
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr w,out uint pid);
 [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
 [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint a,uint b,bool attach);
 [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr w);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr w,int n);
 [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr w,IntPtr after,int x,int y,int cx,int cy,uint flags);
 [DllImport("user32.dll")] public static extern void keybd_event(byte key,byte scan,uint flags,UIntPtr info);
 [DllImport("user32.dll")] public static extern void mouse_event(uint flags,int dx,int dy,uint data,UIntPtr info);
 [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
 public static IntPtr FindWindow(uint target) {
  IntPtr found=IntPtr.Zero;
  EnumWindows(delegate(IntPtr w,IntPtr context) { uint pid; GetWindowThreadProcessId(w,out pid); if(pid==target && GetWindowTextLengthW(w)>0) { found=w; return false; } return true; },IntPtr.Zero);
  return found;
 }
}
'@
[void][OdNativeControl]::SetProcessDPIAware()
$odProcess=Get-Process -Id $TargetPid
if ($odProcess.ProcessName -ne 'OneDiamondShort') {throw 'Only the challenge game may receive QA input.'}
$odWindow=$odProcess.MainWindowHandle
if ($odWindow -eq [IntPtr]::Zero) { $odWindow=[OdNativeControl]::FindWindow([uint32]$TargetPid) }
if ($odWindow -eq [IntPtr]::Zero) {throw 'Game window unavailable; use the authorized native desktop execution context.'}
[void][OdNativeControl]::ShowWindow($odWindow,5)
$odForeground=[OdNativeControl]::GetForegroundWindow()
$odForegroundPid=[uint32]0
$odForegroundThread=[OdNativeControl]::GetWindowThreadProcessId($odForeground,[ref]$odForegroundPid)
$odCurrentThread=[OdNativeControl]::GetCurrentThreadId()
$odAttached=$false
try {
 if ($odForegroundThread -ne 0 -and $odForegroundThread -ne $odCurrentThread) {
  $odAttached=[OdNativeControl]::AttachThreadInput($odCurrentThread,$odForegroundThread,$true)
 }
 [void][OdNativeControl]::BringWindowToTop($odWindow)
 [void][OdNativeControl]::SetForegroundWindow($odWindow)
} finally {
 if ($odAttached) { [void][OdNativeControl]::AttachThreadInput($odCurrentThread,$odForegroundThread,$false) }
}
Start-Sleep -Milliseconds 150
if ([OdNativeControl]::GetForegroundWindow() -ne $odWindow) {throw 'Requested game did not acquire foreground; no input was sent.'}
switch ($Action) {
 'Key' { [OdNativeControl]::keybd_event($Key,0,0,[UIntPtr]::Zero); Start-Sleep -Milliseconds $Milliseconds; [OdNativeControl]::keybd_event($Key,0,2,[UIntPtr]::Zero) }
 'Mouse' { [OdNativeControl]::mouse_event(1,$X,$Y,0,[UIntPtr]::Zero) }
 'Cursor' {
  $odPoint=New-Object OdNativeControl+Point; $odPoint.X=$X; $odPoint.Y=$Y
  [void][OdNativeControl]::ClientToScreen($odWindow,[ref]$odPoint)
  [void][OdNativeControl]::SetCursorPos($odPoint.X,$odPoint.Y)
  $odCoords=[IntPtr](($X -band 65535) -bor (($Y -band 65535) -shl 16))
  [void][OdNativeControl]::PostMessageW($odWindow,0x200,[UIntPtr]::Zero,$odCoords)
 }
 'Click' {
  # Address the game's standard mouse messages directly so an unrelated
  # topmost desktop notification can never receive a QA click.
  $odPoint=New-Object OdNativeControl+Point
  [void][OdNativeControl]::GetCursorPos([ref]$odPoint)
  [void][OdNativeControl]::ScreenToClient($odWindow,[ref]$odPoint)
  $odCoords=[IntPtr](($odPoint.X -band 65535) -bor (($odPoint.Y -band 65535) -shl 16))
  $odDown=if($Button -eq 0){0x201}else{0x204}
  $odPressed=if($Button -eq 0){[UIntPtr]::new([uint64]1)}else{[UIntPtr]::new([uint64]2)}
  [void][OdNativeControl]::PostMessageW($odWindow,0x200,[UIntPtr]::Zero,$odCoords)
  [void][OdNativeControl]::PostMessageW($odWindow,$odDown,$odPressed,$odCoords)
  Start-Sleep -Milliseconds $Milliseconds
  [void][OdNativeControl]::PostMessageW($odWindow,($odDown+1),[UIntPtr]::Zero,$odCoords)
 }
 'Resize' { [void][OdNativeControl]::SetWindowPos($odWindow,[IntPtr]::Zero,30,30,$X,$Y,0x0040) }
}
Start-Sleep -Milliseconds 100
@{pid=$TargetPid;action=$Action;key=$Key;duration_ms=$Milliseconds;x=$X;y=$Y;utc=[DateTime]::UtcNow.ToString('o')} | ConvertTo-Json -Compress
