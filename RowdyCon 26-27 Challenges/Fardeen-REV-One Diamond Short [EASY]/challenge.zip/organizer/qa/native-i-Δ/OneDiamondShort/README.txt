Collect 10 diamonds to win a copy of Minecraft!

One Diamond Short - Demo
You have 15 minutes. The demo clock keeps running while paused.

Controls
W A S D: Move
Space: Jump
Mouse: Look
Left mouse: Mine / attack
Right mouse: Place / use
1-9 / mouse wheel: Select hotbar slot
E: Inventory
Q: Drop one item
Escape: Pause menu / close inventory
Inventory left click: Pick up / place / swap stack
Inventory right click: Split stack / place one
Shift + click: Quick transfer
F11: Fullscreen

--- Demo time expired ---
Time is up! Start a new demo and collect 10 diamonds before the clock runs out.
