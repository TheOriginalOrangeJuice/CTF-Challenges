"""Repackage the edited player folder without rebuilding or replacing its files."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'artifacts/OneDiamondShort'
ARCHIVE = ROOT / 'artifacts/OneDiamondShort.zip'
paths = sorted(SOURCE.rglob('*'))
if any(path.is_symlink() for path in paths):
    raise SystemExit('Refusing symbolic links in the player folder')
for required in ('OneDiamondShort.exe', 'README.txt'):
    if not (SOURCE / required).is_file():
        raise SystemExit(f'Missing {required}')
manifest = {}
temporary = ARCHIVE.with_suffix('.zip.tmp')
with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED) as bundle:
    for path in paths:
        name = path.relative_to(SOURCE).as_posix()
        data = path.read_bytes() if path.is_file() else b''
        info = zipfile.ZipInfo('OneDiamondShort/' + name + ('/' if path.is_dir() else ''),
                               (2010, 9, 18, 0, 0, 0))
        info.create_system = 3
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = ((0o40755 << 16) | 0x10) if path.is_dir() else (0o100644 << 16)
        bundle.writestr(info, data)
        if path.is_file():
            manifest[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
with zipfile.ZipFile(temporary) as bundle:
    assert bundle.testzip() is None
    for name in manifest:
        assert bundle.read('OneDiamondShort/' + name) == (SOURCE / name).read_bytes(), name
temporary.replace(ARCHIVE)
report = {'public_files': manifest, 'zip_sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()}
(ROOT / 'organizer/public-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'files': len(manifest), 'zip_sha256': report['zip_sha256'],
                  'archive_integrity': 'passed', 'file_parity': 'passed'}))
