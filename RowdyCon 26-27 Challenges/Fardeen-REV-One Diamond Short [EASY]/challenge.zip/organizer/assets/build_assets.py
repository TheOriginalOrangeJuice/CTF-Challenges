"""Pack licensed source pixels and rasterize OFL font. Run only in Condev.

Requires Pillow. Output PNGs have no clock or random metadata; ZIP timestamps
are fixed. Generated water/cloud masks and chest panels are code-native art.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import hashlib, json, math, shutil, zipfile, subprocess, sys

ROOT = Path(__file__).resolve().parents[2]
SRC = Path(__file__).resolve().parent / 'sources'
OUT = ROOT / 'challenge/assets'
LEAF = SRC / 'leafish/resourcepack-850b37662181f065eac7a437d798e78c46aaec28/assets/minecraft'
BLOCK = LEAF / 'textures/block'
ITEM = LEAF / 'textures/item'
used = {}
OUT.mkdir(parents=True, exist_ok=True)
subprocess.run([sys.executable,str(Path(__file__).with_name('build_native_tiles.py'))],check=True)
NATIVE=OUT/'native'

def load(path):
    path = Path(path)
    used[str(path.relative_to(ROOT)).replace('\\', '/')] = hashlib.sha256(path.read_bytes()).hexdigest()
    im = Image.open(path).convert('RGBA')
    if im.size != (16,16):
        im = im.crop((0,0,16,16))
    return im

tiles = {
 0:SRC/'grass_top.png', 1:BLOCK/'stone.png', 2:SRC/'dirt.png', 3:SRC/'grass_side.png',
 4:BLOCK/'oak_planks.png',5:BLOCK/'smooth_stone_slab_side.png',6:BLOCK/'smooth_stone.png',
 7:BLOCK/'bricks.png',8:BLOCK/'tnt_side.png',9:BLOCK/'tnt_top.png',10:BLOCK/'tnt_bottom.png',
 12:BLOCK/'red_mushroom.png',13:BLOCK/'dandelion.png',15:BLOCK/'oak_sapling.png',
 16:BLOCK/'cobblestone.png',17:BLOCK/'bedrock.png',18:BLOCK/'sand.png',19:BLOCK/'gravel.png',
 20:BLOCK/'oak_log.png',21:BLOCK/'oak_log_top.png',22:BLOCK/'oak_leaves.png',
 23:BLOCK/'gold_block.png',24:BLOCK/'gold_block.png',25:BLOCK/'sandstone_top.png',
 28:BLOCK/'red_mushroom.png',29:BLOCK/'brown_mushroom.png',
 32:BLOCK/'gold_ore.png',33:BLOCK/'iron_ore.png',34:BLOCK/'coal_ore.png',35:BLOCK/'bookshelf.png',
 36:BLOCK/'mossy_cobblestone.png',37:BLOCK/'obsidian.png',39:BLOCK/'gold_block.png',40:BLOCK/'gold_block.png',
 41:BLOCK/'sandstone.png',43:BLOCK/'crafting_table_top.png',44:BLOCK/'furnace_front.png',45:BLOCK/'furnace_side.png',
 48:BLOCK/'sponge.png',49:BLOCK/'glass.png',50:BLOCK/'diamond_ore.png',51:BLOCK/'diamond.png',
 55:BLOCK/'gold_block.png',56:BLOCK/'gold_block.png',57:BLOCK/'sandstone_bottom.png',
 58:BLOCK/'crafting_table_side.png',59:BLOCK/'crafting_table_front.png',60:BLOCK/'furnace_top.png',
 79:BLOCK/'white_wool.png',80:BLOCK/'torch.png'
}
tiles.update({1:NATIVE/'stone.png',32:NATIVE/'gold_ore.png',33:NATIVE/'iron_ore.png',
    34:NATIVE/'coal_ore.png',50:NATIVE/'diamond_ore.png',51:NATIVE/'diamond_block.png',
    23:NATIVE/'iron_block.png',39:NATIVE/'iron_block.png',55:NATIVE/'iron_block.png',
    24:NATIVE/'gold_block.png',40:NATIVE/'gold_block.png',56:NATIVE/'gold_block.png',
    43:NATIVE/'crafting_table_top.png',58:NATIVE/'crafting_table_side.png',59:NATIVE/'crafting_table_front.png',
    44:NATIVE/'furnace_front.png',45:NATIVE/'stone.png',60:NATIVE/'stone.png',61:NATIVE/'furnace_lit.png'})
atlas = Image.new('RGBA',(256,256))
for idx,path in sorted(tiles.items()):
    tile=load(path)
    atlas.paste(tile,((idx%16)*16,(idx//16)*16))

# Grayscale foliage is multiplied as the donor pack expects; no resampling.
leaf = atlas.crop((96,16,112,32))
for y in range(16):
    for x in range(16):
        r,g,b,a = leaf.getpixel((x,y))
        leaf.putpixel((x,y),(int(r*.55),min(255,int(g*1.18)),int(b*.28),a))
atlas.paste(leaf,(96,16))

# A stable initial fluid frame; the engine can animate these tile locations.
for idx,water in [(14,True),(30,False)]:
    tile=Image.new('RGBA',(16,16))
    for y in range(16):
        for x in range(16):
            n=(math.sin(x*.8+y*.3)+math.sin(y*.7-x*.5))*0.5
            color=(35+int(n*7),76+int(n*10),205+int(n*18),165) if water else (235+int(n*15),95+int(n*40),10,255)
            tile.putpixel((x,y),color)
    atlas.paste(tile,((idx%16)*16,(idx//16)*16))

# Chest is a deliberately simple native pixel panel with a visible metal latch.
for idx,front in [(26,False),(27,True)]:
    tile=Image.new('RGBA',(16,16),(111,75,37,255));d=ImageDraw.Draw(tile)
    d.rectangle((0,0,15,15),outline=(54,35,18),width=1)
    for y in [4,8,12]:d.line((1,y,14,y),fill=(83,53,24))
    d.line((1,1,14,1),fill=(178,127,65));d.line((1,6,14,6),fill=(42,28,16))
    if front:d.rectangle((7,5,9,9),fill=(42,37,28));d.rectangle((7,5,8,8),fill=(194,194,180))
    atlas.paste(tile,((idx%16)*16,(idx//16)*16))
for i in range(10):atlas.paste(load(BLOCK/f'destroy_stage_{i}.png'),((i%16)*16,15*16))
atlas.save(OUT/'terrain.png')

ids={256:'iron_shovel',257:'iron_pickaxe',258:'iron_axe',259:'flint_and_steel',260:'apple',261:'bow',262:'arrow',263:'coal',264:'diamond',265:'iron_ingot',266:'golden_ingot',267:'iron_sword',268:'wooden_sword',269:'wooden_shovel',270:'wooden_pickaxe',271:'wooden_axe',272:'stone_sword',273:'stone_shovel',274:'stone_pickaxe',275:'stone_axe',276:'diamond_sword',277:'diamond_shovel',278:'diamond_pickaxe',279:'diamond_axe',280:'stick',281:'bowl',282:'mushroom_stew',283:'golden_sword',284:'golden_shovel',285:'golden_pickaxe',286:'golden_axe',287:'string',288:'feather',289:'gunpowder',295:'wheat',297:'bread',318:'flint',319:'porkchop',320:'cooked_porkchop',334:'leather',336:'brick',337:'clay_ball'}
items=Image.new('RGBA',(256,256))
for idx,name in sorted(ids.items()):items.paste(load(ITEM/(name+'.png')),(((idx-256)%16)*16,((idx-256)//16)*16))
items.save(OUT/'items.png')

# Pixel-aligned OTF rasterization, preserving the font's proportional widths.
fontpath=SRC/'Minecraft.otf'
used[str(fontpath.relative_to(ROOT)).replace('\\','/')]=hashlib.sha256(fontpath.read_bytes()).hexdigest()
font=ImageFont.truetype(str(fontpath),9)
font_top=font.getbbox('A')[1]
fontatlas=Image.new('RGBA',(128,128))
for c in range(32,256):
    glyph=Image.new('1',(8,8));d=ImageDraw.Draw(glyph)
    d.text((0,-font_top),bytes([c]).decode('cp437'),font=font,fill=1,stroke_width=0)
    rgba=Image.new('RGBA',(8,8),(255,255,255,0));rgba.putalpha(glyph.convert('L'))
    fontatlas.paste(rgba,((c%16)*8,(c//16)*8))
fontatlas.save(OUT/'default.png')

# Ordinary cloud coverage mask generated on a block grid; the timer has its own
# native cuboid geometry and reserves a view-dependent gap in this mask.
cloud=Image.new('RGBA',(256,256))
d=ImageDraw.Draw(cloud)
for y in range(0,256,8):
    for x in range(0,256,8):
        v=math.sin(x*.042)+math.sin(y*.055)+math.cos((x+y)*.029)
        if v>0.95:d.rectangle((x,y,x+7,y+7),fill=(255,255,255,225))
cloud.save(OUT/'clouds.png')
# Atlas contact sheet is a source-pixel inspection aid, never runtime evidence.
contact=Image.new('RGB',(1024,768),(45,45,45))
contact.paste(atlas.resize((512,512),Image.Resampling.NEAREST),(0,0))
contact.paste(items.resize((512,512),Image.Resampling.NEAREST),(512,0))
fontreview=fontatlas.resize((512,512),Image.Resampling.NEAREST).crop((0,0,512,256))
contact.paste(fontreview,(0,512),fontreview)
contact.save(Path(__file__).resolve().parent/'contact-sheet.png')
manifest={'sources':used,'leafish_revision':'850b37662181f065eac7a437d798e78c46aaec28','font_revision':'261ac77fbf28796ca09c22eb83ecdfe386c4b838','terrain_tiles':{str(k):str(v.relative_to(ROOT)).replace('\\','/') for k,v in tiles.items()},'item_tiles':ids,'adaptations':['Atlas packing; grayscale oak-leaf color multiplication (0.55,1.18,0.28); original stone, ore chips and metal panels rasterized from code-native SVG rectangles.','Procedural fluid initial frames, cloud mask and simple chest panels.','OFL font rasterized at 9px em (18 font units,14 cap units), seven-pixel capitals in eight-pixel cells, binary alpha.'],'outputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(OUT.glob('*.png'))}}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
with zipfile.ZipFile(OUT/'default.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in ['terrain.png','default.png','clouds.png']:
        info=zipfile.ZipInfo(name,(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,(OUT/name).read_bytes())
print(json.dumps({'outputs':manifest['outputs'],'sources':len(used)},indent=2))
