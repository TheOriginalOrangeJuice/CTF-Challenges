"""Read-only font raster diagnostics; execute in Condev, never install the OTF."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
FONT=Path(__file__).with_name('sources')/'Minecraft.otf'
for size in (8,9,10,11,12):
    f=ImageFont.truetype(str(FONT),size)
    print('SIZE',size,'METRICS',f.getmetrics(),'A_BOX',f.getbbox('A'),'A_ADVANCE',f.getlength('A'))
    top=f.getbbox('A')[1]
    for c in ('A','a','g','0'):
        im=Image.new('1',(12,12));ImageDraw.Draw(im).text((0,-top),c,font=f,fill=1)
        print(c,'INK',im.getbbox())
        for y in range(10):print(''.join('#' if im.getpixel((x,y)) else '.' for x in range(10)))
