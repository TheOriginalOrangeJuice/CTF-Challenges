# Native visual acceptance

Windows runtime capture is the explicitly approved QA exception. Builds and generators run in Condev. `capture_visual.ps1` records the selected process's actual client area, with a matching JSON provenance record. It does not change inventory, trial state, the clock, or world geometry. Keep reference images under `organizer/assets/references/` separate from real application captures under `screenshots/`.

After root launches the built executable, run:

```powershell
./organizer/assets/capture_visual.ps1 -ProcessId <game-process-id> -Scenario title
```

Inspect every PNG before claiming acceptance. The script now refuses captures unless the selected process owns the foreground window and five points inside the client area; this prevents another overlapping game copy from contaminating evidence. `-KeepFocus` is intended only for a deliberate focus-loss capture where its window remains visible and ownership checks still pass.

Record actual results, executable hash and observed limitations in the organizer QA report. A successful automated capture is not independent human playtesting.

When an external topmost notification covers the desktop capture, use `../qa/capture_frame.ps1`: it sends the public game's normal F2 screenshot input and copies the unmodified framebuffer PNG with provenance. The game captures after rendering its UI. This path produced the final i captures and does not bypass or weaken the desktop helper's ownership checks.

| Capture | Required observation |
|---|---|
| title | Dirt background, proportional crisp text, gray Play Demo / README / Options / Quit controls; each advertised action works. |
| options | Sound, reduced motion, sensitivity and window/fullscreen state change; mouse and keyboard navigation work. |
| daylight-spawn | Bright uniform foliage, 16-pixel textures, recognizable shallow cave, survival starter tools, hearts and nine slots. |
| lake-oak | Water palette, oak/log/leaves, directional block shading, held block/item and pickups. |
| cave-diamonds | Stone/ore contrast and mining cracks; real diamond pickup updates the visible count. |
| inventory | Carried quantities, split/place/shift transfers, 2x2 crafting preview, cursor stack and item names reflect game snapshots. |
| crafting-furnace-chest | 3x3 crafting and both furnace progress/fuel; chest transfers use real container state. |
| clock-shallow / clock-zenith | Complete readable MM:SS at upward pitches 15,30,60,89 degrees and at least four yaws; no mirror/flip/corner clipping. |
| clock-night / clock-clouds-off | Timer remains legible at night and independent of ordinary cloud visibility. |
| clock-roof / clock-leaf-holes | Opaque roofs/terrain occlude digits; leaf holes reveal them; ordinary clouds do not overlap the reserved gap. |
| pause / focus-loss / death | The latest user requirement allows only the cloud countdown: no HUD or menu countdown text. Pause, focus loss and death must still give no time extension. Inventory/death/cave overlays remain readable. |
| result / save-failure | Actual earned reward from the reward snapshot, actual file status/error, functioning retry/open-README controls. |

Check 15:00, 14:59, 01:00, 00:59, 00:01 and 00:00 using real observable application state or clearly labeled organizer diagnostic runs. Do not label a synthetic snapshot or replay as a completed full-duration trial. A full 900-second active run with pause/focus/death intervals is a separate timing acceptance check.

Primary comparison: the visible Alpha v1.1.2_01 MobyGames gameplay image documented in `references/REFERENCE-NOTES.md`. The later Alpha inventory image is a supplemental layout reference only. `visual-review.json` records actual comparisons and per-build limits. Licensed replacement art, original mob/portrait geometry and custom title/cloud clock make this a close alternative, not a one-to-one pixel reproduction.

Build h naturally exited 900.6608366 seconds after the recorded Play Demo keydown, through pause and focus changes. The four `final-cloud-*-h` captures listed as rejected in the report belong to a foreground-window mix-up and must not be used. The file named `h-night-cloud-root.png` shows daylight, despite its name.

Final i fullscreen/windowed and `inventory-final.png` captures show the cloud-only countdown and preserved inventory. Native audio evidence is `../tests/audio-output-native-final.json`: all fourteen clips load, twelve voices overlap with no drops, Windows reports no device error, and WASAPI output-loopback levels confirm mute and resume. The harness excludes transition packets already queued by the system audio engine when calculating stable phase levels. It records output levels, not microphone input; this technical check does not claim a listening audition.
