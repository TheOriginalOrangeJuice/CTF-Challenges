"""Convert pinned licensed foley and render short deterministic native effects.
Run in Condev with ffmpeg. No network access; PCM mono WAVs work with WinMM.
"""
from pathlib import Path
import array, hashlib, json, math, random, subprocess, sys, wave
ROOT=Path(__file__).resolve().parents[2]
SRC=Path(__file__).resolve().parent/'sources'
OUT=ROOT/'challenge/assets/sounds'
LEAF=SRC/'leafish/resourcepack-850b37662181f065eac7a437d798e78c46aaec28/assets/minecraft/sounds'
KENNEY=SRC/'kenney_impact/Audio'
RATE=22050
OUT.mkdir(parents=True,exist_ok=True)
manifest={}

def convert(name,path,filters='volume=0.7'):
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(path),
        '-map_metadata','-1','-ac','1','-ar',str(RATE),'-af',filters,
        '-c:a','pcm_s16le',str(OUT/(name+'.wav'))],check=True)
    manifest[name]={'source':str(path.relative_to(ROOT)).replace('\\','/'),
        'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'conversion':filters}

def synth(name,duration,render):
    data=array.array('h');rng=random.Random(0x1D1A2026);filtered=0
    for i in range(round(duration*RATE)):
        t=i/RATE;noise=rng.uniform(-1,1);filtered=filtered*.94+noise*.06
        sample=render(t,t/duration,noise,filtered)
        data.append(round(max(-.8,min(.8,sample))*32767))
    if sys.byteorder!='little':data.byteswap()
    with wave.open(str(OUT/(name+'.wav')),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(RATE);w.writeframes(data.tobytes())
    manifest[name]={'source':'original deterministic DSP in organizer/assets/build_sounds.py','license':'CC0-1.0'}

convert('step',LEAF/'step/grass1.ogg','volume=0.65')
convert('dig',LEAF/'dig/stone1.ogg','volume=0.55')
convert('break',KENNEY/'impactMining_000.ogg','volume=0.7')
convert('place',KENNEY/'impactWood_light_000.ogg','volume=0.55')
synth('pickup',.12,lambda t,u,n,f:.4*math.sin(2*math.pi*(650*t+1400*t*t))*math.sin(math.pi*u)*(1-u))
convert('hurt',LEAF/'damage/hurt.ogg','volume=0.65')
convert('eat',LEAF/'dig/sand1.ogg','volume=0.65,apad=pad_dur=0.05,aloop=loop=2:size=7000,atrim=duration=0.55')
synth('swing',.18,lambda t,u,n,f:.22*n*math.sin(math.pi*u)**2)
convert('mob_hurt',KENNEY/'impactPunch_medium_000.ogg','volume=0.6')
synth('bow',.24,lambda t,u,n,f:(.18*n+.2*math.sin(2*math.pi*(380*t-350*t*t)))*math.exp(-18*t)*min(1,t*500))
synth('fuse',1.15,lambda t,u,n,f:.16*n*(.5+.5*u)*min(1,t*100)*min(1,(1-u)*30))
synth('explode',.85,lambda t,u,n,f:(1.7*f+.16*n+.12*math.sin(2*math.pi*47*t))*math.exp(-5*t)*min(1,t*300))
convert('craft',KENNEY/'impactWood_light_001.ogg','volume=0.5')
convert('death',LEAF/'damage/hurt.ogg','aresample=22050,asetrate=17640,aresample=22050,volume=0.65')

order=['step','dig','break','place','pickup','hurt','eat','swing','mob_hurt','bow','fuse','explode','craft','death']
for index,name in enumerate(order):
    path=OUT/(name+'.wav')
    with wave.open(str(path),'rb') as w:
        frames=w.readframes(w.getnframes());rate=w.getframerate()
        samples=array.array('h',frames)
        if sys.byteorder!='little':samples.byteswap()
        manifest[name].update({'enum_id':index,'seconds':len(samples)/rate,
          'peak':max(abs(v) for v in samples)/32768,
          'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
        assert 0<len(samples)<RATE*5 and max(abs(v) for v in samples)<32768
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,indent=2))
