"""Rasterize original code-native 16-pixel block-face vector assets (CC0).

Each SVG consists solely of integral rects, with matching PNG output. This
replaces donor ore illustrations with authored speckles in a stone face.
"""
from pathlib import Path
from PIL import Image, ImageDraw
from xml.sax.saxutils import escape
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'challenge/assets/native'
OUT.mkdir(parents=True,exist_ok=True)

# Authored stone value map. Values are palette indexes, not sampled game pixels.
STONE=[
'3344433433222334','3445432343322344','3334342334433334','2233433445544333',
'2334323444344432','3343223333343322','4433233223344333','4343344322334434',
'3333445433333344','2323444344432333','2233343334543232','3322332233433323',
'4332233233334443','4433334443234543','3344434543323433','2334333434333322']
PALETTE=['#525252','#606060','#6b6b6b','#777777','#838383','#8d8d8d']
def stone():
    return [(x,y,1,1,PALETTE[int(STONE[y][x])]) for y in range(16) for x in range(16)]
def emit(name,rects):
    im=Image.new('RGBA',(16,16));d=ImageDraw.Draw(im)
    xml=['<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" shape-rendering="crispEdges">',
      '<metadata>Original One Diamond Short code-native pixel geometry. CC0-1.0.</metadata>']
    for x,y,w,h,c in rects:
        xml.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{escape(c)}"/>')
        d.rectangle((x,y,x+w-1,y+h-1),fill=c)
    xml.append('</svg>')
    (OUT/(name+'.svg')).write_text('\n'.join(xml)+'\n',encoding='utf-8')
    im.save(OUT/(name+'.png'))

emit('stone',stone())
positions=[(3,1),(10,2),(13,6),(6,6),(1,10),(9,11),(4,13)]
ores={'coal_ore':('#303030','#242424','#414141'),
      'iron_ore':('#94735b','#ba967c','#d5b69d'),
      'gold_ore':('#ad8d30','#dfbd4b','#f4db73'),
      'diamond_ore':('#328f93','#62d3d4','#a9f4ed')}
for name,(dark,base,light) in ores.items():
    r=stone()
    for x,y in positions:
        r.extend([(x,y,2,1,dark),(x-1,y+1,3,1,base),(x,y+2,2,1,light),(x+2,y+1,1,1,dark)])
    emit(name,r)

for name,colors in {
 'iron_block':('#b2b2b2','#cdcdcd','#dfdfdf','#bfbfbf'),
 'gold_block':('#bba23b','#d8be54','#ead577','#ccb44b'),
 'diamond_block':('#4fa8af','#79d2d5','#a4e7e6','#68bfc4')}.items():
    edge,base,light,shade=colors
    r=[(0,0,16,16,edge),(1,1,14,14,base),(1,1,14,1,light),(1,2,1,13,light),
       (2,14,13,1,shade),(14,2,1,12,shade)]
    for x,y in [(3,4),(7,3),(11,6),(5,9),(9,12),(3,12),(12,10)]:r.append((x,y,1,1,shade))
    emit(name,r)

wood=[(0,0,16,16,'#78512d'),(1,1,14,14,'#9f7345')]
for yy in (4,8,12):wood.extend([(1,yy,14,1,'#674725'),(2,yy+1,12,1,'#ad8050')])
top=[(0,0,16,16,'#49331d'),(1,1,14,14,'#91683d'),(2,2,12,12,'#b48a55')]
for line in (5,9):top.extend([(line,2,1,12,'#583b21'),(2,line,12,1,'#583b21')])
top.extend([(1,1,14,1,'#c39760'),(1,1,1,14,'#c39760')])
emit('crafting_table_top',top)
for name in ('crafting_table_front','crafting_table_side'):
    r=wood+[(0,0,16,3,'#634323'),(1,1,14,1,'#b68a53'),(1,3,2,13,'#5b3c20'),(13,3,2,13,'#5b3c20')]
    if name.endswith('front'):
        r.extend([(5,5,2,7,'#5c4229'),(4,5,5,2,'#b4aca1'),(10,5,1,8,'#5c4229'),(9,5,3,3,'#8a8b83')])
    else:r.extend([(5,5,7,7,'#87592f'),(6,6,5,1,'#b58a51'),(7,8,3,1,'#5d3b20')])
    emit(name,r)
for name,lit in [('furnace_front',False),('furnace_lit',True)]:
    r=stone()+[(2,2,12,5,'#515151'),(3,3,10,3,'#222222'),(2,8,12,6,'#505050'),(3,9,10,4,'#1b1b1b')]
    if lit:r.extend([(4,11,8,2,'#eb7b16'),(5,10,2,2,'#ffc83b'),(9,9,2,3,'#e9a52b')])
    emit(name,r)
print('Rasterized thirteen original SVG block faces at 16x16.')
