param(
    [Parameter(Mandatory=$true)][int]$ProcessId,
    [Parameter(Mandatory=$true)][ValidatePattern('^[a-z0-9][a-z0-9-]{0,63}$')][string]$Scenario,
    [switch]$KeepFocus
)
$ErrorActionPreference = 'Stop'
$challengeRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$captureRoot = [IO.Path]::GetFullPath((Join-Path $challengeRoot 'screenshots'))
if (-not $captureRoot.StartsWith($challengeRoot + [IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)) {
    throw 'Capture destination escaped the challenge folder.'
}
New-Item -ItemType Directory -Force -Path $captureRoot | Out-Null
Add-Type -AssemblyName System.Drawing
if (-not ('OdCaptureWindow' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class OdCaptureWindow {
    [StructLayout(LayoutKind.Sequential)] public struct Rect { public int Left,Top,Right,Bottom; }
    [StructLayout(LayoutKind.Sequential)] public struct Point { public int X,Y; }
    [DllImport("user32.dll")] public static extern bool GetClientRect(IntPtr handle,out Rect rect);
    [DllImport("user32.dll")] public static extern bool ClientToScreen(IntPtr handle,ref Point point);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr handle);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr handle,int command);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr handle);
    [DllImport("user32.dll")] public static extern IntPtr SetThreadDpiAwarenessContext(IntPtr value);
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr handle,out uint process);
    [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint from,uint to,bool attach);
    [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr handle);
    [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(Point point);
}
'@
}
$gameProcess = Get-Process -Id $ProcessId
$previousDpi = [OdCaptureWindow]::SetThreadDpiAwarenessContext([IntPtr](-4))
$handle = $gameProcess.MainWindowHandle
if ($handle -eq [IntPtr]::Zero) { throw 'The requested process has no visible main window.' }
if (-not $KeepFocus) {
    if ([OdCaptureWindow]::IsIconic($handle)) { [OdCaptureWindow]::ShowWindow($handle,9) | Out-Null }
    [uint32]$foregroundProcess=0
    $foregroundThread=[OdCaptureWindow]::GetWindowThreadProcessId([OdCaptureWindow]::GetForegroundWindow(),[ref]$foregroundProcess)
    $captureThread=[OdCaptureWindow]::GetCurrentThreadId()
    $attached=$false
    try {
        if ($foregroundThread -ne $captureThread) { $attached=[OdCaptureWindow]::AttachThreadInput($captureThread,$foregroundThread,$true) }
        [OdCaptureWindow]::BringWindowToTop($handle) | Out-Null
        [OdCaptureWindow]::SetForegroundWindow($handle) | Out-Null
    } finally {
        if ($attached) { [OdCaptureWindow]::AttachThreadInput($captureThread,$foregroundThread,$false) | Out-Null }
    }
    Start-Sleep -Milliseconds 300
    if ([OdCaptureWindow]::GetForegroundWindow() -ne $handle) { throw 'The requested game did not become foreground; refusing a potentially occluded capture.' }
}
$client = New-Object OdCaptureWindow+Rect
$origin = New-Object OdCaptureWindow+Point
if (-not [OdCaptureWindow]::GetClientRect($handle,[ref]$client)) { throw 'GetClientRect failed.' }
if (-not [OdCaptureWindow]::ClientToScreen($handle,[ref]$origin)) { throw 'ClientToScreen failed.' }
$width = $client.Right-$client.Left
$height = $client.Bottom-$client.Top
if ($width -lt 64 -or $height -lt 64) { throw 'The client area is too small for a valid capture.' }
foreach ($sample in @(@(8,8),@(($width-9),8),@(8,($height-9)),@(($width-9),($height-9)),@([int]($width/2),[int]($height/2)))) {
    $point=New-Object OdCaptureWindow+Point
    $point.X=$origin.X+$sample[0]
    $point.Y=$origin.Y+$sample[1]
    [uint32]$pointOwner=0
    $pointWindow=[OdCaptureWindow]::WindowFromPoint($point)
    [void][OdCaptureWindow]::GetWindowThreadProcessId($pointWindow,[ref]$pointOwner)
    if ($pointOwner -ne $ProcessId) {
        $pointOwnerName=(Get-Process -Id $pointOwner -ErrorAction SilentlyContinue).ProcessName
        throw "Another window covers the requested game client; refusing a contaminated capture. Target PID=$ProcessId HWND=$handle; client=($($origin.X),$($origin.Y),$width,$height); point=($($point.X),$($point.Y)); owner PID=$pointOwner name=$pointOwnerName HWND=$pointWindow; foreground=$([OdCaptureWindow]::GetForegroundWindow())."
    }
}
$bitmap = New-Object Drawing.Bitmap($width,$height)
$graphics = [Drawing.Graphics]::FromImage($bitmap)
$imagePath = Join-Path $captureRoot ($Scenario+'.png')
try {
    $graphics.CopyFromScreen($origin.X,$origin.Y,0,0,$bitmap.Size,[Drawing.CopyPixelOperation]::SourceCopy)
    $bitmap.Save($imagePath,[Drawing.Imaging.ImageFormat]::Png)
} finally {
    $graphics.Dispose()
    $bitmap.Dispose()
    if ($previousDpi -ne [IntPtr]::Zero) { [OdCaptureWindow]::SetThreadDpiAwarenessContext($previousDpi) | Out-Null }
}
$metadata = [ordered]@{
    scenario=$Scenario
    captured_utc=[DateTime]::UtcNow.ToString('o')
    process_id=$ProcessId
    process_name=$gameProcess.ProcessName
    executable_path=$gameProcess.Path
    executable_sha256=(Get-FileHash -LiteralPath $gameProcess.Path -Algorithm SHA256).Hash.ToLowerInvariant()
    window_title=$gameProcess.MainWindowTitle
    client_width=$width
    client_height=$height
    client_screen_x=$origin.X
    client_screen_y=$origin.Y
    image_sha256=(Get-FileHash -LiteralPath $imagePath -Algorithm SHA256).Hash.ToLowerInvariant()
    capture_method='Windows client-area CopyFromScreen; no compositing, mockup, or image alteration'
}
$metadata | ConvertTo-Json | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $captureRoot ($Scenario+'.json'))
Write-Output $imagePath
