#!/usr/bin/env bash
# Run from the complete, parity-verified challenge tree inside Condev.
set -euo pipefail
cd "$(dirname "$0")/../.."
test_dir=$(mktemp -d /tmp/ods-trial-tests.XXXXXX)
trap 'rm -rf -- "$test_dir"' EXIT
compiler=${CC:-gcc}
common=(-std=c99 -Wall -Wextra -Werror)
crypto=challenge/vendor/monocypher/monocypher.c
"$compiler" "${common[@]}" organizer/reward/generate_reward.c "$crypto" -o "$test_dir/generate"
"$test_dir/generate" > "$test_dir/OdRewardBlob.h"
cmp "$test_dir/OdRewardBlob.h" challenge/src/trial/OdRewardBlob.h
printf '%s\n' '{"reward_header_reproducible":true}'
"$compiler" "${common[@]}" organizer/tests/trial_core.c challenge/src/trial/OdTrial.c -o "$test_dir/core"
"$test_dir/core"
"$compiler" "${common[@]}" organizer/tests/trial_crypto.c challenge/src/trial/OdRewardCrypto.c "$crypto" -o "$test_dir/crypto"
"$test_dir/crypto"
if [[ -n "${WINDOWS_CC:-}" ]]; then
    "$WINDOWS_CC" "${common[@]}" -DOD_REWARD_TEST organizer/tests/trial_files_win.c \
        challenge/src/trial/OdTrial.c challenge/src/trial/OdReward.c \
        challenge/src/trial/OdRewardCrypto.c "$crypto" -lshell32 \
        -o "$test_dir/trial-files-win.exe"
    if [[ -n "${WINDOWS_TEST_OUTPUT:-}" ]]; then
        cp "$test_dir/trial-files-win.exe" "$WINDOWS_TEST_OUTPUT"
    fi
    printf '%s\n' '{"windows_file_test_cross_compile":"passed","windows_execution":"pending_native_QA"}'
fi
