#include "../../challenge/src/game/OdInternal.h"
#include <assert.h>
#include <stdio.h>
#include <stddef.h>

static unsigned char blocks[64*64*64];
static int checks,teleports,sounds[32];
static int audio_sequence[64],audio_count;
static int get(int x,int y,int z) {return blocks[(y*64+z)*64+x];}
static void set(int x,int y,int z,int b) {blocks[(y*64+z)*64+x]=(unsigned char)b;}
static void teleport(float x,float y,float z,float yaw,float pitch) {(void)x;(void)y;(void)z;(void)yaw;(void)pitch;teleports++;}
static void sound(int s,float x,float y,float z) {(void)x;(void)y;(void)z;sounds[s]++;if(audio_count<64)audio_sequence[audio_count++]=s;}
static void checked(int value,const char* expression,int line) {checks++;if(!value){fprintf(stderr,"game_conservation:%d: failed: %s\n",line,expression);abort();}}
#define check(value) checked((value),#value,__LINE__)
static void tick(float seconds) {int n=(int)(seconds*20+0.5f),i;for(i=0;i<n;i++)OdGame_Tick(0.05f,&od.player);}
static void quiet(void) {memset(od.mobs,0,sizeof(od.mobs));memset(od.projectiles,0,sizeof(od.projectiles));}
static void reset(void) {OdGame_GenerateWorld();quiet();}
static void move_player(float x,float y,float z) {od.player.position.x=x;od.player.position.y=y;od.player.position.z=z;od.player.on_ground=1;od.player.head_in_water=0;od.player.in_lava=0;od.fall_top=y;}
static int carried(int id) {
    int i,n=0;for(i=0;i<36;i++)if(od.carried.inventory[i].item_id==id)n+=od.carried.inventory[i].count;
    if(od.carried.cursor.item_id==id)n+=od.carried.cursor.count;
    for(i=0;i<9;i++)if(od.carried.craft[i].item_id==id)n+=od.carried.craft[i].count;
    return n;
}
static int dropped(int id) {int i,n=0;for(i=0;i<OD_MAX_DROPS;i++)if(od.drops[i].active&&od.drops[i].stack.item_id==id)n+=od.drops[i].stack.count;return n;}
static int block_count(int id) {int i,n=0;for(i=0;i<64*64*64;i++)if(blocks[i]==id)n++;return n;}
static uint32_t world_hash(void) {int i;uint32_t h=2166136261u;for(i=0;i<64*64*64;i++){h^=blocks[i];h*=16777619u;}return h;}
static int slot(int id) {int i;for(i=0;i<36;i++)if(od.carried.inventory[i].item_id==id&&od.carried.inventory[i].count>0)return i;return -1;}
static void give(int id,int n) {check(Od_Give(id,n,0)==0);}
static void mine(int x,int y,int z) {int n;for(n=0;n<400&&get(x,y,z);n++)OdGame_Mine(x,y,z,1,0.05f);check(get(x,y,z)==0);}

static void test_start_world(void) {
    uint32_t h;const OdCarried* stable=OdGame_GetCarriedState();
    reset();h=world_hash();check(block_count(56)==9);check(carried(264)==0);
    check(carried(257)==1&&carried(258)==1&&carried(256)==1&&carried(267)==1);
    check(carried(50)==16&&carried(320)==4);check(sizeof(int32_t)==4&&offsetof(OdStack,count)==4&&sizeof(OdStack)==12);
    check(((uintptr_t)&od.carried.inventory[0].count&3)==0);
    check(get(24,21,19)==0&&get(24,22,19)==0&&get(24,20,19)!=0);
    reset();check(h==world_hash());check(stable==OdGame_GetCarriedState());
}
static void test_nine_ore(void) {
    static const int ores[9][3]={{21,20,25},{21,20,26},{21,21,26},{27,19,32},{27,19,33},{27,20,33},{23,17,43},{24,17,43},{25,17,43}};
    int i;reset();
    for(i=0;i<9;i++) {
        int x=ores[i][0],y=ores[i][1],z=ores[i][2];
        move_player(x==21?22.2f:x==27?26.1f:x+0.5f,y==21?20.0f:(float)y,z==43?42.1f:z+0.5f);
        mine(x,y,z);tick(1.0f);
        OdGame_Mine(x,y,z,1,0.25f); /* Repeated destruction cannot repeat loot. */
    }
    check(block_count(56)==0);check(carried(264)+dropped(264)==9);
    for(i=0;i<OD_MAX_DROPS;i++)if(od.drops[i].active&&od.drops[i].stack.item_id==264) {
        OdVec3 p=od.drops[i].position;move_player(p.x,p.y,p.z);tick(1.2f);
    }
    check(carried(264)==9);check(dropped(264)==0);check(od.carried.inventory[0].damage==9);
}
static void test_transfers_and_craft(void) {
    int i,s;OdStack output;reset();give(264,9);s=slot(264);
    OdGame_OpenInventory();check(OdGame_ClickSlot(OD_AREA_INVENTORY,s,1,0));
    check(od.carried.cursor.count==5&&od.carried.inventory[s].count==4);
    check(OdGame_ClickSlot(OD_AREA_INVENTORY,35,1,0));check(od.carried.inventory[35].count==1&&od.carried.cursor.count==4);
    check(OdGame_ClickSlot(OD_AREA_INVENTORY,s,0,0));check(carried(264)==9);
    OdGame_CloseScreen();check(Od_OpenStation(20,21,13,58));
    s=slot(264);check(OdGame_ClickSlot(OD_AREA_INVENTORY,s,0,0));
    /* One diamond is in slot35; gather both actual stacks before crafting. */
    if(Od_StackValid(&od.carried.inventory[35])) {
        check(OdGame_ClickSlot(OD_AREA_INVENTORY,35,0,0));
        check(od.carried.cursor.count==0&&od.carried.inventory[35].count==9);
        check(OdGame_ClickSlot(OD_AREA_INVENTORY,35,0,0));
    }
    check(od.carried.cursor.count==9);
    for(i=0;i<9;i++)check(OdGame_ClickSlot(OD_AREA_CRAFT,i,1,0));
    output=OdGame_GetCraftOutput();check(output.item_id==57&&output.count==1);check(carried(264)==9);
    check(OdGame_ClickSlot(OD_AREA_CRAFT_OUTPUT,0,0,0));check(carried(264)==0&&carried(57)==1);
    check(!OdGame_ClickSlot(OD_AREA_CRAFT_OUTPUT,0,0,0)); /* No stale output. */
    check(OdGame_ClickSlot(OD_AREA_CRAFT,0,0,0));output=OdGame_GetCraftOutput();check(output.item_id==264&&output.count==9);
    check(OdGame_ClickSlot(OD_AREA_CRAFT_OUTPUT,0,0,1));check(carried(264)==9&&carried(57)==0);
    OdGame_CloseScreen();
    check(Od_OpenStation(22,21,13,54));s=slot(264);check(OdGame_ClickSlot(OD_AREA_INVENTORY,s,0,1));
    check(carried(264)==0&&od.stations[od.station].slots[0].count==9);
    OdGame_CloseScreen();check(Od_OpenStation(22,21,13,54));check(OdGame_ClickSlot(OD_AREA_CHEST,0,0,1));check(carried(264)==9);
    OdGame_CloseScreen();
}
static void test_full_and_overflow(void) {
    int i;reset();memset(&od.carried,0,sizeof(od.carried));
    give(264,64);give(264,9);check(carried(264)==73);check(od.carried.inventory[0].count==64&&od.carried.inventory[1].count==9);
    OdGame_OpenInventory();check(OdGame_ClickSlot(OD_AREA_INVENTORY,1,0,0));
    check(!OdGame_ClickSlot(OD_AREA_INVENTORY,0,0,0));check(carried(264)==73);
    OdGame_CloseScreen();check(Od_OpenStation(20,21,13,58));
    for(i=0;i<36;i++) {od.carried.inventory[i].item_id=3;od.carried.inventory[i].count=64;}
    for(i=0;i<9;i++) {od.carried.craft[i].item_id=264;od.carried.craft[i].count=1;}
    check(!OdGame_ClickSlot(OD_AREA_CRAFT_OUTPUT,0,0,1));check(carried(264)==9);
    check(OdGame_ClickSlot(OD_AREA_CRAFT_OUTPUT,0,0,0));check(carried(57)==1&&carried(264)==0);
}
static void test_death_respawn(void) {
    const OdCarried* stable;double elapsed;reset();give(264,9);move_player(24.5f,21,11.5f);stable=OdGame_GetCarriedState();
    tick(2);elapsed=od.elapsed;Od_DamagePlayer(20,od.player.position);
    check(OdGame_IsDead());check(carried(264)==0&&dropped(264)==9);check(carried(257)==0);
    OdGame_Respawn();check(!OdGame_IsDead()&&od.health==20);check(carried(257)==0&&carried(264)==0);
    check(OdGame_GetCarriedState()==stable&&od.elapsed==elapsed);check(block_count(56)==9);
    tick(2);check(carried(264)==9&&dropped(264)==0&&carried(257)==1);
}
static void test_furnace_food_place(void) {
    int s;reset();give(263,1);give(319,1);check(Od_OpenStation(21,21,13,61));
    s=slot(319);check(OdGame_ClickSlot(OD_AREA_INVENTORY,s,0,1));s=slot(263);check(OdGame_ClickSlot(OD_AREA_INVENTORY,s,0,1));
    tick(11);check(od.stations[od.station].slots[2].item_id==320&&od.stations[od.station].slots[2].count==1);
    check(carried(319)==0&&carried(263)==0);check(OdGame_ClickSlot(OD_AREA_FURNACE,2,0,1));check(carried(320)==5);
    OdGame_CloseScreen();od.health=8;OdGame_SelectSlot(5);check(OdGame_Use(0,0,0,0,0,0,0));check(od.health==16&&carried(320)==4);
    move_player(24.5f,21,11.5f);OdGame_SelectSlot(4);check(OdGame_Use(24,20,12,0,1,0,1));check(get(24,21,12)==50&&carried(50)==15);
    mine(24,21,12);tick(1);check(carried(50)==16);check(!OdGame_Use(24,20,12,2,0,0,1));
}
static void test_damage_and_combat(void) {
    OdVec3 from;int i;reset();od.player.head_in_water=1;tick(17);check(od.health<20&&od.air<=0);
    reset();move_player(24.5f,30,11.5f);od.player.on_ground=0;tick(0.1f);od.player.position.y=21;od.player.on_ground=1;tick(0.1f);check(od.health==14);
    reset();from=od.player.position;Od_DamagePlayer(3,from);Od_DamagePlayer(3,from);check(od.health==17);
    tick(0.6f);Od_DamagePlayer(3,from);check(od.health==14);
    reset();memset(&od.mobs[0],0,sizeof(OdMob));od.mobs[0].active=1;od.mobs[0].kind=OD_MOB_ZOMBIE;od.mobs[0].health=20;
    od.mobs[0].position=od.player.position;od.mobs[0].position.z+=1;tick(0.1f);check(od.health<20);
    reset();od.mobs[0].active=1;od.mobs[0].kind=OD_MOB_SKELETON;od.mobs[0].health=20;
    od.mobs[0].position=od.player.position;od.mobs[0].position.z+=5;tick(3);check(sounds[OD_SOUND_BOW]>0);check(od.health<20);
    reset();od.mobs[0].active=1;od.mobs[0].kind=OD_MOB_CREEPER;od.mobs[0].health=20;
    od.mobs[0].position=od.player.position;od.mobs[0].position.x+=1.5f;tick(2);check(!od.mobs[0].active&&sounds[OD_SOUND_EXPLODE]>0);
    reset();od.mobs[0].active=1;od.mobs[0].kind=OD_MOB_SHEEP;od.mobs[0].health=10;od.mobs[0].position=od.player.position;
    Od_DamageMob(0,2,od.player.position);check(dropped(35)==2&&od.mobs[0].sheared);
    tick(0.6f);Od_DamageMob(0,20,od.player.position);check(carried(35)+dropped(35)==2);
    reset();for(i=0;i<12;i++) {Od_SpawnDrop(264,1,0,od.player.position,0);tick(0.1f);}check(carried(264)==12&&dropped(264)==0);
}
static void test_sunlight_and_spiders(void) {
    int x,z,i;OdMob* m=&od.mobs[0];
    reset();move_player(5.5f,21,5.5f);
    m->active=1;m->kind=OD_MOB_ZOMBIE;m->health=20;m->position=(OdVec3){24.5f,21,11.5f};
    OdGame_SetWorldTime(0);tick(2.2f);check(m->health<20&&m->burn_time>0);
    reset();move_player(5.5f,21,5.5f);
    m->active=1;m->kind=OD_MOB_SKELETON;m->health=20;m->position=(OdVec3){24.5f,21,11.5f};
    for(x=21;x<=27;x++)for(z=8;z<=14;z++)set(x,24,z,1);
    OdGame_SetWorldTime(0);tick(2.2f);check(m->health==20&&m->burn_time==0);
    reset();move_player(5.5f,21,5.5f);
    m->active=1;m->kind=OD_MOB_ZOMBIE;m->health=20;m->position=(OdVec3){24.5f,21,11.5f};
    OdGame_SetWorldTime(450000);OdGame_Tick(0,&od.player);
    check(Od_Daylight()<0.11f);tick(2.2f);check(m->health==20&&m->burn_time==0);
    OdGame_SetWorldTime(900000);tick(1.2f);check(m->health<20&&m->burn_time>0);
    /* Collision tolerance allows feet a fraction below the floor surface.
     * Put water around its body, not in the supporting floor block. */
    set((int)floorf(m->position.x),(int)floorf(m->position.y+0.2f),(int)floorf(m->position.z),9);
    tick(0.05f);check(m->burn_time==0);
    reset();m->active=1;m->kind=OD_MOB_SPIDER;m->health=20;m->position=od.player.position;m->position.z+=1;
    OdGame_SetWorldTime(0);tick(1.2f);check(od.health==20&&m->anger_time==0);
    Od_DamageMob(0,1,od.player.position);check(m->anger_time>0);
    /* Reset its knockback to keep this a deterministic retaliation-range check. */
    m->position=od.player.position;m->position.z+=1;m->velocity=(OdVec3){0,0,0};m->hurt_time=0;
    tick(0.1f);check(od.health<20);
    reset();m->active=1;m->kind=OD_MOB_SPIDER;m->health=20;m->position=od.player.position;m->position.z+=1;
    OdGame_SetWorldTime(450000);tick(0.1f);check(od.health<20);
    reset();m->active=1;m->kind=OD_MOB_SPIDER;m->health=20;m->position=od.player.position;m->position.z+=1;
    for(x=21;x<=27;x++)for(z=8;z<=15;z++)set(x,24,z,1);
    OdGame_SetWorldTime(0);tick(0.1f);check(od.health<20);
    OdGame_GenerateWorld();check(block_count(56)==9);
    for(i=0;i<OD_MAX_MOBS;i++)if(od.mobs[i].active&&od.mobs[i].kind>=OD_MOB_ZOMBIE)check(od.mobs[i].position.x>=32);
    check(get(31,22,38)==1&&get(32,22,38)==0&&get(38,24,38)==1);
}
static void combat_target(void) {
    od.mobs[0].position=(OdVec3){24.5f,21,13.5f};
    od.mobs[0].velocity=(OdVec3){0,0,0};
    od.player.look=(OdVec3){0,-0.338719f,0.940887f};
}
static void test_melee_events_and_durability(void) {
    OdMob* mob=&od.mobs[0];
    reset();OdGame_SetWorldTime(450000);move_player(24.5f,21,11.5f);OdGame_SelectSlot(3);
    mob->active=1;mob->kind=OD_MOB_ZOMBIE;mob->health=20;combat_target();audio_count=0;
    check(OdGame_Attack()==1);check(mob->health==13&&od.carried.inventory[3].damage==1);
    check(audio_count==2&&audio_sequence[0]==OD_SOUND_SWING&&audio_sequence[1]==OD_SOUND_MOB_HURT);
    check(OdGame_Attack()==1);check(mob->health==13&&od.carried.inventory[3].damage==1&&audio_count==2);
    tick(0.40f);combat_target();check(OdGame_Attack()==1);
    check(mob->health==13&&od.carried.inventory[3].damage==1&&audio_count==2);
    tick(0.15f);combat_target();check(OdGame_Attack()==1);
    check(mob->health==6&&od.carried.inventory[3].damage==2);
    check(audio_count==4&&audio_sequence[2]==OD_SOUND_SWING&&audio_sequence[3]==OD_SOUND_MOB_HURT);
    /* A different source can leave a target invulnerable while our swing is
     * ready. That condition must not silently consume the held tool. */
    reset();OdGame_SetWorldTime(450000);move_player(24.5f,21,11.5f);OdGame_SelectSlot(3);
    mob->active=1;mob->kind=OD_MOB_ZOMBIE;mob->health=20;combat_target();
    check(Od_DamageMob(0,1,od.player.position)==1);audio_count=0;
    check(OdGame_Attack()==1);check(mob->health==19&&od.carried.inventory[3].damage==0&&audio_count==0);
    tick(0.50f);combat_target();check(OdGame_Attack()==1);
    check(mob->health==12&&od.carried.inventory[3].damage==1&&audio_count==2);
    tick(0.55f);combat_target();mob->position.z=19.5f;audio_count=0;
    check(OdGame_Attack()==0);check(mob->health==12&&od.carried.inventory[3].damage==1&&audio_count==0);
}
int main(void) {
    OdGameHooks hooks;memset(&hooks,0,sizeof(hooks));hooks.get_block=get;hooks.set_block=set;hooks.teleport=teleport;hooks.sound=sound;
    OdGame_Init(&hooks);test_start_world();test_nine_ore();test_transfers_and_craft();test_full_and_overflow();
    test_death_respawn();test_furnace_food_place();test_damage_and_combat();test_sunlight_and_spiders();test_melee_events_and_durability();
    printf("{\"suite\":\"game_conservation\",\"checks\":%d,\"status\":\"passed\",\"teleports\":%d}\n",checks,teleports);return 0;
}
