#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "../../challenge/src/trial/OdReward.h"
#include "../../challenge/src/trial/OdRewardBlob.h"
#include "../reward/fixture.h"
extern int OdReward_DecodePayload(int32_t, const uint8_t[16], const uint8_t[16],
                                  const uint8_t[24], char[17]);
int main(void) {
    char code[17];
    uint8_t cipher[16], tag[16], nonce[24];
    int i;
    assert(OdReward_Decode(10, code));
    assert(strcmp(code, OD_PRIVATE_CODE) == 0);
    assert(!OdReward_Decode(9, code) && code[0] == 0);
    assert(!OdReward_Decode(11, code) && code[0] == 0);
    assert(!OdReward_Decode(-1, code) && code[0] == 0);
    memcpy(cipher, od_reward_cipher, sizeof(cipher));
    memcpy(tag, od_reward_tag, sizeof(tag));
    memcpy(nonce, od_reward_nonce, sizeof(nonce));
    for (i=0; i<16; ++i) {
        cipher[i] ^= 1;
        assert(!OdReward_DecodePayload(10,cipher,tag,nonce,code) && code[0]==0);
        cipher[i] ^= 1;
        tag[i] ^= 1;
        assert(!OdReward_DecodePayload(10,cipher,tag,nonce,code) && code[0]==0);
        tag[i] ^= 1;
    }
    for (i=0; i<24; ++i) {
        nonce[i] ^= 1;
        assert(!OdReward_DecodePayload(10,cipher,tag,nonce,code) && code[0]==0);
        nonce[i] ^= 1;
    }
    puts("{\"trial_crypto\":\"passed\",\"cipher_tag_nonce_mutations_rejected\":56,\"wrong_counts_rejected\":3}");
    return 0;
}
