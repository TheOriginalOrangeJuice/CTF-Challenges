#include "OdAudioMixer.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

int main(void) {
    OdAudioMixer m; int16_t out[8]; int i;
    static const int16_t impactData[]={1000,1000,1000,1000,1000,1000};
    static const int16_t swingData[]={100,200,300};
    static const int16_t fullData[]={32767,-32768};
    const OdAudioClip impact={impactData,6},swing={swingData,3},full={fullData,2};
    OdAudioMixer_Init(&m);
    /* The actual former bug: same-call impact followed by swing erased impact. */
    assert(OdAudioMixer_Play(&m,&impact,OdAudioMixer_Priority(8),256));
    assert(OdAudioMixer_Play(&m,&swing,OdAudioMixer_Priority(7),256));
    OdAudioMixer_Render(&m,out,8);
    assert(out[0]==1100&&out[1]==1200&&out[2]==1300);
    assert(out[3]==1000&&out[4]==1000&&out[5]==1000&&out[6]==0&&out[7]==0);
    assert(OdAudioMixer_Active(&m)==0&&m.peak_voices==2);
    /* New digging/steps overlap and cannot stop the tail of a block break. */
    OdAudioMixer_Init(&m); assert(OdAudioMixer_Play(&m,&impact,OdAudioMixer_Priority(2),256));
    OdAudioMixer_Render(&m,out,2); assert(out[0]==1000&&out[1]==1000);
    assert(OdAudioMixer_Play(&m,&swing,OdAudioMixer_Priority(1),256));
    OdAudioMixer_Render(&m,out,4); assert(out[0]==1100&&out[1]==1200&&out[2]==1300&&out[3]==1000);
    /* Full voice pressure cannot replace any protected impact with a step. */
    OdAudioMixer_Init(&m);
    for(i=0;i<OD_AUDIO_VOICES;i++)assert(OdAudioMixer_Play(&m,&impact,3,16));
    assert(!OdAudioMixer_Play(&m,&swing,0,256)); assert(m.dropped==1);
    OdAudioMixer_Render(&m,out,1); assert(out[0]==992);
    /* More important damage may replace the oldest low-priority step. */
    OdAudioMixer_Init(&m);
    for(i=0;i<OD_AUDIO_VOICES;i++)assert(OdAudioMixer_Play(&m,&impact,0,16));
    assert(OdAudioMixer_Play(&m,&swing,4,256));
    assert(m.voices[0].clip==&swing&&m.voices[1].clip==&impact);
    /* Mute immediately discards every queued voice and never resumes old audio. */
    OdAudioMixer_Enable(&m,0); assert(OdAudioMixer_Active(&m)==0);
    assert(!OdAudioMixer_Play(&m,&impact,3,256));
    memset(out,1,sizeof out); OdAudioMixer_Render(&m,out,8);
    for(i=0;i<8;i++)assert(out[i]==0);
    OdAudioMixer_Enable(&m,1); OdAudioMixer_Render(&m,out,2); assert(out[0]==0&&out[1]==0);
    assert(OdAudioMixer_Play(&m,&swing,1,128)); OdAudioMixer_Render(&m,out,3);
    assert(out[0]==50&&out[1]==100&&out[2]==150);
    /* Saturation must clamp, never wrap from positive amplitude to negative. */
    OdAudioMixer_Init(&m);
    assert(OdAudioMixer_Play(&m,&full,3,256)&&OdAudioMixer_Play(&m,&full,3,256));
    OdAudioMixer_Render(&m,out,2); assert(out[0]==32767&&out[1]==-32768);
    puts("{\"pass\":true,\"scenarios\":[\"same-tick hit and swing\",\"break tail under repeated dig\",\"impact priority under voice pressure\",\"oldest lower-priority replacement\",\"mute clears pending voices\",\"unmute does not resume old effects\",\"gain\",\"saturating overlap\"]}");
    return 0;
}
