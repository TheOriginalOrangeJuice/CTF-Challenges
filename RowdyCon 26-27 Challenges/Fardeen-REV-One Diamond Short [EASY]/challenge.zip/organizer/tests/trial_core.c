#include <assert.h>
#include <limits.h>
#include <stddef.h>
#include <stdio.h>
#include <string.h>
#include "../../challenge/src/trial/OdTrial.h"

static OdCarried carried;
static OdTrial trial;
static void start(void) {
    memset(&carried, 0, sizeof(carried));
    OdTrial_Init(&trial);
    assert(trial.state == OD_TRIAL_MENU && trial.remaining_seconds == 900);
    assert(OdTrial_Start(&trial, 10000));
    assert(!OdTrial_Start(&trial, 10001));
}
static void diamonds(OdStack *stack, int count) {
    stack->item_id = 264; stack->count = count; stack->damage = 0;
}
int main(void) {
    int64_t total;
    int i;
    assert(sizeof(((OdStack*)0)->count) == 4);
    assert(offsetof(OdStack, count) % 4 == 0);
    start();
    diamonds(&carried.inventory[0], 10);
    assert(OdTrial_Tick(&trial, 10000, &carried) == OD_TRIAL_WON);
    assert(trial.winning_count == 10 && trial.elapsed_ms == 0);
    carried.inventory[0].count = 0;
    assert(OdTrial_Tick(&trial, 99999999, &carried) == OD_TRIAL_WON);
    start();
    diamonds(&carried.inventory[2], 9);
    assert(OdTrial_Tick(&trial, 909999, &carried) == OD_TRIAL_ACTIVE);
    assert(trial.remaining_seconds == 1);
    carried.inventory[2].count = 10;
    assert(OdTrial_Tick(&trial, 909999, &carried) == OD_TRIAL_WON);
    start();
    diamonds(&carried.inventory[0], 10);
    assert(OdTrial_Tick(&trial, 910000, &carried) == OD_TRIAL_EXPIRED);
    assert(trial.remaining_seconds == 0 && trial.winning_count == 0);
    assert(OdTrial_Tick(&trial, 10001, &carried) == OD_TRIAL_EXPIRED);
    start();
    assert(OdTrial_Tick(&trial, 910001, NULL) == OD_TRIAL_EXPIRED);
    start();
    assert(OdTrial_Tick(&trial, 10001, &carried) == OD_TRIAL_ACTIVE);
    assert(trial.remaining_seconds == 900);
    OdTrial_Tick(&trial, 11000, &carried);
    assert(trial.remaining_seconds == 899);
    OdTrial_Tick(&trial, 10000, &carried);
    assert(trial.remaining_seconds == 899);
    /* A single quiet interval (pause/focus loss/death) consumes the same clock. */
    assert(OdTrial_Tick(&trial, 910000, &carried) == OD_TRIAL_EXPIRED);
    start();
    diamonds(&carried.inventory[35], 3);
    diamonds(&carried.cursor, 2);
    diamonds(&carried.craft[8], 5);
    assert(OdTrial_CountDiamonds(&carried, &total) && total == 10);
    assert(OdTrial_Tick(&trial, 20000, &carried) == OD_TRIAL_WON);
    start();
    diamonds(&carried.cursor, 10);
    assert(OdTrial_Tick(&trial, 20000, &carried) == OD_TRIAL_WON);
    start();
    diamonds(&carried.craft[0], 10);
    assert(OdTrial_Tick(&trial, 20000, &carried) == OD_TRIAL_WON);
    start();
    diamonds(&carried.inventory[0], 11);
    assert(OdTrial_Tick(&trial, 20000, &carried) == OD_TRIAL_ACTIVE);
    diamonds(&carried.inventory[0], 10);
    carried.inventory[1].item_id = 4;
    carried.inventory[1].count = -1;
    assert(OdTrial_Tick(&trial, 20000, &carried) == OD_TRIAL_ACTIVE);
    assert(!trial.inventory_valid);
    carried.inventory[1].count = 65;
    assert(!OdTrial_CountDiamonds(&carried, &total));
    carried.inventory[1].count = INT_MAX;
    assert(!OdTrial_CountDiamonds(&carried, &total));
    carried.inventory[1].count = INT_MIN;
    assert(!OdTrial_CountDiamonds(&carried, &total));
    carried.inventory[1].count = 64;
    assert(OdTrial_CountDiamonds(&carried, &total) && total == 10);
    assert(!OdTrial_CountDiamonds(NULL, &total));
    assert(!OdTrial_CountDiamonds(&carried, NULL));
    start();
    for(i=0;i<36;++i) diamonds(&carried.inventory[i],64);
    for(i=0;i<9;++i) diamonds(&carried.craft[i],64);
    diamonds(&carried.cursor,64);
    assert(OdTrial_CountDiamonds(&carried,&total) && total == 46*64);
    puts("{\"trial_core\":\"passed\",\"boundary_ms\":[899999,900000,900001],\"actual_32_bit_counts\":true,\"prerequisite_mining\":false}");
    return 0;
}
