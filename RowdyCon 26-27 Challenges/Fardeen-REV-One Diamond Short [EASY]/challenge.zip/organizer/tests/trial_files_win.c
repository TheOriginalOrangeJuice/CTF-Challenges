#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include "../../challenge/src/trial/OdReward.h"
#include "../reward/fixture.h"

extern void OdReward_TestPath(const wchar_t *path);
static wchar_t readme[1024];
static OdTrial trial;
static OdReward reward;
static OdCarried carried;

static char *read_all(void) {
    FILE *file = _wfopen(readme, L"rb");
    long size;
    char *result;
    assert(file);
    assert(fseek(file,0,SEEK_END)==0); size=ftell(file); assert(size>=0);
    rewind(file); result=(char*)malloc((size_t)size+1); assert(result);
    assert(fread(result,1,(size_t)size,file)==(size_t)size);
    result[size]=0; assert(fclose(file)==0); return result;
}
static void fresh_win(void) {
    memset(&carried,0,sizeof(carried));
    OdTrial_Init(&trial); assert(OdTrial_Start(&trial,1000));
    carried.inventory[0].item_id=264; carried.inventory[0].count=10;
    assert(OdTrial_Tick(&trial,1001,&carried)==OD_TRIAL_WON);
}
static void fresh_expiry(void) {
    OdTrial_Init(&trial); assert(OdTrial_Start(&trial,1000));
    assert(OdTrial_Tick(&trial,901000,NULL)==OD_TRIAL_EXPIRED);
}

int main(void) {
    wchar_t temp[512], directory[768], missing[1024];
    char *contents, *before;
    HANDLE lock, oversized;
    LARGE_INTEGER position;
    DWORD wrote;
    assert(GetTempPathW(512,temp)>0);
    _snwprintf(directory,768,L"%lsOneDiamondShort-%lu-\x8a66\x9a13",temp,
               (unsigned long)GetCurrentProcessId());
    assert(CreateDirectoryW(directory,NULL));
    _snwprintf(readme,1024,L"%ls\\README.txt",directory);
    OdReward_TestPath(readme);
    OdReward_Init(&reward);
    assert(!reward.earned && reward.code[0]==0);
    contents=read_all();
    assert(strncmp(contents,"Collect 10 diamonds to win a copy of Minecraft!",45)==0);
    assert(!strstr(contents,OD_PRIVATE_FLAG)); free(contents);
    fresh_win(); OdReward_HandleTerminal(&reward,&trial);
    assert(reward.earned && reward.save_status==OD_SAVE_OK);
    assert(strcmp(reward.code,OD_PRIVATE_CODE)==0);
    before=read_all(); assert(strstr(before,OD_PRIVATE_FLAG));
    OdReward_Init(&reward);
    assert(!reward.earned && !reward.terminal_handled && reward.code[0]==0);
    OdTrial_Init(&trial); OdReward_HandleTerminal(&reward,&trial);
    assert(!reward.earned && reward.code[0]==0);
    fresh_expiry(); OdReward_HandleTerminal(&reward,&trial);
    assert(!reward.earned && reward.save_status==OD_SAVE_OK);
    contents=read_all(); assert(strncmp(contents,before,strlen(before))==0);
    assert(strstr(contents,"--- Demo time expired ---"));
    free(before); free(contents);

    /* Sharing violation keeps earned code visible and file untouched. */
    OdReward_Init(&reward); fresh_win(); before=read_all();
    lock=CreateFileW(readme,GENERIC_READ,0,NULL,OPEN_EXISTING,0,NULL);
    assert(lock!=INVALID_HANDLE_VALUE);
    OdReward_HandleTerminal(&reward,&trial);
    assert(reward.earned && reward.save_status==OD_SAVE_ERROR);
    assert(strcmp(reward.flag,OD_PRIVATE_FLAG)==0);
    assert(CloseHandle(lock));
    contents=read_all(); assert(strcmp(before,contents)==0); free(contents); free(before);
    assert(OdReward_RetrySave(&reward,&trial) && reward.save_status==OD_SAVE_OK);

    /* Read-only files are never silently cleared or claimed saved. */
    OdReward_Init(&reward); fresh_win();
    assert(SetFileAttributesW(readme,FILE_ATTRIBUTE_READONLY));
    OdReward_HandleTerminal(&reward,&trial);
    assert(reward.earned && reward.save_status==OD_SAVE_ERROR);
    assert(SetFileAttributesW(readme,FILE_ATTRIBUTE_NORMAL));
    assert(OdReward_RetrySave(&reward,&trial));

    /* Deletion between start and end recreates README beside the target path. */
    assert(DeleteFileW(readme));
    OdReward_Init(&reward); assert(DeleteFileW(readme)); fresh_expiry();
    OdReward_HandleTerminal(&reward,&trial);
    assert(reward.save_status==OD_SAVE_OK);
    contents=read_all(); assert(strstr(contents,"Collect 10 diamonds"));
    assert(strstr(contents,"Demo time expired")); free(contents);

    /* A huge unexpected file is preserved instead of truncated. */
    oversized=CreateFileW(readme,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,0,NULL);
    assert(oversized!=INVALID_HANDLE_VALUE);
    position.QuadPart=1024*1024;
    assert(SetFilePointerEx(oversized,position,NULL,FILE_BEGIN));
    assert(WriteFile(oversized,"x",1,&wrote,NULL) && wrote==1);
    assert(CloseHandle(oversized));
    OdReward_Init(&reward); fresh_win(); OdReward_HandleTerminal(&reward,&trial);
    assert(reward.earned && reward.save_status==OD_SAVE_ERROR);
    assert(reward.system_error==ERROR_FILE_TOO_LARGE);
    assert(DeleteFileW(readme));

    _snwprintf(missing,1024,L"%ls\\absent\\README.txt",directory);
    OdReward_TestPath(missing); OdReward_Init(&reward);
    assert(reward.save_status==OD_SAVE_ERROR);
    fresh_win(); OdReward_HandleTerminal(&reward,&trial);
    assert(reward.earned && reward.save_status==OD_SAVE_ERROR);
    assert(RemoveDirectoryW(directory));
    puts("{\"trial_files_win\":\"passed\",\"unicode_paths\":true,\"missing_recreated\":true,\"earned_text_preserved\":true,\"prior_text_authorizes_win\":false,\"locked_readonly_oversized_missing_directory\":\"honest_errors\",\"retry\":\"passed\"}");
    return 0;
}
