/* Native technical playback test; run with CWD containing release assets/.
 * Loopback is optional. It records the default render endpoint, not a microphone.
 * Do not run alongside other audible applications when comparing its levels. */
#define COBJMACROS
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <initguid.h>
#include <mmdeviceapi.h>
#include <audioclient.h>
#include <mmreg.h>
#include <stdio.h>
#include <math.h>
#include "OdAudio.h"
static IMMDeviceEnumerator* enumerator;
static IMMDevice* endpoint;
static IAudioClient* client;
static IAudioCaptureClient* capture;
static WAVEFORMATEX* format;
static HRESULT loopbackResult;
static double energy[4];
static unsigned long long samples[4];

static int beginLoopback(void) {
    HRESULT hr=CoInitializeEx(NULL,COINIT_MULTITHREADED);
    if(FAILED(hr)) { loopbackResult=hr; return 0; }
    hr=CoCreateInstance(&CLSID_MMDeviceEnumerator,NULL,CLSCTX_ALL,&IID_IMMDeviceEnumerator,(void**)&enumerator);
    if(FAILED(hr))goto failed;
    hr=IMMDeviceEnumerator_GetDefaultAudioEndpoint(enumerator,eRender,eConsole,&endpoint);
    if(FAILED(hr))goto failed;
    hr=IMMDevice_Activate(endpoint,&IID_IAudioClient,CLSCTX_ALL,NULL,(void**)&client);
    if(FAILED(hr))goto failed;
    hr=IAudioClient_GetMixFormat(client,&format); if(FAILED(hr))goto failed;
    hr=IAudioClient_Initialize(client,AUDCLNT_SHAREMODE_SHARED,AUDCLNT_STREAMFLAGS_LOOPBACK,1000000,0,format,NULL);
    if(FAILED(hr))goto failed;
    hr=IAudioClient_GetService(client,&IID_IAudioCaptureClient,(void**)&capture); if(FAILED(hr))goto failed;
    hr=IAudioClient_Start(client); if(FAILED(hr))goto failed;
    loopbackResult=S_OK; return 1;
failed:
    loopbackResult=hr; return 0;
}
static void readLoopback(unsigned elapsed) {
    UINT32 count=0;
    /* Exclude transition packets already queued by the system audio engine. */
    int zone=elapsed<500?0:(elapsed>=1000&&elapsed<1750?1:
             (elapsed>=2300&&elapsed<3000?2:(elapsed>=3500&&elapsed<4000?3:-1)));
    int isFloat=format&&format->wFormatTag==WAVE_FORMAT_IEEE_FLOAT;
    if(format&&format->wFormatTag==WAVE_FORMAT_EXTENSIBLE)
        isFloat=((WAVEFORMATEXTENSIBLE*)format)->SubFormat.Data1==WAVE_FORMAT_IEEE_FLOAT;
    if(!capture)return;
    while(SUCCEEDED(IAudioCaptureClient_GetNextPacketSize(capture,&count))&&count) {
        BYTE* data; DWORD flags; UINT32 frames,i,total;
        if(FAILED(IAudioCaptureClient_GetBuffer(capture,&data,&frames,&flags,NULL,NULL)))break;
        total=frames*format->nChannels;
        for(i=0;i<total;i++) {
            double value=0;
            if(!(flags&AUDCLNT_BUFFERFLAGS_SILENT)) {
                if(isFloat&&format->wBitsPerSample==32)value=((float*)data)[i];
                else if(format->wBitsPerSample==16)value=((short*)data)[i]/32768.0;
                else if(format->wBitsPerSample==32)value=((int*)data)[i]/2147483648.0;
            }
            if(zone>=0) { energy[zone]+=value*value; samples[zone]++; }
        }
        IAudioCaptureClient_ReleaseBuffer(capture,frames);
    }
}
static void endLoopback(void) {
    if(client)IAudioClient_Stop(client);
    if(capture)IAudioCaptureClient_Release(capture);
    if(client)IAudioClient_Release(client);
    if(endpoint)IMMDevice_Release(endpoint);
    if(enumerator)IMMDeviceEnumerator_Release(enumerator);
    if(format)CoTaskMemFree(format);
    CoUninitialize();
}
int main(void) {
    OdAudioStats before,after,muted; DWORD start,elapsed,next=700;
    double rms[4]; int i,loopbackOK;
    int loopback=beginLoopback(),mute=0,resume=0,ok;
    if(!OdAudio_Init()) {
        OdAudio_GetStats(&after);
        printf("{\"pass\":false,\"device_error\":%u,\"loaded\":%u}\n",after.device_result,after.loaded_clips);
        endLoopback(); return 1;
    }
    OdAudio_GetStats(&before); start=GetTickCount();
    do {
        elapsed=GetTickCount()-start;
        if(elapsed>=next&&elapsed<1950) {
            OdAudio_Play(8); OdAudio_Play(7); OdAudio_Play(2); OdAudio_Play(1); OdAudio_Play(0); next+=300;
        }
        if(elapsed>=2000&&!mute) { OdAudio_SetEnabled(0); OdAudio_GetStats(&muted); mute=1; }
        if(elapsed>=3200&&!resume) { OdAudio_SetEnabled(1); OdAudio_Play(8); OdAudio_Play(2); resume=1; }
        if(loopback)readLoopback(elapsed);
        Sleep(5);
    }while(elapsed<4600);
    OdAudio_GetStats(&after);
    for(i=0;i<4;i++)rms[i]=samples[i]?sqrt(energy[i]/samples[i]):0;
    loopbackOK=!loopback||(samples[0]&&samples[1]&&samples[2]&&samples[3]&&rms[1]>.001&&rms[3]>.001&&rms[2]<.0005);
    ok=after.loaded_clips==14&&!after.device_result&&after.completed_buffers>before.completed_buffers+50&&
       after.accepted>=22&&after.peak_voices>=5&&after.nonzero_samples>1000&&muted.active_voices==0&&loopbackOK;
    printf("{\"pass\":%s,\"device_error\":%u,\"loaded\":%u,\"submitted_buffers\":%u,\"completed_buffers\":%u,\"accepted\":%u,\"dropped\":%u,\"peak_voices\":%u,\"nonzero_samples\":%llu,\"mute_active_voices\":%u,\"loopback_available\":%s,\"loopback_hresult\":%ld,\"loopback_levels_pass\":%s,\"loopback_rms\":[%.9f,%.9f,%.9f,%.9f]}\n",
      ok?"true":"false",after.device_result,after.loaded_clips,after.submitted_buffers,after.completed_buffers,after.accepted,after.dropped,after.peak_voices,(unsigned long long)after.nonzero_samples,muted.active_voices,loopback?"true":"false",(long)loopbackResult,
      loopbackOK?"true":"false",rms[0],rms[1],rms[2],rms[3]);
    OdAudio_Free(); endLoopback(); return ok?0:1;
}
