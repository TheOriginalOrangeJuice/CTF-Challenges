"""Create the public offline bundle from an explicit allowlist, in Condev."""
from pathlib import Path
import hashlib, json, shutil, zipfile
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'challenge'
DEST = ROOT / 'artifacts' / 'OneDiamondShort'
DEST.mkdir(parents=True, exist_ok=True)
payload = {'OneDiamondShort.exe': SOURCE / 'build/OneDiamondShort.exe',
           'texpacks/default.zip': SOURCE / 'assets/default.zip',
           'licenses/ATTRIBUTION.md': SOURCE / 'assets/ATTRIBUTION.md'}
for name in ['default.png', 'items.png', 'terrain.png']:
    payload['assets/' + name] = SOURCE / 'assets' / name
for path in sorted((SOURCE / 'assets/sounds').glob('*.wav')):
    payload['assets/sounds/' + path.name] = path
for path in sorted((SOURCE / 'assets/licenses').rglob('*')):
    if path.is_file():
        payload['licenses/assets/' + path.relative_to(SOURCE / 'assets/licenses').as_posix()] = path
for label, name in [('ClassiCube', 'classicube/license.txt'), ('Monocypher', 'monocypher/LICENCE.md')]:
    payload['licenses/' + label + '.txt'] = SOURCE / 'vendor' / name
payload['licenses/TrueCraft.txt'] = ROOT / 'organizer/upstream/truecraft/LICENSE'
for name, path in payload.items():
    target = DEST / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(path, target)
readme = ('Collect 10 diamonds to win a copy of Minecraft!\r\n\r\n'
          'One Diamond Short - Demo\r\n'
          'You have 15 minutes. The demo clock keeps running while paused.\r\n\r\n'
          'W A S D: Move   Space: Jump   Mouse: Look\r\n'
          'Left mouse: Mine / attack   Right mouse: Place / use\r\n'
          '1-9 / mouse wheel: Select hotbar slot   E: Inventory\r\n'
          'Q: Drop one item   Escape: Pause / close inventory   F11: Fullscreen\r\n'
          'Inventory: left click stacks; right click splits or places one; Shift+click transfers.\r\n\r\n'
          'This is a CTF recreation. The purchase code is a challenge reward.\r\n'
          'Open source credits and asset licenses are in the licenses folder.\r\n')
(DEST / 'README.txt').write_bytes(readme.encode('ascii'))
expected = set(payload) | {'README.txt'}
actual = {p.relative_to(DEST).as_posix() for p in DEST.rglob('*') if p.is_file()}
if actual != expected:
    raise SystemExit(f'Unexpected stale public files: {sorted(actual - expected)}')
manifest = {}
for name in sorted(expected):
    data = (DEST / name).read_bytes()
    manifest[name] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
archive = ROOT / 'artifacts/OneDiamondShort.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name in sorted(expected):
        info = zipfile.ZipInfo('OneDiamondShort/' + name, (2010, 9, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        bundle.writestr(info, (DEST / name).read_bytes())
report = {'public_files': manifest, 'zip_sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(ROOT / 'organizer/public-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'files': len(manifest), 'zip_sha256': report['zip_sha256']}))
