#ifndef OD_PRIVATE_FIXTURE_H
#define OD_PRIVATE_FIXTURE_H
/* Organizer-only frozen fixture. Never copy this header or generator into the
 * player package. Not a real redeemable commercial license. */
#define OD_PRIVATE_CODE "M7N3C4F8Q2D6R9K5"
#define OD_PRIVATE_FLAG "RCC{" OD_PRIVATE_CODE "}"
#endif
