#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "fixture.h"
#include "../../challenge/src/trial/OdKeyMaterial.h"

static void emit(const char *name, const uint8_t *bytes, size_t count) {
    size_t i;
    printf("static const uint8_t %s[%u] = {", name, (unsigned)count);
    for (i=0; i<count; ++i) printf("%s0x%02x", i ? "," : "", bytes[i]);
    puts("};");
}

int main(void) {
    uint8_t key[32], cipher[16], tag[16];
    /* Fixed fixture and one fixed payload/key pair, hence reproducible output.
     * This nonce is never used for a second message under this key. */
    const uint8_t nonce[24] = {0x28,0x61,0xa7,0x10,0x8b,0x4d,0x92,0xec,
        0xf0,0x55,0x39,0x16,0xcd,0x73,0xb8,0x04,0x5f,0xaa,0xd1,0x62,0x07,0xe9,0x34,0x8c};
    if (strlen(OD_PRIVATE_CODE) != 16) return 1;
    OdReward_DeriveKey(key, 10);
    crypto_aead_lock(cipher, tag, key, nonce, od_reward_ad,
                     sizeof(od_reward_ad)-1, (const uint8_t*)OD_PRIVATE_CODE, 16);
    puts("/* Deterministically generated; organizer/reward/generate_reward.c. */");
    puts("#ifndef OD_REWARD_BLOB_H\n#define OD_REWARD_BLOB_H\n#include <stdint.h>");
    emit("od_reward_cipher", cipher, 16);
    emit("od_reward_tag", tag, 16);
    emit("od_reward_nonce", nonce, 24);
    puts("#endif");
    crypto_wipe(key, sizeof(key));
    return ferror(stdout) ? 1 : 0;
}
