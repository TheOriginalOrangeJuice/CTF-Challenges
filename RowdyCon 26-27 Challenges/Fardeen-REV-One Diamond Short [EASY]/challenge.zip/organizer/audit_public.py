"""Audit the exact player archive. Run in the verified Condev source copy."""
import hashlib
import io
import json
import struct
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CODE = "M7N3C4F8Q2D6R9K5"
FLAG = "RCC{" + CODE + "}"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def inspect_bytes(name, data):
    for value in (CODE, FLAG):
        for encoding in ("utf-8", "utf-16-le", "utf-16-be"):
            assert value.encode(encoding) not in data, (name, encoding, "plaintext reward")
    if name.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(data)) as nested:
            for child in nested.namelist():
                inspect_bytes(name + "!" + child, nested.read(child))


def main():
    archive = ROOT / "artifacts/OneDiamondShort.zip"
    manifest = json.loads((ROOT / "organizer/public-manifest.json").read_text())
    assert sha(archive.read_bytes()) == manifest["zip_sha256"]
    with zipfile.ZipFile(archive) as bundle:
        names = bundle.namelist()
        assert len(names) == len(set(names)), "duplicate ZIP members"
        expected = {"OneDiamondShort/" + name for name in manifest["public_files"]}
        assert set(names) == expected
        for name, metadata in manifest["public_files"].items():
            assert ".." not in Path(name).parts and not name.startswith("/")
            assert not any(part in {"organizer", "src", "tests", "vendor", ".git"} for part in Path(name).parts)
            assert Path(name).suffix.lower() not in {".pdb", ".c", ".h", ".py", ".ps1", ".obj", ".map"}
            data = bundle.read("OneDiamondShort/" + name)
            assert len(data) == metadata["bytes"] and sha(data) == metadata["sha256"]
            assert data == (ROOT / "artifacts/OneDiamondShort" / name).read_bytes()
            inspect_bytes(name, data)
        exe = bundle.read("OneDiamondShort/OneDiamondShort.exe")
        readme = bundle.read("OneDiamondShort/README.txt")
    assert b"Collect 10 diamonds" in readme and b"RCC{" not in readme
    assert exe[:2] == b"MZ"
    offset = struct.unpack_from("<I", exe, 0x3c)[0]
    assert exe[offset:offset + 4] == b"PE\0\0"
    machine, sections, timestamp, symbols_at, symbols, optional_bytes, _ = struct.unpack_from("<HHIIIHH", exe, offset + 4)
    assert machine == 0x8664 and timestamp == 0 and symbols_at == 0 and symbols == 0
    optional = offset + 24
    assert struct.unpack_from("<H", exe, optional)[0] == 0x20b
    debug_address, debug_size = struct.unpack_from("<II", exe, optional + 112 + 6 * 8)
    assert debug_address == 0 and debug_size == 0
    section_names = [exe[optional + optional_bytes + i * 40:optional + optional_bytes + i * 40 + 8].rstrip(b"\0").decode("ascii") for i in range(sections)]
    assert not any(name.startswith(".debug") or name == ".symtab" for name in section_names)
    report = {
        "result": "passed", "public_files": len(names), "zip_sha256": sha(archive.read_bytes()),
        "exe_sha256": sha(exe), "exact_allowlist_and_file_hashes": True,
        "plaintext_code_and_flag_absent_utf8_utf16_including_nested_archives": True,
        "organizer_source_debug_files_absent": True, "initial_readme_has_no_reward": True,
        "pe": {"architecture": "x86_64", "timestamp": timestamp, "coff_symbols": symbols,
               "debug_directory_bytes": debug_size, "sections": section_names},
        "limits": "Authenticated encrypted reward and stripped native symbols deter straightforward strings extraction. Offline static reversing and runtime extraction remain possible and permitted."
    }
    (ROOT / "organizer/tests/public-package-audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
