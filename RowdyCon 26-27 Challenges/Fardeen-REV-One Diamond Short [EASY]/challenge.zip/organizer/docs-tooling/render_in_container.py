"""Offline Word/PDF renderer for the shared documentation tool."""
from pathlib import Path
import subprocess
import sys

source = Path(sys.argv[1]).resolve()
destination = Path(sys.argv[2]).resolve()
destination.mkdir(parents=True, exist_ok=True)
subprocess.run(["libreoffice", "--headless", "-env:UserInstallation=file:///tmp/lo-profile", "--convert-to", "pdf", "--outdir", str(destination), str(source)], check=True, timeout=180)
pdf = destination / (source.stem + ".pdf")
if not pdf.is_file():
    raise RuntimeError("No rendered PDF")
subprocess.run(["pdftotext", "-layout", str(pdf), str(destination / "rendered.txt")], check=True)
subprocess.run(["pdftoppm", "-scale-to", "1500", "-png", str(pdf), str(destination / "page")], check=True)
