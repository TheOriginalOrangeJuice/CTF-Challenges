"""Small layout pass after the unmodified shared five-section DOCX builder.

Keep the template's columns, margins, Aptos 12 text, and five rows. Condense
only the long left label, and keep short code samples on a single page.
Run inside Condev using the pinned document Python environment.
"""
from pathlib import Path
import sys
from docx import Document
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches

path = Path(sys.argv[1]).resolve()
doc = Document(path)
assert len(doc.tables) == 1 and len(doc.tables[0].rows) == 5
table = doc.tables[0]
for shape in doc.inline_shapes:
    limit = Inches(4.8)
    if shape.width > limit:
        shape.height = int(shape.height * limit / shape.width)
        shape.width = limit
label = table.cell(3, 0).paragraphs[0]
assert label.text == "Walkthrough"
for run in label.runs:
    properties = run._r.get_or_add_rPr()
    for old in list(properties):
        if old.tag == qn("w:w"):
            properties.remove(old)
    scale = OxmlElement("w:w")
    scale.set(qn("w:val"), "90")
    properties.append(scale)

groups = 0
for row in table.rows:
    for cell in row.cells:
        for index, paragraph in enumerate(cell.paragraphs[:-1]):
            following = cell.paragraphs[index + 1]
            if paragraph._p.xpath('.//w:drawing') and following.text and all(run.italic for run in following.runs if run.text):
                paragraph.paragraph_format.keep_with_next = True
        block = []
        previous = None
        introduction = None
        for paragraph in list(cell.paragraphs) + [None]:
            properties = paragraph._p.pPr if paragraph is not None else None
            shading = properties.find(qn("w:shd")) if properties is not None else None
            is_code = shading is not None and shading.get(qn("w:fill")) == "F2F2F2"
            if is_code:
                if not block:
                    introduction = previous
                block.append(paragraph)
                continue
            if 1 <= len(block) <= 12:
                if introduction is not None:
                    introduction.paragraph_format.keep_with_next = True
                for index, line in enumerate(block):
                    line.paragraph_format.keep_together = True
                    line.paragraph_format.keep_with_next = index + 1 < len(block)
                groups += 1
            block = []
            previous = paragraph
doc.save(path)
print(f"Layout: one label condensed to 90%; {groups} short code blocks kept together.")
