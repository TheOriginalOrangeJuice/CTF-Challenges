"""Build and audit the conceptual solve documents only; never run the solver."""
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

from docx import Document
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from build_description import build, parse_sections, MD

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
REVIEW = ROOT / "organizer/document-review"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compact(text):
    return re.sub(r"\s+", "", text)


def main():
    source = ROOT / "Description.md"
    output = ROOT / "Description.docx"
    report = build(source, HERE / "template.docx", output)
    subprocess.run([sys.executable, str(HERE / "fix_layout.py"), str(output)], check=True)
    REVIEW.mkdir(parents=True, exist_ok=True)
    for pattern in ("page-*.png", "contact-*.png", "rendered.txt", "document-check.json", "Description.pdf"):
        for old in REVIEW.glob(pattern):
            if old.is_file():
                old.unlink()
    subprocess.run([sys.executable, str(HERE / "render_in_container.py"), str(output), str(REVIEW)], check=True)

    text = source.read_text(encoding="utf-8-sig")
    _, _, sections = parse_sections(source)
    assert len(re.findall(r"^\d+\. ", sections["Hint(s)"], re.M)) == 3
    assert len(re.findall(r"^\d+\. ", sections["Walkthrough"], re.M)) == 6
    excluded = ["```", "solve_memory.ps1", "TargetPid", "MainModule", "ReadProcessMemory", "WriteProcessMemory", "-Mode Patch", "four-byte", "0x"]
    assert all(value.lower() not in sections["Walkthrough"].lower() for value in excluded)
    assert "earlier build" in sections["Walkthrough"]
    assert report["flag"] not in sections["Description"]
    doc = Document(output)
    assert len(doc.tables) == 1 and len(doc.tables[0].rows) == 5
    table = doc.tables[0]
    assert [row.cells[0].text for row in table.rows] == report["sections"]
    paragraphs_checked = 0
    for row, name in zip(table.rows, report["sections"]):
        actual = compact("".join(row.cells[1]._tc.xpath(".//w:t/text()")))
        for token in MD.parse(sections[name]):
            if token.type != "inline":
                continue
            expected = compact("".join(child.content for child in token.children or [] if child.type in ("text", "code_inline")))
            if expected:
                assert expected in actual, (name, expected[:80])
                paragraphs_checked += 1
    source_hashes = {sha(ROOT / name) for name in report["images"]}
    embedded_hashes = {hashlib.sha256(rel.target_part.blob).hexdigest() for rel in doc.part.rels.values() if rel.reltype == RT.IMAGE}
    assert source_hashes == embedded_hashes
    image_evidence = []
    for name in report["images"]:
        path = ROOT / name
        metadata = json.loads(path.with_suffix(".json").read_text(encoding="utf-8-sig"))
        assert metadata["image_sha256"] == sha(path)
        image_evidence.append({"path": name, "sha256": sha(path), "captured_utc": metadata["captured_utc"],
                               "executable_sha256": metadata.get("exe_sha256", metadata.get("executable_sha256"))})
    rendered = (REVIEW / "rendered.txt").read_text()
    assert compact(report["flag"]) in compact(rendered)
    pages = sorted(REVIEW.glob("page-*.png"))
    assert pages
    report.update({
        "result": "passed", "scope": "Documentation structure, content parity, links, image provenance, and rendering only",
        "pages": len(pages), "matching_content_paragraphs": paragraphs_checked,
        "markdown_sha256": sha(source), "docx_sha256": sha(output), "pdf_sha256": sha(REVIEW / "Description.pdf"),
        "images_match_actual_captures": True, "image_evidence": image_evidence,
        "conceptual_walkthrough_without_memory_operation_specifics": True,
        "blocked_validation_retried": False, "final_release_solve_revalidated": False,
        "earlier_reward_capture_labeled": True, "visual_page_inspection": "pending"
    })
    (REVIEW / "document-check.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
