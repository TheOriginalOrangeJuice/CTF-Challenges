"""Build the five-section submission document from Markdown and the supplied template."""
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path
from urllib.parse import unquote, urlsplit

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from markdown_it import MarkdownIt
from PIL import Image, ImageDraw

SECTIONS = ["Description", "Files", "Hint(s)", "Walkthrough", "Flag"]
MD = MarkdownIt("commonmark").enable("table")


def paragraph_settings(p, *, code=False):
    pf = p.paragraph_format
    pf.space_before = Pt(0)
    pf.space_after = Pt(5 if not code else 0)
    pf.line_spacing = 1.05
    pf.keep_together = not code
    pf.keep_with_next = False
    pf.widow_control = True


def format_run(run, *, code=False, bold=False, italic=False):
    run.font.name = "Consolas" if code else "Aptos"
    run.font.size = Pt(8.5 if code else 12)
    run.bold = bold
    run.italic = italic


def resolve_local(base, target):
    if urlsplit(target).scheme or target.startswith("#"):
        return None
    return (base / unquote(target.split("#", 1)[0])).resolve()


class Writer:
    def __init__(self, doc, base):
        self.doc = doc
        self.base = base
        self.images = []
        self.links = []

    def inline(self, p, children):
        bold = italic = False
        hyperlink = None
        for token in children or []:
            if token.type == "strong_open":
                bold = True
            elif token.type == "strong_close":
                bold = False
            elif token.type == "em_open":
                italic = True
            elif token.type == "em_close":
                italic = False
            elif token.type == "link_open":
                href = token.attrGet("href")
                local = resolve_local(self.base, href)
                if local is not None:
                    if not local.exists():
                        raise FileNotFoundError(f"Broken document link: {href}")
                    self.links.append(href)
                hyperlink = OxmlElement("w:hyperlink")
                hyperlink.set(qn("r:id"), p.part.relate_to(href, RT.HYPERLINK, is_external=True))
                p._p.append(hyperlink)
            elif token.type == "link_close":
                hyperlink = None
            elif token.type in ("text", "code_inline", "softbreak", "hardbreak"):
                text = "\n" if token.type in ("softbreak", "hardbreak") else token.content
                run = p.add_run(text)
                format_run(run, code=token.type == "code_inline", bold=bold, italic=italic)
                if hyperlink is not None:
                    run.font.color.rgb = RGBColor.from_string("165A9C")
                    run.underline = True
                    hyperlink.append(run._r)
            elif token.type == "image":
                target = token.attrGet("src")
                image_path = resolve_local(self.base, target)
                if image_path is None or not image_path.is_file():
                    raise FileNotFoundError(f"Missing screenshot: {target}")
                with Image.open(image_path) as im:
                    width, height = im.size
                scale = min(5.12 / width, 3.55 / height)
                run = p.add_run()
                shape = run.add_picture(str(image_path), width=Inches(width * scale), height=Inches(height * scale))
                shape._inline.docPr.set("descr", token.content)
                self.images.append(target)

    def blocks(self, cell, tokens):
        # Use the cell's mandatory first paragraph rather than leaving a blank line.
        first = True
        current = None
        list_stack = []
        prefix = None
        i = 0
        while i < len(tokens):
            token = tokens[i]
            if token.type in ("ordered_list_open", "bullet_list_open"):
                list_stack.append({"ordered": token.type == "ordered_list_open", "next": int(token.attrGet("start") or 1)})
            elif token.type in ("ordered_list_close", "bullet_list_close"):
                list_stack.pop()
            elif token.type == "list_item_open":
                state = list_stack[-1]
                prefix = f"{state['next']}. " if state["ordered"] else "• "
                state["next"] += 1
            elif token.type == "list_item_close":
                prefix = None
            elif token.type in ("paragraph_open", "heading_open"):
                current = cell.paragraphs[0] if first else cell.add_paragraph()
                first = False
                paragraph_settings(current)
                if prefix is not None:
                    format_run(current.add_run(prefix), bold=False)
                    prefix = None
                if token.type == "heading_open":
                    current.paragraph_format.keep_with_next = True
            elif token.type == "inline":
                if current is None:
                    current = cell.paragraphs[0] if first else cell.add_paragraph()
                    first = False
                    paragraph_settings(current)
                self.inline(current, token.children)
            elif token.type in ("paragraph_close", "heading_close"):
                current = None
            elif token.type in ("fence", "code_block"):
                # One paragraph per source line allows long scripts to break across pages.
                for line in token.content.rstrip("\n").split("\n"):
                    p = cell.paragraphs[0] if first else cell.add_paragraph()
                    first = False
                    paragraph_settings(p, code=True)
                    p.paragraph_format.widow_control = False
                    format_run(p.add_run(line or " "), code=True)
                    shading = OxmlElement("w:shd")
                    shading.set(qn("w:fill"), "F2F2F2")
                    p._p.get_or_add_pPr().append(shading)
                p.paragraph_format.space_after = Pt(7)
                current = None
            elif token.type == "table_open":
                rows = []
                row = None
                while i < len(tokens) and tokens[i].type != "table_close":
                    nested = tokens[i]
                    if nested.type == "tr_open":
                        row = []
                    elif nested.type == "inline":
                        row.append(nested.children)
                    elif nested.type == "tr_close":
                        rows.append(row)
                    i += 1
                if rows:
                    table = cell.add_table(rows=len(rows), cols=max(map(len, rows)))
                    table.style = "Table Grid"
                    table.autofit = False
                    for row_index, values in enumerate(rows):
                        for col_index, children in enumerate(values):
                            p = table.cell(row_index, col_index).paragraphs[0]
                            paragraph_settings(p)
                            self.inline(p, children)
                            for run in p.runs:
                                run.font.size = Pt(9)
                                if row_index == 0:
                                    run.bold = True
                    current = None
                    first = False
            elif token.type in ("html_block", "html_inline"):
                raise ValueError("Raw HTML is not supported in submission documents")
            i += 1


def parse_sections(path):
    text = path.read_text(encoding="utf-8-sig")
    matches = list(re.finditer(r"^## (.+?)\s*$", text, re.M))
    if [m.group(1) for m in matches] != SECTIONS:
        raise ValueError(f"Expected exactly these headings: {SECTIONS}")
    title = re.search(r"^# (.+)$", text, re.M)
    if not title:
        raise ValueError("Document needs a challenge title")
    intro = text[title.end():matches[0].start()].strip()
    sections = {}
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        sections[match.group(1)] = text[match.end():end].strip()
    if not re.fullmatch(r"`?RCC\{[^{}\r\n]+\}`?", sections["Flag"]):
        raise ValueError("Flag section must contain exactly the RCC flag")
    return title.group(1), intro, sections


def build(markdown, template, output):
    title, intro, sections = parse_sections(markdown)
    doc = Document(template)
    if len(doc.tables) != 1 or len(doc.tables[0].rows) != 5:
        raise ValueError("Expected supplied five-row template")
    table = doc.tables[0]
    for child in list(doc._element.body):
        if child is not table._tbl and child.tag != qn("w:sectPr"):
            doc._element.body.remove(child)
    for key, relationship in list(doc.part.rels.items()):
        if relationship.reltype in (RT.IMAGE, RT.HYPERLINK):
            doc.part.drop_rel(key)
    for section in doc.sections:
        section.page_width, section.page_height = Inches(8.5), Inches(11)
        section.top_margin = section.bottom_margin = section.left_margin = section.right_margin = Inches(1)
    normal = doc.styles["Normal"]
    normal.font.name = "Aptos"
    normal.font.size = Pt(12)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    table.columns[0].width = Inches(1.177)
    table.columns[1].width = Inches(5.3125)
    writer = Writer(doc, markdown.parent)
    for index, name in enumerate(SECTIONS):
        row = table.rows[index]
        # Rows, especially Walkthrough, must be allowed to continue across pages.
        trpr = row._tr.get_or_add_trPr()
        for element in list(trpr):
            if element.tag in (qn("w:cantSplit"), qn("w:trHeight")):
                trpr.remove(element)
        for cell in row.cells:
            cell._tc.clear_content()
            cell.add_paragraph()
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.TOP
        row.cells[0].width, row.cells[1].width = Inches(1.177), Inches(5.3125)
        label = row.cells[0].paragraphs[0]
        paragraph_settings(label)
        format_run(label.add_run(name), bold=False)
        writer.blocks(row.cells[1], MD.parse(sections[name]))
    heading = doc.add_paragraph()
    paragraph_settings(heading)
    heading.paragraph_format.keep_with_next = True
    title_run = heading.add_run(title)
    format_run(title_run, bold=True)
    title_run.font.size = Pt(14)
    table._tbl.addprevious(heading._p)
    if intro:
        meta = doc.add_paragraph()
        paragraph_settings(meta)
        meta.paragraph_format.keep_with_next = True
        writer.inline(meta, MD.parseInline(intro)[0].children)
        table._tbl.addprevious(meta._p)
    doc.core_properties.title = title
    doc.core_properties.subject = "RowdyCon challenge submission"
    doc.core_properties.author = "RowdyCon"
    doc.core_properties.comments = ""
    doc.core_properties.keywords = ""
    doc.save(output)
    if not writer.images:
        raise ValueError("Walkthrough needs actual screenshots")
    return {"title": title, "sections": SECTIONS, "images": writer.images, "local_links": writer.links, "flag": sections["Flag"].strip("`"), "docx": str(output)}


def render(docx, destination):
    destination.mkdir(parents=True, exist_ok=True)
    # Remove only previous render products so shorter revisions cannot retain old pages.
    for pattern in ("page-*.png", "contact-*.png", "rendered.txt", "document-check.json", docx.stem + ".pdf"):
        for old in destination.glob(pattern):
            if old.is_file():
                old.unlink()
    # Rocky Linux 10 does not package Writer; use a separate local render image.
    name = "rowdy-doc-render-" + uuid.uuid4().hex[:12]
    try:
        subprocess.run(["docker", "create", "--name", name, "--network", "none", "--cap-drop", "ALL", "--security-opt", "no-new-privileges:true", "rowdy-doc-renderer:20261025", "/work/" + docx.name, "/work/render"], check=True, capture_output=True)
        subprocess.run(["docker", "cp", str(docx), name + ":/work/" + docx.name], check=True, capture_output=True)
        subprocess.run(["docker", "start", "-a", name], check=True, capture_output=True, text=True, timeout=240)
        subprocess.run(["docker", "cp", name + ":/work/render/.", str(destination)], check=True, capture_output=True)
    finally:
        subprocess.run(["docker", "rm", "-f", name], capture_output=True)
    pages = sorted(destination.glob("page-*.png"))
    thumbs = []
    for page in pages:
        with Image.open(page) as im:
            im.thumbnail((510, 660))
            tile = Image.new("RGB", (530, 700), "#dddddd")
            tile.paste(im, ((530 - im.width) // 2, 25))
            ImageDraw.Draw(tile).text((12, 5), page.name, fill="black")
            thumbs.append(tile)
    for group in range(0, len(thumbs), 4):
        batch = thumbs[group:group + 4]
        sheet = Image.new("RGB", (1060, 700 * ((len(batch) + 1) // 2)), "#aaaaaa")
        for offset, tile in enumerate(batch):
            sheet.paste(tile, ((offset % 2) * 530, (offset // 2) * 700))
        sheet.save(destination / f"contact-{group // 4 + 1}.png")
    return len(pages)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("markdown", type=Path)
    parser.add_argument("--template", type=Path, default=Path(__file__).with_name("template.docx"))
    parser.add_argument("--output", type=Path)
    parser.add_argument("--render-dir", type=Path)
    args = parser.parse_args()
    source = args.markdown.resolve()
    output = (args.output or source.with_suffix(".docx")).resolve()
    report = build(source, args.template.resolve(), output)
    if args.render_dir:
        report["pages"] = render(output, args.render_dir.resolve())
        rendered = (args.render_dir / "rendered.txt").read_text()
        if report["flag"] not in re.sub(r"\s+", "", rendered):
            raise ValueError("Rendered PDF is missing the exact flag")
        (args.render_dir / "document-check.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
