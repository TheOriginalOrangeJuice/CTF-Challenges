# K-ON! — Before Departure

The night before March 16th, 2011, I dreamed about me and the gang going to some store a shopping for some souvenirs. The next day, I watched the gang ACTUALLY go to the store, I unfortunetly could not be there. Now that I have adult money, I want to go to this store they went to and relive my dream. Can you find me the store name that they went to? I don't want the new store name (cause who cares), I want name of the realtor when the gang went there. (Which retailer used to run the shop associated with this scene?)

![Image 1](image-01.jpg)

Submit `RCC{retailer}`.


