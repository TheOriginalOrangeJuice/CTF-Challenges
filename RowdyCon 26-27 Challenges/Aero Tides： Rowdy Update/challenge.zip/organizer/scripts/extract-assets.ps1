param(
    [string]$Source = "ChatGPT Image Sep 9, 2026, 02_14_25 PM.png"
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

$projectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$sourcePath = Join-Path $projectRoot (Join-Path "organizer\assets" $Source)
$assetRoot = Join-Path $projectRoot "challenge\web\public\assets"
$cardRoot = Join-Path $assetRoot "cards"
$spriteRoot = Join-Path $assetRoot "sprites"

New-Item -ItemType Directory -Force -Path $assetRoot, $cardRoot, $spriteRoot | Out-Null
Copy-Item -LiteralPath $sourcePath -Destination (Join-Path $assetRoot "event-banner.png") -Force

$sourceImage = [System.Drawing.Bitmap]::FromFile($sourcePath)

function Save-ExactCrop {
    param([string]$Name, [int[]]$Rect)
    $target = New-Object System.Drawing.Bitmap($Rect[2], $Rect[3], [System.Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $graphics = [System.Drawing.Graphics]::FromImage($target)
    try {
        $graphics.CompositingMode = [System.Drawing.Drawing2D.CompositingMode]::SourceCopy
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
        $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
        $destination = New-Object System.Drawing.Rectangle(0, 0, $Rect[2], $Rect[3])
        $graphics.DrawImage($sourceImage, $destination, $Rect[0], $Rect[1], $Rect[2], $Rect[3], [System.Drawing.GraphicsUnit]::Pixel)
        $target.Save((Join-Path $cardRoot "$Name.png"), [System.Drawing.Imaging.ImageFormat]::Png)
    }
    finally {
        $graphics.Dispose()
        $target.Dispose()
    }
}

function Save-MaskedSprite {
    param([string]$Name, [int[]]$Rect, [int[][]]$Points)
    $target = New-Object System.Drawing.Bitmap($Rect[2], $Rect[3], [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $graphics = [System.Drawing.Graphics]::FromImage($target)
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    try {
        $graphics.Clear([System.Drawing.Color]::Transparent)
        $graphics.CompositingMode = [System.Drawing.Drawing2D.CompositingMode]::SourceCopy
        $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
        $graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::Half
        $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::None
        $drawingPoints = @($Points | ForEach-Object { New-Object System.Drawing.Point($_[0], $_[1]) })
        $path.AddPolygon($drawingPoints)
        $graphics.SetClip($path)
        $destination = New-Object System.Drawing.Rectangle(0, 0, $Rect[2], $Rect[3])
        $graphics.DrawImage($sourceImage, $destination, $Rect[0], $Rect[1], $Rect[2], $Rect[3], [System.Drawing.GraphicsUnit]::Pixel)
        $target.Save((Join-Path $spriteRoot "$Name.png"), [System.Drawing.Imaging.ImageFormat]::Png)
    }
    finally {
        $path.Dispose()
        $graphics.Dispose()
        $target.Dispose()
    }
}

$assets = @(
    @{ Name="classic"; Card=@(321,54,258,294); Art=@(330,66,240,225); Mask=@(@(54,5),@(126,14),@(159,39),@(157,64),@(192,82),@(212,122),@(191,151),@(169,144),@(160,185),@(132,215),@(87,223),@(68,201),@(43,182),@(8,132),@(4,73),@(44,89)) },
    @{ Name="nature"; Card=@(585,57,272,291); Art=@(596,66,252,225); Mask=@(@(70,5),@(151,14),@(184,41),@(181,67),@(218,89),@(232,125),@(211,153),@(187,146),@(179,188),@(147,218),@(98,222),@(76,199),@(49,184),@(5,132),@(4,73),@(50,88)) },
    @{ Name="sky"; Card=@(864,59,272,289); Art=@(873,67,254,224); Mask=@(@(69,4),@(153,12),@(186,39),@(181,66),@(220,88),@(239,124),@(215,151),@(190,143),@(181,187),@(149,216),@(99,220),@(74,199),@(48,181),@(5,130),@(3,71),@(50,87)) },
    @{ Name="bubble"; Card=@(297,356,280,288); Art=@(307,365,261,222); Mask=@(@(65,4),@(164,5),@(216,35),@(252,80),@(249,136),@(219,170),@(186,169),@(170,207),@(113,221),@(78,204),@(58,174),@(12,159),@(2,105),@(18,56)) },
    @{ Name="vacation"; Card=@(581,357,275,286); Art=@(592,365,256,223); Mask=@(@(68,3),@(180,5),@(233,38),@(252,90),@(244,143),@(208,158),@(193,199),@(142,221),@(103,207),@(82,179),@(40,170),@(3,126),@(4,76),@(37,42)) },
    @{ Name="globe"; Card=@(863,357,273,287); Art=@(873,365,254,223); Mask=@(@(64,3),@(169,2),@(225,31),@(251,78),@(248,135),@(220,166),@(187,169),@(173,207),@(118,221),@(79,205),@(59,178),@(13,162),@(2,106),@(18,56)) },
    @{ Name="cyber"; Card=@(136,649,319,298); Art=@(145,658,302,214); Mask=@(@(84,3),@(210,2),@(275,27),@(297,70),@(293,123),@(261,152),@(236,150),@(226,194),@(165,212),@(118,198),@(87,174),@(35,181),@(3,137),@(9,67),@(45,26)) },
    @{ Name="surf"; Card=@(462,649,321,298); Art=@(473,658,302,214); Mask=@(@(71,2),@(203,2),@(269,24),@(299,70),@(294,125),@(263,155),@(236,153),@(224,196),@(164,212),@(116,199),@(85,176),@(31,183),@(2,139),@(8,67),@(42,25)) },
    @{ Name="ocean"; Card=@(790,649,326,298); Art=@(802,658,306,214); Mask=@(@(73,2),@(207,2),@(273,24),@(303,70),@(298,125),@(267,155),@(240,153),@(228,196),@(168,212),@(119,199),@(88,176),@(32,183),@(2,139),@(8,67),@(44,25)) },
    @{ Name="dolphin"; Card=@(1133,357,385,591); Art=@(1145,369,363,472); Mask=@(@(79,3),@(278,2),@(348,40),@(361,115),@(348,199),@(355,281),@(331,389),@(274,462),@(160,470),@(69,447),@(15,376),@(1,272),@(16,185),@(4,96),@(33,35)) }
)

try {
    foreach ($asset in $assets) {
        Save-ExactCrop -Name $asset.Name -Rect $asset.Card
        Save-MaskedSprite -Name $asset.Name -Rect $asset.Art -Points $asset.Mask
    }
}
finally {
    $sourceImage.Dispose()
}

Write-Output "Extracted $($assets.Count) exact card crops and polygon-masked sprites into $assetRoot"
