$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing

$projectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$sourcePath = Join-Path $projectRoot "organizer\assets\ChatGPT Image Sep 9, 2026, 02_14_25 PM.png"
$assetRoot = Join-Path $projectRoot "challenge\web\public\assets"
$source = [System.Drawing.Bitmap]::FromFile($sourcePath)

$cards = @{
    classic=@(321,54); nature=@(585,57); sky=@(864,59); bubble=@(297,356); vacation=@(581,357);
    globe=@(863,357); cyber=@(136,649); surf=@(462,649); ocean=@(790,649); dolphin=@(1133,357)
}

try {
    foreach ($entry in $cards.GetEnumerator()) {
        $cardPath = Join-Path $assetRoot "cards\$($entry.Key).png"
        if (-not (Test-Path -LiteralPath $cardPath)) { throw "Missing $cardPath" }
        $card = [System.Drawing.Bitmap]::FromFile($cardPath)
        try {
            $samples = @(
                @(0,0),
                @([Math]::Floor($card.Width / 2), [Math]::Floor($card.Height / 2)),
                @(($card.Width - 1), ($card.Height - 1))
            )
            foreach ($point in $samples) {
                $actual = $card.GetPixel($point[0], $point[1]).ToArgb()
                $expected = $source.GetPixel($entry.Value[0] + $point[0], $entry.Value[1] + $point[1]).ToArgb()
                if ($actual -ne $expected) { throw "Pixel mismatch in $($entry.Key) at $($point[0]),$($point[1])" }
            }
        }
        finally { $card.Dispose() }

        $spritePath = Join-Path $assetRoot "sprites\$($entry.Key).png"
        if (-not (Test-Path -LiteralPath $spritePath)) { throw "Missing $spritePath" }
        $sprite = [System.Drawing.Bitmap]::FromFile($spritePath)
        try {
            $hasTransparent = $false
            for ($x = 0; $x -lt $sprite.Width; $x += [Math]::Max(1, [Math]::Floor($sprite.Width / 12))) {
                for ($y = 0; $y -lt $sprite.Height; $y += [Math]::Max(1, [Math]::Floor($sprite.Height / 12))) {
                    if ($sprite.GetPixel($x, $y).A -eq 0) { $hasTransparent = $true; break }
                }
                if ($hasTransparent) { break }
            }
            if (-not $hasTransparent) { throw "Sprite $($entry.Key) does not contain transparency" }
        }
        finally { $sprite.Dispose() }
    }
}
finally { $source.Dispose() }

Write-Output "Verified all exact card crops and transparent sprite masks."
