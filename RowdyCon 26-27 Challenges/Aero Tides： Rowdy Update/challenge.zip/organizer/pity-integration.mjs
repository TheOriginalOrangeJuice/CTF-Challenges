// Organizer-only ordinary gameplay checks. Run inside an isolated fixture container:
// PITY_TEST_FIXTURE=1 node --input-type=module < organizer/pity-integration.mjs
// The fixture database name must start with rowdy_pity_test_. Never point at a live game.
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { pathToFileURL } from "node:url";

const root = process.env.PITY_TEST_APP_ROOT ?? "/app";
const databaseName = new URL(process.env.DATABASE_URL).pathname.slice(1);
assert.equal(process.env.PITY_TEST_FIXTURE, "1", "Explicit organizer fixture opt-in required");
assert.match(databaseName, /^rowdy_pity_test_[a-z0-9_]+$/, "An isolated test database is required");
const { db, closeDatabases, ident, ledger } = await import(pathToFileURL(`${root}/server/db.mjs`));
const { initializePity } = await import(pathToFileURL(`${root}/server/pity.mjs`));
const { pityStatus } = await import(pathToFileURL(`${root}/server/catalog.mjs`));
const { hash } = await import(pathToFileURL(`${root}/node_modules/@node-rs/argon2/index.js`));
const origin = process.env.PITY_TEST_ORIGIN ?? "http://127.0.0.1:8080";
const reportPath = process.env.PITY_TEST_REPORT ?? "/tmp/pity-integration.json";
const fixturePassword = "pity-fixture-only";
const report = { createdAt: new Date().toISOString(), scope: "Isolated organizer fixture; ordinary gameplay routes only", checks: [] };
const pass = (name, details = {}) => report.checks.push({ name, passed: true, ...details });

async function state(accountId) {
  const result = await db.query(`
    SELECT s.misses, w.${ident(ledger.balanceColumn)} AS balance,
      (SELECT count(*)::integer FROM pulls WHERE account_id = $1) AS pulls,
      (SELECT coalesce(sum(pull_count), 0)::integer FROM collections WHERE account_id = $1) AS collected
    FROM account_pity s JOIN ${ident(ledger.table)} w ON w.${ident(ledger.playerColumn)} = s.account_id
    WHERE s.account_id = $1
  `, [accountId]);
  return result.rows[0];
}

async function account(label, misses = 0, balance = 1_000, initialize = true) {
  const id = randomUUID();
  const username = `pity_${label}_${id.slice(0, 8)}`;
  const passwordHash = await hash(fixturePassword);
  await db.query("INSERT INTO accounts(id, username, password_hash) VALUES ($1, $2, $3)", [id, username, passwordHash]);
  await db.query(`INSERT INTO ${ident(ledger.table)}(${ident(ledger.playerColumn)}, ${ident(ledger.balanceColumn)}) VALUES ($1, $2)`, [id, balance]);
  await db.query("INSERT INTO player_cards(account_id) VALUES ($1)", [id]);
  if (initialize) await db.query("INSERT INTO account_pity(account_id, misses) VALUES ($1, $2)", [id, misses]);
  return { id, username };
}

async function history(player, items) {
  for (let index = 0; index < items.length; index += 1) {
    const item = items[index];
    const id = `${player.id.slice(0, 24)}${String(index + 1).padStart(12, "0")}`;
    await db.query("INSERT INTO pulls(id, account_id, idempotency_key, rowdy_id, was_new, pulled_at) VALUES ($1, $2, $3, $4, false, $5)",
      [id, player.id, `fixture_${index}`, item.rowdy ?? "classic", item.time ?? "2026-10-01T00:00:00Z"]);
  }
}

async function request(path, player, options = {}) {
  const { csrf = player?.csrfToken, body, key, method = "GET" } = options;
  const headers = { Accept: "application/json" };
  if (player?.cookie) headers.Cookie = player.cookie;
  if (csrf) headers["X-CSRF-Token"] = csrf;
  if (key !== undefined) headers["Idempotency-Key"] = key;
  if (body !== undefined) headers["Content-Type"] = "application/json";
  const response = await fetch(`${origin}${path}`, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: response.status, body: await response.json(), cookie: response.headers.getSetCookie()[0]?.split(";")[0] };
}

async function login(player) {
  const response = await request("/api/auth/login", null, { method: "POST", body: { username: player.username, password: fixturePassword } });
  assert.equal(response.status, 200);
  player.cookie = response.cookie;
  const bootstrap = await request("/api/bootstrap", player);
  assert.equal(bootstrap.status, 200);
  player.csrfToken = bootstrap.body.csrfToken;
  return player;
}

const pull = (player, options = {}) => request("/api/pulls", player, { method: "POST", key: randomUUID(), ...options });

try {
  if (process.env.PITY_TEST_PHASE === "restart") {
    const previous = JSON.parse(await readFile(reportPath, "utf8"));
    for (const item of previous.persistedAccounts) {
      assert.deepEqual(await state(item.id), item.state);
      await login(item);
      const bootstrap = await request("/api/bootstrap", item);
      assert.deepEqual(bootstrap.body.pity, pityStatus(item.state.misses));
    }
    previous.checks.push({ name: "Server restart preserves stored pity, balances, collections and history", passed: true, accounts: previous.persistedAccounts.length });
    previous.restartedAt = new Date().toISOString();
    await writeFile(reportPath, `${JSON.stringify(previous, null, 2)}\n`);
    console.log(JSON.stringify({ passed: true, checks: previous.checks.length, restart: true }));
  } else {
    const empty = await account("migration_empty", 0, 1_000, false);
    const misses = await account("migration_misses", 0, 1_000, false);
    const reset = await account("migration_reset", 0, 1_000, false);
    const tied = await account("migration_tied", 0, 1_000, false);
    const old = await account("migration_over_cap", 0, 1_000, false);
    await history(misses, [{}, {}, {}]);
    await history(reset, [{}, { rowdy: "dolphin", time: "2026-10-02T00:00:00Z" }, { time: "2026-10-03T00:00:00Z" }, { time: "2026-10-04T00:00:00Z" }]);
    await history(tied, [{}, { rowdy: "dolphin" }, {}]);
    await history(old, Array.from({ length: 102 }, () => ({})));
    await initializePity(db);
    for (const [player, expected] of [[empty, 0], [misses, 3], [reset, 2], [tied, 1], [old, 102]]) {
      assert.equal((await state(player.id)).misses, expected);
    }
    pass("Legacy migration counts misses after latest legendary, preserves history, and deterministically breaks timestamp ties", { empty: 0, noLegendary: 3, afterLegendary: 2, tiedTimestamps: 1, historicalOverCap: 102 });
    await db.query("UPDATE account_pity SET misses = 7 WHERE account_id = $1", [misses.id]);
    await initializePity(db);
    assert.equal((await state(misses.id)).misses, 7);
    assert.equal((await state(old.id)).pulls, 102);
    pass("Repeated migration preserves authoritative counters and existing pull records");

    const invalid = await login(await account("invalid", 3));
    const invalidBefore = await state(invalid.id);
    assert.equal((await pull(null)).status, 401);
    assert.equal((await pull(invalid, { csrf: "invalid" })).status, 403);
    for (const body of [{ outcome: "dolphin" }, null, [], "invalid"]) {
      assert.equal((await pull(invalid, { body })).status, 422);
    }
    assert.equal((await pull(invalid, { key: "short" })).status, 422);
    assert.deepEqual(await state(invalid.id), invalidBefore);
    pass("Unauthenticated, CSRF-invalid, malformed body and invalid idempotency requests leave all gameplay state unchanged");

    const poor = await login(await account("insufficient", 12, 40));
    const poorBefore = await state(poor.id);
    assert.equal((await pull(poor)).status, 402);
    assert.deepEqual(await state(poor.id), poorBefore);
    pass("Insufficient gems never increase pity or spend the wallet");

    const capped = await login(await account("cap", 100, 500));
    const capKey = randomUUID();
    const guaranteed = await pull(capped, { key: capKey });
    assert.equal(guaranteed.status, 200);
    assert.equal(guaranteed.body.rowdyId, "dolphin");
    assert.deepEqual(guaranteed.body.pity, pityStatus(0));
    assert.deepEqual(await state(capped.id), { balance: 400, misses: 0, pulls: 1, collected: 1 });
    const capSnapshot = await state(capped.id);
    const replay = await pull(capped, { key: capKey });
    assert.equal(replay.status, 200);
    assert.equal(replay.body.pullId, guaranteed.body.pullId);
    assert.deepEqual(await state(capped.id), capSnapshot);
    const following = await pull(capped);
    assert.equal(following.status, 200);
    const expectedAfter = following.body.rowdyId === "dolphin" ? 0 : 1;
    assert.deepEqual(following.body.pity, pityStatus(expectedAfter));
    const laterReplay = await pull(capped, { key: capKey });
    assert.equal(laterReplay.status, 200);
    assert.deepEqual(laterReplay.body.pity, pityStatus(expectedAfter));
    assert.equal(laterReplay.body.balance, 300);
    pass("100 percent guarantees a legendary, resets to base, and old retries return current pity without adding a pull");

    const duplicate = await login(await account("duplicate", 0, 100));
    const duplicateKey = randomUUID();
    const repeated = await Promise.all(Array.from({ length: 4 }, () => pull(duplicate, { key: duplicateKey })));
    assert.ok(repeated.every((item) => item.status === 200));
    assert.equal(new Set(repeated.map((item) => item.body.pullId)).size, 1);
    const duplicateMisses = repeated[0].body.rowdyId === "dolphin" ? 0 : 1;
    assert.deepEqual(await state(duplicate.id), { balance: 0, misses: duplicateMisses, pulls: 1, collected: 1 });
    assert.equal((await pull(duplicate)).status, 402);
    pass("Four simultaneous copies of one idempotency key charge exactly once, even when the wallet reaches zero");

    const concurrent = await login(await account("concurrent", 5, 1_000));
    const parallel = await Promise.all(Array.from({ length: 4 }, () => pull(concurrent)));
    assert.ok(parallel.every((item) => item.status === 200));
    assert.equal(new Set(parallel.map((item) => item.body.pullId)).size, 4);
    let expectedMisses = 5;
    const ordered = parallel.map((item) => item.body).sort((a, b) => b.balance - a.balance);
    for (const [index, result] of ordered.entries()) {
      expectedMisses = result.rowdyId === "dolphin" ? 0 : expectedMisses + 1;
      assert.equal(result.balance, 900 - index * 100);
      assert.deepEqual(result.pity, pityStatus(expectedMisses));
    }
    assert.deepEqual(await state(concurrent.id), { balance: 600, misses: expectedMisses, pulls: 4, collected: 4 });
    const bootstrap = await request("/api/bootstrap", concurrent);
    assert.deepEqual(bootstrap.body.pity, pityStatus(expectedMisses));
    const authenticatedOdds = await request("/api/odds", concurrent);
    assert.equal(authenticatedOdds.body.rateScope, "next-pull");
    assert.deepEqual(authenticatedOdds.body.pity, bootstrap.body.pity);
    assert.deepEqual(authenticatedOdds.body.rates.map((item) => item.chance), bootstrap.body.catalog.map((item) => item.chance));
    const anonymousOdds = await request("/api/odds");
    assert.equal(anonymousOdds.body.rateScope, "base");
    assert.deepEqual(anonymousOdds.body.pity, pityStatus(0));
    assert.deepEqual(await state(poor.id), poorBefore);
    pass("Concurrent distinct pulls apply sequential pity, bootstrap and odds agree, and accounts remain independent", { outcomes: ordered.map(({ rowdyId, balance, pity }) => ({ rowdyId, balance, pity })) });

    const rollback = await login(await account("rollback", 8));
    const rollbackBefore = await state(rollback.id);
    await db.query(`
      CREATE FUNCTION pity_fixture_fail() RETURNS trigger LANGUAGE plpgsql AS $$
      BEGIN
        IF NEW.account_id::text = TG_ARGV[0] THEN RAISE EXCEPTION 'organizer fixture rollback'; END IF;
        RETURN NEW;
      END $$;
      CREATE TRIGGER pity_fixture_fail BEFORE UPDATE ON account_pity FOR EACH ROW
      EXECUTE FUNCTION pity_fixture_fail('${rollback.id}')
    `);
    try {
      assert.equal((await pull(rollback)).status, 500);
      assert.deepEqual(await state(rollback.id), rollbackBefore);
    } finally {
      await db.query("DROP TRIGGER pity_fixture_fail ON account_pity; DROP FUNCTION pity_fixture_fail()");
    }
    pass("A database failure at the final pity update rolls back payment, collection, history and pity together");

    const browser = await account("browser", 5, 10_000);
    await history(browser, Array.from({ length: 5 }, () => ({})));
    await db.query("INSERT INTO collections(account_id, rowdy_id, pull_count) VALUES ($1, 'classic', 5)", [browser.id]);
    report.browserFixture = { username: browser.username, password: fixturePassword, id: browser.id, misses: 5, balance: 10_000, provenance: "Private organizer-created account, wallet and five ordinary nonlegendary history rows; production database untouched" };
    report.persistedAccounts = await Promise.all([capped, duplicate, concurrent, browser].map(async (player) => ({ id: player.id, username: player.username, state: await state(player.id) })));
    report.passed = true;
    await writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`);
    console.log(JSON.stringify({ passed: true, checks: report.checks.length, browserFixture: report.browserFixture }));
  }
} finally {
  await closeDatabases();
}
