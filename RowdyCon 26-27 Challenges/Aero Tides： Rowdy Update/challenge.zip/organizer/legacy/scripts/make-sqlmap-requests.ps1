param(
    [string]$Target = "http://127.0.0.1:8080",
    [string]$OutputDirectory = ".verify-sqlmap"
)

$ErrorActionPreference = "Stop"
$base = $Target.TrimEnd("/")
$uri = [Uri]$base
$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$loginBody = @{ username="abc123"; password="1mN0t4n4dd1ctJu5t4C0nn01553ur" } | ConvertTo-Json -Compress
Invoke-RestMethod -Uri "$base/api/auth/login" -Method Post -ContentType "application/json" -Body $loginBody -WebSession $session | Out-Null
$bootstrap = Invoke-RestMethod -Uri "$base/api/bootstrap" -WebSession $session
$cookie = $session.Cookies.GetCookies($uri)["rowdy_session"].Value
$motto = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("Birds up"))
$hostHeader = if ($uri.IsDefaultPort) { $uri.Host } else { "$($uri.Host):$($uri.Port)" }

$saveRequest = @"
PUT /api/player-card HTTP/1.1
Host: $hostHeader
Cookie: rowdy_session=$cookie
X-CSRF-Token: $($bootstrap.csrfToken)
Content-Type: application/json
Accept: application/json
Connection: close

{"mottoToken":"$motto","frame":"aero"}
"@ -replace "`r?`n", "`r`n"

$syncRequest = @"
POST /api/player-card/sync HTTP/1.1
Host: $hostHeader
Cookie: rowdy_session=$cookie
X-CSRF-Token: $($bootstrap.csrfToken)
Accept: application/json
Connection: close

"@ -replace "`r?`n", "`r`n"

$resolvedOutput = Join-Path (Get-Location) $OutputDirectory
New-Item -ItemType Directory -Force -Path $resolvedOutput | Out-Null
[IO.File]::WriteAllText((Join-Path $resolvedOutput "save.req"), $saveRequest, [Text.Encoding]::ASCII)
[IO.File]::WriteAllText((Join-Path $resolvedOutput "sync.req"), $syncRequest, [Text.Encoding]::ASCII)
Write-Output "Wrote authenticated SQLMap requests to $resolvedOutput"
