"""Ordinary UI checks for the coordinated local review stack, run in Condev.

Requires Playwright/Chromium and GATCHA_UI_PASSWORD. No pulls, wallet changes,
saved profile changes, reward access, legacy helpers, or vulnerability checks.
"""

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://host.docker.internal:18112")
    parser.add_argument("--username", default="TheOriginalAppleJuice")
    parser.add_argument("--chromium-path", default="/usr/bin/chromium-browser")
    parser.add_argument("--secure-review-origin", action="store_true", help="Test-only secure-origin allowance for this exact local review URL")
    args = parser.parse_args()
    url = urlparse(args.base_url)
    if url.scheme != "http" or url.hostname not in {"localhost", "127.0.0.1", "host.docker.internal"} or url.port != 18112:
        parser.error("Use only the coordinated local review stack on port 18112.")
    password = os.environ.get("GATCHA_UI_PASSWORD")
    if not password:
        parser.error("Set GATCHA_UI_PASSWORD to the published seeded login password.")
    screenshots = ROOT / "screenshots"
    screenshots.mkdir(exist_ok=True)
    report_path = ROOT / "organizer/ui-review.json"
    report = json.loads(report_path.read_text(encoding="utf-8-sig"))
    runtime = {
        "status": "running", "started_utc": datetime.now(timezone.utc).isoformat(),
        "base_url": args.base_url, "checks": [], "screenshots": [],
        "console_errors": [], "http_errors": [], "page_errors": [], "human_playtest": False,
        "audio_listening": False,
        "chromium_path": args.chromium_path,
        "secure_origin_allowance": args.base_url if args.secure_review_origin else None,
        "excluded": ["summons", "wallet changes", "reward flows", "solver helpers", "vulnerability checks"],
    }
    report["runtime"] = runtime

    def checked(name):
        runtime["checks"].append({"name": name, "status": "passed"})

    def capture(page, name):
        assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth"), "Horizontal overflow"
        path = screenshots / name
        page.screenshot(path=str(path), full_page=True)
        runtime["screenshots"].append(str(path.relative_to(ROOT)))

    try:
        with sync_playwright() as playwright:
            browser_args = ["--no-sandbox"]
            if args.secure_review_origin:
                browser_args.append(f"--unsafely-treat-insecure-origin-as-secure={args.base_url}")
            browser = playwright.chromium.launch(headless=True, executable_path=args.chromium_path, args=browser_args)
            context = browser.new_context(viewport={"width": 1366, "height": 768}, reduced_motion="reduce")
            page = context.new_page()
            page.on("pageerror", lambda error: runtime["page_errors"].append(str(error)))
            page.on("console", lambda message: runtime["console_errors"].append({"text": message.text, "url": message.location.get("url", "")}) if message.type == "error" else None)
            page.on("response", lambda response: runtime["http_errors"].append({"url": response.url, "status": response.status}) if response.status >= 400 else None)
            page.goto(args.base_url, wait_until="networkidle")
            entry = page.get_by_role("button", name="ENTER EVENT")
            expect(entry).to_be_enabled()
            expect(page.locator(".landing")).to_have_class("landing reduce-motion")
            assert float(page.locator(".bubble-field i").first.evaluate("element => parseFloat(getComputedStyle(element).animationDuration)")) < 0.001
            capture(page, "ui-landing-1366.png")
            checked("OS reduced motion applies on first arrival")

            entry.click()
            dialog = page.get_by_role("dialog", name="Welcome to Aero Tides")
            username = page.get_by_label("USERNAME", exact=True)
            expect(username).to_be_focused()
            close_button = dialog.get_by_role("button", name="Close", exact=True)
            submit = dialog.get_by_role("button", name="SIGN IN", exact=True)
            close_button.focus()
            page.keyboard.press("Shift+Tab")
            expect(submit).to_be_focused()
            page.keyboard.press("Tab")
            expect(close_button).to_be_focused()
            assert page.locator(".event-hero").evaluate("element => element.inert")
            capture(page, "ui-login-1366.png")
            page.keyboard.press("Escape")
            expect(dialog).to_have_count(0)
            expect(entry).to_be_focused()
            assert not page.locator(".event-hero").evaluate("element => element.inert")
            checked("Login focus, both Tab boundaries, inert background, Escape, and focus restoration")

            entry.click()
            username.fill(args.username)
            page.get_by_label("PASSWORD", exact=True).fill(password)
            page.get_by_role("button", name="SIGN IN", exact=True).click()
            expect(page.get_by_role("navigation", name="Game menu")).to_be_visible()
            expect(page.get_by_role("button", name=f"Sign out {args.username}")).to_be_visible()
            expect(page.get_by_role("button", name="ROLL ×1")).to_be_disabled()
            capture(page, "03-summon-1366.png")
            checked("Published login and unchanged low-reserves starting screen")
            nav = page.get_by_role("navigation", name="Game menu")
            for label, heading, image in [
                ("Collection", "Rowdy Collection", "ui-collection-1366.png"),
                ("History", "Recent Pulls", "ui-history-1366.png"),
                ("Drop Rates", "Published Drop Rates", "ui-rates-1366.png"),
            ]:
                button = nav.get_by_role("button", name=label, exact=True)
                button.click()
                expect(button).to_have_attribute("aria-current", "page")
                expect(page.get_by_role("heading", name=heading, exact=True)).to_be_visible()
                capture(page, image)
            checked("Collection, History, and Drop Rates navigation with current-page semantics")

            nav.get_by_role("button", name="Player Card", exact=True).click()
            motto = page.locator(".card-editor textarea")
            original_motto = motto.input_value()
            frame = page.locator(".card-editor select")
            original_frame = frame.input_value()
            motto.fill("Birds up! Enjoying the lagoon.")
            expect(page.locator(".profile-preview blockquote")).to_contain_text("Birds up! Enjoying the lagoon.")
            frame.select_option("lagoon")
            expect(page.locator(".profile-preview")).to_have_class("profile-preview frame-lagoon")
            capture(page, "05-player-card-1366.png")
            motto.fill(original_motto)
            frame.select_option(original_frame)
            checked("Plain-text profile preview and cosmetic frame; no save or sync request")

            nav.get_by_role("button", name="Settings", exact=True).click()
            sound = page.get_by_role("button", name="Sound effects", exact=True)
            motion = page.get_by_role("button", name="Reduced motion", exact=True)
            volume = page.get_by_role("slider", name="Volume", exact=True)
            expect(sound).to_have_attribute("aria-pressed", "true")
            sound.focus()
            page.keyboard.press("Space")
            expect(sound).to_have_attribute("aria-pressed", "false")
            volume.focus()
            page.keyboard.press("ArrowRight")
            expect(volume).to_have_attribute("aria-valuetext", "60 percent")
            expect(sound).to_have_attribute("aria-pressed", "true")
            expect(motion).to_have_attribute("aria-pressed", "true")
            motion.click()
            expect(motion).to_have_attribute("aria-pressed", "false")
            assert not page.locator(".game-shell").evaluate("element => element.classList.contains('reduce-motion')")
            motion.click()
            expect(motion).to_have_attribute("aria-pressed", "true")
            assert float(motion.evaluate("element => parseFloat(getComputedStyle(element).transitionDuration)")) < 0.001
            checked("Keyboard sound toggle, labeled volume value, motion toggle, and reduced transitions")

            fullscreen = page.get_by_role("button", name="ENTER FULLSCREEN", exact=True)
            if fullscreen.is_enabled():
                fullscreen.click()
                expect(page.get_by_role("button", name="EXIT FULLSCREEN", exact=True)).to_be_visible()
                page.get_by_role("button", name="EXIT FULLSCREEN", exact=True).click()
                expect(fullscreen).to_be_visible()
                page.evaluate("() => { document.documentElement.requestFullscreen = () => Promise.reject(new Error('UI test denial')); }")
                fullscreen.click()
                expect(page.get_by_role("status")).to_contain_text("Fullscreen could not change")
                checked("Fullscreen enter/exit and handled browser denial")
            else:
                expect(page.get_by_role("status")).to_contain_text("Fullscreen is unavailable")
                checked("Unsupported fullscreen has disabled control and explanation")
            capture(page, "ui-settings-1366.png")
            page.set_viewport_size({"width": 1920, "height": 1080})
            capture(page, "ui-settings-1920.png")
            page.get_by_role("button", name=f"Sign out {args.username}").click()
            expect(page.locator(".landing")).to_have_class("landing reduce-motion")
            page.emulate_media(reduced_motion="no-preference")
            page.reload(wait_until="networkidle")
            expect(page.locator(".landing")).to_have_class("landing reduce-motion")
            capture(page, "ui-landing-1920.png")
            checked("Saved motion setting survives sign-out/reload with different OS preference")
            assert not runtime["page_errors"], "Browser page errors occurred"
            expected_errors = {("/api/bootstrap", 401), ("/favicon.ico", 404)}
            runtime["unexpected_http_errors"] = [entry for entry in runtime["http_errors"] if (urlparse(entry["url"]).path, entry["status"]) not in expected_errors]
            runtime["unexpected_console_errors"] = [entry for entry in runtime["console_errors"] if not any(urlparse(entry["url"]).path == path and str(status) in entry["text"] for path, status in expected_errors)]
            assert not runtime["unexpected_http_errors"], "Unexpected HTTP errors occurred"
            assert not runtime["unexpected_console_errors"], "Unexpected console errors occurred"
            checked("No page errors or unexpected console errors during ordinary UI checks")
            context.close()
            browser.close()
        runtime["status"] = "passed"
    except Exception as error:
        runtime["status"] = "failed"
        runtime["failure"] = str(error)
        raise
    finally:
        runtime["finished_utc"] = datetime.now(timezone.utc).isoformat()
        report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
