"""Focused pity UI checks. Paid rolls run only on the isolated organizer fixture."""

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixture", action="store_true")
    parser.add_argument("--username", default="TheOriginalAppleJuice")
    parser.add_argument("--password", default="ShoutoutJohnCena@123!")
    args = parser.parse_args()
    port = 18132 if args.fixture else 18112
    base = f"http://host.docker.internal:{port}"
    label = "fixture" if args.fixture else "live"
    report = {
        "scope": "Ordinary gameplay/UI; no profile save/sync or exploit workflow",
        "base_url": base,
        "isolated_fixture": args.fixture,
        "secure_origin_allowance": base if args.fixture else None,
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "checks": [], "screenshots": [], "page_errors": [],
        "human_playtesting": False, "audio_listening": False,
        "anti_agent_effectiveness": "not evaluated",
    }

    def checked(name):
        report["checks"].append(name)

    def capture(page, name):
        assert page.evaluate("document.documentElement.scrollWidth <= innerWidth")
        path = ROOT / "screenshots" / name
        page.screenshot(path=str(path), full_page=True)
        report["screenshots"].append(str(path.relative_to(ROOT)))

    def bootstrap(page):
        data = page.evaluate("async () => { const r = await fetch('/api/bootstrap'); if (!r.ok) throw Error(r.status); return r.json(); }")
        pity = data["pity"]
        assert round(pity["legendaryChance"] * 10000) == min(10000, 67 + 100 * pity["misses"])
        assert abs(sum(row["chance"] for row in data["catalog"]) - 1) < 1e-10
        return data

    def visible_chance(page, data):
        chance = f'{data["pity"]["legendaryChance"] * 100:.2f}%'
        expect(page.locator(".mini-event-banner__copy")).to_contain_text(chance)
        expect(page.locator(".summon-notes")).not_to_contain_text("NO PITY")

    try:
        with sync_playwright() as p:
            launch_args = ["--no-sandbox"]
            if args.fixture:
                launch_args.append(f"--unsafely-treat-insecure-origin-as-secure={base}")
            browser = p.chromium.launch(executable_path="/usr/bin/chromium-browser", headless=True, args=launch_args)
            context = browser.new_context(viewport={"width": 1366, "height": 768}, reduced_motion="reduce")
            page = context.new_page()
            page.on("pageerror", lambda error: report["page_errors"].append(str(error)))
            page.goto(base, wait_until="networkidle")
            page.get_by_role("button", name="ENTER EVENT").click()
            page.get_by_label("USERNAME", exact=True).fill(args.username)
            page.get_by_label("PASSWORD", exact=True).fill(args.password)
            page.get_by_role("button", name="SIGN IN", exact=True).click()
            nav = page.get_by_role("navigation", name="Game menu")
            expect(nav).to_be_visible()
            before = bootstrap(page)
            report["before"] = {"balance": before["balance"], "pity": before["pity"]}
            visible_chance(page, before)
            checked("Server chance matches miss count; current odds appear on Summon")
            capture(page, "pity-fixture-before-1366.png" if args.fixture else "pity-live-summon-1366.png")

            if args.fixture:
                with page.expect_response(lambda r: r.url.endswith("/api/pulls") and r.request.method == "POST") as pending:
                    page.get_by_role("button", name="ROLL ×1").click()
                response = pending.value
                assert response.ok, response.status
                result = response.json()
                page.get_by_role("button", name="CONTINUE", exact=True).click(timeout=15000)
                expect(page.get_by_role("dialog")).to_have_count(0)
                after = bootstrap(page)
                expected_misses = 0 if result["rowdyId"] == "dolphin" else before["pity"]["misses"] + 1
                assert after["pity"]["misses"] == expected_misses
                assert after["balance"] == before["balance"] - before["pullPrice"]
                visible_chance(page, after)
                report["ordinary_pull"] = {"rowdy_id": result["rowdyId"], "balance": after["balance"], "pity": after["pity"]}
                checked("An ordinary paid roll updates displayed odds and spends exactly one pull price")
                capture(page, "pity-fixture-after-1366.png")
            else:
                after = before

            nav.get_by_role("button", name="Drop Rates", exact=True).click()
            expect(page.get_by_role("heading", name="Published Drop Rates", exact=True)).to_be_visible()
            for rowdy in after["catalog"]:
                row = page.locator(".odds-row").filter(has_text=rowdy["name"])
                expect(row).to_contain_text(f'{rowdy["chance"] * 100:.2f}%')
                expect(row).to_contain_text(f'{rowdy["baseChance"] * 100:.2f}%')
            checked("Every card's base and current probability matches the authenticated catalog")
            capture(page, f"pity-{label}-rates-1366.png")
            page.set_viewport_size({"width": 1920, "height": 1080})
            capture(page, f"pity-{label}-rates-1920.png")
            nav.get_by_role("button", name="Summon", exact=True).click()
            capture(page, f"pity-{label}-summon-1920.png")
            page.reload(wait_until="networkidle")
            expect(nav).to_be_visible()
            reloaded = bootstrap(page)
            assert reloaded["pity"] == after["pity"]
            visible_chance(page, reloaded)
            checked("Reload retains pity and the matching visible chance")
            page.get_by_role("button", name=f"Sign out {args.username}", exact=True).click()
            expect(page.get_by_role("button", name="ENTER EVENT")).to_be_visible()
            assert not report["page_errors"]
            checked("No JavaScript page errors; signed out after checks")
            context.close()
            browser.close()
        report["status"] = "passed"
    except Exception as exc:
        report["status"] = "failed"
        report["failure"] = str(exc)
        raise
    finally:
        report["finished_utc"] = datetime.now(timezone.utc).isoformat()
        (ROOT / "organizer" / f"pity-ui-{label}.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
