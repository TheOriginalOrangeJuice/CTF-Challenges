"""Measure the live review site's audio through ordinary controls; never make a pull."""

import json
from datetime import datetime, timezone
from pathlib import Path

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]
PROBE = """(() => {
  const taps = [];
  const connect = AudioNode.prototype.connect;
  AudioNode.prototype.connect = function(destination, ...args) {
    const result = connect.call(this, destination, ...args);
    if (destination === this.context.destination && !this.context.startRendering) {
      const analyser = this.context.createAnalyser();
      analyser.fftSize = 2048;
      connect.call(this, analyser);
      taps.push({ context: this.context, analyser });
    }
    return result;
  };
  window.measureGameAudio = async (milliseconds = 500) => {
    const buffer = new Float32Array(2048);
    let sum = 0, count = 0, peak = 0;
    const until = performance.now() + milliseconds;
    while (performance.now() < until) {
      for (const tap of taps) {
        tap.analyser.getFloatTimeDomainData(buffer);
        for (const sample of buffer) { sum += sample * sample; count++; peak = Math.max(peak, Math.abs(sample)); }
      }
      await new Promise(resolve => setTimeout(resolve, 12));
    }
    return { rms: count ? Math.sqrt(sum / count) : 0, peak,
      outputs: taps.length, states: taps.map(tap => tap.context.state) };
  };
})();"""


def main():
    report = {
        "scope": "Real local review site: login, navigation and audio preferences only",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "checks": [], "page_errors": [], "mutating_requests": [],
        "independent_human_listening": False,
    }
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path="/usr/bin/chromium-browser", headless=True,
                                    args=["--no-sandbox", "--autoplay-policy=user-gesture-required"])
        context = browser.new_context(viewport={"width": 1366, "height": 768}, reduced_motion="reduce")
        context.add_init_script(PROBE)
        page = context.new_page()
        page.on("pageerror", lambda error: report["page_errors"].append(str(error)))
        page.on("request", lambda request: report["mutating_requests"].append(request.url)
                if request.method not in {"GET", "HEAD", "OPTIONS"} else None)

        def measure(name, audible):
            signal = page.evaluate("() => measureGameAudio()")
            assert signal["peak"] <= 1, (name, signal)
            if audible:
                assert signal["rms"] > 0.0001, (name, signal)
                assert signal["outputs"] == 1, (name, signal)
            else:
                assert signal["rms"] < 0.000001, (name, signal)
            report["checks"].append({"name": name, "passed": True, "signal": signal})

        try:
            page.goto("http://host.docker.internal:18112", wait_until="networkidle")
            measure("Silent before first interaction", False)
            page.get_by_role("button", name="ENTER EVENT").click()
            page.wait_for_timeout(1800)
            measure("Music produces real output after the first gesture", True)
            page.get_by_label("USERNAME", exact=True).fill("TheOriginalAppleJuice")
            page.get_by_label("PASSWORD", exact=True).fill("ShoutoutJohnCena@123!")
            page.get_by_role("button", name="SIGN IN", exact=True).click()
            nav = page.get_by_role("navigation", name="Game menu")
            expect(nav).to_be_visible()
            nav.get_by_role("button", name="Settings", exact=True).click()
            page.get_by_role("button", name="Background music", exact=True).click()
            page.wait_for_timeout(650)
            measure("Music can be silenced independently", False)
            nav.get_by_role("button", name="Collection", exact=True).click()
            measure("Mouse navigation cue with music disabled", True)
            nav.get_by_role("button", name="History", exact=True).focus()
            page.keyboard.press("Enter")
            measure("Keyboard navigation cue with music disabled", True)
            nav.get_by_role("button", name="Settings", exact=True).click()
            page.get_by_role("button", name="Game audio", exact=True).click()
            page.wait_for_timeout(150)
            nav.get_by_role("button", name="Collection", exact=True).click()
            measure("Master mute suppresses button sounds", False)
            nav.get_by_role("button", name="Settings", exact=True).click()
            page.get_by_role("button", name="Game audio", exact=True).click()
            measure("Unmuting restores real output", True)
            page.screenshot(path=str(ROOT / "screenshots/audio-settings-live-1366.png"), full_page=True)
            page.get_by_role("button", name="Sign out TheOriginalAppleJuice", exact=True).click()
            expect(page.get_by_role("button", name="ENTER EVENT")).to_be_visible()
            assert not report["page_errors"]
            assert all(url.endswith(("/api/auth/login", "/api/auth/logout")) for url in report["mutating_requests"])
            report["status"] = "passed"
        except Exception as error:
            report["status"] = "failed"
            report["failure"] = str(error)
            raise
        finally:
            report["finished_utc"] = datetime.now(timezone.utc).isoformat()
            (ROOT / "organizer/audio-live-review.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
            context.close()
            browser.close()


if __name__ == "__main__":
    main()
