"""Frontend audio QA with mocked ordinary APIs; no requests reach the game backend."""
import argparse
import functools
import hashlib
import http.server
import json
import threading
from datetime import datetime, timezone
from pathlib import Path
from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[1]
PROBE = r"""(() => {
  const Native=window.AudioContext, connect=AudioNode.prototype.connect;
  const p=window.audioProbe={contexts:[],notes:[],loops:[],analysers:[],gains:[]};
  window.AudioContext=new Proxy(Native,{construct(Target,args){
    const c=new Target(...args);p.contexts.push(c);
    const oscillator=c.createOscillator.bind(c);
    c.createOscillator=()=>{const n=oscillator(),start=n.start.bind(n);n.start=(...a)=>{p.notes.push({frequency:n.frequency.value,at:a[0]});return start(...a);};return n;};
    const source=c.createBufferSource.bind(c);
    c.createBufferSource=()=>{const n=source(),start=n.start.bind(n);n.start=(...a)=>{p.loops.push({node:n,started:c.currentTime});return start(...a);};return n;};
    const gain=c.createGain.bind(c);
    c.createGain=()=>{const n=gain();p.gains.push(n);return n;};
    return c;
  }});
  AudioNode.prototype.connect=function(destination,...args){
    if(destination instanceof AudioDestinationNode && p.contexts.includes(this.context)){
      const a=this.context.createAnalyser();a.fftSize=2048;p.analysers.push(a);
      connect.call(this,a);connect.call(a,destination);return destination;
    }return connect.call(this,destination,...args);
  };
  p.measure=async(ms=220)=>{
    let sum=0,count=0,peak=0,maxRms=0;const end=performance.now()+ms;
    while(performance.now()<end){for(const a of p.analysers){const s=new Float32Array(a.fftSize);a.getFloatTimeDomainData(s);let local=0;
      for(const v of s){sum+=v*v;local+=v*v;peak=Math.max(peak,Math.abs(v));count++;}maxRms=Math.max(maxRms,Math.sqrt(local/s.length));}
      await new Promise(r=>setTimeout(r,8));}return {rms:count?Math.sqrt(sum/count):0,max_rms:maxRms,peak};
  };
  p.score=()=>{
    const b=p.loops[0].node.buffer,s=b.getChannelData(0);let peak=0,sum=0,maxStep=0;const sections=[];
    for(let i=0;i<s.length;i++){peak=Math.max(peak,Math.abs(s[i]));sum+=s[i]**2;if(i)maxStep=Math.max(maxStep,Math.abs(s[i]-s[i-1]));}
    for(let t=0;t<b.duration;t++){let q=0;for(let i=t*b.sampleRate;i<(t+1)*b.sampleRate;i++)q+=s[i]**2;sections.push(Math.sqrt(q/b.sampleRate));}
    return {seconds:b.duration,sample_rate:b.sampleRate,channels:b.numberOfChannels,rms:Math.sqrt(sum/s.length),peak,
      loop_seam_step:Math.abs(s[0]-s.at(-1)),max_internal_step:maxStep,per_second_rms:sections};
  };
})();"""


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dist",type=Path,default=ROOT/"challenge/dist-web")
    parser.add_argument("--output",type=Path,default=ROOT/"organizer/audio-review.json")
    args=parser.parse_args()
    report={"scope":"Frontend audio; mocked ordinary login/bootstrap/roll/card responses, no real account or backend calls",
            "started_utc":datetime.now(timezone.utc).isoformat(),"checks":[],"signals":{},"page_errors":[],
            "human_listening":False,"human_playtesting":False,"exploit_testing":"not performed",
            "measurement":"Real Chromium destination signal via organizer-injected analyser; no production test hooks"}
    class QuietHandler(http.server.SimpleHTTPRequestHandler):
        def log_message(self,*_):pass
    server=http.server.ThreadingHTTPServer(("127.0.0.1",0),functools.partial(QuietHandler,directory=str(args.dist)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    base=f"http://127.0.0.1:{server.server_port}"
    def checked(name):report["checks"].append(name)
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(executable_path="/usr/bin/chromium-browser",headless=True,args=["--no-sandbox","--autoplay-policy=document-user-activation-required"])
            context=browser.new_context(viewport={"width":1366,"height":768},reduced_motion="reduce",permissions=["clipboard-write"])
            context.add_init_script(PROBE)
            page=context.new_page()
            page.set_default_timeout(10000)
            page.on("pageerror",lambda error:report["page_errors"].append(str(error)))
            state={"signed_in":False,"fail_login":False,"rarity":"common","low_balance":False}
            ids=["nature","sky","bubble","vacation","globe","cyber","surf","ocean","dolphin","classic"]
            catalog=[{"id":v,"name":f"{v.title()} Rowdy","rarity":"legendary" if v=="dolphin" else "common","weight":1,
                      "card":"/assets/event-banner.png","sprite":"/assets/event-banner.png","chance":0.1,"baseChance":0.1} for v in ids]
            def route_api(route):
                path=route.request.url.split("/api/",1)[1];status,body=200,{}
                if path=="bootstrap":
                    if not state["signed_in"]:status,body=401,{"message":"Sign in"}
                    else:body={"player":{"username":"audio-fixture"},"balance":0 if state["low_balance"] else 10000,
                               "walletCap":10000,"pullPrice":100,"pity":{"misses":0,"legendaryChance":0.0067},
                               "catalog":catalog,"history":[],"collection":[],"csrfToken":"audio-only-fixture",
                               "playerCard":{"motto":"Birds up!","frame":"aero"}}
                elif path=="auth/login":
                    if state["fail_login"]:status,body=401,{"message":"Audio fixture sign-in error"}
                    else:state["signed_in"]=True
                elif path=="auth/logout":state["signed_in"]=False
                elif path=="pulls":body={"rowdyId":"dolphin" if state["rarity"]=="legendary" else "nature","rarity":state["rarity"],
                                         "message":"Organizer audio-only fixture message","balance":9900,"isNew":True,
                                         "pity":{"misses":1,"legendaryChance":0.0167},"catalog":catalog}
                elif path=="player-card/sync":body={"status":"AERO_SYNCED","message":"Audio fixture synced"}
                elif path=="player-card":body={"ok":True}
                else:raise AssertionError(f"Unexpected API call: {path}")
                route.fulfill(status=status,content_type="application/json",body=json.dumps(body))
            context.route("**/api/**",route_api)
            def measure(label,ms=220,audible=True):
                signal=page.evaluate("ms=>audioProbe.measure(ms)",ms);report["signals"][label]=signal
                assert signal["peak"]<0.9,(label,signal)
                assert signal["max_rms"]>0.00005 if audible else signal["peak"]<0.0000001,(label,signal)
                return signal
            def action_signal(label,action,notes=None,wait=0):
                before=page.evaluate("audioProbe.notes.length")
                page.evaluate("()=>{window.pendingSignal=audioProbe.measure(450);}")
                action();signal=page.evaluate("pendingSignal");report["signals"][label]=signal
                assert signal["max_rms"]>0.00005 and signal["peak"]<0.9,(label,signal)
                if wait:page.wait_for_timeout(wait)
                if notes is not None:assert page.evaluate("audioProbe.notes.length")-before==notes,label
                page.wait_for_timeout(550)
            def set_range(locator,value):
                locator.press("Home")
                for _ in range(round(value/0.05)):locator.press("ArrowRight")
            page.goto(base,wait_until="networkidle")
            assert page.evaluate("audioProbe.contexts.length")==0
            checked("No context or playback before a game-control gesture")
            page.get_by_role("button",name="ENTER EVENT").click()
            page.wait_for_function("audioProbe.loops.length===1")
            page.wait_for_timeout(400)
            measure("music_after_first_gesture")
            score=page.evaluate("audioProbe.score()");report["score"]=score
            assert score["seconds"]==40 and min(score["per_second_rms"])>0.0002
            assert score["loop_seam_step"]<0.005 and score["loop_seam_step"]<=score["max_internal_step"]
            checked("Stereo score has continuous signal, safe headroom, and smooth sample seam")
            dialog=page.get_by_role("dialog")
            dialog.get_by_role("button",name="Game audio",exact=True).click()
            page.wait_for_timeout(100)
            measure("landing_dialog_master_mute",audible=False)
            dialog.get_by_role("button",name="Game audio",exact=True).click()
            dialog.get_by_role("button",name="Background music",exact=True).click()
            page.wait_for_timeout(500)
            measure("music_off_idle",audible=False)
            checked("Landing/sign-in controls mute ongoing music without login")
            action_signal("modal_close_keyboard",lambda:page.keyboard.press("Escape"),2)
            action_signal("modal_open_keyboard",lambda:page.get_by_role("button",name="ENTER EVENT").press("Enter"),2)
            before=page.evaluate("audioProbe.notes.length")
            page.get_by_label("USERNAME",exact=True).fill("audio-fixture")
            page.get_by_label("PASSWORD",exact=True).fill("fixture")
            page.get_by_label("PASSWORD",exact=True).hover()
            assert page.evaluate("audioProbe.notes.length")==before
            measure("typing_hover_silent",audible=False)
            state["fail_login"]=True
            action_signal("submit_and_login_error",lambda:page.get_by_role("button",name="SIGN IN",exact=True).click(),5,100)
            state["fail_login"]=False
            action_signal("keyboard_submit_login_success",lambda:page.get_by_label("PASSWORD",exact=True).press("Enter"),6,100)
            checked("Modal/submit cues fire once by mouse and keyboard; outcomes differ; typing/hover silent")
            nav=page.get_by_role("navigation",name="Game menu")
            action_signal("navigation",lambda:nav.get_by_role("button",name="Collection",exact=True).click(),2)
            action_signal("navigation_keyboard",lambda:nav.get_by_role("button",name="Settings",exact=True).press("Space"),2)
            action_signal("motion_toggle",lambda:page.get_by_role("button",name="Reduced motion",exact=True).click(),2)
            action_signal("master_slider_keyboard",lambda:page.get_by_role("slider",name="Master volume",exact=True).press("ArrowRight"),1)
            action_signal("music_slider_keyboard",lambda:page.get_by_role("slider",name="Music volume",exact=True).press("ArrowRight"),1)
            action_signal("fullscreen",lambda:page.get_by_role("button",name="ENTER FULLSCREEN",exact=True).click(),2,100)
            if page.get_by_role("button",name="EXIT FULLSCREEN",exact=True).count():
                action_signal("exit_fullscreen",lambda:page.get_by_role("button",name="EXIT FULLSCREEN",exact=True).click(),2,100)
            page.evaluate("()=>{document.documentElement.requestFullscreen=()=>Promise.reject(Error('Organizer fixture'));}")
            action_signal("fullscreen_error",lambda:page.get_by_role("button",name="ENTER FULLSCREEN",exact=True).click(),2,100)
            checked("Navigation, toggles, sliders, fullscreen success/failure emit measured feedback")
            nav.get_by_role("button",name="Player Card",exact=True).click()
            page.wait_for_timeout(600)
            action_signal("select_frame",lambda:page.get_by_label("CARD FRAME").select_option("lagoon"),2)
            action_signal("mocked_save_success",lambda:page.get_by_role("button",name="SAVE CARD",exact=True).click(),6,100)
            action_signal("mocked_sync_success",lambda:page.get_by_role("button",name="SYNC TO EVENT",exact=True).click(),6,100)
            page.get_by_label("EVENT MOTTO").fill("")
            action_signal("validation_error",lambda:page.get_by_role("button",name="SAVE CARD",exact=True).click(),5)
            checked("Mocked ordinary save/sync and empty-motto validation have cues; no vulnerable-path testing")
            nav.get_by_role("button",name="Summon",exact=True).click()
            for rarity in ["common","rare","epic","legendary"]:
                state["rarity"]=rarity
                page.wait_for_timeout(600)
                action_signal(f"{rarity}_roll_button",lambda:page.get_by_role("button",name="ROLL ×1").click())
                measure(f"{rarity}_reel_ticks",650)
                page.wait_for_function("Boolean(document.querySelector('.reveal-overlay'))",timeout=10000)
                measure(f"{rarity}_fanfare",400)
                if rarity=="legendary":
                    page.evaluate("audioProbe.gains[0].gain.setValueAtTime(0,audioProbe.contexts[0].currentTime)")
                    page.wait_for_timeout(100)
                    measure("inflight_queued_master_gain_zero",450,audible=False)
                    page.evaluate("audioProbe.gains[0].gain.setValueAtTime(0.6,audioProbe.contexts[0].currentTime)")
                page.wait_for_timeout(1600)
                if rarity=="common":action_signal("copy_success",lambda:page.get_by_role("button",name="COPY MESSAGE",exact=True).click(),4,100)
                if rarity=="rare":
                    page.evaluate("Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async()=>{throw Error('Organizer fixture')}}})")
                    action_signal("copy_fallback",lambda:page.get_by_role("button",name="COPY MESSAGE",exact=True).click(),4,100)
                action_signal(f"{rarity}_reveal_close",lambda:page.get_by_role("button",name="CONTINUE",exact=True).click(),2)
            checked("Real reel/reveal UI plays four fanfares using mocked results; gain zero silences in-flight notes")
            nav.get_by_role("button",name="Settings",exact=True).click()
            page.get_by_role("button",name="Background music",exact=True).click()
            page.wait_for_timeout(650)
            measure("music_resumes_same_source")
            assert page.evaluate("audioProbe.loops.length")==1
            master=page.get_by_role("slider",name="Master volume",exact=True)
            music=page.get_by_role("slider",name="Music volume",exact=True)
            set_range(master,0);page.wait_for_timeout(100)
            measure("master_volume_zero",audible=False)
            set_range(master,0.5);page.wait_for_timeout(450)
            measure("master_half_music")
            assert page.evaluate("audioProbe.gains[0].gain.value")==0.5
            set_range(music,0);page.wait_for_timeout(400)
            measure("music_volume_zero",audible=False)
            set_range(music,0.3);page.wait_for_timeout(450)
            measure("music_volume_restored")
            page.get_by_role("button",name="Game audio",exact=True).click();page.wait_for_timeout(100)
            measure("master_mute_music",audible=False)
            set_range(music,0.4);page.wait_for_timeout(200)
            measure("slider_preserves_mute",audible=False)
            page.get_by_role("button",name="Game audio",exact=True).click();page.wait_for_timeout(500)
            checked("Settings master/music switches and zero volumes silence actual output; sliders preserve mute")
            # Headless Chromium does not reliably hide background tabs. Only the state/event
            # is simulated here; the tested audio clock and suspension/resumption are real.
            page.evaluate("Object.defineProperty(document,'visibilityState',{configurable:true,value:'hidden'});document.dispatchEvent(new Event('visibilitychange'))")
            page.wait_for_function("audioProbe.contexts[0].state==='suspended'")
            frozen=page.evaluate("audioProbe.contexts[0].currentTime");page.wait_for_timeout(250)
            assert page.evaluate("audioProbe.contexts[0].currentTime")==frozen
            page.evaluate("Object.defineProperty(document,'visibilityState',{configurable:true,value:'visible'});document.dispatchEvent(new Event('visibilitychange'))")
            page.wait_for_function("audioProbe.contexts[0].state==='running'")
            measure("visibility_resume")
            checked("Simulated visibility event suspends real audio clock and resumes one music source")
            set_range(master,1);set_range(music,1);page.wait_for_timeout(500)
            measure("maximum_music_volume",1000)
            page.evaluate("()=>{window.pendingSignal=audioProbe.measure(1200);}")
            page.evaluate("async()=>{for(let i=0;i<80;i++){document.querySelectorAll('.game-nav button')[i%2].click();await new Promise(r=>setTimeout(r,5));}}")
            stress=page.evaluate("pendingSignal");report["signals"]["rapid_input_maximum_volume"]=stress
            assert 0.00005<stress["max_rms"] and stress["peak"]<0.9,stress
            checked("80 rapid activations with music/master at 100 percent remain unclipped")
            until=page.evaluate("40-((audioProbe.contexts[0].currentTime-audioProbe.loops[0].started)%40)")
            if until>0.2:page.wait_for_timeout((until-0.15)*1000)
            measure("realtime_loop_boundary",450)
            assert page.evaluate("audioProbe.loops.length")==1
            checked("Actual continuous playback crosses 40-second boundary using one source")
            action_signal("signout",lambda:page.get_by_role("button",name="Sign out audio-fixture").click(),3)
            page.get_by_role("button",name="ENTER EVENT").click()
            page.get_by_label("USERNAME",exact=True).fill("audio-fixture")
            page.get_by_label("PASSWORD",exact=True).fill("fixture")
            page.get_by_role("button",name="SIGN IN",exact=True).click()
            expect(nav).to_be_visible()
            assert page.evaluate("audioProbe.contexts.length===1 && audioProbe.loops.length===1")
            checked("Login/logout/navigation never duplicate contexts or music layers")
            state["low_balance"]=True
            page.reload(wait_until="networkidle")
            before=page.evaluate("audioProbe.notes.length")
            roll=page.get_by_role("button",name="ROLL ×1");expect(roll).to_be_disabled();roll.dispatch_event("click")
            assert page.evaluate("audioProbe.notes.length")==before
            checked("Disabled controls stay silent")
            page.evaluate("localStorage.setItem('rowdy-settings',JSON.stringify({muted:true,volume:0.2,reducedMotion:true}))")
            page.reload(wait_until="networkidle")
            nav.get_by_role("button",name="Settings",exact=True).click()
            page.wait_for_function("audioProbe.loops.length===1");page.wait_for_timeout(100)
            measure("legacy_muted_migration",audible=False)
            assert page.get_by_role("slider",name="Master volume",exact=True).input_value()=="0.2"
            expect(page.get_by_role("button",name="Reduced motion",exact=True)).to_have_attribute("aria-pressed","true")
            checked("Legacy muted/volume/reduced-motion preferences survive migration and keep new music silent")
            page.screenshot(path=str(args.output.with_suffix(".png")),full_page=True)
            assert not report["page_errors"],report["page_errors"]
            checked("No browser JavaScript errors")
            report["status"]="passed"
            browser.close()
    except Exception as error:
        report["status"]="failed";report["failure"]=str(error)
        raise
    finally:
        report["source_sha256"]={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest() for path in [ROOT/"challenge/web/src/audio.js",ROOT/"challenge/web/src/audio-score.js",ROOT/"challenge/web/src/main.jsx",ROOT/"challenge/web/src/styles.css"]}
        args.output.write_text(json.dumps(report,indent=2)+"\n")
        server.shutdown()
        print(json.dumps({"status":report.get("status"),"checks":len(report["checks"]),"output":str(args.output)}))


if __name__=="__main__":main()
