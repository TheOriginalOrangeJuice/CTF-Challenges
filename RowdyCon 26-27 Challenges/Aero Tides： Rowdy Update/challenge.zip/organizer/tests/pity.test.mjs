import test from "node:test";
import assert from "node:assert/strict";
import {
  LEGENDARY_ID, NONLEGENDARY_SPACE, ROLL_SPACE, ROWDYS,
  drawRowdy, pityStatus, publicCatalog
} from "../../challenge/server/catalog.mjs";

test("pity adds one percentage point per miss and caps at 100 percent", () => {
  for (const [misses, chance] of [[0, 0.0067], [1, 0.0167], [2, 0.0267], [99, 0.9967], [100, 1], [500, 1]]) {
    assert.equal(pityStatus(misses).legendaryChance, chance);
    assert.equal(pityStatus(misses).misses, misses);
  }
  for (const value of [-1, 1.2, NaN, Infinity, "1", Number.MAX_SAFE_INTEGER + 1]) {
    assert.throws(() => pityStatus(value), RangeError);
  }
});

test("every integer gate outcome produces the exact pity threshold", () => {
  for (const misses of [0, 1, 2, 50, 99, 100, 500]) {
    let legendary = 0;
    for (let gate = 0; gate < ROLL_SPACE; gate += 1) {
      let calls = 0;
      const rowdy = drawRowdy(misses, (minimum, maximum) => {
        assert.equal(minimum, 0);
        calls += 1;
        assert.equal(maximum, calls === 1 ? ROLL_SPACE : NONLEGENDARY_SPACE);
        return calls === 1 ? gate : 0;
      });
      if (rowdy.id === LEGENDARY_ID) {
        legendary += 1;
        assert.equal(calls, 1);
      } else {
        assert.equal(calls, 2);
      }
    }
    assert.equal(legendary, Math.min(10_000, 67 + 100 * misses));
  }
});

test("the second independent draw preserves every nonlegendary weight", () => {
  for (const misses of [0, 1, 99]) {
    const observed = new Map(ROWDYS.filter((rowdy) => rowdy.id !== LEGENDARY_ID).map((rowdy) => [rowdy.id, 0]));
    for (let roll = 0; roll < NONLEGENDARY_SPACE; roll += 1) {
      let calls = 0;
      const rowdy = drawRowdy(misses, () => (++calls === 1 ? 9_999 : roll));
      observed.set(rowdy.id, observed.get(rowdy.id) + 1);
    }
    for (const rowdy of ROWDYS.filter((rowdy) => rowdy.id !== LEGENDARY_ID)) {
      assert.equal(observed.get(rowdy.id), rowdy.weight);
    }
  }
});

test("published next-pull rates sum to one and retain conditional ratios", () => {
  for (const misses of [0, 1, 5, 99, 100, 500]) {
    const catalog = publicCatalog(misses);
    const legendary = catalog.find((rowdy) => rowdy.id === LEGENDARY_ID);
    assert.equal(legendary.chance, pityStatus(misses).legendaryChance);
    assert.ok(Math.abs(catalog.reduce((sum, rowdy) => sum + rowdy.chance, 0) - 1) < 1e-12);
    for (const rowdy of catalog.filter((rowdy) => rowdy.id !== LEGENDARY_ID)) {
      assert.equal(rowdy.baseChance, rowdy.weight / ROLL_SPACE);
      if (misses === 0) assert.ok(Math.abs(rowdy.chance - rowdy.baseChance) < 1e-15);
      if (legendary.chance === 1) assert.equal(rowdy.chance, 0);
      else assert.ok(Math.abs(rowdy.chance / (1 - legendary.chance) - rowdy.weight / NONLEGENDARY_SPACE) < 1e-12);
    }
  }
});
