import test from "node:test";
import assert from "node:assert/strict";
import { readFile, readdir } from "node:fs/promises";
import { join } from "node:path";

test("the web source does not contain the real flag environment name or development flag", async () => {
  const webFiles = [
    join("web", "index.html"),
    join("web", "src", "main.jsx"),
    join("web", "src", "styles.css")
  ];
  for (const file of webFiles) {
    const content = await readFile(file, "utf8");
    assert.equal(content.includes("CTF_FLAG"), false, file);
    assert.equal(content.includes("local_development_only"), false, file);
  }
});

test("every catalog id has a card and sprite asset", async () => {
  const cards = new Set(await readdir(join("web", "public", "assets", "cards")));
  const sprites = new Set(await readdir(join("web", "public", "assets", "sprites")));
  for (const id of ["classic", "nature", "sky", "bubble", "vacation", "globe", "cyber", "surf", "ocean", "dolphin"]) {
    assert.ok(cards.has(`${id}.png`), `missing card for ${id}`);
    assert.ok(sprites.has(`${id}.png`), `missing sprite for ${id}`);
  }
});

test("the player-facing image contains no source map directive", async () => {
  const source = await readFile(join("web", "src", "main.jsx"), "utf8");
  assert.equal(source.includes("sourceMappingURL"), false);
});
