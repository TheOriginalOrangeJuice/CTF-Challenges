import test from "node:test";
import assert from "node:assert/strict";
import {
  LEGENDARY_ID,
  ROLL_SPACE,
  ROWDYS,
  publicCatalog,
  rowdyForRoll,
  summonMessage
} from "../../challenge/server/catalog.mjs";

test("the weight table fills the complete roll space", () => {
  assert.equal(ROWDYS.reduce((total, rowdy) => total + rowdy.weight, 0), ROLL_SPACE);
});

test("all 10,000 integer outcomes map to the exact published weights", () => {
  const observed = new Map(ROWDYS.map((rowdy) => [rowdy.id, 0]));
  for (let roll = 0; roll < ROLL_SPACE; roll += 1) {
    const rowdy = rowdyForRoll(roll);
    observed.set(rowdy.id, observed.get(rowdy.id) + 1);
  }
  for (const rowdy of ROWDYS) assert.equal(observed.get(rowdy.id), rowdy.weight, rowdy.id);
});

test("the legendary range is exactly 67 values, or 0.67 percent", () => {
  const legendary = Array.from({ length: ROLL_SPACE }, (_, roll) => rowdyForRoll(roll))
    .filter((rowdy) => rowdy.id === LEGENDARY_ID);
  assert.equal(legendary.length, 67);
  assert.equal(legendary.length / ROLL_SPACE, 0.0067);
});

test("invalid roll values are rejected", () => {
  for (const value of [-1, ROLL_SPACE, 1.2, Number.NaN]) {
    assert.throws(() => rowdyForRoll(value), RangeError);
  }
});

test("only Dolphin Rowdy receives the runtime flag", () => {
  const flag = "RCC{unit_test_secret}";
  for (const rowdy of ROWDYS) {
    const message = summonMessage(rowdy, flag);
    assert.equal(message.includes(flag), rowdy.id === LEGENDARY_ID, rowdy.id);
  }
});

test("public catalog exposes exact rates but no summon messages", () => {
  const catalog = publicCatalog();
  assert.equal(catalog.length, 10);
  assert.ok(Math.abs(catalog.reduce((total, rowdy) => total + rowdy.chance, 0) - 1) < Number.EPSILON * 2);
  assert.ok(catalog.every((rowdy) => !("message" in rowdy)));
});
