// Original Aero Tides score: 16 bars in D major, 96 BPM, composed for this game.
// Rendered locally once. Release tails wrap into the opening for a true loop.
export const MUSIC_SECONDS = 40;

export async function renderMusic(sampleRate = 44100) {
  const Offline = window.OfflineAudioContext || window.webkitOfflineAudioContext;
  if (!Offline) return null;
  const context = new Offline(2, Math.ceil(45 * sampleRate), sampleRate);
  const mix = context.createGain();
  mix.gain.value = 0.62;
  mix.connect(context.destination);
  const echo = context.createDelay(1);
  echo.delayTime.value = 0.46875;
  const feedback = context.createGain();
  feedback.gain.value = 0.21;
  echo.connect(feedback).connect(echo);
  const wet = context.createGain();
  wet.gain.value = 0.21;
  echo.connect(wet).connect(mix);
  const hz = (note) => 440 * 2 ** ((note - 69) / 12);
  function voice(note, start, length, level, type = "sine", pan = 0, attack = 0.012, detune = 0, echoes = true) {
    const oscillator = context.createOscillator();
    const envelope = context.createGain();
    const stereo = context.createStereoPanner();
    oscillator.type = type;
    oscillator.frequency.value = hz(note);
    oscillator.detune.value = detune;
    stereo.pan.value = pan;
    envelope.gain.setValueAtTime(0, start);
    envelope.gain.linearRampToValueAtTime(level, start + attack);
    envelope.gain.exponentialRampToValueAtTime(0.00001, start + length);
    envelope.gain.setValueAtTime(0, start + length + 0.005);
    oscillator.connect(envelope).connect(stereo).connect(mix);
    if (echoes) stereo.connect(echo);
    oscillator.start(start);
    oscillator.stop(start + length + 0.01);
  }
  function bell(note, at, level, pan) {
    voice(note, at, 1.8, level, "sine", pan);
    voice(note + 12, at, 0.6, level * 0.2, "sine", -pan, 0.004, 4);
    voice(note + 19, at, 0.25, level * 0.055, "sine", pan, 0.003);
  }
  let seed = 0x41545231;
  const noise = context.createBuffer(1, Math.ceil(sampleRate * 0.11), sampleRate);
  const noiseData = noise.getChannelData(0);
  for (let i = 0; i < noiseData.length; i++) {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    noiseData[i] = (seed / 2147483648 - 1) * (1 - i / noiseData.length) ** 3;
  }
  function brush(at, accent = false) {
    const source = context.createBufferSource();
    const filter = context.createBiquadFilter();
    const gain = context.createGain();
    source.buffer = noise;
    filter.type = "highpass";
    filter.frequency.value = accent ? 3200 : 6200;
    gain.gain.value = accent ? 0.025 : 0.012;
    source.connect(filter).connect(gain).connect(mix);
    source.start(at);
  }
  const chords = [[50, 57, 61, 64, 69], [45, 57, 59, 64, 69], [47, 54, 57, 62, 66], [43, 55, 59, 62, 66]];
  const phrases = [
    [[0,78],[1.5,81],[2.5,76]], [[0.5,76],[2,73],[3,71]],
    [[0,74],[1,78],[2.5,81]], [[0.5,79],[2,78],[3.5,74]],
    [[0,78],[1.5,76],[2.5,73],[3.5,76]], [[0.5,81],[2,83],[3,81]],
    [[0,78],[1.5,74],[3,73]], [[0.5,71],[2,74],[3,76]]
  ];
  const beat = 0.625;
  for (let bar = 0; bar < 16; bar++) {
    const start = bar * 4 * beat;
    const chord = chords[Math.floor(bar / 2) % 4];
    chord.slice(1).forEach((note, i) => {
      voice(note, start, 4.9, 0.036, "sine", (i - 1.5) * 0.32, 0.65, i % 2 ? 3 : -3);
      voice(note, start, 4.1, 0.009, "triangle", (1.5 - i) * 0.3, 0.8);
    });
    for (const [offset, note] of phrases[bar % 8]) {
      bell(note + (bar >= 8 && bar % 4 === 2 ? 12 : 0), start + offset * beat, 0.06, bar % 2 ? 0.24 : -0.24);
    }
    if (bar >= 8) bell(chord[3] + 12, start + 2.75 * beat, 0.026, -0.35);
    [0, 2.5].forEach((offset, i) => voice(chord[0] + (i ? 12 : 0), start + offset * beat, 0.62, 0.09, "triangle", 0, 0.008, 0, false));
    [0, 1, 2, 3].forEach((offset) => {
      brush(start + (offset + 0.5) * beat);
      if (offset % 2) brush(start + offset * beat, true);
    });
    voice(31, start, 0.17, 0.06, "sine", 0, 0.003, 0, false);
  }
  const rendered = await context.startRendering();
  const frames = Math.round(MUSIC_SECONDS * sampleRate);
  const loop = new AudioBuffer({ numberOfChannels: 2, length: frames, sampleRate });
  let peak = 0;
  for (let channel = 0; channel < 2; channel++) {
    const source = rendered.getChannelData(channel);
    const output = loop.getChannelData(channel);
    output.set(source.subarray(0, frames));
    for (let frame = frames; frame < source.length; frame++) output[frame - frames] += source[frame];
    for (const sample of output) peak = Math.max(peak, Math.abs(sample));
  }
  const scale = peak > 0.6 ? 0.6 / peak : 1;
  for (let channel = 0; channel < 2; channel++) {
    const output = loop.getChannelData(channel);
    for (let frame = 0; frame < frames; frame++) output[frame] *= scale;
  }
  return loop;
}
