import { renderMusic } from "./audio-score.js";

// One mixer survives navigation, sign-in, sign-out, and React effect remounts.
let context, master, effects, music, musicSource, musicBuffer, rendering;
let settings = { muted: false, volume: 0.55, music: true, musicVolume: 0.3 };
let unlocked = false;
let previewAt = 0;
const voices = new Set();

function applyGains() {
  if (!context) return;
  const now = context.currentTime;
  for (const [node, value] of [[master, settings.muted ? 0 : settings.volume], [music, settings.music ? settings.musicVolume : 0]]) {
    node.gain.cancelAndHoldAtTime(now);
    node.gain.linearRampToValueAtTime(value, now + 0.008);
  }
}

function startMusic() {
  if (musicSource || !musicBuffer || !context || !unlocked) return;
  musicSource = context.createBufferSource();
  musicSource.buffer = musicBuffer;
  musicSource.loop = true;
  musicSource.connect(music);
  musicSource.start();
}

function unlock() {
  const Audio = window.AudioContext || window.webkitAudioContext;
  if (!Audio) return;
  if (!context) {
    context = new Audio();
    master = context.createGain();
    effects = context.createGain();
    music = context.createGain();
    effects.connect(master);
    music.connect(master);
    const limiter = context.createDynamicsCompressor();
    limiter.threshold.value = -8;
    limiter.knee.value = 8;
    limiter.ratio.value = 12;
    limiter.attack.value = 0.003;
    limiter.release.value = 0.12;
    master.connect(limiter).connect(context.destination);
    applyGains();
  }
  unlocked = true;
  if (document.visibilityState !== "hidden" && context.state !== "running") context.resume().catch(() => {});
  if (!rendering) {
    rendering = renderMusic(context.sampleRate).then((buffer) => {
      musicBuffer = buffer;
      startMusic();
    }).catch(() => { /* Effects still work if offline rendering is unavailable. */ });
  }
}

// Glass/bell palette; each action or outcome has its own melodic contour.
const cues = {
  tap: [[880, 0, 0.11, 0.07], [1320, 0.018, 0.09, 0.018]],
  nav: [[659, 0, 0.13, 0.065], [988, 0.045, 0.15, 0.045]],
  open: [[587, 0, 0.17, 0.06], [880, 0.06, 0.21, 0.05]],
  close: [[880, 0, 0.13, 0.05], [587, 0.055, 0.15, 0.045]],
  submit: [[440, 0, 0.16, 0.06], [659, 0.055, 0.19, 0.05], [880, 0.11, 0.19, 0.04]],
  success: [[659, 0, 0.24, 0.065], [831, 0.09, 0.27, 0.055], [1109, 0.18, 0.35, 0.055]],
  error: [[392, 0, 0.18, 0.055], [330, 0.12, 0.23, 0.055]],
  info: [[587, 0, 0.2, 0.055], [740, 0.09, 0.24, 0.045]],
  toggle: [[784, 0, 0.12, 0.06], [1047, 0.05, 0.13, 0.035]],
  slider: [[784, 0, 0.075, 0.045]],
  copy: [[1047, 0, 0.14, 0.05], [1568, 0.065, 0.22, 0.04]],
  signout: [[880, 0, 0.21, 0.05], [659, 0.09, 0.25, 0.045], [440, 0.18, 0.3, 0.04]],
  fullscreen: [[523, 0, 0.18, 0.055], [1047, 0.09, 0.25, 0.05]],
  tick: [[1175, 0, 0.055, 0.045], [1762, 0, 0.04, 0.012]],
  common: [[523, 0, 0.25, 0.07], [659, 0.13, 0.3, 0.06]],
  rare: [[587, 0, 0.3, 0.07], [740, 0.12, 0.35, 0.06], [1175, 0.24, 0.48, 0.055]],
  epic: [[440, 0, 0.4, 0.07], [659, 0.12, 0.45, 0.06], [880, 0.24, 0.55, 0.06], [1319, 0.36, 0.65, 0.05]],
  legendary: [[392, 0, 0.55, 0.07], [523, 0.12, 0.6, 0.065], [659, 0.24, 0.65, 0.06], [784, 0.36, 0.7, 0.055], [1047, 0.48, 0.85, 0.055], [1319, 0.6, 1, 0.045]]
};

function play(kind = "tap") {
  if (!context || !unlocked || settings.muted || settings.volume <= 0 || document.visibilityState === "hidden") return;
  const notes = cues[kind] ?? cues.tap;
  const now = context.currentTime;
  while (voices.size + notes.length > 32) {
    const oldest = voices.values().next().value;
    oldest.stop();
    voices.delete(oldest);
  }
  for (const [frequency, delay, duration, level] of notes) {
    const source = context.createOscillator();
    const envelope = context.createGain();
    const start = now + delay;
    source.type = "sine";
    source.frequency.value = frequency;
    envelope.gain.setValueAtTime(0, start);
    envelope.gain.linearRampToValueAtTime(level, start + 0.004);
    envelope.gain.exponentialRampToValueAtTime(0.00001, start + duration);
    envelope.gain.setValueAtTime(0, start + duration + 0.004);
    source.connect(envelope).connect(effects);
    source.start(start);
    source.stop(start + duration + 0.01);
    voices.add(source);
    source.onended = () => { voices.delete(source); source.disconnect(); envelope.disconnect(); };
  }
}

export const audio = {
  configure(next) { settings = next; applyGains(); },
  play,
  preview() {
    unlock();
    if (performance.now() - previewAt > 90) { previewAt = performance.now(); play("slider"); }
  },
  attach() {
    function controlClick(event) {
      const button = event.target.closest?.("button, a[href]");
      if (!button || button.matches(":disabled, [aria-disabled='true']") || button.closest("[inert]")) return;
      unlock();
      if (button.dataset.sound === "none" || (button.tagName === "BUTTON" && button.type === "submit" && button.form)) return;
      play(button.dataset.sound ?? (button.closest("nav") ? "nav" : "tap"));
    }
    function submit() { unlock(); play("submit"); }
    function change(event) {
      if (event.target.matches("select:not(:disabled)")) { unlock(); play("toggle"); }
    }
    function visibility() {
      if (!context || !unlocked) return;
      if (document.visibilityState === "hidden") {
        for (const voice of voices) voice.stop();
        voices.clear();
        context.suspend().catch(() => {});
      } else context.resume().catch(() => {});
    }
    document.addEventListener("click", controlClick, true);
    document.addEventListener("submit", submit, true);
    document.addEventListener("change", change, true);
    document.addEventListener("visibilitychange", visibility);
    return () => {
      document.removeEventListener("click", controlClick, true);
      document.removeEventListener("submit", submit, true);
      document.removeEventListener("change", change, true);
      document.removeEventListener("visibilitychange", visibility);
    };
  }
};
