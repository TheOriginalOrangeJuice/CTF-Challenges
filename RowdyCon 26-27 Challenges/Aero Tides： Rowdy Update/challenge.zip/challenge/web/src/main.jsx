import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";
import { audio } from "./audio.js";

const NAV_ITEMS = [
  ["summon", "Summon"],
  ["collection", "Collection"],
  ["history", "History"],
  ["card", "Player Card"],
  ["odds", "Drop Rates"],
  ["settings", "Settings"]
];

const DEFAULT_SETTINGS = { muted: false, volume: 0.55, music: true, musicVolume: 0.3, reducedMotion: false };

function readSettings() {
  const defaults = { ...DEFAULT_SETTINGS, reducedMotion: window.matchMedia("(prefers-reduced-motion: reduce)").matches };
  try {
    const saved = JSON.parse(localStorage.getItem("rowdy-settings") ?? "{}");
    return {
      muted: typeof saved?.muted === "boolean" ? saved.muted : defaults.muted,
      volume: typeof saved?.volume === "number" ? Math.min(1, Math.max(0, saved.volume)) : defaults.volume,
      music: typeof saved?.music === "boolean" ? saved.music : defaults.music,
      musicVolume: typeof saved?.musicVolume === "number" ? Math.min(1, Math.max(0, saved.musicVolume)) : defaults.musicVolume,
      reducedMotion: typeof saved?.reducedMotion === "boolean" ? saved.reducedMotion : defaults.reducedMotion
    };
  } catch {
    return defaults;
  }
}

function Modal({ onDismiss, children, ...props }) {
  const dialogRef = useRef(null);
  const dismissRef = useRef(onDismiss);
  dismissRef.current = onDismiss;

  useLayoutEffect(() => {
    const dialog = dialogRef.current;
    const previousFocus = document.activeElement;
    const siblings = Array.from(dialog.parentElement.children)
      .filter((element) => element !== dialog)
      .map((element) => [element, element.inert]);
    const previousOverflow = document.body.style.overflow;
    const focusable = () => Array.from(dialog.querySelectorAll(
      'button:not(:disabled), input:not(:disabled), textarea:not(:disabled), select:not(:disabled), a[href], [tabindex]:not([tabindex="-1"])'
    )).filter((element) => element.tabIndex >= 0 && element.getClientRects().length > 0);
    const focusDialog = () => (dialog.querySelector("[data-modal-autofocus]") ?? dialog).focus();
    focusDialog();
    siblings.forEach(([element]) => { element.inert = true; });
    document.body.style.overflow = "hidden";

    function onKeyDown(event) {
      if (event.key === "Escape") {
        event.preventDefault();
        event.stopPropagation();
        if (dismissRef.current) { audio.play("close"); dismissRef.current(); }
      } else if (event.key === "Tab") {
        const controls = focusable();
        const currentIndex = controls.indexOf(document.activeElement);
        if (!controls.length || currentIndex === -1 ||
            (event.shiftKey && currentIndex === 0) ||
            (!event.shiftKey && currentIndex === controls.length - 1)) {
          event.preventDefault();
          (controls[event.shiftKey ? controls.length - 1 : 0] ?? dialog).focus();
        }
      }
    }
    function onFocus(event) {
      if (!dialog.contains(event.target)) focusDialog();
    }
    document.addEventListener("keydown", onKeyDown, true);
    document.addEventListener("focusin", onFocus);
    return () => {
      document.removeEventListener("keydown", onKeyDown, true);
      document.removeEventListener("focusin", onFocus);
      siblings.forEach(([element, wasInert]) => { element.inert = wasInert; });
      document.body.style.overflow = previousOverflow;
      if (previousFocus?.isConnected) previousFocus.focus();
    };
  }, []);

  return <div {...props} ref={dialogRef} role="dialog" aria-modal="true" tabIndex={-1}>{children}</div>;
}

async function api(path, options = {}, csrfToken) {
  const headers = { Accept: "application/json", ...(options.headers ?? {}) };
  if (options.body !== undefined) headers["Content-Type"] = "application/json";
  if (csrfToken) headers["X-CSRF-Token"] = csrfToken;
  const response = await fetch(path, { credentials: "same-origin", ...options, headers });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(payload.message ?? "The Aero Network did not respond.");
    error.status = response.status;
    error.code = payload.error;
    throw error;
  }
  return payload;
}

function encodeBase64(value) {
  const bytes = new TextEncoder().encode(value);
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

function formatChance(chance) {
  return `${(chance * 100).toFixed(2)}%`;
}

function formatDate(value) {
  if (!value) return "Unknown tide";
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit"
  }).format(new Date(value));
}

function BubbleField() {
  return <div className="bubble-field" aria-hidden="true">
    {Array.from({ length: 16 }, (_, index) => <i key={index} style={{ "--i": index }} />)}
  </div>;
}

function Brand({ compact = false }) {
  return <div className={`brand ${compact ? "brand--compact" : ""}`}>
    <span className="brand__utsa">UTSA</span>
    <span className="brand__rowdy">ROWDY</span>
    <span className="brand__sub">GACHA COLLECTION</span>
  </div>;
}

function updateAudio(settings, setSettings, patch, preview = false) {
  const next = { ...settings, ...patch };
  audio.configure(next);
  setSettings(next);
  if (preview) audio.preview();
  else audio.play("toggle");
}

function LandingAudio({ settings, setSettings }) {
  return <div className="landing-audio" aria-label="Game audio controls">
    <button type="button" data-sound="none" aria-label="Game audio" aria-pressed={!settings.muted} onClick={() => updateAudio(settings, setSettings, { muted: !settings.muted })}><span aria-hidden="true">♫</span> Sound {settings.muted ? "off" : "on"}</button>
    <button type="button" data-sound="none" aria-label="Background music" aria-pressed={settings.music} onClick={() => updateAudio(settings, setSettings, { music: !settings.music })}>Music {settings.music ? "on" : "off"}</button>
  </div>;
}

function Landing({ onLogin, loading, settings, setSettings }) {
  const [loginOpen, setLoginOpen] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setSubmitting(true);
    setError("");
    try {
      await onLogin(username, password);
    } catch (err) {
      setError(err.message);
      audio.play("error");
    } finally {
      setSubmitting(false);
    }
  }

  return <main className={`landing ${settings.reducedMotion ? "reduce-motion" : ""}`}>
    <BubbleField />
    <section className="landing__chrome">
      <Brand />
      <div className="landing__tools"><span className="live-pill"><i /> EVENT LIVE</span><LandingAudio settings={settings} setSettings={setSettings} /></div>
    </section>
    <section className="event-hero">
      <div className="event-hero__copy">
        <p className="eyebrow">LIMITED SUMMON SHOWCASE</p>
        <h1>AERO TIDES</h1>
        <h2>Rowdy Ascension</h2>
        <p>Ten forms. One sparkling lagoon. Summon campus legends and chase the impossible golden tide.</p>
        <div className="event-chips">
          <span>10 ROWDYS</span><span>NEW REVEALS</span><span>0.67% BASE LEGENDARY</span>
        </div>
        <button className="summon-cta" data-sound="open" onClick={() => setLoginOpen(true)} disabled={loading}>
          <span>ENTER EVENT</span><small>Sign in to start summoning</small>
        </button>
      </div>
      <figure className="event-poster">
        <div className="event-poster__shine" />
        <img src="/assets/event-banner.png" alt="Ten collectible Rowdy forms in the Aero Tides event" />
        <figcaption>FEATURED COLLECTION · AERO TIDES</figcaption>
      </figure>
    </section>
    <section className="landing__features" aria-label="Event features">
      <article><b>✦</b><div><strong>DISCOVER</strong><span>Unlock ten illustrated Rowdy forms</span></div></article>
      <article><b>◉</b><div><strong>COLLECT</strong><span>Track every summon and first encounter</span></div></article>
      <article><b>≈</b><div><strong>ASCEND</strong><span>Break through the legendary golden tide</span></div></article>
    </section>

    {loginOpen && <Modal className="modal-shell" aria-labelledby="login-title" onDismiss={() => setLoginOpen(false)}>
      <button className="modal-shell__backdrop" data-sound="close" tabIndex={-1} onClick={() => setLoginOpen(false)} aria-label="Close sign in" />
      <form className="login-card glass-panel" onSubmit={submit}>
        <button type="button" className="icon-close" data-sound="close" onClick={() => setLoginOpen(false)} aria-label="Close">×</button>
        <span className="login-orb">✦</span>
        <p className="eyebrow">PLAYER GATEWAY</p>
        <h2 id="login-title">Welcome to Aero Tides</h2>
        <label>USERNAME<input data-modal-autofocus autoComplete="username" value={username} onChange={(e) => setUsername(e.target.value)} /></label>
        <label>PASSWORD<input type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} /></label>
        {error && <p className="form-error" role="alert">{error}</p>}
        <button className="primary-button" disabled={submitting}>{submitting ? "CONNECTING…" : "SIGN IN"}</button>
        <small>Your player data is bound to this event instance.</small>
        <LandingAudio settings={settings} setSettings={setSettings} />
      </form>
    </Modal>}
  </main>;
}

function Topbar({ data, settings, onSettings, onLogout }) {
  return <header className="topbar">
    <Brand compact />
    <div className="topbar__right">
      <div className="wallet-pill" title={`Aero Gem vault capacity: ${data.walletCap.toLocaleString()}`}>
        <span className="gem-icon">◆</span><div><small>AERO GEMS</small><strong>{data.balance.toLocaleString()}</strong></div>
      </div>
      <button className="round-button" data-sound="nav" onClick={onSettings} aria-label="Open settings">{settings.muted ? "♩̸" : "♫"}</button>
      <button className="player-pill" data-sound="signout" onClick={onLogout} aria-label={`Sign out ${data.player.username}`} title={`Sign out ${data.player.username}`}><span>{data.player.username.slice(0, 1).toUpperCase()}</span>{data.player.username}</button>
    </div>
  </header>;
}

function Sidebar({ active, setActive }) {
  return <nav className="game-nav" aria-label="Game menu">
    {NAV_ITEMS.map(([id, label], index) => <button key={id} className={active === id ? "active" : ""} aria-current={active === id ? "page" : undefined} onClick={() => setActive(id)}>
      <span className="nav-glyph" aria-hidden="true">{["✦", "◇", "◷", "▣", "%", "⚙"][index]}</span><span>{label}</span>
    </button>)}
  </nav>;
}

function weightedVisualPick(catalog) {
  const rollSpace = catalog.reduce((total, rowdy) => total + rowdy.weight, 0);
  const value = crypto.getRandomValues(new Uint32Array(1))[0] % rollSpace;
  let cursor = 0;
  for (const rowdy of catalog) {
    cursor += rowdy.weight;
    if (value < cursor) return rowdy;
  }
  return catalog[0];
}

function ReelOverlay({ result, catalog, settings, onLanded }) {
  const trackRef = useRef(null);
  const viewportRef = useRef(null);
  const targetIndex = 37;
  const items = useMemo(() => {
    const list = Array.from({ length: 48 }, () => weightedVisualPick(catalog));
    list[targetIndex] = catalog.find((item) => item.id === result.rowdyId);
    return list;
  }, [catalog, result]);

  useEffect(() => {
    const play = audio.play;
    const tick = setInterval(() => play("tick"), 470);
    const frame = requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        const track = trackRef.current;
        const viewport = viewportRef.current;
        const target = track?.children[targetIndex];
        if (!track || !viewport || !target) return;
        const travel = target.offsetLeft - (viewport.clientWidth - target.clientWidth) / 2;
        track.style.transform = `translate3d(${-travel}px,0,0)`;
      });
    });
    const timer = setTimeout(() => {
      clearInterval(tick);
      play(result.rarity);
      onLanded();
    }, 5600);
    return () => { cancelAnimationFrame(frame); clearInterval(tick); clearTimeout(timer); };
  }, [onLanded, result]);

  return <Modal className={`reel-overlay ${settings.reducedMotion ? "reduced" : ""}`} aria-label="Summon in progress">
    <div className="reel-title"><span>SUMMON GATE</span><b>Synchronizing Aero resonance…</b></div>
    <div className="reel-viewport" ref={viewportRef}>
      <div className="reel-marker reel-marker--top" /><div className="reel-marker reel-marker--bottom" />
      <div className="reel-track" ref={trackRef}>
        {items.map((item, index) => <article className={`reel-item rarity-${item.rarity}`} key={`${index}-${item.id}`}>
          <img src={item.card} alt="" /><span>{item.name}</span>
        </article>)}
      </div>
    </div>
    <div className="reel-progress"><i /></div>
    <p>Every summon is decided securely by the Aero Gate.</p>
  </Modal>;
}

function RevealOverlay({ result, catalog, onClose }) {
  const [copyStatus, setCopyStatus] = useState("");
  const [manualCopy, setManualCopy] = useState(false);
  const messageRef = useRef(null);
  const rowdy = catalog.find((item) => item.id === result.rowdyId);

  useEffect(() => {
    if (manualCopy) { messageRef.current?.focus(); messageRef.current?.select(); }
  }, [manualCopy]);

  async function copyMessage() {
    try {
      if (!navigator.clipboard?.writeText) throw new Error("Clipboard unavailable");
      await navigator.clipboard.writeText(result.message);
      setManualCopy(false);
      setCopyStatus("Message copied.");
      audio.play("copy");
    } catch {
      setManualCopy(true);
      audio.play("info");
      setCopyStatus("Automatic copying is unavailable. Select the message below and copy it with your browser or keyboard.");
      messageRef.current?.focus();
      messageRef.current?.select();
    }
  }

  return <Modal className={`reveal-overlay rarity-${result.rarity}`} data-rowdy={result.rowdyId} aria-labelledby="reveal-name" onDismiss={onClose}>
    <div className="reveal-backdrop" />
    <div className="reveal-rings" aria-hidden="true"><i /><i /><i /></div>
    <div className="reveal-particles" aria-hidden="true">
      {Array.from({ length: 24 }, (_, index) => <i key={index} style={{ "--i": index }} />)}
    </div>
    <section className="reveal-card">
      {result.isNew && <span className="new-ribbon">FIRST DISCOVERY!</span>}
      <p className="rarity-label">{result.rarity.toUpperCase()}</p>
      <div className="reveal-art"><img src={rowdy.sprite} alt={rowdy.name} /></div>
      <h2 id="reveal-name">{rowdy.name}</h2>
      <div className="stars">{result.rarity === "legendary" ? "★★★★★★" : result.rarity === "epic" ? "★★★" : result.rarity === "rare" ? "★★" : "★"}</div>
      <blockquote>{result.message}</blockquote>
      <div className="reveal-actions">
        <button className="secondary-button" onClick={copyMessage}>COPY MESSAGE</button>
        <button className="primary-button" data-sound="close" onClick={onClose}>CONTINUE</button>
      </div>
      <p className="control-status" role="status">{copyStatus}</p>
      {manualCopy && <label className="copy-fallback">MESSAGE<textarea ref={messageRef} readOnly value={result.message} onFocus={(event) => event.target.select()} /></label>}
    </section>
  </Modal>;
}

function SummonPanel({ data, onPull, pulling, goToCard }) {
  const canPull = data.balance >= data.pullPrice;
  return <section className="summon-screen page-enter">
    <div className="mini-event-banner">
      <img src="/assets/event-banner.png" alt="Aero Tides featured collection" />
      <div className="mini-event-banner__copy">
        <p className="eyebrow">FEATURED EVENT</p><h1>AERO TIDES</h1><span>ROWDY ASCENSION</span>
        <small>Legendary Dolphin Rowdy · {formatChance(data.pity.legendaryChance)} next pull</small>
      </div>
      <i className="banner-glare" />
    </div>
    <div className="summon-console glass-panel">
      <div className="summon-console__status">
        <span>SUMMON GATE</span><b className={canPull ? "online" : "offline"}>{canPull ? "READY" : "LOW RESERVES"}</b>
      </div>
      <div className="summon-orb" aria-hidden="true"><i /><span>✦</span></div>
      <h2>{canPull ? "The Aero Gate is resonating" : "Not enough Aero Gems"}</h2>
      <p>{canPull ? "Commit 100 gems to summon one event Rowdy." : `A summon costs ${data.pullPrice} gems. Your reserve currently holds ${data.balance}.`}</p>
      <p aria-live="polite"><strong>Next legendary: {formatChance(data.pity.legendaryChance)}</strong> · {data.pity.misses} {data.pity.misses === 1 ? "pull" : "pulls"} without a legendary</p>
      <button className="roll-button" data-sound="submit" disabled={!canPull || pulling} onClick={onPull}>
        <span>{pulling ? "OPENING GATE…" : "ROLL ×1"}</span><small><b>◆</b> {data.pullPrice}</small>
      </button>
      {!canPull && <button className="text-button" onClick={goToCard}>Review Player Card</button>}
    </div>
    <div className="summon-notes">
      <span><b>PITY</b> Each pull without a legendary adds 1 percentage point, up to 100%. A legendary resets the chance to 0.67%.</span>
      <span><b>VAULT CAP</b> Maximum reserve: {data.walletCap.toLocaleString()} gems.</span>
    </div>
  </section>;
}

function CollectionPanel({ data }) {
  const owned = new Map(data.collection.map((item) => [item.rowdyId, item]));
  return <section className="page-enter">
    <div className="section-heading"><div><p className="eyebrow">AERO ARCHIVE</p><h1>Rowdy Collection</h1></div><span className="completion-ring">{owned.size}<small>/10</small></span></div>
    <div className="collection-grid">
      {data.catalog.map((rowdy) => {
        const record = owned.get(rowdy.id);
        return <article key={rowdy.id} className={`collection-card rarity-${rowdy.rarity} ${record ? "owned" : "locked"}`}>
          <div className="collection-card__art"><img src={rowdy.card} alt={record ? rowdy.name : "Undiscovered Rowdy"} /></div>
          <div><span>{record ? rowdy.rarity.toUpperCase() : "UNKNOWN"}</span><h3>{record ? rowdy.name : "??? Rowdy"}</h3>
            <small>{record ? `Pulled ${record.pullCount}× · ${formatDate(record.firstPulledAt)}` : "Awaiting discovery"}</small></div>
        </article>;
      })}
    </div>
  </section>;
}

function HistoryPanel({ data }) {
  return <section className="page-enter">
    <div className="section-heading"><div><p className="eyebrow">SUMMON LOG</p><h1>Recent Pulls</h1></div><span className="counter-chip">LAST 100</span></div>
    {data.history.length === 0 ? <div className="empty-state glass-panel"><b>◷</b><h2>No summon history yet</h2><p>Your first Rowdy will appear here.</p></div> :
      <div className="history-list">{data.history.map((pull, index) => {
        const rowdy = data.catalog.find((item) => item.id === pull.rowdyId);
        return <article key={pull.pullId} className={`history-row rarity-${pull.rarity}`}>
          <span className="history-number">#{data.history.length - index}</span><img src={rowdy.card} alt="" />
          <div><small>{pull.rarity.toUpperCase()} {pull.isNew && "· FIRST DISCOVERY"}</small><h3>{pull.name}</h3><p>{pull.message}</p></div>
          <time>{formatDate(pull.pulledAt)}</time>
        </article>;
      })}</div>}
  </section>;
}

function PlayerCardPanel({ data, onRefresh, toast }) {
  const [motto, setMotto] = useState(data.playerCard.motto ?? "Birds up! The tide is calling.");
  const [frame, setFrame] = useState(data.playerCard.frame ?? "aero");
  const [busy, setBusy] = useState(false);
  const [sync, setSync] = useState(null);

  async function save() {
    if (!motto.trim()) return toast("Write a motto before saving.", "error");
    setBusy(true);
    try {
      await api("/api/player-card", {
        method: "PUT",
        body: JSON.stringify({ mottoToken: encodeBase64(motto), frame })
      }, data.csrfToken);
      toast("Player Card saved to your event profile.");
      await onRefresh();
    } catch (error) { toast(error.message, "error"); }
    finally { setBusy(false); }
  }

  async function synchronize() {
    setBusy(true);
    try {
      const result = await api("/api/player-card/sync", { method: "POST" }, data.csrfToken);
      setSync(result);
      toast(result.message, result.status === "AERO_SYNCED" ? "success" : "info");
      await onRefresh();
    } catch (error) { toast(error.message, "error"); }
    finally { setBusy(false); }
  }

  return <section className="page-enter">
    <div className="section-heading"><div><p className="eyebrow">PLAYER IDENTITY</p><h1>Event Player Card</h1></div><span className="counter-chip">AERO NETWORK</span></div>
    <div className="card-editor-grid">
      <div className={`profile-preview frame-${frame}`}>
        <span className="profile-preview__badge">EVENT PLAYER</span><div className="profile-avatar">{data.player.username[0].toUpperCase()}</div>
        <h2>{data.player.username}</h2><blockquote>“{motto || "Your motto appears here."}”</blockquote>
        <div className="profile-stats"><span><b>{data.collection.length}</b> DISCOVERED</span><span><b>{data.history.length}</b> RECENT PULLS</span></div>
      </div>
      <div className="card-editor glass-panel">
        <h2>Customize your card</h2><p>Your motto is packed into a compact event token when saved.</p>
        <label>EVENT MOTTO<textarea maxLength={2048} value={motto} onChange={(event) => setMotto(event.target.value)} /></label>
        <label>CARD FRAME<select value={frame} onChange={(event) => setFrame(event.target.value)}><option value="aero">Aero Blue</option><option value="lagoon">Lagoon Green</option><option value="sunset">Sunset Orange</option></select></label>
        <div className="editor-actions"><button className="secondary-button" data-sound="submit" onClick={save} disabled={busy}>SAVE CARD</button><button className="primary-button" data-sound="submit" onClick={synchronize} disabled={busy}>SYNC TO EVENT</button></div>
        {sync && <div className={`sync-result ${sync.status === "AERO_SYNCED" ? "ok" : "warn"}`}><b>{sync.status.replaceAll("_", " ")}</b><span>{sync.message}</span></div>}
      </div>
    </div>
  </section>;
}

function OddsPanel({ data }) {
  const tiers = ["common", "rare", "epic", "legendary"].map((rarity) => [
    rarity.toUpperCase(),
    data.catalog.filter((rowdy) => rowdy.rarity === rarity).reduce((sum, rowdy) => sum + rowdy.chance, 0),
    rarity === "legendary" ? "Dolphin Rowdy only" : "Three featured Rowdys"
  ]);
  return <section className="page-enter">
    <div className="section-heading"><div><p className="eyebrow">YOUR NEXT SUMMON</p><h1>Published Drop Rates</h1></div><span className="counter-chip">{data.pity.misses} {data.pity.misses === 1 ? "MISS" : "MISSES"} · +1% PITY</span></div>
    <div className="tier-rates">{tiers.map(([name, chance, note]) => <article key={name} className={`tier-rate rarity-${name.toLowerCase()}`}><small>{name}</small><strong>{formatChance(chance)}</strong><span>{note}</span></article>)}</div>
    <div className="odds-table glass-panel">
      <div className="odds-row odds-row--head"><span>ROWDY</span><span>RARITY</span><span>BASE CHANCE</span><span>NEXT PULL</span></div>
      {data.catalog.map((rowdy) => <div className="odds-row" key={rowdy.id}><span><img src={rowdy.card} alt="" />{rowdy.name}</span><span className={`rarity-text-${rowdy.rarity}`}>{rowdy.rarity.toUpperCase()}</span><span>{formatChance(rowdy.baseChance)}</span><strong>{formatChance(rowdy.chance)}</strong></div>)}
    </div>
    <p className="rate-note">Your legendary chance starts at 0.67%. Each paid pull without a legendary adds 1 percentage point for the next pull, up to 100%. Summoning a legendary resets it to 0.67%. Pity is saved to your account. Other Rowdys keep their relative chances as the legendary chance rises. Rates shown are rounded to two decimal places; each summon uses secure server randomness.</p>
  </section>;
}

function SettingsPanel({ settings, setSettings }) {
  const fullscreenAvailable = Boolean(document.fullscreenEnabled && document.documentElement.requestFullscreen);
  const [fullscreen, setFullscreen] = useState(Boolean(document.fullscreenElement));
  const [fullscreenStatus, setFullscreenStatus] = useState("");

  useEffect(() => {
    const onChange = () => {
      setFullscreen(Boolean(document.fullscreenElement));
      setFullscreenStatus(document.fullscreenElement ? "Fullscreen is on. Press Escape to leave fullscreen." : "Fullscreen is off.");
    };
    document.addEventListener("fullscreenchange", onChange);
    return () => document.removeEventListener("fullscreenchange", onChange);
  }, []);

  async function toggleFullscreen() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await document.documentElement.requestFullscreen();
      audio.play("fullscreen");
    } catch {
      audio.play("error");
      setFullscreenStatus("Fullscreen could not change. You can keep playing in this window.");
    }
  }

  function update(patch, preview = false) { updateAudio(settings, setSettings, patch, preview); }
  return <section className="page-enter settings-page">
    <div className="section-heading"><div><p className="eyebrow">QUALITY OF LIFE</p><h1>Game Settings</h1></div></div>
    <div className="settings-card glass-panel">
      <div className="setting-row"><div><h3 id="sound-label">Game audio</h3><p>Master switch for music, button tones, reel ticks, and fanfares.</p></div><button className={`toggle ${settings.muted ? "" : "on"}`} data-sound="none" aria-labelledby="sound-label" aria-pressed={!settings.muted} onClick={() => update({ muted: !settings.muted })}><i /></button></div>
      <div className="setting-row"><div><h3 id="volume-label">Master volume</h3><p>{Math.round(settings.volume * 100)}% · Audio starts when you use a game control.</p></div><input type="range" aria-labelledby="volume-label" aria-valuetext={`${Math.round(settings.volume * 100)} percent`} min="0" max="1" step="0.05" value={settings.volume} onChange={(event) => update({ volume: Number(event.target.value) }, true)} /></div>
      <div className="setting-row"><div><h3 id="music-label">Background music</h3><p>A quiet melody from the Aero lagoon.</p></div><button className={`toggle ${settings.music ? "on" : ""}`} data-sound="none" aria-labelledby="music-label" aria-pressed={settings.music} onClick={() => update({ music: !settings.music })}><i /></button></div>
      <div className="setting-row"><div><h3 id="music-volume-label">Music volume</h3><p>{Math.round(settings.musicVolume * 100)}% · Balanced beneath the game sounds.</p></div><input type="range" aria-labelledby="music-volume-label" aria-valuetext={`${Math.round(settings.musicVolume * 100)} percent`} min="0" max="1" step="0.05" value={settings.musicVolume} onChange={(event) => update({ musicVolume: Number(event.target.value) }, true)} /></div>
      <div className="setting-row"><div><h3 id="motion-label">Reduced motion</h3><p>Replace high-motion reel and reveal effects with calmer transitions.</p></div><button className={`toggle ${settings.reducedMotion ? "on" : ""}`} data-sound="none" aria-labelledby="motion-label" aria-pressed={settings.reducedMotion} onClick={() => update({ reducedMotion: !settings.reducedMotion })}><i /></button></div>
      <button className="secondary-button" data-sound="none" onClick={toggleFullscreen} disabled={!fullscreenAvailable}>{fullscreen ? "EXIT FULLSCREEN" : "ENTER FULLSCREEN"}</button>
      <p className="control-status" role="status">{fullscreenAvailable ? fullscreenStatus : "Fullscreen is unavailable in this browser. You can keep playing in this window."}</p>
    </div>
  </section>;
}

function Toasts({ items }) {
  return <div className="toast-stack" aria-live="polite">{items.map((item) => <div className={`toast toast--${item.type}`} key={item.id}><i />{item.message}</div>)}</div>;
}

function Game({ initialData, onLogout, settings, setSettings }) {
  const [data, setData] = useState(initialData);
  const [active, setActive] = useState("summon");
  const [pulling, setPulling] = useState(false);
  const [result, setResult] = useState(null);
  const [stage, setStage] = useState(null);
  const [toasts, setToasts] = useState([]);

  const landReel = useCallback(() => setStage("reveal"), []);

  function toast(message, type = "success") {
    audio.play(type);
    const id = crypto.randomUUID();
    setToasts((current) => [...current, { id, message, type }]);
    setTimeout(() => setToasts((current) => current.filter((item) => item.id !== id)), 4200);
  }

  async function refresh() {
    const next = await api("/api/bootstrap");
    setData(next);
    return next;
  }

  async function pull() {
    setPulling(true);
    try {
      const pullResult = await api("/api/pulls", {
        method: "POST",
        headers: { "Idempotency-Key": crypto.randomUUID() }
      }, data.csrfToken);
      setResult(pullResult);
      setData((current) => ({ ...current, balance: pullResult.balance, pity: pullResult.pity, catalog: pullResult.catalog }));
      setStage("reel");
    } catch (error) {
      toast(error.message, "error");
      if (error.status === 402) await refresh();
    } finally { setPulling(false); }
  }

  async function finishReveal() {
    setResult(null); setStage(null);
    try { await refresh(); } catch { toast("History will refresh when the Aero Network reconnects.", "info"); }
  }

  let content;
  if (active === "collection") content = <CollectionPanel data={data} />;
  else if (active === "history") content = <HistoryPanel data={data} />;
  else if (active === "card") content = <PlayerCardPanel data={data} onRefresh={refresh} toast={toast} />;
  else if (active === "odds") content = <OddsPanel data={data} />;
  else if (active === "settings") content = <SettingsPanel settings={settings} setSettings={setSettings} />;
  else content = <SummonPanel data={data} onPull={pull} pulling={pulling} goToCard={() => setActive("card")} />;

  return <div className={`game-shell ${settings.reducedMotion ? "reduce-motion" : ""}`}>
    <BubbleField />
    <Topbar data={data} settings={settings} onSettings={() => setActive("settings")} onLogout={onLogout} />
    <Sidebar active={active} setActive={setActive} />
    <main className="game-content">{content}</main>
    <Toasts items={toasts} />
    {stage === "reel" && result && <ReelOverlay result={result} catalog={data.catalog} settings={settings} onLanded={landReel} />}
    {stage === "reveal" && result && <RevealOverlay result={result} catalog={data.catalog} onClose={finishReveal} />}
  </div>;
}

function App() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState(readSettings);

  useLayoutEffect(() => { audio.configure(settings); }, [settings]);
  useEffect(() => audio.attach(), []);

  useEffect(() => {
    try { localStorage.setItem("rowdy-settings", JSON.stringify(settings)); }
    catch { /* Settings still work for this visit when storage is unavailable. */ }
  }, [settings]);

  useEffect(() => {
    api("/api/bootstrap").then(setData).catch(() => {}).finally(() => setLoading(false));
  }, []);

  async function login(username, password) {
    await api("/api/auth/login", { method: "POST", body: JSON.stringify({ username, password }) });
    setData(await api("/api/bootstrap"));
    audio.play("success");
  }

  async function logout() {
    try { await api("/api/auth/logout", { method: "POST" }); } catch { /* Clear local state regardless. */ }
    setData(null);
  }

  return data ? <Game initialData={data} onLogout={logout} settings={settings} setSettings={setSettings} /> : <Landing onLogin={login} loading={loading} settings={settings} setSettings={setSettings} />;
}

createRoot(document.getElementById("root")).render(<React.StrictMode><App /></React.StrictMode>);
