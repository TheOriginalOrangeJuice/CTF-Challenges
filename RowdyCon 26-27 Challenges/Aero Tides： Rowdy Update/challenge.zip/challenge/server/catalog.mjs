import { randomInt } from "node:crypto";

export const ROLL_SPACE = 10_000;
export const LEGENDARY_ID = "dolphin";

export const ROWDYS = Object.freeze([
  {
    id: "classic",
    name: "Classic Rowdy",
    rarity: "common",
    weight: 2300,
    message: "Birds up—Classic Rowdy charges into the spotlight!"
  },
  {
    id: "nature",
    name: "Nature Rowdy",
    rarity: "common",
    weight: 2300,
    message: "Leaves up, spirits high—Nature Rowdy answers the call!"
  },
  {
    id: "sky",
    name: "Sky Rowdy",
    rarity: "common",
    weight: 2300,
    message: "No runway required—Sky Rowdy drops in from the blue!"
  },
  {
    id: "bubble",
    name: "Bubble Rowdy",
    rarity: "rare",
    weight: 800,
    message: "Pop, sparkle, repeat—Bubble Rowdy makes a splash!"
  },
  {
    id: "vacation",
    name: "Vacation Rowdy",
    rarity: "rare",
    weight: 800,
    message: "Out of office, never off duty—Vacation Rowdy joins the party!"
  },
  {
    id: "globe",
    name: "Globe Rowdy",
    rarity: "rare",
    weight: 800,
    message: "One world, one flock—Globe Rowdy has entered orbit!"
  },
  {
    id: "cyber",
    name: "Cyber Rowdy",
    rarity: "epic",
    weight: 211,
    message: "Firewall breached. Spirit level: maximum. Cyber Rowdy is online!"
  },
  {
    id: "surf",
    name: "Surf Rowdy",
    rarity: "epic",
    weight: 211,
    message: "Catch the swell and ride it home—Surf Rowdy is on deck!"
  },
  {
    id: "ocean",
    name: "Ocean Rowdy",
    rarity: "epic",
    weight: 211,
    message: "From the deep blue, Ocean Rowdy rises!"
  },
  {
    id: LEGENDARY_ID,
    name: "Dolphin Rowdy",
    rarity: "legendary",
    weight: 67,
    message: null
  }
]);

export const ROWDY_BY_ID = new Map(ROWDYS.map((rowdy) => [rowdy.id, rowdy]));
export const BASE_LEGENDARY_WEIGHT = ROWDY_BY_ID.get(LEGENDARY_ID).weight;
export const PITY_STEP_WEIGHT = 100;
export const NONLEGENDARY_SPACE = ROLL_SPACE - BASE_LEGENDARY_WEIGHT;

export function pityStatus(misses = 0) {
  if (!Number.isSafeInteger(misses) || misses < 0) {
    throw new RangeError("pity misses must be a nonnegative safe integer");
  }
  return {
    misses,
    legendaryChance: Math.min(ROLL_SPACE, BASE_LEGENDARY_WEIGHT + PITY_STEP_WEIGHT * misses) / ROLL_SPACE,
    baseLegendaryChance: BASE_LEGENDARY_WEIGHT / ROLL_SPACE,
    increasePerMiss: PITY_STEP_WEIGHT / ROLL_SPACE
  };
}

export function rowdyForRoll(roll) {
  if (!Number.isInteger(roll) || roll < 0 || roll >= ROLL_SPACE) {
    throw new RangeError(`roll must be an integer from 0 through ${ROLL_SPACE - 1}`);
  }

  let cursor = 0;
  for (const rowdy of ROWDYS) {
    cursor += rowdy.weight;
    if (roll < cursor) return rowdy;
  }
  throw new Error("invalid Rowdy weight configuration");
}

export function drawRowdy(misses = 0, drawInteger = randomInt) {
  const threshold = Math.min(ROLL_SPACE, BASE_LEGENDARY_WEIGHT + PITY_STEP_WEIGHT * pityStatus(misses).misses);
  if (drawInteger(0, ROLL_SPACE) < threshold) return ROWDY_BY_ID.get(LEGENDARY_ID);
  // A separate draw preserves the original relative weights among all other Rowdys.
  return rowdyForRoll(drawInteger(0, NONLEGENDARY_SPACE));
}

export function summonMessage(rowdy, flag) {
  if (rowdy.id === LEGENDARY_ID) {
    return `A legendary voice breaks through the surf: ${flag}`;
  }
  return rowdy.message;
}

export function publicCatalog(misses = 0) {
  const { legendaryChance } = pityStatus(misses);
  return ROWDYS.map(({ id, name, rarity, weight }) => ({
    id,
    name,
    rarity,
    weight,
    baseChance: weight / ROLL_SPACE,
    chance: id === LEGENDARY_ID ? legendaryChance : (1 - legendaryChance) * weight / NONLEGENDARY_SPACE,
    card: `/assets/cards/${id}.png`,
    sprite: `/assets/sprites/${id}.png`
  }));
}
