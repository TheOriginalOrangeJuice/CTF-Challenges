import { createHash, randomUUID } from "node:crypto";
import pg from "pg";
import { hash, Algorithm } from "@node-rs/argon2";
import { initializePity } from "./pity.mjs";

const { Pool } = pg;

const DATABASE_URL = process.env.DATABASE_URL ?? "postgresql://rowdy_admin:organizer-change-this@127.0.0.1:5432/rowdy";
const VULN_DATABASE_URL = process.env.VULN_DATABASE_URL ?? "postgresql://rowdy_vuln:vuln-internal-change-this@127.0.0.1:5432/rowdy";
const INSTANCE_SEED = process.env.INSTANCE_SEED ?? "local-development-instance";
const VULN_DB_PASSWORD = process.env.VULN_DB_PASSWORD ?? "vuln-internal-change-this";
const SEEDED_USERNAME = "TheOriginalAppleJuice";
const SEEDED_PASSWORD = "ShoutoutJohnCena@123!";
const LEGACY_SEEDED_USERNAME = "abc123";

export const db = new Pool({ connectionString: DATABASE_URL, max: 12 });
export const vulnDb = new Pool({ connectionString: VULN_DATABASE_URL, max: 4 });

const digest = createHash("sha256").update(`rowdy-ledger:${INSTANCE_SEED}`).digest("hex");
export const ledger = Object.freeze({
  table: `aero_reserve_${digest.slice(0, 8)}`,
  playerColumn: `pilot_${digest.slice(8, 12)}`,
  balanceColumn: `spark_${digest.slice(12, 16)}`
});

export function ident(value) {
  if (!/^[a-z_][a-z0-9_]*$/i.test(value)) throw new Error("unsafe SQL identifier");
  return `"${value}"`;
}

function literal(value) {
  return `'${String(value).replaceAll("'", "''")}'`;
}

export function walletSql(selectClause = "*") {
  return `SELECT ${selectClause} FROM ${ident(ledger.table)}`;
}

export async function bootstrapDatabase() {
  const client = await db.connect();
  try {
    await client.query("BEGIN");
    await client.query(`
      CREATE TABLE IF NOT EXISTS accounts (
        id uuid PRIMARY KEY,
        username text UNIQUE NOT NULL,
        password_hash text NOT NULL,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS sessions (
        token_hash text PRIMARY KEY,
        account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
        csrf_token text NOT NULL,
        expires_at timestamptz NOT NULL,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON sessions(expires_at);
      CREATE TABLE IF NOT EXISTS player_cards (
        account_id uuid PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
        motto text NOT NULL DEFAULT '',
        frame text NOT NULL DEFAULT 'aero',
        updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS collections (
        account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
        rowdy_id text NOT NULL,
        first_pulled_at timestamptz NOT NULL DEFAULT now(),
        pull_count integer NOT NULL DEFAULT 1 CHECK (pull_count > 0),
        PRIMARY KEY (account_id, rowdy_id)
      );
      CREATE TABLE IF NOT EXISTS pulls (
        id uuid PRIMARY KEY,
        account_id uuid NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
        idempotency_key text NOT NULL,
        rowdy_id text NOT NULL,
        was_new boolean NOT NULL,
        pulled_at timestamptz NOT NULL DEFAULT now(),
        UNIQUE (account_id, idempotency_key)
      );
      CREATE INDEX IF NOT EXISTS pulls_account_time_idx ON pulls(account_id, pulled_at DESC);
      CREATE TABLE IF NOT EXISTS event_notices (
        notice_key text PRIMARY KEY,
        body text NOT NULL,
        active boolean NOT NULL DEFAULT true
      );
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS ${ident(ledger.table)} (
        ${ident(ledger.playerColumn)} uuid PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
        ${ident(ledger.balanceColumn)} integer NOT NULL DEFAULT 40
          CHECK (${ident(ledger.balanceColumn)} BETWEEN 0 AND 10000)
      )
    `);

    await client.query(`
      INSERT INTO event_notices(notice_key, body, active) VALUES
        ('aero-connection', 'The Aero Network is sparkling today.', true),
        ('card-parade', 'Player cards are ready for the event parade.', true),
        ('water-report', 'The lagoon is calm and crystal clear.', true)
      ON CONFLICT (notice_key) DO NOTHING
    `);

    const accounts = await client.query(
      "SELECT id, username FROM accounts WHERE username IN ($1, $2) FOR UPDATE",
      [SEEDED_USERNAME, LEGACY_SEEDED_USERNAME]
    );
    const currentAccount = accounts.rows.find(account => account.username === SEEDED_USERNAME);
    const legacyAccount = accounts.rows.find(account => account.username === LEGACY_SEEDED_USERNAME);
    if (currentAccount && legacyAccount) {
      throw new Error("Seeded account migration requires resolving the existing username conflict.");
    }
    let accountId = currentAccount?.id ?? legacyAccount?.id;
    if (!currentAccount) {
      const passwordHash = await hash(SEEDED_PASSWORD, {
        algorithm: Algorithm.Argon2id,
        memoryCost: 19456,
        timeCost: 2,
        parallelism: 1,
        outputLen: 32
      });
      if (legacyAccount) {
        // Keep all progress attached to the same account; retire its old sessions once.
        await client.query(
          "UPDATE accounts SET username = $2, password_hash = $3 WHERE id = $1",
          [accountId, SEEDED_USERNAME, passwordHash]
        );
        await client.query("DELETE FROM sessions WHERE account_id = $1", [accountId]);
      } else {
        accountId = randomUUID();
        await client.query(
          "INSERT INTO accounts(id, username, password_hash) VALUES ($1, $2, $3)",
          [accountId, SEEDED_USERNAME, passwordHash]
        );
      }
    }

    await client.query(
      `INSERT INTO ${ident(ledger.table)}(${ident(ledger.playerColumn)}, ${ident(ledger.balanceColumn)}) VALUES ($1, 40) ON CONFLICT (${ident(ledger.playerColumn)}) DO NOTHING`,
      [accountId]
    );
    await client.query(
      "INSERT INTO player_cards(account_id, motto, frame) VALUES ($1, '', 'aero') ON CONFLICT (account_id) DO NOTHING",
      [accountId]
    );

    await client.query(`
      DO $role$
      BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'rowdy_vuln') THEN
          CREATE ROLE rowdy_vuln LOGIN;
        END IF;
      END
      $role$;
      ALTER ROLE rowdy_vuln WITH NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS;
      ALTER ROLE rowdy_vuln PASSWORD ${literal(VULN_DB_PASSWORD)};
      ALTER ROLE rowdy_vuln SET statement_timeout = '2s';
      ALTER ROLE rowdy_vuln SET lock_timeout = '750ms';
      REVOKE CREATE ON SCHEMA public FROM PUBLIC;
      GRANT USAGE ON SCHEMA public TO rowdy_vuln;
      REVOKE ALL ON ALL TABLES IN SCHEMA public FROM rowdy_vuln;
      GRANT SELECT ON event_notices TO rowdy_vuln;
      GRANT SELECT ON ${ident(ledger.table)} TO rowdy_vuln;
      GRANT UPDATE (${ident(ledger.balanceColumn)}) ON ${ident(ledger.table)} TO rowdy_vuln;
      ALTER TABLE ${ident(ledger.table)} ENABLE ROW LEVEL SECURITY;
      ALTER TABLE ${ident(ledger.table)} FORCE ROW LEVEL SECURITY;
      DROP POLICY IF EXISTS rowdy_wallet_owner ON ${ident(ledger.table)};
      CREATE POLICY rowdy_wallet_owner ON ${ident(ledger.table)} TO rowdy_vuln
        USING (${ident(ledger.playerColumn)}::text = current_setting('app.player_id', true))
        WITH CHECK (${ident(ledger.playerColumn)}::text = current_setting('app.player_id', true));
    `);

    await initializePity(client);
    await client.query("DELETE FROM sessions WHERE expires_at <= now()");
    await client.query("COMMIT");
    return { accountId, ledger };
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function closeDatabases() {
  await Promise.all([db.end(), vulnDb.end()]);
}
