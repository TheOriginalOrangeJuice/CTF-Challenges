import { LEGENDARY_ID, pityStatus } from "./catalog.mjs";

export async function initializePity(client) {
  await client.query(`
    CREATE TABLE IF NOT EXISTS account_pity (
      account_id uuid PRIMARY KEY REFERENCES accounts(id) ON DELETE CASCADE,
      misses integer NOT NULL DEFAULT 0 CHECK (misses >= 0)
    )
  `);
  // Legacy pulls have no sequence number. UUID breaks timestamp ties consistently;
  // once initialized, the transactionally maintained counter is authoritative.
  await client.query(`
    INSERT INTO account_pity(account_id, misses)
    SELECT a.id, (
      SELECT count(*)::integer FROM pulls p
      WHERE p.account_id = a.id AND p.rowdy_id <> $1
        AND (latest.id IS NULL OR (p.pulled_at, p.id) > (latest.pulled_at, latest.id))
    )
    FROM accounts a
    LEFT JOIN LATERAL (
      SELECT id, pulled_at FROM pulls
      WHERE account_id = a.id AND rowdy_id = $1
      ORDER BY pulled_at DESC, id DESC LIMIT 1
    ) latest ON true
    WHERE NOT EXISTS (SELECT 1 FROM account_pity state WHERE state.account_id = a.id)
    ON CONFLICT (account_id) DO NOTHING
  `, [LEGENDARY_ID]);
}

export async function loadPity(client, accountId) {
  const result = await client.query("SELECT misses FROM account_pity WHERE account_id = $1", [accountId]);
  if (!result.rows[0]) throw new Error("account pity state is missing");
  return pityStatus(result.rows[0].misses);
}
