import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  root: "web",
  publicDir: "public",
  build: {
    outDir: "../dist-web",
    emptyOutDir: true,
    sourcemap: false
  },
  server: {
    proxy: {
      "/api": "http://localhost:8080",
      "/healthz": "http://localhost:8080",
      "/llms.txt": "http://localhost:8080",
      "/.well-known": "http://localhost:8080"
    }
  }
});
