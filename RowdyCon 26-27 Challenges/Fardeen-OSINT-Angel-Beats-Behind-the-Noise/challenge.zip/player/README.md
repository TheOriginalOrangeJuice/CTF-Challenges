# Angel Beats! — Behind the Noise

For 12 years of my life, this guitar solo has been living rent-free in my head. It's from my favorite animated TV Show too! I've been wanting to recreate the sound of the solo fomr the longest time but I can't find the exact fuzz-pdeal model that the guitarist used when he recorded this part. I'm sure someone asked about this and it was answered somewhere, can you find me the fuzz-pedal model?  

[Listen to the guitar solo](audio-01.mp3)

Submit: `RCC{pedal_model}`

©VisualArt's/Key/Angel Beats! Project
