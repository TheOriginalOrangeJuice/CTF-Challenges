﻿/* AeroTwitter: ordinary public and signed-in account interface. */
(() => {
  'use strict';
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const state = { user: null, posts: [], replies: new Map(), route: 'home', routeHash: 'home', revision: 0, toastTimer: null };
  const view = $('#view');
  const avatars = ['default.png','flagbeast.png','cloudy.png','touchgrass.png','anon.png','gamer1.png','gamer2.png','skeptic.png'];
  const avatarNames = ['Blue egg','Yellow sunglasses','Headphones','Wildflower','Anonymous mask','Retro controller','Goldfish','Glasses'];
  const icons = {
    reply: '<path d="M9 3 2 8l7 5V9c5 0 7 2 8 6 2-7-2-10-8-10z"/>',
    retweet: '<path d="m5 1 4 4H6v7h4v3H3V5H0zm10 16-4-4h3V6h-4V3h7v10h3z"/>',
    favorite: '<path d="m10 1 2.7 5.5 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L.2 7.4l6.1-.9z"/>'
  };
  function escape(value) { return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function avatar(file, size = '') { return `<span class="avatar ${size}" data-avatar="${avatars.includes(file) ? file : 'default.png'}" aria-hidden="true"></span>`; }
  function linkedText(text) {
    return String(text ?? '').split(/([@#][A-Za-z0-9_]+)/g).map(piece => {
      if (piece.startsWith('@') && /^@\w+$/.test(piece)) return `<a href="#user-${encodeURIComponent(piece.slice(1))}">${escape(piece)}</a>`;
      if (piece.startsWith('#') && /^#\w+$/.test(piece)) return `<a href="#search?q=${encodeURIComponent(piece)}">${escape(piece)}</a>`;
      return escape(piece);
    }).join('');
  }
  function dateLabel(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return '';
    const mins = Math.floor((Date.now() - date.getTime()) / 60000);
    if (mins >= 0 && mins < 1) return 'less than a minute ago';
    if (mins >= 1 && mins < 60) return `${mins} minute${mins === 1 ? '' : 's'} ago`;
    if (mins >= 60 && mins < 1440) return `about ${Math.floor(mins / 60)} hour${mins < 120 ? '' : 's'} ago`;
    return date.toLocaleString('en-US', {month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit'});
  }
  async function api(path, method = 'GET', body) {
    const response = await fetch(path, {method, credentials:'same-origin', headers: {'Content-Type':'application/json'}, ...(body === undefined ? {} : {body:JSON.stringify(body)})});
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
    return data;
  }
  function notice(text) { clearTimeout(state.toastTimer); $('#status').textContent = text; $('#status').hidden = false; state.toastTimer = setTimeout(() => $('#status').hidden = true, 4500); }
  async function busy(button, work, loading = 'Working…') {
    if (button.disabled) return;
    const label = button.innerHTML; button.disabled = true; button.textContent = loading;
    try { await work(); } catch (error) { notice(error.message); }
    finally { if (button.isConnected) {button.disabled = false; button.innerHTML = label;} }
  }
  function empty(title, text) { return `<div class="state-box"><h3>${escape(title)}</h3><p>${escape(text)}</p></div>`; }
  function failure(error) { view.innerHTML = `<div class="state-box error" role="alert"><h3>Couldn't load this page.</h3><p>${escape(error.message)}</p><button class="button" id="retry">Try again</button></div>`; $('#retry').onclick = renderRoute; }
  function stats(user) { return `<div class="stats"><div><strong>${Number(user.tweetsCount || 0)}</strong><span>tweets</span></div><div><strong>${Number(user.followingCount || 0)}</strong><span>following</span></div><div><strong>${Number(user.followersCount || 0)}</strong><span>followers</span></div></div>`; }
  async function refreshAccount() {
    const data = await api('/api/me'); state.user = data.authenticated ? data.user : null;
    $$('.signed-in').forEach(el => el.hidden = !state.user);
    $('#auth-nav').textContent = state.user ? 'Sign out' : 'Sign in';
    $('#welcome').hidden = !!state.user; $('#composer').hidden = !state.user;
    if (state.user) {
      const user = state.user;
      $('#profile-card').innerHTML = `<a class="identity" href="#user-${encodeURIComponent(user.handle)}">${avatar(user.avatar)}<div><strong>${escape(user.displayName)}</strong><small>@${escape(user.handle)} · View profile →</small></div></a>${stats(user)}`;
      $('#composer-handle').textContent = `@${user.handle}`; $('#mention-name').textContent = user.handle;
      await refreshDraftCount();
    } else {
      $('#profile-card').innerHTML = '<p class="guest-title">Life in 140 characters.</p><p class="guest-copy">A little window into everyone’s world.<br>Follow along. Make yourself at home.</p>';
      $('#draft-count').textContent = '0';
    }
  }
  async function refreshDraftCount() {
    if (!state.user) return;
    try { const data = await api('/api/drafts'); $('#draft-count').textContent = (data.drafts || []).length; } catch (_) { $('#draft-count').textContent = '–'; }
  }
  function peopleFromPosts() {
    const seen = new Map(); state.posts.forEach(post => {if (!seen.has(post.authorHandle)) seen.set(post.authorHandle, {handle:post.authorHandle, displayName:post.authorDisplayName, avatar:post.authorAvatar});});
    return [...seen.values()];
  }
  function renderPeopleStrip() { $('#people-strip').innerHTML = peopleFromPosts().slice(0,8).map(user => `<a href="#user-${encodeURIComponent(user.handle)}" title="@${escape(user.handle)}" aria-label="View @${escape(user.handle)}">${avatar(user.avatar,'tiny')}</a>`).join(''); }
  function setPage(title) {
    $('#page-title').textContent = title; document.title = `AeroTwitter / ${title}`; $('#timeline-end').hidden = true;
    $$('.side-nav a, .top-nav a').forEach(link => {const active = link.dataset.nav === state.route; link.classList.toggle('active', active); if(active) link.setAttribute('aria-current','page'); else link.removeAttribute('aria-current');});
  }
  function unsavedEdits() {
    const textChanged=$$('.reply-form textarea, .draft-editor textarea, #settings-form input, #settings-form textarea',view).some(input=>input.value!==input.defaultValue);
    const settings=$('#settings-form');const picture=$('.avatar-choice[aria-pressed="true"]',view);
    return textChanged || !!(settings && picture && picture.dataset.choice!==settings.dataset.savedAvatar);
  }
  function navigate(hash, {discard=false}={}) { if(discard){history.pushState(null,'',`#${hash}`);return renderRoute({discard:true});} if (location.hash === `#${hash}`) return renderRoute(); else location.hash = hash; }
  async function renderRoute(options={}) {
    const raw = location.hash.slice(1) || 'home';
    if(unsavedEdits() && !options.discard){
      history.replaceState(null,'',`#${state.routeHash}`);
      confirmAction('Discard unsaved changes?','Your reply, draft edit, or profile changes have not been saved. Stay here to keep working, or discard them to continue.','Discard changes',async()=>{await navigate(raw,{discard:true});});
      $('#cancel-action').textContent='Keep editing';
      return;
    }
    const revision = ++state.revision;
    state.routeHash=raw;state.route = raw.split('?')[0];
    const route = state.route;
    setPage(route === 'home' ? 'Home' : route.startsWith('user-') ? 'Profile' : route.charAt(0).toUpperCase()+route.slice(1));
    view.setAttribute('aria-busy','true'); view.innerHTML = '<p class="state-box">Loading…</p>';
    try {
      if (route.startsWith('user-')) {
        const data = await api(`/api/user/${encodeURIComponent(decodeURIComponent(route.slice(5)))}`); if(revision!==state.revision)return; renderProfile(data);
      } else if (['home','mentions','favorites','following'].includes(route)) {
        const data = await api('/api/timeline'); if(revision!==state.revision)return;
        state.posts = data.posts || []; renderPeopleStrip(); let posts = state.posts;
        if (route !== 'home' && !state.user) {view.innerHTML=empty('Sign in to see this timeline.','Join the conversation with your own AeroTwitter account.'); return;}
        if(route==='mentions') posts = posts.filter(p=>p.content.toLowerCase().includes(`@${state.user.handle.toLowerCase()}`));
        if(route==='favorites') posts = posts.filter(p=>p.isFavorited);
        appendPosts(posts, view, route==='favorites'?'No favorites yet.':'Nothing here yet.', route==='favorites'?'Click the star beside a tweet to keep it here.':'When someone mentions you, their public tweet will appear here.');
        $('#timeline-end').hidden = !posts.length;
      } else if (route === 'drafts') {
        if(!state.user){view.innerHTML=empty('Your thoughts, before they’re tweets.','Sign in to write and revisit your own drafts.');return;}
        const data = await api('/api/drafts'); if(revision!==state.revision)return; renderDrafts(data.drafts || []);
      } else if (route === 'settings') {
        if(!state.user){view.innerHTML=empty('Make yourself at home.','Sign in to edit your profile.');return;} renderSettings();
      } else if (route === 'search') {
        const q = new URLSearchParams(raw.split('?').slice(1).join('?')).get('q') || ''; $('#search-input').value=q;
        if(!q.trim()){view.innerHTML=empty('What are you looking for?','Search for people, words, or a hashtag using the box on the right.');return;}
        const data = await api(`/api/search?q=${encodeURIComponent(q)}`); if(revision!==state.revision)return;
        setPage(`Search: ${q}`); renderSearch(data,q);
      } else if (route === 'people') {
        if(!state.posts.length){const data=await api('/api/timeline');state.posts=data.posts||[];renderPeopleStrip();} if(revision!==state.revision)return;
        setPage('Find People');view.innerHTML='<p class="section-caption">A few familiar faces from the public timeline.</p>';renderPeople(peopleFromPosts(),view);
      } else renderInfo(route);
    } catch (error) {if(revision===state.revision) failure(error);}
    finally {if(revision===state.revision)view.setAttribute('aria-busy','false');}
  }
  function appendPosts(posts, target, title='No tweets yet.', description='A quiet corner of the timeline. Check back after posting.') {
    target.replaceChildren(); if(!posts.length){target.innerHTML=empty(title,description);return;}
    posts.forEach(post=>target.append(createPost(post)));
  }
  function createPost(post) {
    const article=document.createElement('article');article.className='post';article.dataset.postId=post.id;
    const content=String(post.content||'');
    const breakAt=content.indexOf('\n');
    const bodyHtml=breakAt<0?`<div class="post-content">${linkedText(content)}</div>`:`<div class="post-content">${linkedText(content.slice(0,breakAt))}</div><details class="attachment"><summary><span class="attachment-closed">Read attached text</span><span class="attachment-open">Hide attached text</span><span class="attachment-type">TXT</span></summary><div class="attachment-text">${linkedText(content.slice(breakAt+1))}</div></details>`;
    article.innerHTML=`<a class="post-avatar" href="#user-${encodeURIComponent(post.authorHandle)}" aria-label="View @${escape(post.authorHandle)}">${avatar(post.authorAvatar)}</a>
      <div class="post-heading"><a class="post-author" href="#user-${encodeURIComponent(post.authorHandle)}">${escape(post.authorHandle)}</a><span class="display-name">${escape(post.authorDisplayName)}</span></div>
      ${post.replyToId?'<p class="thread-note">In reply to a tweet</p>':''}${bodyHtml}
      <div class="post-meta"><time datetime="${escape(post.createdAt)}" title="${escape(new Date(post.createdAt).toLocaleString())}">${escape(dateLabel(post.createdAt))}</time><span>from web</span></div>
      <div class="post-actions">${['reply','retweet','favorite'].map(action=>`<button class="action ${action}" aria-label="${action.charAt(0).toUpperCase()+action.slice(1)}" ${action==='reply'?'aria-expanded="false"':`aria-pressed="${action==='retweet'?!!post.isRetweeted:!!post.isFavorited}"`}><svg viewBox="0 0 20 20" aria-hidden="true">${icons[action]}</svg><span>${action==='favorite'?'Favorite':action==='retweet'?'Retweet':'Reply'}</span><span class="count">${Number(post[action==='reply'?'repliesCount':action==='retweet'?'retweetsCount':'favoritesCount']||0)||''}</span></button>`).join('')}</div>`;
    $('.reply',article).onclick=()=>{if(!requireAccount())return;toggleReply(article,post);};
    ['favorite','retweet'].forEach(action=>{const button=$(`.${action}`,article);button.onclick=async()=>{
      if(!requireAccount()||button.disabled)return;button.disabled=true;
      try{const data=await api(`/api/tweets/${encodeURIComponent(post.id)}/${action}`,'POST');const active=action==='favorite'?data.isFavorited:data.isRetweeted;button.setAttribute('aria-pressed',String(!!active));$('.count',button).textContent=Number(data[action==='favorite'?'favoritesCount':'retweetsCount']||0)||'';post[action==='favorite'?'isFavorited':'isRetweeted']=!!active;notice(active?(action==='favorite'?'Saved to Favorites.':'Retweeted.'):(action==='favorite'?'Removed from Favorites.':'Retweet undone.'));}
      catch(error){notice(error.message);}finally{button.disabled=false;}
    };});
    renderReplyReceipts(article,post.id);
    return article;
  }
  function renderReplyReceipts(article,postId){
    $('.reply-receipts',article)?.remove();const replies=state.replies.get(postId)||[];if(!replies.length)return;
    const receipts=document.createElement('div');receipts.className='reply-receipts';receipts.innerHTML=replies.map(reply=>`<div class="reply-receipt">${avatar(reply.authorAvatar,'tiny')}<div><a href="#user-${encodeURIComponent(reply.authorHandle)}"><strong>${escape(reply.authorHandle)}</strong></a> <span class="receipt-label">replied</span><p>${linkedText(reply.content)}</p></div></div>`).join('');article.append(receipts);
  }
  function requireAccount(){if(state.user)return true;showAuth('login');return false;}
  function toggleReply(article,post){
    const existing=$('.reply-form',article);const toggle=$('.reply',article);if(existing){const discard=()=>{existing.remove();toggle.setAttribute('aria-expanded','false');toggle.focus();};if($('textarea',existing).value.trim()){confirmAction('Discard this reply?','This reply has not been posted yet.','Discard reply',async()=>discard());$('#cancel-action').textContent='Keep writing';}else discard();return;}
    const form=document.createElement('form');form.className='reply-form';form.innerHTML=`<label class="sr-only" for="reply-${escape(post.id)}">Reply to @${escape(post.authorHandle)}</label><textarea id="reply-${escape(post.id)}" maxlength="140" rows="2" placeholder="Reply to @${escape(post.authorHandle)}"></textarea><div class="reply-footer"><span class="reply-counter">140</span><button type="button" class="text-button cancel-reply">Cancel</button><button class="button" disabled>Reply</button></div>`;
    article.append(form);toggle.setAttribute('aria-expanded','true');const input=$('textarea',form),submit=$('.button',form);
    input.oninput=()=>{$('.reply-counter',form).textContent=140-input.value.length;submit.disabled=!input.value.trim();};$('.cancel-reply',form).onclick=()=>toggleReply(article,post);
    form.onsubmit=event=>{event.preventDefault();busy(submit,async()=>{const result=await api('/api/tweets','POST',{content:input.value.trim(),replyToId:post.id});state.replies.set(post.id,[...(state.replies.get(post.id)||[]),result.post]);const count=$('.reply .count',article);count.textContent=Number(count.textContent||0)+1;form.remove();renderReplyReceipts(article,post.id);toggle.setAttribute('aria-expanded','false');toggle.focus();notice('Your reply was posted.');await refreshAccount();},'Posting…');};input.focus();
  }
  function updateComposer(){const left=140-$('#tweet-text').value.length;$('#char-count').textContent=left;$('#char-count').classList.toggle('warning',left<20);const empty=!$('#tweet-text').value.trim();$('#tweet-btn').disabled=empty;$('#save-draft-btn').disabled=empty;}
  async function submitComposition(draft,button){
    const content=$('#tweet-text').value.trim();if(!content||!state.user)return;
    await busy(button,async()=>{await api(draft?'/api/drafts':'/api/tweets','POST',{content});$('#tweet-text').value='';notice(draft?'Draft saved. Open Drafts to return to it.':'Your tweet was posted.');await refreshAccount();if(draft&&state.route==='drafts')await renderRoute();if(!draft){navigate('home');}$('#tweet-text').focus();},draft?'Saving…':'Posting…');updateComposer();
  }
  function renderProfile(data){
    const user=data.user;view.innerHTML=`<section class="profile-header"><div class="profile-identity">${avatar(user.avatar,'large')}<div><h2>${escape(user.displayName)}</h2><p class="handle">@${escape(user.handle)}</p></div></div><p class="profile-bio">${linkedText(user.bio||'Still thinking of something to put here.')}</p><div class="profile-controls">${stats(user)}${data.isOwnProfile?'<a class="button" href="#settings">Edit your profile</a>':'<button class="button follow-button">Follow</button>'}</div></section><div id="profile-posts"></div>`;
    if(!data.isOwnProfile)wireFollow($('.follow-button',view),user.handle,!!data.isFollowing);
    appendPosts(data.posts||[],$('#profile-posts'));setPage(`@${user.handle}`);
  }
  function wireFollow(button,handle,following){button.textContent=following?'Following ✓':'Follow';button.setAttribute('aria-pressed',String(following));button.onclick=async()=>{if(!requireAccount()||button.disabled)return;button.disabled=true;try{const data=await api(`/api/user/${encodeURIComponent(handle)}/follow`,'POST');button.textContent=data.isFollowing?'Following ✓':'Follow';button.setAttribute('aria-pressed',String(!!data.isFollowing));notice(data.isFollowing?`You’re now following @${handle}.`:`You unfollowed @${handle}.`);await refreshAccount();if(state.route===`user-${handle}`){const data=await api(`/api/user/${encodeURIComponent(handle)}`);$('.profile-controls .stats').outerHTML=stats(data.user);}}catch(error){notice(error.message);}finally{button.disabled=false;}};}
  function renderPeople(users,target){users.forEach(user=>{const row=document.createElement('div');row.className='people-row';row.innerHTML=`<a href="#user-${encodeURIComponent(user.handle)}" aria-label="View @${escape(user.handle)}">${avatar(user.avatar)}</a><div class="person-detail"><a href="#user-${encodeURIComponent(user.handle)}"><strong>${escape(user.displayName)}</strong></a><small>@${escape(user.handle)}</small></div><a class="button" href="#user-${encodeURIComponent(user.handle)}">View profile</a>`;target.append(row);});}
  function renderSearch(data,q){view.innerHTML=`<p class="search-summary">Results for <strong>${escape(q)}</strong> · ${(data.users||[]).length} people · ${(data.posts||[]).length} tweets</p>`;renderPeople(data.users||[],view);const posts=document.createElement('div');view.append(posts);appendPosts(data.posts||[],posts,'No matching tweets.','Try a handle, a different word, or one of the trending topics.');}
  function renderDrafts(drafts){
    view.innerHTML='<div class="draft-intro"><span>Only you can see your unpublished tweets.</span><button class="button" id="new-draft">New draft</button></div><div id="draft-list"></div>';
    $('#new-draft').onclick=()=>{$('#tweet-text').focus();notice('Write above, then choose Save draft.');};const list=$('#draft-list');
    if(!drafts.length){list.innerHTML=empty('No drafts yet.','Save a thought from the composer above. It will be waiting here.');return;}
    drafts.forEach(draft=>{const item=document.createElement('article');item.className='draft';item.dataset.draftId=draft.id;item.innerHTML=`<p>${escape(draft.content)}</p><time datetime="${escape(draft.updatedAt)}">Saved ${escape(dateLabel(draft.updatedAt))}</time><div class="draft-actions"><button class="button edit">Edit</button><button class="button publish">Publish</button><button class="text-button delete">Delete</button></div>`;
      $('.edit',item).onclick=()=>editDraft(item,draft);
      $('.publish',item).onclick=()=>confirmAction('Publish this draft?','This will appear as a tweet on your public profile.','Publish',async()=>{await api(`/api/drafts/${encodeURIComponent(draft.id)}/publish`,'POST');await refreshAccount();await renderRoute();notice('Your draft is now a tweet.');$('#new-draft')?.focus();});
      $('.delete',item).onclick=()=>confirmAction('Delete this draft?','This saved thought will be removed permanently.','Delete',async()=>{await api(`/api/drafts/${encodeURIComponent(draft.id)}`,'DELETE');await refreshDraftCount();await renderRoute();notice('Draft deleted.');$('#new-draft')?.focus();});list.append(item);
    });
  }
  function editDraft(item,draft){item.innerHTML=`<form class="draft-editor"><label class="sr-only" for="edit-${escape(draft.id)}">Draft content</label><textarea id="edit-${escape(draft.id)}" maxlength="140">${escape(draft.content)}</textarea><div class="draft-actions"><button class="button">Save</button><button type="button" class="text-button cancel">Cancel</button><span class="reply-counter">${140-draft.content.length}</span></div></form>`;const form=$('form',item),input=$('textarea',item),submit=$('.button',item);input.oninput=()=>{$('.reply-counter',item).textContent=140-input.value.length;submit.disabled=!input.value.trim();};$('.cancel',item).onclick=async()=>{await renderRoute();$(`[data-draft-id="${draft.id}"] .edit`)?.focus();};form.onsubmit=event=>{event.preventDefault();busy(submit,async()=>{await api(`/api/drafts/${encodeURIComponent(draft.id)}`,'PATCH',{content:input.value.trim()});input.defaultValue=input.value;await renderRoute();notice('Draft updated.');$(`[data-draft-id="${draft.id}"] .edit`)?.focus();},'Saving…');};input.focus();}
  function renderSettings(){
    view.innerHTML=`<form class="settings-form" id="settings-form"><div class="field"><label for="settings-name">Display name</label><input id="settings-name" maxlength="20" required value="${escape(state.user.displayName)}"><small>Your name, as you'd like it to appear beside your tweets.</small></div><div class="field"><label for="settings-bio">Bio</label><textarea id="settings-bio" maxlength="160">${escape(state.user.bio||'')}</textarea><small>A little about you, in 160 characters.</small></div><div class="field"><label>Your picture</label><div class="avatar-choices">${avatars.map((file,i)=>`<button type="button" class="avatar-choice" data-choice="${file}" aria-label="${avatarNames[i]} avatar" aria-pressed="${state.user.avatar===file}">${avatar(file)}</button>`).join('')}</div></div><p class="form-error" role="alert"></p><button class="button blue">Save changes</button></form>`;
    let selected=state.user.avatar;$('#settings-form').dataset.savedAvatar=selected;$$('.avatar-choice',view).forEach(button=>button.onclick=()=>{selected=button.dataset.choice;$$('.avatar-choice',view).forEach(b=>b.setAttribute('aria-pressed',String(b===button)));});
    $('#settings-form').onsubmit=event=>{event.preventDefault();busy($('#settings-form > .button'),async()=>{try{await api('/api/me/profile','PATCH',{displayName:$('#settings-name').value.trim(),bio:$('#settings-bio').value.trim(),avatar:selected});$$('#settings-form input,#settings-form textarea').forEach(input=>input.defaultValue=input.value);$('#settings-form').dataset.savedAvatar=selected;await refreshAccount();notice('Your profile has been saved.');}catch(error){const message=$('.form-error',view);if(message)message.textContent=error.message;else notice(error.message);}},'Saving…');};
  }
  const modal=$('#modal');let returnFocus=null;
  function openModal(title,html){if(!modal.open)returnFocus=document.activeElement;$('#modal-title').textContent=title;$('#modal-body').innerHTML=html;if(!modal.open)modal.showModal();setTimeout(()=>$('#modal-body input, #modal-body button')?.focus(),0);}
  function closeModal(){modal.close();if(returnFocus?.isConnected)returnFocus.focus();else $('#new-draft, #content')?.focus();}
  function showAuth(mode){const register=mode==='register';
    openModal(register?'Join AeroTwitter':'Sign in to AeroTwitter',`<form id="auth-form"><div class="field"><label for="auth-handle">Username</label><input id="auth-handle" name="handle" autocomplete="username" required ${register?'maxlength="15" pattern="[A-Za-z0-9_]+"':''}><small>${register?'Up to 15 letters, numbers, or underscores.':'Your username, without the @.'}</small></div>${register?'<div class="field"><label for="auth-name">Display name</label><input id="auth-name" name="displayName" maxlength="20" autocomplete="name" required></div>':''}<div class="field"><label for="auth-password">Password</label><input id="auth-password" name="password" type="password" autocomplete="${register?'new-password':'current-password'}" ${register?'minlength="6"':''} required>${register?'<small>At least six characters.</small>':''}</div><p class="form-error" id="auth-error" role="alert"></p><button class="button ${register?'green':'blue'}">${register?'Create my account':'Sign in'}</button></form><p class="auth-switch">${register?'Already here?':'New around here?'} <button class="text-button" id="switch-auth">${register?'Sign in':'Join AeroTwitter'}</button></p>`);
    $('#switch-auth').onclick=()=>showAuth(register?'login':'register');$('#auth-form').onsubmit=event=>{event.preventDefault();const button=$('#auth-form .button');busy(button,async()=>{
      const body={handle:$('#auth-handle').value.trim().replace(/^@/,''),password:$('#auth-password').value};if(register)body.displayName=$('#auth-name').value.trim();
      try{await api(register?'/api/register':'/api/login','POST',body);}catch(error){const message=$('#auth-error');if(message)message.textContent=error.message;else notice(error.message);return;}
      closeModal();
      try{await refreshAccount();await renderRoute();notice(register?'Welcome to AeroTwitter. What’s happening?':`Welcome back, @${state.user.handle}.`);$('#tweet-text').focus();}
      catch(error){notice('Signed in, but the page could not refresh. Choose Refresh to try again.');}
    },register?'Creating…':'Signing in…');};
  }
  function confirmAction(title,description,label,action){openModal(title,`<p>${escape(description)}</p><p class="form-error" role="alert"></p><div class="modal-actions"><button class="button" id="confirm-action">${escape(label)}</button><button class="text-button" id="cancel-action">Cancel</button></div>`);$('#cancel-action').onclick=closeModal;$('#confirm-action').onclick=()=>busy($('#confirm-action'),async()=>{try{await action();closeModal();}catch(error){$('#modal-body .form-error').textContent=error.message;}},'Working…');}
  function renderInfo(route){
    const pages={help:['A little help getting started',`<p>Browse Home to see the conversation, or click a username to visit their profile. Search finds people and tweets; hashtags run that search for you.</p><p>Sign up to post a thought in 140 characters, reply, retweet, favorite, and follow. Favorites keeps your starred tweets together. Drafts saves a thought until you're ready to publish it.</p>`],about:['Small updates. A big conversation.','<p>AeroTwitter is a place for quick thoughts, aquarium pictures, retro gaming, and the people behind them.</p><p>Follow someone interesting. Say hello. Try keeping it under 140 characters.</p>'],terms:['House rules','<p>Be kind to the people behind the avatars. Keep your account details to yourself and use your own account for your tweets.</p>'],privacy:['Your public and private spaces','<p>Your profile, tweets, and replies are public. Drafts belong to your signed-in account until you publish them.</p><p>Signing out ends your visit. You can sign back in with the username and password you chose.</p>']};
    const page=pages[route]||pages.help;view.innerHTML=`<div class="document-view"><h3>${page[0]}</h3>${page[1]}<a href="#home">← Back to Home</a></div>`;
  }
  $('#tweet-text').addEventListener('input',updateComposer);$('#tweet-btn').onclick=()=>submitComposition(false,$('#tweet-btn'));$('#save-draft-btn').onclick=()=>submitComposition(true,$('#save-draft-btn'));
  async function signOut(){await busy($('#auth-nav'),async()=>{await api('/api/logout','POST');$('#tweet-text').value='';updateComposer();await refreshAccount();await navigate('home',{discard:true});notice('You have signed out.');},'Signing out…');$('#auth-nav').textContent=state.user?'Sign out':'Sign in';}
  $('#auth-nav').onclick=async()=>{if(!state.user){showAuth('login');return;}if(unsavedEdits()||$('#tweet-text').value.trim()){confirmAction('Sign out with unsaved work?','Your unsaved tweet or edits will be discarded.','Sign out',signOut);return;}await signOut();};
  $$('[data-auth]').forEach(button=>button.onclick=()=>showAuth(button.dataset.auth));$('#modal-close').onclick=closeModal;modal.addEventListener('click',event=>{if(event.target===modal){const r=modal.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeModal();}});modal.addEventListener('cancel',()=>{if(returnFocus?.isConnected)returnFocus.focus();});
  $('#search-form').onsubmit=event=>{event.preventDefault();navigate(`search?q=${encodeURIComponent($('#search-input').value.trim())}`);};$('#refresh-btn').onclick=()=>busy($('#refresh-btn'),async()=>{await refreshAccount();await renderRoute();},'Refreshing…');window.addEventListener('hashchange',renderRoute);
  window.addEventListener('beforeunload',event=>{if(unsavedEdits()||$('#tweet-text').value.trim()){event.preventDefault();event.returnValue='';}});
  async function init(){try{await refreshAccount();await renderRoute();if(!state.posts.length){const data=await api('/api/timeline');state.posts=data.posts||[];renderPeopleStrip();}}catch(error){failure(error);view.setAttribute('aria-busy','false');}}
  init();
})();
