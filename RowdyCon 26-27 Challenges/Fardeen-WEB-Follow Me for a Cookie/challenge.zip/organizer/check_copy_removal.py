﻿"""Guest-only copy-removal checks; no account or private-workflow testing.
Run in Condev: python check_copy_removal.py SOURCE URL OUTPUT
"""
import hashlib
import json
import subprocess
import sys
import urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

source, base, output = Path(sys.argv[1]), sys.argv[2].rstrip('/'), Path(sys.argv[3])
output.mkdir(parents=True, exist_ok=True)
checks, errors, external, console_errors = [], [], [], []

def check(name, condition):
    checks.append({'check': name, 'passed': bool(condition)})
    assert condition, name

def digest(data):
    return hashlib.sha256(data).hexdigest()

frozen = {
    'challenge/server.js': 'ad8dd0320b321330aac6758b58b01351df38e3ffbc6704f721ad7d9da86744d8',
    'challenge/package.json': 'fa26d1b3d69419a2fd9c3ccb677a132435322d972d6b986e4c6b2278166b515f',
    'challenge/Dockerfile': '8585ac5d329e41d611aa73b273f3a5345c89853d9b6d16c229173320851b103b',
}
for name, expected in frozen.items():
    check(name + ' unchanged this pass', digest((source/name).read_bytes()) == expected)
html = (source/'challenge/public/index.html').read_text(encoding='utf-8-sig')
css = (source/'challenge/public/css/main.css').read_text(encoding='utf-8-sig')
js = (source/'challenge/public/js/main.js').read_text(encoding='utf-8-sig')
check('Removed panel and all orphan selectors', 'story-note' not in html and 'story-note' not in css)
check('Removed explicit instruction and giveaway commentary from authored UI copy', all(text not in html + js for text in ['A flag gone missing', 'Find the stolen flag', 'About that missing flag', 'your friend wants it back', 'questionable giveaway', 'sending money']))

with urllib.request.urlopen(base + '/api/timeline') as response:
    posts = json.load(response)['posts']
seed_digest = digest(json.dumps(posts, sort_keys=True, separators=(',', ':')).encode())
check('Public seeded post bytes and ordering unchanged', seed_digest == '9bb119615257c832c1891300003f0d0ab9d0e1769d3eab1d0ce4ff948d7b3ee3')

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium-browser', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':1366,'height':768}, reduced_motion='reduce')
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.on('console', lambda message: console_errors.append(message.text) if message.type == 'error' else None)
    page.on('request', lambda request: external.append(request.url) if not request.url.startswith(base) and not request.url.startswith('data:') else None)
    try:
        for route in ['home', 'help', 'about', 'terms', 'privacy', 'people']:
            page.goto(base + '/#' + route)
            expect(page.locator('#view')).to_have_attribute('aria-busy','false')
            await_sprite = page.evaluate("""async () => { const sprite = new Image(); sprite.src = '/images/community-avatars-v2.png'; await sprite.decode(); return sprite.naturalWidth > 1000; }""")
            if route == 'home':
                check('Local avatar sprite fully decoded before capture', await_sprite)
            expect(page.locator('.story-note')).to_have_count(0)
            if route in ['help','about','terms','privacy']:
                text = page.locator('.document-view').inner_text().lower()
                check(route + ' has no challenge-specific guidance', not any(term in text for term in ['flagbeast', 'missing flag', 'stolen flag', '67k', 'session cookie', 'giveaway', 'donation']))
            check(route + ' desktop has no horizontal overflow', page.evaluate('document.documentElement.scrollWidth <= innerWidth'))
            page.screenshot(path=str(output/(route+'-1366.png')))
            if route in ['home','help']:
                page.set_viewport_size({'width':1920,'height':1080})
                page.screenshot(path=str(output/(route+'-1920.png')))
                check(route + ' wide desktop has no horizontal overflow', page.evaluate('document.documentElement.scrollWidth <= innerWidth'))
                page.set_viewport_size({'width':1366,'height':768})
            if route == 'home':
                page.screenshot(path=str(output/'public-timeline-full.png'), full_page=True)
            if route == 'help':
                check('Ordinary Twitter usage help retained', '140' in text and 'drafts' in text and 'profile' in text)
        page.goto(base + '/#home')
        expect(page.locator('#view')).to_have_attribute('aria-busy','false')
        summary = page.locator('.attachment summary').first
        summary.focus()
        page.keyboard.press('Enter')
        expect(page.locator('.attachment-text').first).to_be_visible()
        check('Seeded attachment remains keyboard accessible', True)
        page.locator('.post').filter(has=page.locator('.attachment')).first.screenshot(path=str(output/'public-attachment.png'))
        summary.click()
        page.get_by_role('button', name='Sign up', exact=True).click()
        expect(page.locator('#modal')).to_be_visible()
        page.screenshot(path=str(output/'register.png'))
        page.keyboard.press('Escape')
        page.locator('.post-author').first.click()
        expect(page.locator('.profile-header')).to_be_visible()
        page.evaluate('window.scrollTo(0,0)')
        page.screenshot(path=str(output/'public-profile.png'))
        check('No browser JavaScript or console errors', not errors and not console_errors)
        check('No external browser requests', not external)
    finally:
        browser.close()

public = {p.relative_to(source/'challenge').as_posix():digest(p.read_bytes()) for p in (source/'challenge/public').rglob('*') if p.is_file()}
expected = dict(public)
expected.update({name.removeprefix('challenge/'): value for name,value in frozen.items() if not name.endswith('Dockerfile')})
raw = subprocess.check_output(['docker','exec','rowdy09-cookie','sha256sum',*('/app/'+name for name in expected)],text=True)
deployed = {line.split()[1].removeprefix('/app/'):line.split()[0] for line in raw.splitlines()}
check('Deployed source and public assets match', deployed == expected)
for name, expected_hash in public.items():
    with urllib.request.urlopen(base + '/' + name.removeprefix('public/')) as response:
        assert digest(response.read()) == expected_hash, name
check('All served public assets match source', True)
report = {
    'scope':'Guest-only frontend copy removal. Historical 54 account checks were not rerun.',
    'checks':checks,
    'passed':all(item['passed'] for item in checks),
    'seeded_public_timeline_sha256':seed_digest,
    'seeded_posts':len(posts),
    'unchanged_backend_hashes':frozen,
    'deployed_files_compared':len(expected),
    'http_public_files_compared':len(public),
    'page_errors':errors,
    'console_errors':console_errors,
    'external_requests':external,
    'limitations':'No private seeded-account access, session replay, solver, security testing, or private walkthrough changes. No independent human playtest.',
}
(output/'checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':report['passed'],'checks':len(checks),'output':str(output)}))
