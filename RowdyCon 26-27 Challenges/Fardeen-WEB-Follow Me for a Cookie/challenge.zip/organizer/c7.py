from playwright.sync_api import sync_playwright
import os

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, args=['--no-sandbox'])
    page = browser.new_page()
    page.set_viewport_size({'width': 1920, 'height': 1080})
    page.goto('http://host.docker.internal:18109', wait_until='networkidle')
    page.wait_for_selector('.feed-content')
    page.context.add_cookies([{
        'name': 'aero_session',
        'value': 'aero_sess_flagbeast_2026_stolen_flag',
        'domain': 'host.docker.internal',
        'path': '/',
        'httpOnly': True,
        'sameSite': 'Lax'
    }])
    page.reload(wait_until='networkidle')
    page.wait_for_timeout(1000)
    page.evaluate("document.querySelector('.drafts-nav').style.display = 'flex'")
    page.click('.drafts-nav')
    page.wait_for_selector('.drafts-page')
    page.wait_for_timeout(500)
    page.screenshot(path='/mnt/hostshare/rowdy09-validation/screenshots/07-drafts-flag.png')
    browser.close()
    print('Captured 7')