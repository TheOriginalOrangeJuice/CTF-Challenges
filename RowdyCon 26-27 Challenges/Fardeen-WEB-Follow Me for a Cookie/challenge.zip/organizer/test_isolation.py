#!/usr/bin/env python3
"""Test team isolation - verify team containers don't affect each other."""

import requests
import os

in_container = os.path.exists('/.dockerenv') or os.getenv('CONDEV') or os.getenv('IN_CONDEV')
if in_container:
    TEAM1_URL = "http://host.docker.internal:18109"
    TEAM2_URL = "http://host.docker.internal:18119"
    COOKIE_DOMAIN = "host.docker.internal"
else:
    TEAM1_URL = "http://localhost:18109"
    TEAM2_URL = "http://localhost:18119"
    COOKIE_DOMAIN = "localhost"

TARGET_COOKIE = "aero_sess_flagbeast_2026_stolen_flag"
EXPECTED_FLAG = "RCC{aero_session_hijack_1n_th3_w1ld}"

def check_drafts(base_url, label):
    session = requests.Session()
    session.cookies.set("aero_session", TARGET_COOKIE, domain=COOKIE_DOMAIN, path="/")
    resp = session.get(f"{base_url}/api/drafts")
    drafts = resp.json().get("drafts", [])
    print(f"{label}: {len(drafts)} draft(s)")
    for d in drafts:
        print(f"  Draft {d['id']}: Flag present = {EXPECTED_FLAG in d['content']}")
    return drafts

print("=== Team Isolation Test ===")
print()

drafts1 = check_drafts(TEAM1_URL, "Team 1 (port 18109)")
drafts2 = check_drafts(TEAM2_URL, "Team 2 (port 18119)")

print()
if len(drafts1) == 1 and len(drafts2) == 1:
    print("[+] Both teams have their own independent @FlagBeast draft")
    print("[+] Team isolation working correctly")
else:
    print("[-] Team isolation issue detected")
