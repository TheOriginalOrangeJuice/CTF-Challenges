"""Ordinary deployment parity and clean reset. No private-account or security checks."""
import hashlib
import json
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

source = Path(sys.argv[1])
base = sys.argv[2].rstrip('/')
service = sys.argv[3]
output = Path(sys.argv[4])
expected_backend = {
    'server.js': 'ad8dd0320b321330aac6758b58b01351df38e3ffbc6704f721ad7d9da86744d8',
    'package.json': 'fa26d1b3d69419a2fd9c3ccb677a132435322d972d6b986e4c6b2278166b515f',
    'Dockerfile': '8585ac5d329e41d611aa73b273f3a5345c89853d9b6d16c229173320851b103b',
}
sha = lambda data: hashlib.sha256(data).hexdigest()
for name, expected in expected_backend.items():
    assert sha((source / 'challenge' / name).read_bytes()) == expected, name
public = {p.relative_to(source / 'challenge').as_posix(): sha(p.read_bytes()) for p in (source / 'challenge/public').rglob('*') if p.is_file()}
expected = dict(public)
expected.update({name: expected_backend[name] for name in ('server.js', 'package.json')})
result = subprocess.check_output(['docker', 'exec', service, 'sha256sum', *('/app/' + name for name in expected)], text=True)
deployed = {line.split()[1].removeprefix('/app/'): line.split()[0] for line in result.splitlines()}
assert deployed == expected, 'Deployment bytes differ'
http_differences = []
for name, digest in public.items():
    with urllib.request.urlopen(base + '/' + name.removeprefix('public/')) as response:
        if sha(response.read()) != digest:
            http_differences.append(name)
assert not http_differences

def get(path):
    with urllib.request.urlopen(base + path) as response:
        return json.load(response)

def digest_posts(posts):
    return sha(json.dumps(posts, sort_keys=True, separators=(',', ':')).encode())

before = get('/api/timeline')['posts']
seeded_before = [post for post in before if post['authorHandle'] != 'ui09review']
subprocess.run(['docker', 'restart', service], check=True, capture_output=True)
for _ in range(40):
    try:
        get('/api/health')
        break
    except Exception:
        time.sleep(.25)
after = get('/api/timeline')['posts']
assert digest_posts(after) == digest_posts(seeded_before), 'Seeded public timeline changed'
reviewer_search = get('/api/search?q=ui09review')
assert not reviewer_search['users'] and not reviewer_search['posts'], 'Reviewer state was not reset'
health = ''
for _ in range(25):
    health = subprocess.check_output(['docker', 'inspect', '--format', '{{.State.Health.Status}}', service], text=True).strip()
    if health == 'healthy':
        break
    time.sleep(2)
assert health == 'healthy', health
report = {
    'scope': 'Byte parity, ordinary public assets, public timeline reset, and service health only.',
    'verified_source_hashes': expected_backend,
    'server_and_package_unchanged': True,
    'dockerfile_change': 'Approved one-line IPv4 health-probe address correction; localhost replaced by 127.0.0.1 for the same /api/health route.',
    'deployed_files_compared': len(expected),
    'deployed_hash_differences': 0,
    'http_public_files_compared': len(public),
    'http_public_hash_differences': 0,
    'public_seeded_timeline_posts': len(after),
    'public_seeded_timeline_sha256': digest_posts(after),
    'public_timeline_after_reset_matches_seeded_posts_before_reset': True,
    'reviewer_account_and_posts_reset': True,
    'service': service,
    'health': health,
    'url': base,
    'limitations': 'No private target access, session replay, exploit solver, cross-account probing, or negative security tests performed.'
}
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
