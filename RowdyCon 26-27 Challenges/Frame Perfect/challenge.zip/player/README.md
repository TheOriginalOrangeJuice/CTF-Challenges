# The Borrowed Stage

As a kid, I remember watching this episode that aired on April 14th, 2010 and wanting to go to this EXACT spot and recreate this pose, but 2D animation is not real :( - HOWEVER, As I got older, I found out that the guitarist is a real person??!! Which means this spot is real and this stage is real! I'd like to visit the place captured in the photograph he resembles. What was the concert site called?

![The guitar-appraisal montage](pause.jpg)

Submit the **specific concert-site name** as `RCC{site_name}`. 
