# Built for the End of the World


Look, I work in a Nuclear Facility and my PRIMARY worry is that my laptop won't survive if a disaster occurs. While I watching Evangelion, I saw that they were using a paticular laptop that look quite sturdy. I think this is the laptop that would ease all my worries. Can you find out what laptop it is so that I can go out and buy it? I just need the model number.


![Film frame showing a laptop in use](scene.jpg)

Submit `RCC{model}`. The model family is enough.

