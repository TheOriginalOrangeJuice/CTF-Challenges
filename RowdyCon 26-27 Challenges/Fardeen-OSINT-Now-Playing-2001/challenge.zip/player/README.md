# Now Playing, 2001


I got a job to work for the government as an IT Assitant! On my first day, they asked to me to reinstall the Windows XP Operating System... weird we still use that in 2026. I reinstalled it and wanted to test the functionality to I booted up the Original Media Player. I was so shocked when the male singer's voice started playing as the default song. His voie was so crisp and clear.. I must know what microphone he used to record it. What microphone model did the original album's producer say he used for those vocals?


Submit `RCC{model}`. - I don't need the brand, it's probably a Sony. 
