# A Souvenir with a Moveset

My friend got this invitation to a launch party of some Digimon game. He apparently got a free monster that a curved horn and was a holding a "Ganlon Berry"? It's also somewhat rare becasue it came with a move that it normally couldn't learn from the original game? I really want to know what move that was; can you tell me the English name of that special move?


![Original launch invitation](invitation.jpg)

Submit `RCC{move_name}`.

