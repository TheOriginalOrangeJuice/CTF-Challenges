# A Voice Before Launch

Before Halo 2 launched in 2004, its promotional campaign had players answering real payphones to unlock pieces of an audio story. I'm trying to find one of those original clips: a junior officer suspects a ship's records were deliberately erased, while his superior denies a cover-up. When he suggests asking the captain to confirm the story, his superior says she is dead. I never found out what the filename was for the full recording, could you get the name?

Submit `RCC{filename.acc}`.
