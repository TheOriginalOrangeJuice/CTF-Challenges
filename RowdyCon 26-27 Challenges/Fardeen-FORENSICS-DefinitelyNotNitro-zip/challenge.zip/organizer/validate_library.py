"""Validate optional media, HTTP seeking, and the frozen evidence on the final service."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import subprocess
from urllib.request import Request,urlopen
from urllib.error import HTTPError
import wave
import zipfile
from PIL import Image

def validate(url):
    root=Path(__file__).resolve().parents[1]
    catalog=json.load(urlopen(url+'/catalog.json'))
    result={'downloads':[],'media_ranges':[],'evidence_unchanged':False}
    for entry in catalog['entries']:
        with urlopen(url+entry['download']) as response:
            data=response.read();headers=response.headers
        assert len(data)==entry['bytes']
        assert entry['name'] in headers['Content-Disposition']
        local=root/'challenge/public'/entry['download'].lstrip('/')
        assert data==local.read_bytes()
        if entry['name'].endswith('.zip'):
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                assert archive.testzip() is None
                for file in entry['files']:
                    body=archive.read(file['name']);assert len(body)==file['bytes']
                    if file['name'].endswith('.jpg'):
                        im=Image.open(io.BytesIO(body));assert im.size==(1920,1200);im.verify()
                    if file['name'].endswith('.wav'):
                        with wave.open(io.BytesIO(body)) as wav:
                            assert wav.getnframes()>1000 and wav.getnchannels() in [1,2]
        else:
            probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(local)],text=True))
            assert float(probe['format']['duration'])>10
            assert probe['streams'][0]['codec_name']==('flac' if entry['id']==2 else 'wmv2')
        result['downloads'].append({'name':entry['name'],'bytes':len(data),'opened':True})
        for item in entry['previews']:
            route=item['url'];head=urlopen(Request(url+route,method='HEAD'))
            total=int(head.headers['Content-Length']);assert not head.read()
            with urlopen(Request(url+route,headers={'Range':'bytes=0-63'})) as response:
                assert response.status==206 and len(response.read())==64
                assert response.headers['Content-Range']==f'bytes 0-63/{total}'
            with urlopen(Request(url+route,headers={'Range':'bytes=-32'})) as response:
                assert response.status==206 and len(response.read())==32
            for bad in [f'bytes={total}-','bytes=9-2','bytes=-0','bytes=0-2,5-9','bytes=abc']:
                try:urlopen(Request(url+route,headers={'Range':bad}))
                except HTTPError as error:assert error.code==416
                else:raise AssertionError('Invalid range accepted')
            result['media_ranges'].append(route)
    baseline=json.loads((root/'organizer/evidence-baseline.json').read_text())
    for name,digest in baseline.items():
        assert hashlib.sha256(urlopen(url+'/evidence/'+name).read()).hexdigest()==digest
    result['evidence_unchanged']=True
    result['result']='PASS'
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--url',required=True);parser.add_argument('--report',type=Path,required=True);args=parser.parse_args()
    result=validate(args.url);args.report.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
