"""Render the frozen licensed notation with the organizer-only media image."""
from pathlib import Path
import subprocess
import tempfile

root=Path(__file__).resolve().parents[1]
sources=root/'organizer/media-sources'
with tempfile.TemporaryDirectory(prefix='nitro06-piano-') as temporary:
    work=Path(temporary)
    score=(sources/'lunatic-princess.ly').read_text()
    # Keep the composer's notes; set a comfortable piano tempo for the rendering.
    score=score.replace('\\midi { }','\\midi { \\tempo 4 = 144 }')
    (work/'piano.ly').write_text(score)
    subprocess.run(['lilypond','-dno-print-pages','-o',str(work/'piano'),str(work/'piano.ly')],check=True)
    subprocess.run(['fluidsynth','-ni','-r','44100','-g','0.6','-R','1','-C','0',
                    '-F',str(sources/'lunatic-princess.wav'),
                    '/usr/share/sounds/sf2/TimGM6mb.sf2',str(work/'piano.midi')],check=True)
    (sources/'soundfont-copyright.txt').write_bytes(Path('/usr/share/doc/timgm6mb-soundfont/copyright').read_bytes())
