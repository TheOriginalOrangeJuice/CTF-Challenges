"""Exercise the final client, download real files, and capture actual browser output."""
import argparse
import json
from pathlib import Path
from datetime import datetime, timezone
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright, expect
from solve import recover

def capture_download_buttons(browser,url,out):
    page=browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=3)
    page.goto(url)
    expect(page.locator('#transfer-rows tr')).to_have_count(5)
    first=page.locator('#save-capture').bounding_box()
    last=page.locator('#save-torrent').bounding_box()
    page.screenshot(path=str(out/'07-evidence-downloads.png'),clip={
        'x':first['x']-4,'y':first['y']-4,
        'width':last['x']+last['width']-first['x']+8,'height':first['height']+8})
    page.close()

def main(url,out):
    out.mkdir(parents=True,exist_ok=True)
    errors=[];external=[];report={}
    with sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path='/usr/bin/chromium-browser',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.on('console',lambda m:errors.append(m.text) if m.type=='error' else None)
        page.on('request',lambda r:external.append(r.url) if urlsplit(r.url).scheme in ('http','https') and urlsplit(r.url).netloc!=urlsplit(url).netloc else None)
        moment=datetime(2010,10,23,20,15,tzinfo=timezone.utc)
        page.clock.install(time=moment);page.clock.pause_at(moment)
        page.goto(url);expect(page.locator('#transfer-rows tr')).to_have_count(5)
        catalog=page.request.get(url+'/catalog.json').json()
        expect(page.locator('#transfer-rows [data-id="2"]')).to_contain_text('Downloading')
        expect(page.locator('#transfer-rows [data-id="4"]')).to_contain_text('Queued')
        expect(page.locator('#save-file')).to_be_disabled()
        page.clock.run_for(12000)
        expect(page.locator('#transfer-rows [data-id="4"]')).to_contain_text('Downloading')
        page.screenshot(path=str(out/'01-client-overview.png'),full_page=True)
        capture_download_buttons(browser,url,out)
        row=page.locator('#transfer-rows [data-id="2"]')
        row.click();before=row.locator('.progress em').inner_text()
        page.locator('#transfer-toggle').click();page.clock.run_for(4000)
        expect(row).to_contain_text('Paused')
        assert row.locator('.progress em').inner_text()==before
        expect(row.locator('[data-field="down"]')).to_have_text('—')
        page.locator('#transfer-toggle').click();page.clock.run_for(2000)
        assert row.locator('.progress em').inner_text()!=before
        page.locator('#pause-all').click()
        progress=page.locator('.progress em').all_text_contents()
        page.clock.run_for(5000)
        assert page.locator('.progress em').all_text_contents()==progress
        expect(page.locator('#download-speed')).to_have_text('0.0')
        expect(page.locator('#upload-speed')).to_have_text('0.0')
        # Downloads remain available during session and row pauses.
        for entry in catalog['entries']:
            page.locator(f'#transfer-rows [data-id="{entry["id"]}"]').click()
            with page.expect_download() as got:page.locator('#save-file').click()
            download=got.value;assert download.suggested_filename==entry['name']
            target=out/entry['name'];download.save_as(str(target));assert target.stat().st_size==entry['bytes']
        page.locator('#pause-all').click()
        page.locator('#transfer-rows [data-id="2"]').click()
        page.locator('[data-tab="peers"]').click()
        first=page.locator('#live-peers').inner_text()
        page.clock.run_for(6000)
        assert page.locator('#live-peers').inner_text()!=first
        expect(page.locator('#live-peers')).to_contain_text('Incoming')
        expect(page.locator('#live-peers')).to_contain_text('Outgoing')
        page.screenshot(path=str(out/'02-live-peers.png'),full_page=True)
        page.locator('#toggle-addresses').click()
        expect(page.locator('#live-peers')).not_to_contain_text('203.0.113.')
        page.locator('#toggle-addresses').click()
        page.locator('[data-tab="trackers"]').click();page.locator('#refresh-trackers').click()
        expect(page.locator('#toast')).to_contain_text('updated')
        page.locator('[data-tab="speed"]').click()
        for mode in ['download','upload','both']:page.locator('#graph-type').select_option(mode)
        page.screenshot(path=str(out/'03-speed-graph.png'),full_page=True)
        page.locator('[data-tab="logger"]').click()
        expect(page.locator('#log-lines')).to_contain_text('Incoming connection')
        with page.expect_download() as got:page.locator('#save-log').click()
        got.value.save_as(str(out/'aerotorrent-session.log'))
        # Media controls load actual pixels/audio, seek, and stop when closed.
        for entry in catalog['entries']:
            page.locator(f'#transfer-rows [data-id="{entry["id"]}"]').click()
            page.locator('#open-file').click();expect(page.locator('#dialog')).to_be_visible()
            if entry['id']==1:
                image=page.locator('#wallpaper');expect(image).to_be_visible()
                image.evaluate('(im)=>im.decode()')
                assert image.evaluate('(im)=>im.naturalWidth')==1920
                original=image.get_attribute('src');page.locator('#next-wallpaper').click()
                assert image.get_attribute('src')!=original
                page.locator('#previous-wallpaper').click();assert image.get_attribute('src')==original
            else:
                media=page.locator('#dialog audio,#dialog video')
                for item in media.all():
                    item.evaluate("""async el => {
                      if(el.readyState<1) await new Promise((resolve,reject)=>{
                        el.addEventListener('loadedmetadata',resolve,{once:true});
                        el.addEventListener('error',reject,{once:true});el.load();
                      });
                      if(!Number.isFinite(el.duration)||el.duration<=0) throw Error('Missing media duration');
                      await el.play();
                      el.currentTime=Math.min(el.duration*.5,8);
                      await new Promise(resolve=>el.addEventListener('seeked',resolve,{once:true}));
                    }""")
                    assert item.evaluate('(el)=>!el.paused && el.currentTime>0')
                    item.evaluate('(el)=>el.pause()')
                if entry['id']==2:
                    page.locator('[data-track="0"]').click()
                    assert not page.locator('#music-player').evaluate('(el)=>el.paused')
            page.screenshot(path=str(out/f'preview-{entry["id"]}.png'),full_page=True)
            page.keyboard.press('Escape');expect(page.locator('#dialog')).not_to_be_visible()
        # File tab and context menu downloads use the same real file.
        page.locator('#transfer-rows [data-id="1"]').click();page.locator('[data-tab="files"]').click()
        expect(page.locator('#detail-panel .detail-table tbody tr')).to_have_count(3)
        with page.expect_download() as got:page.locator('#detail-panel a[download]').click()
        assert got.value.suggested_filename=='Aqua_Wallpapers_1920x1200.zip'
        page.locator('#transfer-rows [data-id="3"]').click(button='right')
        with page.expect_download() as got:page.locator('#menu [data-action="save"]').click()
        assert got.value.suggested_filename=='Windows_7_Sounds_Extra.zip'
        page.locator('#favorite').click();page.locator('[data-filter="favorite"]').click()
        expect(page.locator('#transfer-rows tr')).to_have_count(2)
        page.locator('[data-filter="all"]').click();page.locator('#search').fill('touhou')
        expect(page.locator('#transfer-rows tr')).to_have_count(1)
        page.locator('#search').fill('not a file');expect(page.locator('#empty')).to_be_visible()
        page.locator('#search').fill('');page.locator('#attention').check()
        expect(page.locator('#transfer-rows tr')).to_have_count(1)
        page.locator('#attention').uncheck()
        for key in ['name','bytes','progress','state','down','up','seeds','eta']:
            button=page.locator(f'th[data-key="{key}"] button');button.click()
            expect(button.locator('..')).to_have_attribute('aria-sort','ascending')
            button.click();expect(button.locator('..')).to_have_attribute('aria-sort','descending')
        page.locator('[data-menu="file"]').click()
        with page.expect_download() as got:page.locator('#menu [data-action="export"]').click()
        assert got.value.suggested_filename=='aerotorrent-history.csv'
        page.locator('[data-menu="view"]').click();page.locator('#menu [data-action="expand"]').click()
        expect(page.locator('body')).to_have_class('expanded')
        page.locator('#expand').click()
        page.locator('[data-menu="options"]').click();page.locator('#menu [data-action="options"]').click()
        page.locator('#option-addresses').check();page.locator('#option-motion').check();page.locator('#option-expand').check()
        page.locator('#dialog-ok').click();expect(page.locator('body')).to_have_class('reduce-motion expanded')
        page.locator('#help').click();expect(page.locator('#dialog')).to_contain_text('Save file')
        page.locator('#dialog-ok').click()
        # Keyboard navigation and background updates preserve focus.
        page.locator('#reset').click();page.clock.run_for(3000)
        page.locator('#transfer-rows [data-id="1"]').focus();page.keyboard.press('ArrowDown')
        expect(page.locator('#selection-name')).to_have_text('Touhou_Piano_Collection.flac')
        focused=page.evaluate('document.activeElement.dataset.id');page.clock.run_for(3000)
        assert page.evaluate('document.activeElement.dataset.id')==focused
        page.keyboard.press('Shift+F10');expect(page.locator('#menu')).to_be_visible()
        page.keyboard.press('Escape');expect(page.locator('#menu')).not_to_be_visible()
        page.locator('#tab-general').focus();page.keyboard.press('ArrowRight')
        expect(page.locator('#tab-trackers')).to_be_focused()
        page.locator('#reset').click()
        original=page.locator('#transfer-rows').inner_text()
        page.clock.run_for(9000)
        sequence=page.locator('#transfer-rows').inner_text()
        page.locator('#reset').click();assert page.locator('#transfer-rows').inner_text()==original
        page.clock.run_for(9000);assert page.locator('#transfer-rows').inner_text()==sequence
        # Reduced motion preserves activity and the full authored queue progression.
        page.emulate_media(reduced_motion='reduce');page.locator('#reset').click();page.clock.run_for(9000)
        assert page.locator('#transfer-rows').inner_text()==sequence
        assert page.locator('.progress span').first.evaluate('(el)=>getComputedStyle(el).transitionDuration')=='0s'
        page.clock.run_for(300000)
        expect(page.locator('[data-filter="seeding"] b')).to_have_text('4')
        page.locator('#reset').click();page.reload();expect(page.locator('#transfer-rows tr')).to_have_count(5)
        assert page.locator('#transfer-rows').inner_text()==original
        # Nitro remains the original historical evidence, separate from ambient activity.
        page.locator('[data-tab="peers"]').click()
        expect(page.locator('#detail-panel')).to_contain_text('198.51.100.21:51413')
        expect(page.locator('#detail-panel .detail-table tbody tr')).to_have_count(4)
        page.locator('[data-tab="logger"]').click()
        expect(page.locator('.logger .warning')).to_have_count(2)
        page.screenshot(path=str(out/'04-nitro-log.png'),full_page=True)
        page.locator('[data-tab="files"]').click();page.locator('#uploader-note').click()
        expect(page.locator('#dialog')).to_contain_text('FREE NITRO')
        page.locator('#dialog-ok').click()
        for selector,name in [('#save-capture','transfer-session.pcap'),('#save-torrent','DefinitelyNotNitro.torrent')]:
            with page.expect_download() as got:page.locator(selector).click()
            assert got.value.suggested_filename==name;got.value.save_as(str(out/name))
        stats=recover(out/'DefinitelyNotNitro.torrent',out/'transfer-session.pcap',out/'recovered')
        page.goto((out/'recovered/OPEN_ME.png').resolve().as_uri())
        expect(page.locator('img')).to_be_visible();page.locator('img').evaluate('(im)=>im.decode()')
        bounds=page.locator('img').bounding_box()
        page.screenshot(path=str(out/'09-recovered-code.png'),clip={'x':bounds['x']+170,'y':bounds['y']+270,'width':1090,'height':410})
        browser.close()
    assert not errors,errors
    assert not external,external
    report={'result':'PASS','console_errors':errors,'external_requests':external,'public_download_solve':stats,
            'controls':'automatic activity, per-row pause/resume, global pause/resume, queued start, seeding, deterministic reset/reload, filters, search, all sorts, favorites, all tabs, menus, keyboard, context menu, focus retention, options, exports',
            'media':'all four downloads while paused; image carousel, FLAC playback, track button, all four WAVs, video playback and seeking; file-tab/context save',
            'reduced_motion':'same queue progression; decorative transitions disabled',
            'viewports':['1440x1000'],'independent_human_playtest':False}
    (out/'browser-results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--url',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();main(a.url,a.output)
