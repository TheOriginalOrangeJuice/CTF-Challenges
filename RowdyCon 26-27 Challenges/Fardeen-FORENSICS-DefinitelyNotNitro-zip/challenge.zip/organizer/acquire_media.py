"""Acquire presentation sources. Run only in Condev; never modifies puzzle evidence."""
from pathlib import Path
from urllib.request import Request, urlopen
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'organizer/media-sources'
DEST.mkdir(parents=True, exist_ok=True)

SOURCES = {
    'ocean.mp4': 'https://videos.pexels.com/video-files/1409899/1409899-hd_1920_1080_25fps.mp4',
    'lunatic-princess.ly': 'https://raw.githubusercontent.com/BakaBBQ/touhou-recollections.ly/master/th08_6b_boss.ly',
    'piano-license.md': 'https://raw.githubusercontent.com/BakaBBQ/touhou-recollections.ly/master/README.md',
    'reactos-license.txt': 'https://raw.githubusercontent.com/reactos/reactos/master/COPYING',
    'ReactOS_Startup.wav': 'https://raw.githubusercontent.com/reactos/reactos/master/media/sounds/ReactOS_Startup.wav',
    'ReactOS_Notify.wav': 'https://raw.githubusercontent.com/reactos/reactos/master/media/sounds/ReactOS_Notify.wav',
    'ReactOS_Recycle.wav': 'https://raw.githubusercontent.com/reactos/reactos/master/media/sounds/ReactOS_Recycle.wav',
    'ReactOS_Critical_Stop.wav': 'https://raw.githubusercontent.com/reactos/reactos/master/media/sounds/ReactOS_Critical_Stop.wav',
    'reactos-sound-list.json': 'https://api.github.com/repos/reactos/reactos/contents/media/sounds',
}
records=[]
for name,url in SOURCES.items():
    file=DEST/name
    try:
        if not file.exists():
            with urlopen(Request(url, headers={'User-Agent': 'Mozilla/5.0 AeroTorrent educational media archive'}),timeout=90) as response:
                data=response.read()
                if name.endswith('.mp3') and (data[:100].lstrip().startswith(b'<!') or len(data)<10000):
                    raise ValueError('Expected audio, received a page')
                file.write_bytes(data)
        records.append({'file':name,'url':url,'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
        print(name, file.stat().st_size, flush=True)
    except Exception as error:
        print(name, type(error).__name__, str(error), flush=True)
(DEST/'acquisition.json').write_text(json.dumps(records,indent=2)+'\n')
