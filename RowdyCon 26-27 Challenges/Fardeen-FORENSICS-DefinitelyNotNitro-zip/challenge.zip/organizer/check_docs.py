"""Verify local documentation links and current source/deployment asset parity."""
import argparse
import hashlib
from pathlib import Path
import re
import zipfile
import xml.etree.ElementTree as ET
from urllib.request import urlopen

parser=argparse.ArgumentParser();parser.add_argument('--url',required=True);args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
links=0
for doc in root.glob('*.md'):
    for link in re.findall(r'!?\[[^\]]*\]\(([^)]+)\)',doc.read_text()):
        if '://' in link:continue
        assert (doc.parent/link.split('#')[0]).is_file(),(doc,link)
        links+=1
for file in (root/'challenge/public').rglob('*'):
    if file.is_file():
        route='/'+file.relative_to(root/'challenge/public').as_posix()
        assert urlopen(args.url+route).read()==file.read_bytes(),route
doc=(root/'Description.md').read_text(encoding='utf-8')
assert re.findall(r'^## (.+)$',doc,re.M)==['Description','Files','Hint(s)','Walkthrough','Flag']
assert (root/'Description.docx').is_file()
assert 'RCC{n1tr0g3n_1s_78_p3rc3nt_fr33}' in doc
with zipfile.ZipFile(root/'Description.docx') as archive:
    xml=ET.fromstring(archive.read('word/document.xml'))
    namespaces={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    script=re.search(r'```python\n(.*?)\n```',doc,re.S).group(1)
    lines=[line.rstrip() for line in script.splitlines()]
    paragraphs=[''.join(p.itertext()).rstrip() for p in xml.findall('.//w:p',namespaces)]
    first=paragraphs.index(lines[0])
    assert paragraphs[first:first+len(lines)]==lines,'DOCX script indentation or text differs'
    assert script.strip()==(root/'organizer/walkthrough_recover.py').read_text().strip()
    word_text=''.join(xml.itertext())
    # Compare every authored text/code fragment, including linked labels and
    # Windows commands, after removing Markdown's presentation characters.
    normalized=lambda text:re.sub(r'\s+','',text)
    word_text=normalized(word_text)
    body=doc[doc.index('## Description'):]
    for line in body.splitlines():
        if not line.strip() or line.startswith(('## ','```','![')):continue
        line=re.sub(r'\[([^\]]+)\]\([^)]+\)',r'\1',line)
        line=line.replace('**','').replace('`','')
        # A continuation backtick is part of the actual PowerShell command.
        assert normalized(line) in word_text,(line,'missing from DOCX')
    images=re.findall(r'!\[[^\]]*\]\(([^)]+)\)',doc)
    expected={hashlib.sha256((root/name).read_bytes()).hexdigest() for name in images}
    embedded={hashlib.sha256(archive.read(name)).hexdigest() for name in archive.namelist() if name.startswith('word/media/')}
    assert len(images)==5 and expected==embedded,'DOCX screenshots differ from Markdown'
assert not any((root/name).exists() for name in ['README.md','DEPLOYMENT.md','QA.md','SOLTION.md'])
print(f'PASS: {links} local links, five sections, matching DOCX text and five screenshot files, and every public source file matches the running image')
