# Maintaining AeroTorrent

The checked-in `challenge/` is ready to build. It contains the public app, evidence, and optional media; organizer files are excluded from the deployment image. See `Description.md` for build/run commands. The review container is `rowdy06-nitro-test`, port 18106; stop it with `docker stop rowdy06-nitro-test`. From Condev use `http://host.docker.internal:18106`.

On Windows, execute project tools through Condev. Stage the complete challenge with `organizer/stage_for_condev.ps1 -StageName nitro06-<unique-name>` and require zero SHA-256 differences. It uses the Condev skill's staging helper and checks the isolated container copy. Do not test a stale stage after editing.

## Evidence

The original capture, torrent, and manifest remain frozen. To rebuild deliberately, run in the staged challenge root:

```bash
python3 -m venv .venv
.venv/bin/pip install -r organizer/requirements.txt
.venv/bin/python organizer/generate.py
.venv/bin/python organizer/validate.py --url http://host.docker.internal:18106
```

`validate.py` compares independent regenerations, checks protocol integrity, reconstructs the archive, and checks serving boundaries. Compare against `evidence-baseline.json`. Keep the recovered ZIP and card private. `solve.py` prints two lines normally; `--verbose` enables diagnostics.

## Optional media and screenshots

Frozen media inputs are in `organizer/media-sources/`. They are separate from puzzle generation. Build the isolated organizer tools from the challenge root inside Condev:

```bash
docker build -f organizer/Dockerfile.capture -t rowdy06-capture:20261026 .
docker build -f organizer/Dockerfile.media -t rowdy06-media:20261026 .
docker run -d --name rowdy06-media-tools --network none rowdy06-media:20261026 sleep infinity
docker cp . rowdy06-media-tools:/work/challenge06
docker exec rowdy06-media-tools python /work/challenge06/organizer/render_piano.py
docker exec rowdy06-media-tools python /work/challenge06/organizer/generate_library.py
```

Copy generated `challenge/public/` and `organizer/library-build.json` back before rebuilding the app. Required license notices are bundled with the media. `acquire_media.py` can restore missing inputs when network access is available; it reuses existing files. Ordinary builds and play are offline.

`capture_walkthrough.py --root ROOT --work ROOT/NitroRecovery --output ROOT/screenshots` runs real Wireshark and xterm windows under Xvfb in the organizer image. Put the two browser-downloaded evidence files in `ROOT/NitroRecovery` first. It copies the complete printed Python code from `Description.md` into `recover.py`, enables packet reassembly in Wireshark, expands an actual piece message, and runs `python recover.py` from that folder. Use `--terminal-only` when only the script output has changed. The guide uses a focused capture of the decoded fields; `wireshark-full.png` retains the complete window. Stop the disposable tools container after use.

The concise guide also uses `capture_settings.py --capture ROOT/NitroRecovery/transfer-session.pcap --output ROOT/screenshots` for the two real protocol-preference captures. The printed script now uses Wireshark's TShark for TCP reassembly and `bencodepy==0.9.5` for torrent metadata. Both are in the capture image; the original Scapy reference solver remains available for maintenance.

## Checks

Run these in the current staged challenge root with the shared Condev Python environment (or an environment containing organizer requirements and Playwright). Browser automation uses Chromium at `/usr/bin/chromium-browser`.

```bash
python organizer/browser_qa.py --url http://host.docker.internal:18106 --output /tmp/nitro06-browser-review
python organizer/validate_library.py --url http://host.docker.internal:18106 --report /tmp/nitro06-library-review.json
python organizer/check_reset.py --url http://host.docker.internal:18106 --container rowdy06-nitro-test
python organizer/check_docs.py --url http://host.docker.internal:18106
python organizer/validate_walkthrough.py --url http://host.docker.internal:18106 --output /tmp/nitro06-walkthrough-review --solver-container rowdy06-media-tools
```

Run `python organizer/build_document.py --builder PATH_TO_SHARED/build_description.py` to rebuild `Description.docx`. This uses the shared builder and template, with print sizing for the five screenshots. Inspect every rendered page before copying it back. Keep test reports in `organizer/`, separate from the guide. Windows commands are reviewed separately from Condev execution; neither is independent human playtesting.

Players receive the website only. The walkthrough must begin with a new folder and the website's downloads; it must not invoke `organizer/solve.py` or assume access to the source tree. Its complete `recover.py` is printed in the guide. `walkthrough_recover.py` is the organizer's matching maintenance copy. `validate_walkthrough.py` extracts that printed code into an empty folder, downloads both inputs through the browser, and runs it without organizer imports.

The torrent's experimental notice and labeled sample code are optional metadata outside the `info` dictionary. They add no solve step and do not block scripts or browsers. Autonomous-agent deterrent effectiveness remains unmeasured.
