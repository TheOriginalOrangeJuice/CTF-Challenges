"""Compare a complete staged source tree against an external SHA-256 inventory."""
import argparse
import hashlib
import json
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('manifest', type=Path)
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
expected = json.loads(args.manifest.read_text(encoding='utf-8-sig'))
actual = {
    file.relative_to(root).as_posix(): hashlib.sha256(file.read_bytes()).hexdigest().lower()
    for file in root.rglob('*')
    if file.is_file() and '__pycache__' not in file.parts
}
assert actual == expected, {
    name: (expected.get(name), actual.get(name))
    for name in sorted(expected.keys() | actual.keys())
    if expected.get(name) != actual.get(name)
}
print(json.dumps({'source_files': len(actual), 'hash_differences': 0}))
