"""Print useful observations from the two player downloads, without recovering files."""
import argparse
from collections import Counter
import hashlib
from pathlib import Path
import struct
from scapy.all import rdpcap, IP, TCP
from solve import bdecode, reassemble, messages

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('torrent',type=Path);parser.add_argument('pcap',type=Path)
args=parser.parse_args()
meta,raw_info=bdecode(args.torrent.read_bytes());info=meta[b'info'];ih=hashlib.sha1(raw_info).digest()
print('FILE:',info[b'name'].decode())
print('FILE LENGTH:',info[b'length'])
print('PIECE LENGTH:',info[b'piece length'])
print('HASH COUNT:',len(info[b'pieces'])//20)
print('INFO HASH:',ih.hex())
print('FIRST PIECE SHA-1:',info[b'pieces'][:20].hex())
packets=rdpcap(str(args.pcap));print('PACKETS:',len(packets))
print('FIRST THREE TCP FLAGS:',','.join(str(p[TCP].flags) for p in packets[:3]))
print('PEERS:',', '.join(sorted({p[IP].src for p in packets if p[TCP].sport==51413})))
streams,repeated=reassemble(packets)
print('DIRECTIONAL TCP STREAMS:',len(streams))
print('DUPLICATE TCP BYTES:',repeated)
for flow,stream in sorted(streams.items()):
    if flow[1]!=51413:continue
    records=list(messages(stream,ih))
    print('\nPEER:',flow[0],'HANDSHAKE INFO HASH:',stream[28:48].hex())
    print('MESSAGE IDS:',dict(Counter(kind for kind,_ in records)))
    print('FIRST FIVE PIECE BLOCKS (index, begin, length):')
    blocks=[(*struct.unpack('!II',body[:8]),len(body)-8) for kind,body in records if kind==7]
    for block in blocks[:5]:print(' ',block)
