"""Follow the guide in an empty folder using only the website and its printed code."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid
import zipfile
from PIL import Image
from playwright.sync_api import sync_playwright

parser=argparse.ArgumentParser()
parser.add_argument('--url',required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--solver-container',help='Isolated rowdy06 container with Python, bencodepy and TShark')
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
guide=(root/'Description.md').read_text()
code=re.search(r'```python\n(.*?)\n```',guide,re.S).group(1)+'\n'
assert code.strip()==(root/'organizer/walkthrough_recover.py').read_text().strip()
walkthrough=guide.split('## Walkthrough',1)[1].split('## Flag',1)[0]
assert 'organizer/' not in walkthrough and 'organizer\\' not in walkthrough
assert 'Open this challenge folder' not in walkthrough
session=args.output/'NitroRecovery'
session.mkdir(parents=True,exist_ok=False)
(session/'recover.py').write_text(code)
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium-browser',args=['--no-sandbox'])
    page=browser.new_page()
    page.goto(args.url)
    for button,name in [('#save-capture','transfer-session.pcap'),('#save-torrent','DefinitelyNotNitro.torrent')]:
        with page.expect_download() as event:page.locator(button).click()
        assert event.value.suggested_filename==name
        event.value.save_as(str(session/name))
    browser.close()
initial=sorted(path.name for path in session.iterdir())
assert initial==['DefinitelyNotNitro.torrent','recover.py','transfer-session.pcap']
env=os.environ.copy()
env.pop('PYTHONPATH',None)
archive=session/'DefinitelyNotNitro.zip'
if args.solver_container:
    assert args.solver_container.startswith('rowdy06-')
    remote='/tmp/nitro06-player-'+uuid.uuid4().hex
    subprocess.run(['docker','cp',str(session),args.solver_container+':'+remote],check=True)
    run=subprocess.run(['docker','exec','-w',remote,args.solver_container,'python','recover.py'],check=True,text=True,capture_output=True)
    subprocess.run(['docker','cp',args.solver_container+':'+remote+'/DefinitelyNotNitro.zip',str(archive)],check=True)
else:
    run=subprocess.run([sys.executable,'recover.py'],cwd=session,env=env,check=True,text=True,capture_output=True)
with zipfile.ZipFile(archive) as z:
    assert sorted(z.namelist())==['OPEN_ME.png','READ_ME.txt']
    for name in z.namelist():(session/name).write_bytes(z.read(name))
with Image.open(session/'OPEN_ME.png') as image:image.verify()
digest=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
baseline=json.loads((root/'organizer/evidence-baseline.json').read_text())
for name in ['DefinitelyNotNitro.torrent','transfer-session.pcap']:
    assert digest(session/name)==baseline[name]
report={
    'result':'PASS','initial_files':initial,
    'script_source':'Complete Python code copied from Description.md',
    'evidence_source':args.url,'execution':'Condev; equivalent Python command',
    'script_sha256':digest(session/'recover.py'),
    'archive_sha256':digest(archive),'output':run.stdout.strip().splitlines(),
    'original_evidence_unchanged':True,'archive_opened':True,'redemption_image_opened':True,
    'requires_organizer_files':False,'native_windows_execution':False,
    'independent_human_playtest':False
}
(args.output/'walkthrough-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
