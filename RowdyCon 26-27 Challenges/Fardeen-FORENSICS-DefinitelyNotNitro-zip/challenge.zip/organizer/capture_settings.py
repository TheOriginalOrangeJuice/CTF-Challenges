"""Capture real Wireshark protocol settings in the disposable rowdy06 tools image."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time

p=argparse.ArgumentParser()
p.add_argument('--capture',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
args=p.parse_args()
args.output.mkdir(parents=True,exist_ok=True)
log=(args.output/'settings-capture.log').open('w')
processes=[]
def run(*command):
    return subprocess.run([str(item) for item in command],check=True)
try:
    os.environ['XDG_CONFIG_HOME']=tempfile.mkdtemp(prefix='nitro06-wireshark-')
    display=subprocess.Popen(['Xvfb','-displayfd','1','-screen','0','1280x900x24'],stdout=subprocess.PIPE,stderr=log,text=True)
    processes.append(display)
    number=display.stdout.readline().strip()
    assert number.isdigit(),'Xvfb did not start'
    os.environ['DISPLAY']=':'+number
    processes.append(subprocess.Popen(['openbox'],stdout=log,stderr=log))
    time.sleep(1)
    processes.append(subprocess.Popen(['wireshark','-r',str(args.capture),
        '-o','tcp.reassemble_out_of_order:TRUE','-o','bittorrent.desegment:TRUE'],stdout=log,stderr=log))
    time.sleep(4)
    window=subprocess.check_output(['xdotool','search','--class','wireshark'],text=True).splitlines()[-1]
    run('xdotool','windowactivate','--sync',window,'key','ctrl+shift+p')
    time.sleep(1)
    prefs=subprocess.check_output(['xdotool','search','--name','Wireshark.*Preferences'],text=True).splitlines()[-1]
    run('xdotool','windowmove',prefs,'300','166')
    run('xdotool','mousemove','355','322','click','1','key','Right','type','--delay','100','TCP')
    time.sleep(.6)
    run('import','-window','root',args.output/'preferences-tcp-full.png')
    run('import','-window','root','-crop','535x149+466+178',args.output/'11-tcp-reassembly.png')
    time.sleep(1.2)
    run('xdotool','type','--delay','100','BitTorrent')
    time.sleep(.6)
    run('import','-window','root',args.output/'preferences-bittorrent-full.png')
    run('import','-window','root','-crop','535x61+468+178',args.output/'12-bittorrent-reassembly.png')
    (args.output/'settings-capture.json').write_text(json.dumps({
        'tool':'Wireshark under Xvfb','capture':str(args.capture),
        'files':['11-tcp-reassembly.png','12-bittorrent-reassembly.png'],
        'method':'Actual window captures; focused crops; no fabricated UI'
    },indent=2)+'\n')
finally:
    for process in reversed(processes):
        if process.poll() is None:
            process.terminate()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.kill()
    log.close()
