from collections import defaultdict
from hashlib import sha1
from pathlib import Path
import bencodepy, shutil, subprocess

info = bencodepy.decode(
    Path("DefinitelyNotNitro.torrent").read_bytes())[b"info"]
size, total = info[b"piece length"], info[b"length"]
hashes = info[b"pieces"]
tshark = shutil.which("tshark") or (
    r"C:\Program Files\Wireshark\tshark.exe")
command = [tshark, "-r", "transfer-session.pcap",
    "-o", "tcp.reassemble_out_of_order:TRUE",
    "-o", "bittorrent.desegment:TRUE",
    "-Y", "bittorrent.msg.type == 7", "-T", "fields"]
for field in ["tcp.stream", "bittorrent.piece.index",
              "bittorrent.piece.begin", "bittorrent.piece.data"]:
    command += ["-e", field]
rows = subprocess.check_output(
    command, text=True, stderr=subprocess.DEVNULL)

# Keep each connection's copies separate.
blocks = defaultdict(dict)
for row in rows.splitlines():
    peer, indices, offsets, data = row.split("\t")
    for i, offset, raw in zip(indices.split(","),
                             offsets.split(","), data.split(",")):
        blocks[peer, int(i, 0)][int(offset, 0)] = bytes.fromhex(raw)

# Place blocks by offset and keep intact pieces.
pieces = {}
for (_, i), parts in blocks.items():
    piece = bytearray(min(size, total - i * size))
    for offset, data in parts.items():
        piece[offset:offset + len(data)] = data
    if sha1(piece).digest() == hashes[i * 20:(i + 1) * 20]:
        pieces[i] = piece
archive = b"".join(pieces[i] for i in range(len(hashes) // 20))
Path("DefinitelyNotNitro.zip").write_bytes(archive)
print("Recovered DefinitelyNotNitro.zip")
