"""Restart only the named challenge container and re-solve its public downloads."""
import argparse
import hashlib
from pathlib import Path
import subprocess
import tempfile
import time
from urllib.request import urlopen
from solve import recover

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--url',required=True)
parser.add_argument('--container',default='rowdy06-nitro-test')
args=parser.parse_args()
if not args.container.startswith('rowdy06-nitro'):
    raise SystemExit('Refusing to restart a container outside this challenge')
names=['DefinitelyNotNitro.torrent','transfer-session.pcap','manifest.json']
before={name:urlopen(args.url+'/evidence/'+name).read() for name in names}
subprocess.run(['docker','restart',args.container],check=True)
for attempt in range(30):
    try:
        after={name:urlopen(args.url+'/evidence/'+name,timeout=2).read() for name in names}
        break
    except OSError:
        time.sleep(.1)
else:raise AssertionError('Container did not become ready after restart')
assert before==after
print('PASS: all three evidence files identical before/after real container restart')
with tempfile.TemporaryDirectory(prefix='rowdy06-reset-') as tmp:
    out=Path(tmp)
    for name,body in after.items():(out/name).write_bytes(body)
    recover(out/names[0],out/names[1],out/'recovered')
listing=subprocess.check_output(['docker','exec',args.container,'find','/app','-type','f'],text=True)
root=Path(__file__).resolve().parents[1]
expected={'/app/server.py'}|{'/app/public/'+p.relative_to(root/'challenge/public').as_posix() for p in (root/'challenge/public').rglob('*') if p.is_file()}
assert set(listing.splitlines())==expected,listing
print(f'PASS: deployment contains exactly the server and {len(expected)-1} public files; no organizer material or recovered ZIP/image')
print('\n'.join(name+'  '+hashlib.sha256(body).hexdigest() for name,body in after.items()))
