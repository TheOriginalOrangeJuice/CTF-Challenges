"""Public-evidence-only reference solver. Reads no generator or private constants."""
import argparse
from collections import defaultdict
import hashlib
import io
from pathlib import Path
import struct
import zipfile

from scapy.all import rdpcap, IP, TCP


def bdecode(data):
    """Read bencoded torrent values, preserving the raw info dictionary span."""
    position=0;info_span=None
    def value():
        nonlocal position,info_span
        start=position;token=data[position:position+1]
        if token==b'i':
            end=data.index(b'e',position);position=end+1;return int(data[start+1:end])
        if token==b'd':
            position+=1;out={}
            while data[position:position+1]!=b'e':
                key=value();begin=position;out[key]=value()
                if key==b'info':info_span=(begin,position)
            position+=1;return out
        if token==b'l':
            position+=1;out=[]
            while data[position:position+1]!=b'e':out.append(value())
            position+=1;return out
        end=data.index(b':',position);length=int(data[position:end]);position=end+1+length
        if position>len(data):raise ValueError('Truncated bencode')
        return data[end+1:position]
    result=value()
    if position!=len(data) or info_span is None:raise ValueError('Invalid torrent')
    return result,data[info_span[0]:info_span[1]]


def reassemble(packets):
    """One directional stream per (source IP, source port, destination IP, port)."""
    segments=defaultdict(list)
    for p in packets:
        if IP in p and TCP in p and bytes(p[TCP].payload):
            tcp=p[TCP]
            segments[(p[IP].src,tcp.sport,p[IP].dst,tcp.dport)].append((tcp.seq,bytes(tcp.payload)))
    result={};retransmitted=0
    for key,parts in segments.items():
        first=min(seq for seq,_ in parts);last=max(seq+len(data) for seq,data in parts)
        buf=bytearray(last-first);seen=bytearray(last-first)
        for seq,data in parts:
            offset=seq-first
            for i,byte in enumerate(data):
                at=offset+i
                if seen[at]:
                    if buf[at]!=byte:raise ValueError('Conflicting TCP retransmission')
                    retransmitted+=1
                buf[at]=byte;seen[at]=1
        if not all(seen):raise ValueError('TCP capture gap')
        result[key]=bytes(buf)
    return result,retransmitted


def messages(stream,info_hash):
    if len(stream)<68 or stream[:20]!=b'\x13BitTorrent protocol':return
    if stream[28:48]!=info_hash:return
    pos=68
    while pos<len(stream):
        if pos+4>len(stream):raise ValueError('Partial message length')
        length=struct.unpack_from('!I',stream,pos)[0];pos+=4
        if length==0:continue
        body=stream[pos:pos+length]
        if len(body)!=length:raise ValueError('Partial message body')
        pos+=length
        yield body[0],body[1:]


def recover(torrent,pcap,output,verbose=False):
    # The walkthrough uses concise output; full diagnostics remain available for organizers.
    detail = print if verbose else lambda *args, **kwargs: None
    meta,raw_info=bdecode(torrent.read_bytes());info=meta[b'info'];info_hash=hashlib.sha1(raw_info).digest()
    length=info[b'length'];piece_length=info[b'piece length'];hashes=info[b'pieces']
    count=(length+piece_length-1)//piece_length
    if len(hashes)!=count*20:raise ValueError('Piece hash count mismatch')
    detail(f"Name: {info[b'name'].decode()}\nLength: {length} bytes\nPiece length: {piece_length}\nPieces: {count}\nInfo hash: {info_hash.hex()}")
    packets=rdpcap(str(pcap));streams,retransmitted=reassemble(packets)
    detail(f'TCP: {len(packets)} packets, {len(streams)} directional streams, {retransmitted} retransmitted bytes deduplicated')
    accepted={};invalid=[];duplicates=0;message_count=0
    for flow,stream in sorted(streams.items()):
        # Each peer supplies at most one version of a piece in this evidence.
        by_piece=defaultdict(dict)
        for kind,body in messages(stream,info_hash):
            if kind!=7:continue
            if len(body)<9:raise ValueError('Empty piece block')
            index,begin=struct.unpack_from('!II',body);block=body[8:];message_count+=1
            if index>=count or begin+len(block)>min(piece_length,length-index*piece_length):raise ValueError('Block outside file')
            if begin in by_piece[index]:
                if by_piece[index][begin]!=block:raise ValueError('Ambiguous same-peer block; inspect attempts')
                duplicates+=1
            by_piece[index][begin]=block
        for index,blocks in sorted(by_piece.items()):
            size=min(piece_length,length-index*piece_length);piece=bytearray(size);seen=bytearray(size)
            for begin,block in blocks.items():
                if any(seen[begin:begin+len(block)]):raise ValueError('Unexpected overlapping block offsets')
                piece[begin:begin+len(block)]=block;seen[begin:begin+len(block)]=b'\1'*len(block)
            if not all(seen):raise ValueError(f'Incomplete piece {index} from {flow[0]}')
            if hashlib.sha1(piece).digest()!=hashes[index*20:index*20+20]:
                detail(f'REJECT piece {index:02d} from {flow[0]}: SHA-1 mismatch');invalid.append(index);continue
            if index in accepted and accepted[index]!=piece:raise ValueError('SHA-1 collision')
            accepted[index]=bytes(piece)
            detail(f'OK     piece {index:02d} from {flow[0]}: {size} bytes')
    if len(accepted)!=count:raise ValueError(f'Missing valid pieces: {set(range(count))-accepted.keys()}')
    result=b''.join(accepted[i] for i in range(count))
    if len(result)!=length:raise ValueError('Final length mismatch')
    output.mkdir(parents=True,exist_ok=True)
    archive=output/'DefinitelyNotNitro.zip';archive.write_bytes(result)
    with zipfile.ZipFile(io.BytesIO(result)) as z:
        if z.testzip():raise ValueError('ZIP CRC failure')
        if sorted(z.namelist())!=['OPEN_ME.png','READ_ME.txt']:raise ValueError('Unexpected archive members')
        for name in z.namelist():(output/name).write_bytes(z.read(name))
    stats={'packets':len(packets),'streams':len(streams),'valid_pieces':count,'rejected_attempts':len(invalid),
           'duplicate_blocks':duplicates,'piece_messages':message_count,'retransmitted_bytes':retransmitted,
           'archive_sha256':hashlib.sha256(result).hexdigest()}
    detail(f"Verified {count}/{count} pieces; rejected {len(invalid)} corrupt attempts; ignored {duplicates} repeated blocks.")
    detail(f"Archive SHA-256: {stats['archive_sha256']}")
    print(f"Recovered {archive}\nOpen {output/'OPEN_ME.png'} to read the redemption code.")
    return stats


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('torrent',type=Path);parser.add_argument('pcap',type=Path)
    parser.add_argument('--output',type=Path,default=Path('recovered'))
    parser.add_argument('--verbose',action='store_true',help='Show piece-by-piece diagnostics')
    args=parser.parse_args()
    recover(args.torrent,args.pcap,args.output,args.verbose)
