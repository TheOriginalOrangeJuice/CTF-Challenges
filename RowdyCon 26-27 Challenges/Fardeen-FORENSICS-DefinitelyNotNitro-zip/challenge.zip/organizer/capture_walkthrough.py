"""Capture real Wireshark and terminal windows inside the isolated Condev tools image."""
import argparse
import os
from pathlib import Path
import re
import subprocess
import time

def run(*args,**kwargs):
    return subprocess.run([str(a) for a in args],check=True,**kwargs)

def capture(root,work,out,terminal_only=False):
    out.mkdir(parents=True,exist_ok=True)
    processes=[]
    log=(out/'capture-tool.log').open('w')
    os.environ['DISPLAY']=':96'
    try:
        processes.append(subprocess.Popen(['Xvfb',':96','-screen','0','1200x800x24'],stdout=log,stderr=log))
        time.sleep(1)
        processes.append(subprocess.Popen(['openbox'],stdout=log,stderr=log))
        time.sleep(1)
        if not terminal_only:
            processes.append(subprocess.Popen(['wireshark','-r',str(work/'transfer-session.pcap'),'-Y','bittorrent.msg.type == 7','-g','65',
                '-o','tcp.reassemble_out_of_order:TRUE','-o','bittorrent.desegment:TRUE','-o','gui.qt.font_name:DejaVu Sans Mono,12,-1,5,50,0,0,0,0,0'],stdout=log,stderr=log))
            time.sleep(4)
            window=subprocess.check_output(['xdotool','search','--onlyvisible','--class','wireshark'],text=True).splitlines()[-1]
            run('xdotool','windowmove',window,'0','0');run('xdotool','windowsize',window,'1200','780')
            run('xdotool','windowactivate','--sync',window)
            run('xdotool','mousemove','180','562','click','1','key','ctrl+Left','Right','Down','Right')
            time.sleep(.5)
            run('import','-window','root',out/'wireshark-full.png')
            run('import','-window','root','-crop','600x270+0+440',out/'08-wireshark-pieces.png')
            processes[-1].terminate();processes[-1].wait(timeout=5)
        # This is a real command executed in xterm, not a rendered transcript.
        guide=(root/'Description.md').read_text()
        code=re.search(r'```python\n(.*?)\n```',guide,re.S).group(1)+'\n'
        (work/'recover.py').write_text(code)
        command=['python','recover.py']
        processes.append(subprocess.Popen(['xterm','-hold','-title','Recovering the download','-fa','DejaVu Sans Mono','-fs','14','-geometry','62x4+0+0','-bg','#f8fbfe','-fg','#213b4b','-e',*command],cwd=work,stdout=log,stderr=log))
        term=None
        for attempt in range(30):
            found=subprocess.run(['xdotool','search','--class','[Xx][Tt]erm'],text=True,capture_output=True)
            if found.returncode==0:
                term=found.stdout.splitlines()[-1]
                break
            time.sleep(.5)
        if term is None:
            run('import','-window','root',out/'terminal-desktop.png')
            raise RuntimeError('Terminal window did not appear')
        run('xdotool','windowmap','--sync',term)
        run('xdotool','windowactivate','--sync',term)
        time.sleep(3)
        run('import','-window',term,out/'10-recovery-output.png')
    finally:
        for process in reversed(processes):
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=5)
                except subprocess.TimeoutExpired:process.kill()
        log.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--work',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--terminal-only',action='store_true')
    a=p.parse_args();capture(a.root,a.work,a.output,a.terminal_only)
