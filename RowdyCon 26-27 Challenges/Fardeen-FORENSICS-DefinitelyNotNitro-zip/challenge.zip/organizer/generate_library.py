"""Build only the optional media library from frozen sources; never touch evidence/."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'organizer/media-sources'
PUBLIC=ROOT/'challenge/public'

def run(*args):
    subprocess.run([str(a) for a in args],check=True)

def encode(source,destination,*args):
    run('ffmpeg','-hide_banner','-loglevel','error','-y','-i',source,*args,'-map_metadata','-1','-fflags','+bitexact',destination)

def zip_files(path, files):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,data in sorted(files.items()):
            info=zipfile.ZipInfo(name,date_time=(2010,10,23,20,0,0))
            info.external_attr=0o100644<<16
            info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,data)

def build():
    downloads=PUBLIC/'downloads';media=PUBLIC/'media'
    downloads.mkdir(exist_ok=True);media.mkdir(exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='rowdy06-library-') as tmp:
        temp=Path(tmp)
        ocean=SOURCE/'ocean.mp4'
        wallfiles={}
        for title,at in [('Turquoise Coast',2),('Whitewater',9),('Pacific Blue',17)]:
            name=title.replace(' ','_')+'.jpg'
            run('ffmpeg','-hide_banner','-loglevel','error','-y','-ss',at,'-i',ocean,'-frames:v','1',
                '-vf','scale=2134:1200,crop=1920:1200','-q:v','2',media/name)
            wallfiles[name]=(media/name).read_bytes()
        zip_files(downloads/'Aqua_Wallpapers_1920x1200.zip',wallfiles)
        encode(ocean,downloads/'Ocean_Desktop_Dreamscene.wmv','-t','20','-an','-vf','scale=1280:720','-c:v','wmv2','-b:v','2500k')
        encode(ocean,media/'ocean.webm','-t','20','-an','-vf','scale=1280:720','-c:v','libvpx-vp9','-crf','32','-b:v','0','-threads','2')
        # The organizer's media tooling renders the licensed score into this WAV.
        encode(SOURCE/'lunatic-princess.wav',downloads/'Touhou_Piano_Collection.flac',
               '-c:a','flac','-sample_fmt','s16','-ar','44100','-metadata','title=Flight of the Bamboo Cutter - Lunatic Princess',
               '-metadata','artist=ZUN; piano arrangement by BakaBBQ','-metadata','comment=Touhou Project fan arrangement; CC BY-NC 4.0 arrangement; rendered with TimGM6mb')
        soundfiles={}
        soundnames=[('Startup','ReactOS_Startup.wav'),('Notification','ReactOS_Notify.wav'),('Recycle','ReactOS_Recycle.wav'),('Critical Stop','ReactOS_Critical_Stop.wav')]
        for title,source in soundnames:
            name=title.replace(' ','_')+'.wav'
            shutil.copyfile(SOURCE/source,media/name)
            soundfiles[name]=(media/name).read_bytes()
        soundcredit='Windows 7 Sounds Extra — community desktop sound pack\n\nWindows-compatible WAV sounds from ReactOS contributors. These are additional sounds, not Microsoft stock recordings.\nSource: https://github.com/reactos/reactos/tree/master/media/sounds\nDistributed with the project license in COPYING.txt.\n\nTo use in Windows 7: Control Panel > Sound > Sounds. Select an event, choose Browse, and select the corresponding WAV. Use Test to listen; Save As stores your scheme.\n'
        soundfiles['CREDITS.txt']=soundcredit.encode();soundfiles['COPYING.txt']=(SOURCE/'reactos-license.txt').read_bytes()
        zip_files(downloads/'Windows_7_Sounds_Extra.zip',soundfiles)
        duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(downloads/'Touhou_Piano_Collection.flac')],text=True))
        def entry(id,name,kind,description,credit,**extras):
            file=downloads/name
            return dict(id=id,name=name,bytes=file.stat().st_size,kind=kind,description=description,credit=credit,
                        download='/downloads/'+name,files=[{'name':name,'bytes':file.stat().st_size}],**extras)
        wallpapers=[{'name':title.replace('_',' ').removesuffix('.jpg'),'url':'/media/'+title} for title in wallfiles if title.endswith('.jpg')]
        entries=[
            entry(1,'Aqua_Wallpapers_1920x1200.zip','archive','3 coastal wallpapers · 1920 × 1200','Photography: Michal Marek / Pexels · Pexels License',previews=wallpapers),
            entry(2,'Touhou_Piano_Collection.flac','music','Flight of the Bamboo Cutter — Lunatic Princess','Touhou Project fan work · Music by ZUN · Piano arrangement: BakaBBQ · CC BY-NC 4.0',artist='BakaBBQ · Touhou Recollections',duration=duration,tracks=[{'title':'Flight of the Bamboo Cutter — Lunatic Princess','start':0}],previews=[{'name':'Touhou piano','url':'/media/piano.flac'}]),
            entry(3,'Windows_7_Sounds_Extra.zip','archive','4 Windows-compatible desktop sounds','Community sound scheme · ReactOS contributors · GPL-2.0',previews=[{'name':title,'url':'/media/'+title.replace(' ','_')+'.wav'} for title,_ in soundnames]),
            entry(4,'Ocean_Desktop_Dreamscene.wmv','video','Ocean waves · 1280 × 720 · 20 seconds','Ocean footage: Michal Marek / Pexels · Pexels License',durationLabel='20 seconds',poster='/media/Turquoise_Coast.jpg',previews=[{'name':'Ocean Desktop','url':'/media/ocean.webm'}])
        ]
        for e in entries:
            e.pop('credit',None)
            e.pop('artist',None)
            if e['id'] in [1,3]:
                contents=wallfiles if e['id']==1 else soundfiles
                e['files']=[{'name':n,'bytes':len(data)} for n,data in contents.items() if n.lower().endswith(('.jpg','.wav'))]
        (PUBLIC/'catalog.json').write_text(json.dumps({'entries':entries},ensure_ascii=False,indent=2)+'\n')
        (media/'LICENSES.txt').write_text('Touhou_Piano_Collection.flac\nMusic: ZUN / Team Shanghai Alice. Touhou Project fan work.\nPiano arrangement: BakaBBQ, CC BY-NC 4.0. Tempo set to 144; rendered with FluidSynth / TimGM6mb.\nhttps://github.com/BakaBBQ/touhou-recollections.ly\nhttps://creativecommons.org/licenses/by-nc/4.0/\n\n'+(SOURCE/'piano-license.md').read_text())
        # Preview is a separate URL to the same FLAC: no duplicated large audio asset.
        index=[str(p.relative_to(PUBLIC)).replace('\\','/') for folder in [downloads,media] for p in sorted(folder.iterdir()) if p.is_file()]
        (PUBLIC/'asset-index.json').write_text(json.dumps(index,indent=2)+'\n')
        report={'sources':'organizer/media-sources/acquisition.json','assets':{name:hashlib.sha256((PUBLIC/name).read_bytes()).hexdigest() for name in index},'piano_duration_seconds':duration,'evidence_modified':False}
        (ROOT/'organizer/library-build.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({'assets':len(index),'piano_duration':duration,'result':'built'},indent=2))

if __name__=='__main__':build()
