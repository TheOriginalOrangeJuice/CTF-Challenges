"""Use the shared template builder, then fit this guide's screenshots and page breaks."""
import argparse
import importlib.util
import json
from pathlib import Path
from docx import Document
from docx.shared import Inches, Pt

parser=argparse.ArgumentParser()
parser.add_argument('--builder',type=Path,required=True)
args=parser.parse_args()
root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('shared_description',args.builder)
builder=importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)
output=root/'Description.docx'
report=builder.build(root/'Description.md',args.builder.with_name('template.docx'),output)
doc=Document(output)
assert len(doc.inline_shapes)==5
for shape,width in zip(doc.inline_shapes,[2.8,4.9,4.9,4.4,4.5]):
    height=shape.height*Inches(width)/shape.width
    shape.width=Inches(width)
    shape.height=int(height)
for row in doc.tables[0].rows:
    for cell in row.cells:
        for paragraph in cell.paragraphs:
            if paragraph._p.xpath('./w:pPr/w:shd'):
                for run in paragraph.runs:
                    run.font.name='Courier New'
            if paragraph._p.xpath('.//w:drawing'):
                paragraph.paragraph_format.left_indent=Inches(0)
                paragraph.paragraph_format.right_indent=Inches(0)
walkthrough=doc.tables[0].cell(3,1)
for paragraph in walkthrough.paragraphs:
    paragraph.paragraph_format.space_after=min(paragraph.paragraph_format.space_after or 0,Pt(3))
    if paragraph.text == "# Keep each connection's copies separate.":
        paragraph.paragraph_format.space_before=Pt(40)
doc.save(output)
destination=root/'organizer/document-review'
report['pages']=builder.render(output,destination)
report['layout']='Shared five-section template; focused screenshot sizes and paragraph spacing'
(destination/'document-check.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
