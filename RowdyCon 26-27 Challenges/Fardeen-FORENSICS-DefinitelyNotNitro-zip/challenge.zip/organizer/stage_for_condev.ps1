param([Parameter(Mandatory=$true)][ValidatePattern('^nitro06-[a-z0-9-]+$')][string]$StageName)
$ErrorActionPreference = 'Stop'
$challengeRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$stageParent = Join-Path 'C:\Users\Public\Docker' $StageName
$runtimeRoot = '/tmp/' + $StageName
$condevExe = 'C:\Users\fbhimani\AppData\Local\bin\condev.exe'
& 'C:\Users\fbhimani\.codex\skills\condev-development\scripts\stage_tree.ps1' -Source $challengeRoot -StageParent $stageParent
$inventory = @{}
Get-ChildItem -LiteralPath $challengeRoot -Recurse -File | Where-Object { $_.FullName -notmatch '[\\/]__pycache__[\\/]' } | ForEach-Object {
    $relative = $_.FullName.Substring($challengeRoot.Length + 1).Replace('\','/')
    $inventory[$relative] = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLower()
}
$manifestFile = Join-Path $stageParent 'manifest.json'
$inventory | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 -LiteralPath $manifestFile
& docker cp (Join-Path $stageParent (Split-Path -Leaf $challengeRoot)) ('condev-default:' + $runtimeRoot)
if ($LASTEXITCODE -ne 0) { throw 'Complete tree copy failed' }
& docker cp $manifestFile ('condev-default:' + $runtimeRoot + '-manifest.json')
if ($LASTEXITCODE -ne 0) { throw 'Manifest copy failed' }
& $condevExe exec --root -- chown -R 1000:1000 $runtimeRoot
if ($LASTEXITCODE -ne 0) { throw 'Staged tree ownership failed' }
& $condevExe exec -- /tmp/rowdy-ctf-tools/bin/python ($runtimeRoot + '/organizer/verify_tree.py') ($runtimeRoot + '-manifest.json')
if ($LASTEXITCODE -ne 0) { throw 'Condev source parity failed' }
