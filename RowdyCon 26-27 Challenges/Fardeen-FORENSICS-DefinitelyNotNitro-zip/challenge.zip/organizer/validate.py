"""Artifact, protocol, deterministic-build, and simple-extraction checks."""
import argparse
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile
from urllib.error import HTTPError
from urllib.request import urlopen, Request
import zipfile

from PIL import Image
from scapy.all import rdpcap, Ether, IP, TCP, Raw
from solve import bdecode, reassemble, messages, recover


def must_fail(action,label):
    try:action()
    except (ValueError,zipfile.BadZipFile,KeyError,EOFError):return
    raise AssertionError('Unexpected shortcut: '+label)


def validate(root,url):
    public=root/'challenge/public';evidence=public/'evidence'
    manifest=json.loads((evidence/'manifest.json').read_text())
    torrent=(evidence/'DefinitelyNotNitro.torrent').read_bytes();pcap=(evidence/'transfer-session.pcap').read_bytes()
    meta,raw_info=bdecode(torrent);ih=hashlib.sha1(raw_info).digest()
    assert ih.hex()==manifest['info_hash']
    assert b'Experimental autonomous-agent notice' in meta[b'comment']
    assert b'notice' not in raw_info and b'sample' not in raw_info
    for name,digest in manifest['evidence_sha256'].items():assert hashlib.sha256((evidence/name).read_bytes()).hexdigest()==digest
    with tempfile.TemporaryDirectory(prefix='rowdy06-qa-') as tmp:
        temp=Path(tmp)
        stats=recover(evidence/'DefinitelyNotNitro.torrent',evidence/'transfer-session.pcap',temp/'recovered')
        assert stats['rejected_attempts']==2 and stats['duplicate_blocks']==4 and stats['streams']==8
        assert stats['valid_pieces']==manifest['piece_count']
        Image.open(temp/'recovered/OPEN_ME.png').verify()
        for run in [1,2]:
            subprocess.run([sys.executable,str(root/'organizer/generate.py'),'--output',str(temp/f'regenerated{run}')],check=True,stdout=subprocess.PIPE,text=True)
            for name in ['DefinitelyNotNitro.torrent','transfer-session.pcap','manifest.json']:
                assert (temp/f'regenerated{run}'/name).read_bytes()==(evidence/name).read_bytes(),('Non-deterministic',name)
        print('PASS: two independent regenerations are byte-identical to every deployed evidence file')
    packets=rdpcap(str(evidence/'transfer-session.pcap'));streams,repeat=reassemble(packets)
    assert repeat>5000
    flags=Counter();out_of_order=0;lastseq={}
    for p in packets:
        assert IP in p and TCP in p
        key=(p[IP].src,p[TCP].sport,p[IP].dst,p[TCP].dport)
        flags[str(p[TCP].flags)]+=1
        if bytes(p[TCP].payload):
            if key in lastseq and p[TCP].seq<lastseq[key]:out_of_order+=1
            lastseq[key]=p[TCP].seq
        check=p.copy();del check[IP].chksum;del check[TCP].chksum
        rebuilt=Ether(bytes(check))
        assert rebuilt[IP].chksum==p[IP].chksum and rebuilt[TCP].chksum==p[TCP].chksum
        assert len(bytes(p[IP]))==p[IP].len
    assert flags['S']==4 and flags['SA']==4 and flags['FA']==8 and out_of_order>10
    for i in range(4):
        remote=f'198.51.100.{21+i}';port=49160+i
        connection=[p for p in packets if p[IP].src==remote or p[IP].dst==remote]
        assert [str(p[TCP].flags) for p in connection[:3]]==['S','SA','A']
        assert connection[1][TCP].ack==connection[0][TCP].seq+1
        assert connection[2][TCP].ack==connection[1][TCP].seq+1
        assert [str(p[TCP].flags) for p in connection[-4:]]==['FA','A','FA','A']
        client=streams[('192.0.2.10',port,remote,51413)];server=streams[(remote,51413,'192.0.2.10',port)]
        assert client[28:48]==server[28:48]==ih
        requests=Counter(struct.unpack('!III',body) for kind,body in messages(client,ih) if kind==6)
        incoming=Counter((*struct.unpack('!II',body[:8]),len(body)-8) for kind,body in messages(server,ih) if kind==7)
        assert requests==incoming
        sm=list(messages(server,ih));assert sm[0][0]==5 and sm[1][0]==1
        bits=sm[0][1];n=manifest['piece_count'];assert bits[-1]&((1<<(8-n%8))-1)==0 if n%8 else True
    print(f'PASS: {len(packets)} Ethernet/IP/TCP packets; checksums, lengths, handshakes, closes, bitfields, and request/reply offsets; {out_of_order} reordered/repeated segments')
    # A strings scan has no actual code. The contextualized sample is the sole token.
    for file in public.rglob('*'):
        if file.is_file():
            codes=re.findall(rb'(?:RCC|RowdyCon)\{[^}\r\n]{1,100}\}',file.read_bytes())
            assert all(c==b'RCC{sample_not_a_reward}' for c in codes),(file,codes)
    must_fail(lambda:zipfile.ZipFile(io.BytesIO(pcap)).testzip(),'open PCAP as ZIP')
    raw_concat=b''.join(bytes(p[TCP].payload) for p in packets if bytes(p[TCP].payload))
    must_fail(lambda:zipfile.ZipFile(io.BytesIO(raw_concat)).testzip(),'concatenate packet payloads')
    for stream in streams.values():must_fail(lambda:zipfile.ZipFile(io.BytesIO(stream)).testzip(),'raw TCP stream ZIP carve')
    # Collect index/offset-framed complete messages from isolated packets only.
    packet_blocks=set()
    for p in packets:
        data=bytes(p[TCP].payload)
        for pos in range(max(0,len(data)-12)):
            length=struct.unpack_from('!I',data,pos)[0]
            if 10<=length<=2057 and pos+4+length<=len(data) and data[pos+4]==7:
                index,begin=struct.unpack_from('!II',data,pos+5)
                if index<manifest['piece_count'] and begin<manifest['piece_length']:packet_blocks.add((index,begin))
    assert len(packet_blocks)<manifest['piece_count']
    # Valid negative parsing fixtures: truncated BT frames and contradictory TCP bytes.
    stream=next(iter(streams.values()))
    must_fail(lambda:list(messages(stream[:-1],ih)),'truncated stream')
    sample=next(p for p in packets if bytes(p[TCP].payload))
    conflict=sample.copy();body=bytearray(bytes(conflict[TCP].payload));body[0]^=1;conflict[TCP].remove_payload();conflict[TCP].add_payload(Raw(bytes(body)))
    must_fail(lambda:reassemble([sample,conflict]),'conflicting TCP retransmission')
    print('PASS: no plaintext reward; direct ZIP, packet-order concatenation, individual-stream carving, and packet-only parsing fail; malformed stream tests reject')
    if url:
        routes=['/','/app.js','/style.css','/favicon.svg','/evidence/DefinitelyNotNitro.torrent','/evidence/transfer-session.pcap','/evidence/manifest.json']
        for route in routes:
            response=urlopen(url+route);assert response.status==200
            body=response.read();assert body
            assert "script-src 'self'" in response.headers['Content-Security-Policy']
            if route.startswith('/evidence/'):assert body==(public/route.lstrip('/')).read_bytes()
        for route in ['/flag','/api/flag','/api/win','/organizer/generate.py','/server.py','/DefinitelyNotNitro.zip','/OPEN_ME.png','/../organizer/generate.py','/%2e%2e/organizer/generate.py','/evidence/../server.py','/evidence/%2e%2e/server.py','/.git/config','/app.js.map','/evidence/manifest.json/extra']:
            try:urlopen(url+route)
            except HTTPError as error:assert error.code==404
            else:raise AssertionError('Unintended route: '+route)
        try:urlopen(Request(url+'/api/win',data=b'{"won":true}',headers={'Content-Type':'application/json'}))
        except HTTPError as error:assert error.code==405
        else:raise AssertionError('Unexpected win API')
        print('PASS: exact HTTP allowlist, 14 unauthorized/traversal/source routes, and fabricated win request')
    print('ALL CHECKS PASSED')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--url');args=parser.parse_args()
    validate(Path(__file__).resolve().parents[1],args.url)
