"use strict";
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const icon = name => '<svg class="icon" aria-hidden="true"><use href="/icons.svg#'+name+'"/></svg>';
const labels = {error:"Disk write error",downloading:"Downloading",seeding:"Seeding",paused:"Paused",queued:"Queued"};
const historicalPeers = [
 ["198.51.100.21:51413","trust_me_bro","AeroTorrent 2.2","Yes"],
 ["198.51.100.22:51413","seed_this_pls","AeroTorrent 2.2","Yes"],
 ["198.51.100.23:51413","totally_official","AeroTorrent 2.2","Yes"],
 ["198.51.100.24:51413","peer_pressure","AeroTorrent 2.2","Yes"]
];
const historicalLog = [
 ["20:11:03","info","Added DefinitelyNotNitro.zip — VeryVerifiedOfficial"],
 ["20:11:04","info","Tracker announce: 999 seeds, 67 peers (cached)"],
 ["20:11:05","info","Peer exchange: 4 connected peers"],
 ["20:11:06","info","Incoming protocol: BitTorrent / unencrypted"],
 ["20:11:19","warning","Piece hash mismatch; scheduling replacement from another peer"],
 ["20:11:21","warning","Piece hash mismatch; scheduling replacement from another peer"],
 ["20:11:35","info","Replacement blocks received; network transfer complete"],
 ["20:11:36","error","Disk write failed: destination no longer available (E:\\)"],
 ["20:14:37","info","Transfer session closed; diagnostic network capture preserved"]
];
const peerNames = ["sky_is_the_limit","marisa_borrowed_it","water_you_waiting_for","glass_is_class","seed_this_pls","aqua_after_dark","start_me_up","cirno_⑨"];
const rates = [244,312,286,364,278,402,338,294,376,322,410,354,268,306,382,340];
let rows=[], selected=0, filter="all", tab="general", sortKey=null, ascending=true;
let manifest, catalog, tick=0, pausedAll=false, hideAddresses=false, graphType="both", timer=null;
let sessionLog=[], downHistory=[], upHistory=[], menuReturn=null;

function bytes(n){if(n>=1048576)return (n/1048576).toFixed(1)+" MiB";return (n/1024).toFixed(1)+" KiB"}
function time(n){n=Math.max(0,Math.ceil(n));return Math.floor(n/60)+"m "+String(n%60).padStart(2,"0")+"s"}
function stamp(){return "20:"+String(15+Math.floor(tick/60)).padStart(2,"0")+":"+String(tick%60).padStart(2,"0")}
function toast(message){$("#toast").textContent=message;$("#toast").hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$("#toast").hidden=true,2800)}
function record(message){sessionLog.push([stamp(),"info",message]);if(sessionLog.length>100)sessionLog.shift()}
function currentState(r){return r.id && (pausedAll||r.paused) ? "paused":r.state}
function active(r){return r.id && !pausedAll && !r.paused && r.state!=="queued"}
function visibleRows(){
 let list=rows.filter(r=>(filter==="all"||filter==="favorite"&&r.favorite||currentState(r)===filter)&&
 (!$("#attention").checked||r.id===0)&&r.name.toLowerCase().includes($("#search").value.toLowerCase()));
 if(sortKey)list.sort((a,b)=>{const av=sortKey==="state"?currentState(a):a[sortKey],bv=sortKey==="state"?currentState(b):b[sortKey];return (typeof av==="number"?av-bv:String(av).localeCompare(String(bv)))*(ascending?1:-1)||a.id-b.id});
 return list;
}
function initialRows(){
 return [{id:0,name:"DefinitelyNotNitro.zip",bytes:manifest.file_length,kind:"archive",uploader:"VeryVerifiedOfficial",seeds:999,
  folder:"E:\\Premium\\ (unavailable)",progress:100,state:"error",favorite:true,down:0,up:0,uploaded:0,eta:0},
 ...catalog.entries.map(c=>({...c,folder:c.id===1?"C:\\Pictures\\":c.id===2?"C:\\Music\\":c.id===4?"C:\\Videos\\":"C:\\Downloads\\",
  uploader:["","sky_is_the_limit","marisa_borrowed_it","start_me_up","water_you_waiting_for"][c.id],
  seeds:[0,84,12,67,32][c.id],progress:c.id===2?61:c.id===4?0:100,
  state:c.id===2?"downloading":c.id===4?"queued":"seeding",
  favorite:false,paused:false,down:0,up:0,uploaded:0,eta:0,elapsed:0,connections:[]}))];
}
function updateRates(){
 for(const r of rows){
  if(!active(r)){r.down=0;r.up=0;r.eta=0;r.connections=[];continue}
  const factor=r.id===2?.12:r.id===4?.2:.3;
  r.down=r.state==="downloading"?rates[(tick+r.id*3)%rates.length]*factor:0;
  r.up=(12+rates[(tick*3+r.id)%rates.length]*.12)*(r.state==="seeding"?1:.4);
  r.eta=r.down?((100-r.progress)/100*r.bytes)/(r.down*1024):0;
  const phase=Math.floor(tick/5);
  r.connections=Array.from({length:3+(phase+r.id)%3},(_,i)=>({
   address:"203.0.113."+(40+r.id*10+i)+":51413",name:peerNames[(i+phase+r.id)%peerNames.length],
   direction:(i+phase)%2?"Outgoing":"Incoming",down:r.down/(i+2),up:r.up/(i+2)
  }));
 }
}
function rowMarkup(r){
 return '<tr data-id="'+r.id+'" tabindex="0"><td>'+icon(r.kind)+'<span class="row-name">'+esc(r.name)+'</span><span class="row-star"></span></td><td data-field="bytes"></td><td><div class="progress"><span></span><em></em></div></td><td data-field="state"></td><td class="rate-down" data-field="down"></td><td class="rate-up" data-field="up"></td><td data-field="seeds"></td><td data-field="eta"></td></tr>';
}
function renderRows(){
 if(!rows.length)return;
 const visible=visibleRows(), body=$("#transfer-rows"), ids=visible.map(r=>r.id).join(",");
 if(body.dataset.ids!==ids){
  const focusId=document.activeElement?.closest("#transfer-rows tr")?.dataset.id;
  const old=new Map([...body.children].map(el=>[Number(el.dataset.id),el]));
  const nodes=visible.map(r=>{if(old.has(r.id))return old.get(r.id);const t=document.createElement("tbody");t.innerHTML=rowMarkup(r);return t.firstElementChild});
  body.replaceChildren(...nodes);body.dataset.ids=ids;
  if(focusId!==undefined)body.querySelector('[data-id="'+focusId+'"]')?.focus();
 }
 for(const r of visible){
  const el=body.querySelector('[data-id="'+r.id+'"]'),state=currentState(r);
  el.classList.toggle("selected",r.id===selected);el.setAttribute("aria-selected",r.id===selected);
  el.querySelector(".row-star").textContent=r.favorite?"★":"";
  el.querySelector('[data-field="bytes"]').textContent=bytes(r.bytes);
  el.querySelector(".progress").className="progress "+state;
  el.querySelector(".progress span").style.width=r.progress+"%";
  el.querySelector(".progress em").textContent=r.progress.toFixed(r.progress===100||r.progress===0?0:1)+"%";
  el.querySelector('[data-field="state"]').innerHTML='<span class="status-dot '+state+'"></span>'+labels[state];
  el.querySelector('[data-field="state"]').className=r.id===0?"state-error":"";
  el.querySelector('[data-field="down"]').textContent=r.down?r.down.toFixed(1)+" KiB/s":"—";
  el.querySelector('[data-field="up"]').textContent=r.up?r.up.toFixed(1)+" KiB/s":"—";
  el.querySelector('[data-field="seeds"]').textContent=r.seeds;
  el.querySelector('[data-field="eta"]').textContent=r.eta?time(r.eta):"—";
 }
 $("#visible-count").textContent=visible.length+" transfer"+(visible.length===1?"":"s");$("#empty").hidden=visible.length>0;
 $$("[data-filter]").forEach(b=>{const f=b.dataset.filter;b.querySelector("b").textContent=rows.filter(r=>f==="all"||f==="favorite"&&r.favorite||currentState(r)===f).length;b.classList.toggle("active",f===filter)});
 $$("th[data-key]").forEach(th=>th.setAttribute("aria-sort",sortKey===th.dataset.key?(ascending?"ascending":"descending"):"none"));
 updateControls();
}
function updateControls(){
 const r=rows[selected];$("#selection-name").textContent=r.name;
 $("#selection-icon use").setAttribute("href","/icons.svg#"+r.kind);
 $("#favorite").textContent=r.favorite?"★ Favorited":"☆ Favorite";$("#favorite").setAttribute("aria-pressed",r.favorite);
 const label=currentState(r)==="paused"||r.state==="queued"?"Resume":"Pause";
 $("#transfer-toggle").innerHTML=icon(label==="Resume"?"play":"pause")+"<span>"+label+"</span>";
 $("#transfer-toggle").disabled=!r.id||pausedAll;
 $("#transfer-toggle").title=pausedAll?"Resume the session to control individual transfers":!r.id?"Destination drive unavailable":label+" selected transfer";
 $("#save-file").disabled=!r.id;$("#open-file").disabled=!r.id;
 $("#save-file").title=r.id?"Save "+r.name:"Destination drive unavailable";
 $("#pause-all").innerHTML=icon(pausedAll?"play":"pause-all")+"<span>"+(pausedAll?"Resume all":"Pause all")+"</span>";
}
function table(headers,data,bodyId=""){
 return '<table class="detail-table"><thead><tr>'+headers.map(h=>"<th>"+h+"</th>").join("")+'</tr></thead><tbody'+(bodyId?' id="'+bodyId+'"':"")+">"+data.map(row=>"<tr>"+row.map(v=>"<td>"+v+"</td>").join("")+"</tr>").join("")+"</tbody></table>";
}
function graphMarkup(large=false){return '<div class="mini-graph '+(large?"large-graph":"")+'"><canvas id="graph" aria-label="Session download and upload rates"></canvas><span class="graph-label">KiB/s</span></div><div class="graph-legend"><span><i></i> Download</span><span><i class="up"></i> Upload</span><span>Last 60 seconds</span></div>'}
function renderDetails(){
 if(!rows.length)return;
 const r=rows[selected],target=!r.id,panel=$("#detail-panel");
 $$(".tabs button").forEach(b=>{b.setAttribute("aria-selected",b.dataset.tab===tab);b.tabIndex=b.dataset.tab===tab?0:-1});
 panel.setAttribute("aria-labelledby","tab-"+tab);
 if(tab==="general")panel.innerHTML='<div class="general-grid"><section><h2 class="panel-heading">Transfer information</h2><dl class="detail-list">'+
 '<dt>Downloaded</dt><dd id="detail-downloaded"></dd><dt>Uploaded</dt><dd id="detail-uploaded"></dd><dt>Added by</dt><dd>'+r.uploader+'</dd><dt>Save location</dt><dd>'+esc(r.folder)+'</dd>'+
 (target?'<dt>Info hash</dt><dd><code>'+manifest.info_hash+'</code></dd><dt>Comment</dt><dd>FREE NITRO 2026 — lifetime premium. Trust the seeds!</dd>':'<dt>Contents</dt><dd>'+esc(r.description)+'</dd><dt>Availability</dt><dd><a href="'+r.download+'" download>Save file</a> · Ready in library</dd>')+
 '</dl></section><section><h2 class="panel-heading">Session activity <span>— all transfers</span></h2>'+graphMarkup()+
 (target?'<div class="integrity">'+icon("warning")+'<span>Destination unavailable. Network capture saved.</span></div>':'')+'</section></div>';
 if(tab==="trackers")panel.innerHTML='<div class="panel-actions"><h2 class="panel-heading">'+(target?"Tracker history":"Trackers")+'</h2><button class="small-button" id="refresh-trackers">Refresh</button></div>'+
 table(["URL","Status","Seeds","Peers","Last announce"],target?[["http://tracker.aerotorrent.invalid:6969/announce","Cached reply",999,67,"20:11:04"],["DHT","Disabled in saved session","—","—","—"],["Local peer discovery","No local peers",0,0,"20:11:05"]]:
 [["http://tracker.aerotorrent.invalid:6969/announce","Working",r.seeds,'<span id="tracker-peers"></span>','<span id="tracker-time">'+stamp()+'</span>'],["DHT","Working","—","—","—"],["Peer exchange","Enabled","—","—","—"]]);
 if(tab==="peers")panel.innerHTML='<div class="panel-actions"><h2 class="panel-heading">'+(target?"4 peers in saved session":'<span id="peer-heading">Connected peers</span>')+'</h2><button class="small-button" id="toggle-addresses">'+(hideAddresses?"Show":"Hide")+' addresses</button></div>'+
 (target?table(["Address","Peer nickname","Client","Handshake","Received"],historicalPeers.map((p,i)=>[hideAddresses?"Peer "+(i+1):p[0],...p.slice(1),bytes(manifest.peer_data_bytes[i])])):
 table(["Address","Peer nickname","Connection","Down speed","Up speed"],[],"live-peers"))+
 '<p class="subnote">'+(target?"Local endpoint: 192.0.2.10 · Unencrypted BitTorrent":"Peer exchange · TCP · Port 51413")+'</p>';
 if(tab==="files")panel.innerHTML='<h2 class="panel-heading">Files</h2>'+table(["Name","Size","Availability"],(target?[{name:r.name,bytes:r.bytes}]:r.files).map(f=>[icon(r.kind)+esc(f.name),bytes(f.bytes),target?"Missing from destination":"Ready in library"]))+
 (target?'<div class="file-actions"><a class="button-link" href="/evidence/transfer-session.pcap" download>'+icon("capture")+'Save capture</a><a class="button-link" href="/evidence/DefinitelyNotNitro.torrent" download>'+icon("torrent")+'Save .torrent</a><button id="uploader-note" class="small-button">Uploader note</button></div>':
 '<div class="file-actions"><a class="button-link" href="'+r.download+'" download>'+icon("save")+'Save file</a><button id="preview-file">'+icon("preview")+' Preview</button></div>');
 if(tab==="speed")panel.innerHTML='<div class="speed-controls"><strong>Session transfer rates</strong><label>Graph <select id="graph-type"><option value="both">Download + upload</option><option value="download">Download only</option><option value="upload">Upload only</option></select></label><span id="graph-position"></span></div>'+graphMarkup(true);
 if(tab==="logger")panel.innerHTML='<div class="panel-actions"><h2 class="panel-heading">'+(target?"Saved diagnostic log":"Session log")+'</h2><button id="save-log" class="small-button">Save log</button></div><div class="logger" id="log-lines"></div>';
 $("#refresh-trackers")?.addEventListener("click",()=>{if(!target){$("#tracker-time").textContent=stamp();record("Tracker announce completed — "+r.name)}toast(target?"Saved tracker reply loaded.":"Tracker list updated.")});
 $("#toggle-addresses")?.addEventListener("click",()=>{hideAddresses=!hideAddresses;renderDetails();$("#toggle-addresses").focus()});
 $("#uploader-note")?.addEventListener("click",()=>modal("A message from VeryVerifiedOfficial",'<h3>FREE NITRO. FOREVER. PROBABLY.</h3><p>999 seeders can’t be wrong. Open your premium redemption card for an upgrade that’s out of this world.</p><p>— VeryVerifiedOfficial<br>Community uploader · verification self-awarded</p>'));
 $("#preview-file")?.addEventListener("click",preview);
 $("#save-log")?.addEventListener("click",()=>textDownload("aerotorrent-session.log",(target?historicalLog:sessionLog).map(l=>"["+l[0]+"] "+l[1].toUpperCase()+" "+l[2]).join("\n")));
 if($("#graph-type")){$("#graph-type").value=graphType;$("#graph-type").onchange=e=>{graphType=e.target.value;drawGraph()}}
 updateDetails();drawGraph();
}
function updateDetails(){
 const r=rows[selected];
 if($("#detail-downloaded"))$("#detail-downloaded").textContent=bytes(r.bytes*r.progress/100)+" / "+bytes(r.bytes)+" · "+labels[currentState(r)];
 if($("#detail-uploaded"))$("#detail-uploaded").textContent=r.id?bytes(r.uploaded):"0.0 KiB";
 if($("#tracker-peers"))$("#tracker-peers").textContent=r.connections.length;
 if($("#live-peers")){
  $("#peer-heading").textContent=r.connections.length+" connected peers";
  $("#live-peers").innerHTML=r.connections.map((p,i)=>'<tr><td>'+icon("peer")+esc(hideAddresses?"Peer "+(i+1):p.address)+'</td><td>'+esc(p.name)+'</td><td class="'+(p.direction==="Incoming"?"peer-in":"peer-out")+'">'+(p.direction==="Incoming"?"↓ ":"↑ ")+p.direction+'</td><td>'+p.down.toFixed(1)+' KiB/s</td><td>'+p.up.toFixed(1)+" KiB/s</td></tr>").join("");
 }
 if($("#log-lines")){
  const el=$("#log-lines"),atEnd=el.scrollHeight-el.scrollTop-el.clientHeight<20;
  const html=(r.id?sessionLog:historicalLog).map(l=>'<div class="'+l[1]+'">['+l[0]+"] "+esc(l[2])+"</div>").join("");
  if(el.innerHTML!==html){el.innerHTML=html;if(atEnd)el.scrollTop=el.scrollHeight}
 }
 if($("#graph-position"))$("#graph-position").textContent=pausedAll?"Session paused":stamp();
}
function drawGraph(){
 const canvas=$("#graph");if(!canvas)return;
 const ratio=window.devicePixelRatio||1,w=canvas.clientWidth,h=canvas.clientHeight;if(!w||!h)return;
 canvas.width=w*ratio;canvas.height=h*ratio;const c=canvas.getContext("2d");c.scale(ratio,ratio);
 c.strokeStyle="#d8e8f1";c.lineWidth=1;
 for(let x=0;x<w;x+=30){c.beginPath();c.moveTo(x,0);c.lineTo(x,h);c.stroke()}
 for(let y=20;y<h;y+=25){c.beginPath();c.moveTo(0,y);c.lineTo(w,y);c.stroke()}
 const maximum=Math.max(600,...downHistory,...upHistory)*1.12;
 function line(values,color,fill){
  c.beginPath();values.forEach((v,i)=>{const x=i/59*w,y=h-7-v/maximum*(h-18);if(i)c.lineTo(x,y);else c.moveTo(x,y)});c.strokeStyle=color;c.lineWidth=1.7;c.stroke();
  if(fill){c.lineTo((values.length-1)/59*w,h);c.lineTo(0,h);c.closePath();c.fillStyle=fill;c.fill()}
 }
 if(graphType!=="upload")line(downHistory,"#369aca","#65bcdf28");
 if(graphType!=="download")line(upHistory,"#7ca64b");
}
function totals(){
 const down=rows.reduce((s,r)=>s+r.down,0),up=rows.reduce((s,r)=>s+r.up,0),connections=rows.reduce((s,r)=>s+(r.connections?.length||0),0);
 $("#download-speed").textContent=down.toFixed(1);$("#upload-speed").textContent=up.toFixed(1);
 $("#total-rates").textContent="↓ "+down.toFixed(1)+"  ↑ "+up.toFixed(1)+" KiB/s";
 $("#connection-count").textContent=connections+" connections";
 $("#connection-state").textContent=pausedAll?"Session paused":"Peer exchange enabled";
 $("#session-label").textContent=pausedAll?"AeroTorrent · paused":"AeroTorrent · connected";
 $("#dht-status").textContent="DHT: "+(184+Math.floor(tick/7)%9)+" nodes";
 $("#status").textContent=rows.filter(r=>currentState(r)==="downloading").length+" downloading · "+rows.filter(r=>currentState(r)==="seeding").length+" seeding";
 $("#activity-led").className="led "+(connections?"blink":"idle");
 return [down,up];
}
function step(){
 if(!pausedAll){
  tick++;
  for(const r of rows.slice(1)){
   if(r.paused)continue;
   if(r.state==="queued"&&tick>=8){r.state="downloading";record("Connecting — "+r.name)}
   if(r.state==="downloading"){
    r.elapsed++;r.progress=Math.min(100,r.progress+r.down*1024/r.bytes*100);
    if(r.progress>=100){r.state="seeding";record("Download complete; seeding — "+r.name)}
   }
   r.uploaded+=r.up*1024;
  }
  if(tick%5===0){const name=peerNames[Math.floor(tick/5)%peerNames.length];record((tick%10?"Incoming connection from ":"Outgoing connection to ")+name);$("#activity-message").textContent=sessionLog.at(-1)[2]}
 }
 updateRates();const [down,up]=totals();downHistory.push(down);upHistory.push(up);downHistory.shift();upHistory.shift();
 renderRows();updateDetails();drawGraph();
}
function select(id){selected=id;renderRows();renderDetails()}
function toggleTransfer(){const r=rows[selected];if(!r.id||pausedAll)return;if(r.state==="queued"){r.state="downloading";r.paused=false}else r.paused=!r.paused;record((r.paused?"Paused — ":"Resumed — ")+r.name);updateRates();totals();renderRows();updateDetails();toast(r.paused?"Transfer paused.":"Transfer resumed.")}
function toggleAll(){pausedAll=!pausedAll;record(pausedAll?"Session paused":"Session resumed");$("#activity-message").textContent=pausedAll?"All transfers paused":"Peer exchange resumed";updateRates();totals();renderRows();updateDetails();toast(pausedAll?"All transfers paused.":"Session resumed.")}
function reset(){
 if(!catalog||!manifest)return;
 clearInterval(timer);closeMenu();if($("#dialog").open)$("#dialog").close();
 rows=initialRows();selected=0;filter="all";tab="general";sortKey=null;ascending=true;tick=0;pausedAll=false;hideAddresses=false;graphType="both";
 sessionLog=[["20:15:00","info","Session restored; peer exchange started"],["20:15:00","info","Resumed Touhou_Piano_Collection.flac"],["20:15:00","info","Ocean_Desktop_Dreamscene.wmv queued"]];
 downHistory=Array(60).fill(0);upHistory=Array(60).fill(0);$("#search").value="";$("#attention").checked=false;
 document.body.classList.remove("expanded","reduce-motion");$("#list-title").textContent="All transfers";$("#activity-message").textContent="Session restored · connecting to peers";
 updateRates();const [down,up]=totals();downHistory[59]=down;upHistory[59]=up;renderRows();renderDetails();timer=setInterval(step,1000);
}
function textDownload(name,data){const a=document.createElement("a"),url=URL.createObjectURL(new Blob([data],{type:"text/plain;charset=utf-8"}));a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast("Saved "+name)}
function saveFile(){const r=rows[selected];if(!r.download)return;const a=document.createElement("a");a.href=r.download;a.download=r.name;a.click();toast("Saving "+r.name)}
function exportHistory(){const q=v=>'"'+String(v).replace(/"/g,'""')+'"';textDownload("aerotorrent-history.csv","Name,Size,Progress,Status,Seeds\n"+rows.map(r=>[r.name,bytes(r.bytes),r.progress.toFixed(1)+"%",labels[currentState(r)],r.seeds].map(q).join(",")).join("\n"))}
function modal(title,html){closeMenu();$("#dialog-title").textContent=title;$("#dialog-content").innerHTML=html;$("#dialog").showModal()}
function preview(){
 const r=rows[selected];if(!r.id)return;
 const save='<a class="button-link" href="'+r.download+'" download>'+icon("save")+"Save file</a>";
 if(r.id===1){
  let at=0;modal("Aqua Wallpapers",'<img class="wallpaper" alt="" id="wallpaper"><div class="preview-controls"><button id="previous-wallpaper">Previous</button><span id="wallpaper-name"></span><button id="next-wallpaper">Next</button>'+save+'</div>');
  const show=()=>{$("#wallpaper").src=r.previews[at].url;$("#wallpaper").alt=r.previews[at].name;$("#wallpaper-name").textContent=(at+1)+" / "+r.previews.length+" · 1920 × 1200"};
  $("#previous-wallpaper").onclick=()=>{at=(at+r.previews.length-1)%r.previews.length;show()};$("#next-wallpaper").onclick=()=>{at=(at+1)%r.previews.length;show()};show();
 }else if(r.id===2){
  modal("Touhou Piano Collection",'<div class="album-art">'+icon("music")+'<div><h3>Touhou Piano Collection</h3><small>Piano selections · FLAC</small></div></div><audio id="music-player" controls preload="metadata" src="'+r.previews[0].url+'"></audio><ol class="track-list">'+r.tracks.map((t,i)=>'<li><button data-track="'+i+'">'+icon("play")+'</button><span>'+esc(t.title)+'</span></li>').join("")+'</ol><div class="preview-controls">'+save+'</div>');
  $$("[data-track]").forEach(b=>{b.setAttribute("aria-label","Play "+r.tracks[Number(b.dataset.track)].title);b.onclick=()=>{const a=$("#music-player");a.currentTime=r.tracks[Number(b.dataset.track)].start;a.play().catch(()=>toast("Press Play to start the music."))}});
 }else if(r.id===3){
  modal("Windows 7 Sounds Extra",'<h3>Desktop sound collection</h3>'+r.previews.map(p=>'<div class="sound-row"><span>'+esc(p.name)+'</span><audio controls preload="none" aria-label="'+esc(p.name)+'" src="'+p.url+'"></audio></div>').join("")+'<div class="preview-controls">'+save+'</div>');
 }else{
  modal("Ocean Desktop Dreamscene",'<video controls loop playsinline preload="metadata" poster="'+r.poster+'" src="'+r.previews[0].url+'"></video><div class="preview-controls"><span>Ocean Desktop · '+esc(r.durationLabel)+'</span>'+save+'</div>');
 }
 $$("#dialog audio, #dialog video").forEach(media=>{
  media.addEventListener("play",()=>{$$("#dialog audio, #dialog video").forEach(other=>{if(other!==media)other.pause()})});
  media.addEventListener("error",()=>toast("This preview could not load. Save the file to open it locally."));
 });
}
function closeMenu(restore=false){$("#menu").hidden=true;if(restore&&menuReturn?.isConnected)menuReturn.focus()}
function showMenu(items,x,y,returnFocus){
 menuReturn=returnFocus||document.activeElement;
 const menu=$("#menu");menu.innerHTML=items.map(item=>item===null?"<hr>":'<button role="menuitem" data-action="'+item[0]+'" '+(item[3]?"disabled":"")+'>'+icon(item[1])+item[2]+"</button>").join("");menu.hidden=false;
 menu.style.left=Math.min(x,window.innerWidth-menu.offsetWidth-10)+"px";menu.style.top=Math.min(y,window.innerHeight-menu.offsetHeight-10)+"px";
 menu.querySelector("button:not(:disabled)")?.focus();
}
const actions={
 save:saveFile,preview,toggle:toggleTransfer,all:toggleAll,reset:()=>{reset();toast("Original session restored.")},export:exportHistory,
 favorite:()=>{rows[selected].favorite=!rows[selected].favorite;renderRows()},
 capture:()=>$("#save-capture").click(),torrent:()=>$("#save-torrent").click(),
 expand:()=>{document.body.classList.toggle("expanded");drawGraph()},
 speed:()=>{tab="speed";renderDetails()},addresses:()=>{hideAddresses=!hideAddresses;renderDetails()},options:options,help:help
};
function context(x,y,target){const r=rows[selected];showMenu([["save","save","Save file",!r.id],["preview","preview","Preview",!r.id],null,["toggle",currentState(r)==="paused"?"play":"pause",currentState(r)==="paused"||r.state==="queued"?"Resume transfer":"Pause transfer",!r.id||pausedAll],["favorite","star",r.favorite?"Remove favorite":"Add to favorites"],null,["capture","capture","Save capture"],["torrent","torrent","Save .torrent"]],x,y,target)}
function options(){
 modal("AeroTorrent options",'<h3>Display</h3><label><input type="checkbox" id="option-addresses" '+(hideAddresses?"checked":"")+'> Hide peer addresses</label><label><input type="checkbox" id="option-expand" '+(document.body.classList.contains("expanded")?"checked":"")+'> Expand application window</label><label><input type="checkbox" id="option-motion" '+(document.body.classList.contains("reduce-motion")?"checked":"")+'> Reduce decorative motion</label>');
 $("#option-addresses").onchange=e=>{hideAddresses=e.target.checked;renderDetails()};
 $("#option-expand").onchange=e=>{document.body.classList.toggle("expanded",e.target.checked);drawGraph()};
 $("#option-motion").onchange=e=>document.body.classList.toggle("reduce-motion",e.target.checked);
}
function help(){modal("AeroTorrent help",'<h3>Your library, at a glance</h3><p>Select a transfer to see its files, trackers, peers, and log. Pause or resume transfers with the toolbar or right-click menu.</p><p><b>Save file</b> copies a library item to your Downloads folder. <b>Preview</b> opens music, video, sounds, or wallpapers. Library files remain available when transfers are paused.</p><p>Use <b>Save capture</b> and <b>Save .torrent</b> for the saved Nitro transfer. Its destination drive is unavailable.</p><p><b>Reset session</b> restores the original transfer list and display preferences.</p>')}
$("#transfer-rows").onclick=e=>{const tr=e.target.closest("tr[data-id]");if(tr)select(Number(tr.dataset.id))};
$("#transfer-rows").ondblclick=e=>{const tr=e.target.closest("tr[data-id]");if(tr){select(Number(tr.dataset.id));preview()}};
$("#transfer-rows").oncontextmenu=e=>{const tr=e.target.closest("tr[data-id]");if(tr){e.preventDefault();select(Number(tr.dataset.id));context(e.clientX,e.clientY,tr)}};
$("#transfer-rows").onkeydown=e=>{
 const tr=e.target.closest("tr[data-id]");if(!tr)return;
 if(e.key==="Enter"||e.key===" "){e.preventDefault();select(Number(tr.dataset.id))}
 if(e.key==="ContextMenu"||e.shiftKey&&e.key==="F10"){e.preventDefault();select(Number(tr.dataset.id));const b=tr.getBoundingClientRect();context(b.x+60,b.y+20,tr)}
 if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();const next=e.key==="ArrowDown"?tr.nextElementSibling:tr.previousElementSibling;if(next){select(Number(next.dataset.id));next.focus()}}
};
$("#menu").onclick=e=>{const action=e.target.closest("[data-action]");if(action){closeMenu(true);actions[action.dataset.action]?.()}};
$("#menu").onkeydown=e=>{
 const items=[...$("#menu").querySelectorAll("button:not(:disabled)")],i=items.indexOf(document.activeElement);
 if(e.key==="Escape"){e.preventDefault();closeMenu(true)}
 if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();items[(i+items.length+(e.key==="ArrowDown"?1:-1))%items.length]?.focus()}
 if(e.key==="Tab")closeMenu();
};
document.addEventListener("pointerdown",e=>{if(!e.target.closest("#menu")&&!e.target.closest("[data-menu]"))closeMenu()});
$$("[data-menu]").forEach(b=>b.onclick=()=>{
 const kind=b.dataset.menu,rect=b.getBoundingClientRect();
 const lists={file:[["save","save","Save selected file",!rows[selected]?.id],["capture","capture","Save capture"],["torrent","torrent","Save .torrent"],null,["export","document","Export history"]],
 view:[["expand","window","Expand / restore window"],["speed","network","Speed graph"],["addresses","peer",hideAddresses?"Show peer addresses":"Hide peer addresses"]],
 options:[["all",pausedAll?"play":"pause-all",pausedAll?"Resume all":"Pause all"],["options","window","Display options"],null,["reset","reset","Reset session"]]};
 showMenu(lists[kind],rect.left,rect.bottom,b);
});
$("#search").oninput=renderRows;$("#attention").onchange=renderRows;
$$("th[data-key] button").forEach(b=>b.onclick=()=>{const key=b.parentElement.dataset.key;ascending=sortKey===key?!ascending:true;sortKey=key;renderRows()});
$$("[data-filter]").forEach(b=>b.onclick=()=>{filter=b.dataset.filter;$("#list-title").textContent=b.childNodes[1].textContent.trim();renderRows()});
$$(".tabs button").forEach((b,i)=>{b.onclick=()=>{tab=b.dataset.tab;renderDetails()};b.onkeydown=e=>{if(["ArrowLeft","ArrowRight","Home","End"].includes(e.key)){e.preventDefault();const all=$$(".tabs button");const n=e.key==="Home"?0:e.key==="End"?all.length-1:(i+all.length+(e.key==="ArrowRight"?1:-1))%all.length;tab=all[n].dataset.tab;renderDetails();all[n].focus()}}});
$("#favorite").onclick=actions.favorite;$("#export").onclick=exportHistory;$("#transfer-toggle").onclick=toggleTransfer;$("#pause-all").onclick=toggleAll;
$("#save-file").onclick=saveFile;$("#open-file").onclick=preview;$("#reset").onclick=actions.reset;
$("#expand").onclick=actions.expand;$("#help").onclick=$("#about").onclick=help;
$("#dialog-close").onclick=$("#dialog-ok").onclick=()=>$("#dialog").close();
$("#dialog").addEventListener("close",()=>{$$("#dialog audio,#dialog video").forEach(m=>{m.pause();m.removeAttribute("src");m.load()});$("#dialog-content").replaceChildren()});
window.addEventListener("resize",drawGraph);
Promise.all([fetch("/evidence/manifest.json"),fetch("/catalog.json")]).then(async responses=>{
 if(responses.some(r=>!r.ok))throw Error("Catalog unavailable");
 [manifest,catalog]=await Promise.all(responses.map(r=>r.json()));reset();
}).catch(()=>{$("#status").textContent="Library unavailable";toast("The library could not load. Reload to try again.");$$(".toolbar button").forEach(b=>b.disabled=true)});
