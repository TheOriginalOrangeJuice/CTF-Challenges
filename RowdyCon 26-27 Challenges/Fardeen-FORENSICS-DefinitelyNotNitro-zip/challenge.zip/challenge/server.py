"""AeroTorrent: explicit public routes, immutable evidence, seekable local media."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import argparse
import mimetypes
import json
import re

PUBLIC = Path(__file__).parent / 'public'
FILES = {
    '/': 'index.html', '/index.html': 'index.html',
    '/app.js': 'app.js', '/style.css': 'style.css', '/favicon.svg': 'favicon.svg',
    '/icons.svg': 'icons.svg', '/catalog.json': 'catalog.json',
    '/asset-index.json': 'asset-index.json',
    '/evidence/DefinitelyNotNitro.torrent': 'evidence/DefinitelyNotNitro.torrent',
    '/evidence/transfer-session.pcap': 'evidence/transfer-session.pcap',
    '/evidence/manifest.json': 'evidence/manifest.json',
}
# Generated from the frozen presentation library, never from request input.
for relative in json.loads((PUBLIC / 'asset-index.json').read_text()):
    candidate = PUBLIC / relative
    if candidate.resolve().parent != PUBLIC.resolve() and PUBLIC.resolve() not in candidate.resolve().parents:
        raise ValueError('Asset outside public root')
    FILES['/' + relative] = relative
FILES['/media/piano.flac'] = 'downloads/Touhou_Piano_Collection.flac'


class Handler(BaseHTTPRequestHandler):
    server_version = 'AeroTorrent/2.2'

    def serve_file(self, head=False):
        path = urlsplit(self.path).path
        if path not in FILES:
            self.send_error(404, 'File not found')
            return
        file = PUBLIC / FILES[path]
        if not file.is_file():
            self.send_error(503, 'File unavailable')
            return
        size = file.stat().st_size
        start, end = 0, size - 1
        requested = self.headers.get('Range') if not head else None
        if requested:
            match = re.fullmatch(r'bytes=(\d*)-(\d*)', requested)
            try:
                if not match or not any(match.groups()):
                    raise ValueError()
                first, last = match.groups()
                if first:
                    start = int(first)
                    end = min(int(last), size - 1) if last else size - 1
                else:
                    suffix = int(last)
                    if suffix <= 0:
                        raise ValueError()
                    start = max(0, size - suffix)
                if start > end or start >= size:
                    raise ValueError()
            except ValueError:
                self.send_response(416)
                self.send_header('Content-Range', f'bytes */{size}')
                self.send_header('Content-Length', '0')
                self.end_headers()
                return
        self.send_response(206 if requested else 200)
        kind = mimetypes.guess_type(str(file))[0] or 'application/octet-stream'
        kind = {'.flac': 'audio/flac', '.wmv': 'video/x-ms-wmv', '.wav': 'audio/wav',
                '.webm': 'video/webm', '.svg': 'image/svg+xml'}.get(file.suffix, kind)
        if file.suffix in ('.html', '.js', '.css', '.json'):
            kind += '; charset=utf-8'
        self.send_header('Content-Type', kind)
        self.send_header('Content-Length', str(end - start + 1))
        self.send_header('Accept-Ranges', 'bytes')
        if requested:
            self.send_header('Content-Range', f'bytes {start}-{end}/{size}')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; media-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cache-Control', 'no-store')
        if file.suffix in ('.torrent', '.pcap') or path.startswith('/downloads/'):
            self.send_header('Content-Disposition', f'attachment; filename="{file.name}"')
        self.end_headers()
        if not head:
            try:
                with file.open('rb') as stream:
                    stream.seek(start)
                    remaining = end - start + 1
                    while remaining:
                        block = stream.read(min(65536, remaining))
                        if not block:
                            break
                        self.wfile.write(block)
                        remaining -= len(block)
            except (BrokenPipeError, ConnectionResetError):
                pass  # Normal when a media player seeks or a download is cancelled.

    def do_GET(self):
        self.serve_file()

    def do_POST(self):
        self.send_error(405, 'Method not allowed')

    def do_HEAD(self):
        self.serve_file(head=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=18106)
    args = parser.parse_args()
    ThreadingHTTPServer(('0.0.0.0', args.port), Handler).serve_forever()
