# The Axon That Moved

Unlocked by **A Voice Before Launch**.

Finding the recording in A Voice Before Launch made me curious about the people who unlocked it. The payphone call associated with it moved to Denver after the original location failed. On the retry day, the player community warned that callers would face a new question. According to the notice published that day, what one-word answer were players supposed to give?

Submit `RCC{word}`.
