# 1273

Ever since I was a baby, I feel like I was being influenced by someone to learn a "Summoning Dance?" Now, whenever says those words I just start doing some silly dance from the 2010s. I found a video of it, I just want to know who called it a Summoning Dance? 

[Watch the video](https://www.youtube.com/watch?v=9xJXSnYDkks)

Submit: `RCC{username}`
