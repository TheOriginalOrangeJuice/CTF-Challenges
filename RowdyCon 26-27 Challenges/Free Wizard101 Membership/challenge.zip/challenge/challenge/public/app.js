﻿"use strict";
const $ = selector => document.querySelector(selector);

// Original local bell, glass and wooden-button voices. The offline renderer uses
// the same synthesis graph as the live controls; no samples or network audio.
const CrownAudio = (() => {
  const volume = 0.34, voiceLimit = 4;
  const cues = {
    click: [[240,0,.075,.13,"triangle",150],[1480,.008,.12,.035,"sine"]],
    select: [[880,0,.13,.09,"sine"],[1760,.025,.18,.035,"sine"]],
    open: [[587.33,0,.34,.10,"sine"],[880,.055,.38,.075,"sine"],[1174.66,.11,.45,.055,"sine"]],
    close: [[880,0,.16,.08,"sine"],[587.33,.06,.22,.075,"sine"]],
    copy: [[1318.51,0,.17,.10,"sine"],[1760,.065,.24,.07,"sine"],[2637.02,.015,.11,.025,"sine"]],
    generate: [[180,0,.32,.07,"triangle",360],[293.66,0,.40,.075,"sine"],[440,.065,.40,.075,"sine"],[587.33,.13,.44,.08,"sine"],[739.99,.195,.48,.07,"sine"],[880,.26,.55,.065,"sine"]],
    verify: [[440,0,.25,.09,"sine"],[659.25,.08,.30,.07,"sine"]],
    error: [[349.23,0,.15,.09,"triangle",293.66],[220,.14,.23,.09,"triangle"]],
    success: [[587.33,0,.65,.085,"sine"],[739.99,.11,.65,.075,"sine"],[880,.22,.72,.075,"sine"],[1174.66,.33,.82,.07,"sine"],[2349.32,.34,.45,.02,"sine"]],
    reset: [[440,0,.12,.08,"triangle",220],[587.33,.09,.25,.07,"sine"]]
  };
  let enabled = true, context = null, master = null, serial = 0;
  const voices = new Map(), history = [];
  let maxVoices = 0, scheduled = 0;
  function synth(ctx, destination, kind, when) {
    const nodes = [], oscillators = [];
    const bus = ctx.createGain(); bus.connect(destination);
    let end = when;
    for (const [frequency, offset, duration, level, shape, finish] of (cues[kind] || cues.click)) {
      const start = when + offset;
      const osc = ctx.createOscillator(), gain = ctx.createGain();
      osc.type = shape; osc.frequency.setValueAtTime(frequency,start);
      if (finish) osc.frequency.exponentialRampToValueAtTime(finish,start+duration);
      gain.gain.setValueAtTime(0,start);
      gain.gain.linearRampToValueAtTime(level,start+.006);
      gain.gain.exponentialRampToValueAtTime(.0001,start+duration);
      gain.gain.setValueAtTime(0,start+duration+.008);
      osc.connect(gain); gain.connect(bus);
      osc.start(start); osc.stop(start+duration+.012);
      osc.onended = () => { osc.disconnect(); gain.disconnect(); };
      oscillators.push(osc); nodes.push(gain);
      end = Math.max(end,start+duration+.012);
    }
    const stop = () => {
      bus.gain.cancelScheduledValues(ctx.currentTime);
      bus.gain.setValueAtTime(0,ctx.currentTime); bus.disconnect();
      oscillators.forEach(osc => { try { osc.stop(ctx.currentTime); } catch (_) {} });
    };
    return {end,stop,bus};
  }
  function unlock() {
    if (!enabled) return;
    try {
      if (!context) {
        const Audio = window.AudioContext || window.webkitAudioContext;
        if (!Audio) return;
        context = new Audio(); master = context.createGain();
        master.gain.value = volume; master.connect(context.destination);
      }
      if (context.state === "suspended") context.resume().catch(() => {});
    } catch (_) { /* Audio availability must never block a control. */ }
  }
  function play(kind = "click", gesture = false) {
    if (!enabled) return false;
    if (gesture) unlock();
    if (!context || context.state === "closed") return false;
    try {
      if (voices.size >= voiceLimit) {
        const [id,voice] = voices.entries().next().value;
        voice.stop(); voices.delete(id);
      }
      const id = ++serial;
      const voice = synth(context,master,kind,context.currentTime+.004);
      voices.set(id,voice); scheduled++; maxVoices = Math.max(maxVoices,voices.size);
      history.push({id,kind}); if (history.length>80) history.shift();
      setTimeout(() => { voice.bus.disconnect(); voices.delete(id); }, Math.ceil((voice.end-context.currentTime)*1000)+80);
      return true;
    } catch (_) { return false; }
  }
  function setEnabled(value) {
    enabled = Boolean(value);
    if (master) {
      master.gain.cancelScheduledValues(context.currentTime);
      master.gain.value = enabled ? volume : 0;
    }
    if (!enabled) {
      voices.forEach(voice => voice.stop()); voices.clear();
    }
  }
  async function render(kind,count=1) {
    const offline = new OfflineAudioContext(1,Math.ceil(1.6*44100),44100);
    const output = offline.createGain(); output.gain.value = enabled ? volume : 0; output.connect(offline.destination);
    for (let i=0; i<Math.max(1,Math.min(voiceLimit,count)); i++) synth(offline,output,kind,.01);
    return offline.startRendering();
  }
  return Object.freeze({play,unlock,setEnabled,render,kinds:Object.freeze(Object.keys(cues)),
    snapshot:() => ({enabled,state:context?.state || "uninitialized",outputGain:master?.gain.value || 0,scheduled,active:voices.size,maxVoices,voiceLimit,history:history.slice()})});
})();
window.CrownAudio = CrownAudio;

// Click is also the browser's native keyboard activation event. Using it alone
// for buttons/links/summaries prevents pointerdown + click duplicate sounds.
document.addEventListener("click", event => {
  const control = event.target.closest("button,a,summary,input");
  if (!control || control.disabled || control.id === "sound-toggle") return;
  let kind = "click";
  if (control.tagName === "SUMMARY") kind = control.parentElement.open ? "close" : "open";
  else if (control.matches("a[download]")) kind = "copy";
  else if (control.dataset.sound) kind = control.dataset.sound;
  else if (control.id.startsWith("copy-")) kind = "copy";
  else kind = ({generate:"generate","claim-submit":"verify","open-verification":"open","close-verification":"close","back-to-log":"close",reset:"reset"})[control.id] || "click";
  CrownAudio.play(kind,true);
},true);
document.addEventListener("change", event => { if (event.target.matches("select")) CrownAudio.play("select",true); });
document.addEventListener("keydown", event => {
  if (!event.repeat && event.target.matches("select") && ["Enter"," "].includes(event.key)) CrownAudio.play("open",true);
});
document.addEventListener("invalid", () => CrownAudio.play("error",true),true);
$("#sound-toggle").addEventListener("click", () => {
  const enabled = !CrownAudio.snapshot().enabled;
  CrownAudio.setEnabled(enabled);
  $("#sound-toggle").setAttribute("aria-pressed",String(enabled));
  $("#sound-toggle").textContent = enabled ? "♫ Sound On" : "♫ Sound Off";
  if (enabled) CrownAudio.play("select",true);
});

// Fixed page-clock schedule: all copies begin with these rows and repeat the
// same names, packages and count movements. Feed updates never make a sound.
const initialActivity = [
  ["FireStormLegend",10000,"fire",-120000], ["SapphireMage",50000,"storm",-240000],
  ["BlazeLife101",25000,"myth",-360000], ["MoonShadow",67000,"moon",-480000],
  ["CoolWizardDude",99999,"ice",-600000]
];
const activitySchedule = [
  ["LunaStarfall",25000,"moon"], ["DragonBlaze",10000,"fire"],
  ["FrostWizard12",50000,"ice"], ["MythicMerlin",67000,"myth"],
  ["AmberStorm",99999,"storm"], ["RavenSpell",10000,"moon"],
  ["JadeFireheart",50000,"fire"], ["CrystalWand",25000,"ice"],
  ["SpiralSeeker",99999,"myth"], ["ThunderMage",67000,"storm"],
  ["WolfMoon101",25000,"moon"], ["SilverPhoenix",50000,"fire"]
];
const onlineOffsets = [0,3,1,5,2,6,4,7,3,8,5,2];
let feedEpoch = performance.now(), feedTick = -1, feedTimer = null;
function updateActivity() {
  const elapsed = Math.max(0,performance.now()-feedEpoch), tick = Math.floor(elapsed/4000);
  const list = $("#activity-list");
  if (tick !== feedTick) {
    feedTick = tick;
    const rows = [];
    for (let index=tick; index>0 && rows.length<5; index--) rows.push([...activitySchedule[(index-1)%activitySchedule.length],index*4000]);
    rows.push(...initialActivity.slice(0,5-rows.length));
    const fragment = document.createDocumentFragment();
    rows.forEach(([name,amount,style,created],index) => {
      const row = document.createElement("li");
      if (index === 0 && tick>0) row.className = "is-new";
      const avatar = document.createElement("span"); avatar.className = `avatar ${style}`; avatar.setAttribute("aria-hidden","true");
      const body = document.createElement("div"), username = document.createElement("strong"), message = document.createElement("p"), quantity = document.createElement("b"), age = document.createElement("small");
      username.textContent = name; quantity.textContent = `${amount.toLocaleString("en-US")} Crowns!`;
      message.append(document.createTextNode("just generated "),quantity);
      age.dataset.created = String(created); body.append(username,message,age); row.append(avatar,body); fragment.append(row);
    });
    list.replaceChildren(fragment); list.dataset.tick = String(tick);
    $("#online-count").textContent = (1248+onlineOffsets[tick%onlineOffsets.length]).toLocaleString("en-US");
  }
  list.querySelectorAll("small").forEach(age => {
    const seconds = Math.max(0,Math.floor((elapsed-Number(age.dataset.created))/1000));
    age.textContent = seconds<5 ? "Just now" : seconds<60 ? `${seconds} seconds ago` : `${Math.floor(seconds/60)} minutes ago`;
  });
}
function resetActivity() {
  clearInterval(feedTimer); feedEpoch = performance.now(); feedTick = -1;
  updateActivity(); feedTimer = setInterval(updateActivity,1000);
}
resetActivity();
document.addEventListener("visibilitychange", () => { if (!document.hidden) updateActivity(); });

let keys, receiptText, fullLog, timer = null, stage = -1, running = false, completed = false, generationStart = 0;
const stages = [
  [0,"Connecting to Wizard City delivery gateway…"], [20,"Negotiating secure Crown delivery — Mirror A…"],
  [45,"Mirror A busy. Connecting to Mirror B…"], [70,"Generating Crowns…"],
  [90,"Encrypting your claim receipt with Mirror A…"], [100,"Crowns generated. Verification required."]
];
let toastTimer;
function announce(message) {
  clearTimeout(toastTimer);
  ($("#verification").open ? $("#verification") : document.body).append($("#toast"));
  $("#toast").textContent = message; $("#toast").hidden = false;
  toastTimer = setTimeout(() => { $("#toast").hidden = true; },3500);
}
async function copy(text) {
  try {
    if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
    else {
      const field = document.createElement("textarea"); field.value = text; field.setAttribute("aria-label","Text to copy");
      const previous = document.activeElement;
      ($("#verification").open ? $("#verification") : document.body).append(field);
      field.select(); const ok = document.execCommand("copy"); field.remove(); previous?.focus();
      if (!ok) throw new Error("clipboard unavailable");
    }
    announce("Copied to clipboard.");
  } catch (_) { CrownAudio.play("error"); announce("Clipboard unavailable. Select the text or use its download link."); }
}
function appendStage(index) {
  const [percent,message] = stages[index];
  const entry = document.createElement("div"); entry.className = "log-entry";
  const marker = document.createElement("span"); marker.className = "log-percent"; marker.textContent = `[${String(percent).padStart(3,"0")}%] `;
  entry.append(marker,document.createTextNode(message));
  if (index === 1 || index === 2) {
    const id = index === 1 ? "A" : "B", key = keys[`mirror_${id}`];
    const details = document.createElement("details"); details.className = "key-detail";
    const summary = document.createElement("summary"); summary.textContent = `Mirror ${id} • n${id} = ${key.n.slice(0,22)}… • e = ${key.e} (expand full key)`;
    const value = document.createElement("p"); value.textContent = `n${id} = ${key.n}\ne${id} = ${key.e}`;
    const button = document.createElement("button"); button.type = "button"; button.className = "small-button"; button.dataset.sound = "copy"; button.textContent = `Copy full n${id}`;
    button.addEventListener("click", () => copy(key.n)); details.append(summary,value,button); entry.append(details);
  }
  $("#log-entries").append(entry); $("#delivery-status").textContent = message;
}
function openVerification() {
  if (!completed || running) return;
  if (!$("#verification").open) $("#verification").showModal();
  $("#verification-title").focus();
}
function updateProgress(percent) {
  if (!running) return;
  if (percent === 100 && performance.now()-generationStart<12000) percent=99;
  $("#progress-fill").style.width = `${percent}%`; $("#progress-value").textContent = `${percent}%`;
  $(".progress").setAttribute("aria-valuenow",percent);
  const visual = matchMedia("(prefers-reduced-motion: reduce)").matches ? stages.filter(([value]) => value<=percent).at(-1)[0] : percent;
  document.querySelectorAll(".stage-row").forEach((row,index) => {
    const value = Math.min(100,Math.max(0,Math.round((visual-index*23)/(100-index*23)*100)));
    row.querySelector(".meter span").style.width = `${value}%`; row.querySelector("b").textContent = `${value}%`;
  });
  while (stage+1<stages.length && percent>=stages[stage+1][0]) appendStage(++stage);
  if (percent === 100) {
    clearInterval(timer); timer=null; running=false; completed=true;
    $("#ready").hidden=false; $("#session-actions").hidden=false; $("#reset").disabled=false;
    $("#delivery-title").textContent="❧ Generation Complete ❧";
    $("#reserved-message").textContent=`${Number($("#amount").value).toLocaleString("en-US")} Crowns reserved for you!`;
    CrownAudio.play("open"); openVerification();
  }
}
function begin() {
  if (!keys || running || completed) return;
  running=true; completed=false; generationStart=performance.now(); stage=-1;
  $("#generate").disabled=true; $("#reset").disabled=true; $("#session-actions").hidden=true;
  $("#log-entries").replaceChildren(); $("#verification").close();
  $("#reward").hidden=true; $("#ready").hidden=true; $("#setup").hidden=true;
  $("#claim-form").reset(); $("#claim-error").hidden=true; $("#flag").textContent="";
  $("#delivery").hidden=false; $("#technical-log").hidden=false; $("#technical-log").open=true;
  $("#delivery-title").textContent="❧ Generating Crowns ❧";
  const nickname=$("#nickname").value.trim() || "Young Wizard", amount=Number($("#amount").value).toLocaleString("en-US");
  $("#welcome").textContent=`${nickname}, your ${amount} Crowns are on their way!`;
  updateProgress(0); $("#generator").scrollIntoView({block:"start"});
  timer=setInterval(() => updateProgress(Math.min(100,Math.floor((performance.now()-generationStart)/120))),50);
}
$("#generate-form").addEventListener("submit",event => { event.preventDefault(); begin(); });
$("#reset").addEventListener("click", () => {
  if (running || !completed) return;
  completed=false; stage=-1; $("#verification").close();
  $("#generate-form").reset(); $("#claim-form").reset();
  $("#delivery").hidden=true; $("#reward").hidden=true; $("#technical-log").hidden=true; $("#session-actions").hidden=true;
  $("#setup").hidden=false; $("#generate").disabled=!keys;
  $("#flag").textContent=""; $("#log-entries").replaceChildren(); resetActivity(); $("#nickname").focus();
});
$("#open-verification").addEventListener("click",openVerification);
$("#verification").addEventListener("keydown",event => {
  if (event.key!=="Tab") return;
  const items=[...$("#verification").querySelectorAll("button,a[href],input,summary,[tabindex='0']")].filter(element => !element.disabled && element.getClientRects().length);
  const index=items.indexOf(document.activeElement);
  if (index===-1 || (!event.shiftKey && index===items.length-1) || (event.shiftKey && index===0)) { event.preventDefault(); items[event.shiftKey ? items.length-1 : 0]?.focus(); }
});
$("#verification").addEventListener("cancel", () => CrownAudio.play("close",true));
$("#close-verification").addEventListener("click", () => $("#verification").close());
$("#back-to-log").addEventListener("click", () => {
  $("#verification").close(); $("#technical-log").open=true; $("#technical-log>summary").focus(); $("#technical-log").scrollIntoView({block:"start"});
});
$("#copy-log").addEventListener("click", () => copy(fullLog));
$("#copy-receipt").addEventListener("click", () => copy(receiptText));
$("#copy-flag").addEventListener("click", () => copy($("#flag").textContent));
$("#claim-form").addEventListener("submit",async event => {
  event.preventDefault(); if (!completed || running || $("#claim-submit").disabled) return;
  $("#claim-error").hidden=true; $("#claim-submit").disabled=true;
  try {
    const response=await fetch("/api/claim",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:$("#claim-code").value.trim()})});
    const data=await response.json(); if (!response.ok) throw new Error(data.error || "Verification failed. Try again.");
    $("#flag").textContent=data.flag; $("#reward-message").textContent=data.message;
    $("#verification").close(); $("#delivery").hidden=true; $("#reward").hidden=false; $("#reward-title").focus(); CrownAudio.play("success");
  } catch (error) {
    $("#claim-error").textContent=error.message==="Failed to fetch" ? "The delivery gateway is unavailable. Try again." : error.message;
    $("#claim-error").hidden=false; CrownAudio.play("error");
  } finally { $("#claim-submit").disabled=false; }
});
(async () => {
  try {
    const responses=await Promise.all(["/keys.json","/claim.json","/generation-log.txt"].map(path => fetch(path)));
    if (responses.some(response => !response.ok)) throw new Error("delivery evidence unavailable");
    [keys,receiptText,fullLog]=await Promise.all([responses[0].json(),responses[1].text(),responses[2].text()]);
    $("#receipt-preview").textContent=receiptText; $("#generate").disabled=false;
  } catch (_) { $("#load-error").hidden=false; }
})();
