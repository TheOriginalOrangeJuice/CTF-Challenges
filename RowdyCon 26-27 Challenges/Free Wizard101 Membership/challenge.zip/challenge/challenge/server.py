"""Local Crown Generator CTF: explicit public files and hash-only redemption."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import hashlib
import hmac
import json
import re

ROOT = Path(__file__).resolve().parent
PRIVATE = json.loads((ROOT / "private/verifier.json").read_text())
PUBLIC = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"),
    "/app.js": ("app.js", "text/javascript; charset=utf-8"),
    "/wizard.svg": ("wizard.svg", "image/svg+xml"),
    "/masthead.png": ("masthead.png", "image/png"),
    "/crowns.png": ("crowns.png", "image/png"),
    "/icons.svg": ("icons.svg", "image/svg+xml"),
    "/reference-art.png": ("reference-art.png", "image/png"),
    "/keys.json": ("keys.json", "application/json"),
    "/claim.json": ("claim.json", "application/json"),
    "/generation-log.txt": ("generation-log.txt", "text/plain; charset=utf-8"),
}
CSP = "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate property")
        result[key] = value
    return result


class Handler(BaseHTTPRequestHandler):
    server_version = "CrownGateway"

    def setup(self):
        super().setup()
        self.connection.settimeout(10)

    def reply(self, status, data, mime="application/json", head=False):
        if isinstance(data, dict):
            data = json.dumps(data, separators=(",", ":")).encode()
        self.send_response(status)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Content-Security-Policy", CSP)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        if not head:
            self.wfile.write(data)

    def do_GET(self):
        path = urlsplit(self.path).path
        entry = PUBLIC.get(path)
        if not entry:
            return self.reply(404, {"error": "Page not found."}, head=self.command == "HEAD")
        filename, mime = entry
        self.reply(200, (ROOT / "public" / filename).read_bytes(), mime, self.command == "HEAD")

    do_HEAD = do_GET

    def do_POST(self):
        if self.path != "/api/claim":
            return self.reply(404, {"error": "Page not found."})
        lengths = self.headers.get_all("Content-Length", [])
        if (self.headers.get("Transfer-Encoding") or len(lengths) != 1
                or len(lengths[0]) > 6 or not lengths[0].isascii() or not lengths[0].isdigit()):
            return self.reply(400, {"error": "A single content length is required."})
        length = int(lengths[0])
        if length > 256:
            return self.reply(413, {"error": "Claim is too large."})
        if self.headers.get("Content-Type", "").split(";")[0].strip() != "application/json":
            return self.reply(415, {"error": "Send a JSON claim."})
        try:
            data = json.loads(self.rfile.read(length), object_pairs_hook=unique_object)
            if (not isinstance(data, dict) or set(data) != {"code"}
                    or not isinstance(data["code"], str)
                    or not re.fullmatch(r"CROWN-[0-9a-f]{32}", data["code"])):
                raise ValueError("invalid claim")
        except (ValueError, UnicodeError, TimeoutError):
            return self.reply(400, {"error": "Use CROWN- followed by 32 lowercase hexadecimal characters."})
        digest = hashlib.sha256(data["code"].encode("ascii")).hexdigest()
        if not hmac.compare_digest(digest, PRIVATE["expected_sha256"]):
            return self.reply(403, {"error": "That claim code did not verify. Check the decrypted receipt."})
        self.reply(200, {"flag": PRIVATE["flag"], "message": "Crowns delivered: 0. Flag delivered: 1."})


if __name__ == "__main__":
    ThreadingHTTPServer(("0.0.0.0", 8080), Handler).serve_forever()
