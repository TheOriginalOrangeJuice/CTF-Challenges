"""Run recorded checks sequentially against the current staged tree and Docker service."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
reports = ROOT / "organizer/results"
reports.mkdir(exist_ok=True)
for script, name in [("check_math.py", "math.json"), ("solve_public.py", "public-solve.json"), ("test_http.py", "http.json"), ("test_browser.py", "browser.json"), ("check_determinism.py", "determinism.json")]:
    result = subprocess.run([sys.executable, str(ROOT / "organizer" / script)], capture_output=True, text=True)
    if result.returncode:
        (reports / (name + ".failure.txt")).write_text(result.stdout + result.stderr)
        print(result.stdout + result.stderr, flush=True)
        raise SystemExit(result.returncode)
    (reports / name).write_text(result.stdout, encoding="utf-8")
    print(f"PASS {script} -> organizer/results/{name}", flush=True)
