﻿"""Assemble current UI acceptance evidence without claiming human playtesting."""
from pathlib import Path
import hashlib,json,re,sys,zipfile
ROOT=Path(__file__).resolve().parents[1]
R=ROOT/'organizer/results'
def read(name): return json.loads((R/name).read_text(encoding='utf-8-sig'))
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
browser,http,determinism,walkthrough=map(read,['browser.json','http.json','determinism.json','walkthrough.json'])
assert all(item['result']=='PASS' for item in (browser,http,determinism,walkthrough))
public_solve=read('public-solve.json')
flag=public_solve['redemption']['flag']
assert flag=='RCC{tw0_m1rr0rs_0ne_pr1me_z3r0_cr0wns_9e7a42c1}'
frozen={
'challenge/public/keys.json':'a1a6e21fced7a0281ca690b31ef53d2a14e60a6b88c617c686b1f37283cbaca9',
'challenge/public/generation-log.txt':'0f67aebe38a58f7f795193722041bce6d762d31c771c7546c1990ef4fac2eb08',
'challenge/public/claim.json':'8ac9a999ab0b1e0d869970e2f167cf4f5598e530394967004933c2823a3ab6aa',
'challenge/private/verifier.json':'7bf8eb1790719da15bbd50b6249c431bff3de3826d23469252017206470760f6',
'organizer/fixtures.json':'20261fd059f3873537c0367f95cd77f64234793a6df0f806b5954998522ecdea'}
assert all(digest(ROOT/name)==value for name,value in frozen.items())
assert all(digest(ROOT/'challenge/public'/name)==value for name,value in http['public_hashes'].items())
assert all(digest(ROOT/'challenge'/name)==value for name,value in determinism['deployed_app_sha256'].items())
doc_check=json.loads((ROOT/'organizer/document-review/document-check.json').read_text())
assert doc_check['pages']==3
with zipfile.ZipFile(ROOT/'Description.docx') as doc:
    embedded={hashlib.sha256(doc.read(name)).hexdigest() for name in doc.namelist() if name.startswith('word/media/')}
images={name:digest(ROOT/name) for name in doc_check['images']}
assert set(images.values())==embedded
markdown=(ROOT/'Description.md').read_text(encoding='utf-8-sig')
assert re.findall(r'^## (.+)$',markdown,re.M)==['Description','Files','Hint(s)','Walkthrough','Flag']
assert all(not (ROOT/name).exists() for name in ('README.md','DEPLOYMENT.md','QA.md','SOLTION.md'))
manifest=Path(sys.argv[1]); expected=json.loads(manifest.read_text(encoding='utf-8-sig'))
actual={str(p.relative_to(ROOT)):digest(p) for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
assert actual==expected
refs=sorted(str(p.relative_to(ROOT)) for p in (ROOT/'example UI').glob('*.png'))
assert len(refs)==4
report={
'result':'PASS','date':'2026-10-25','scope':'Substantial desktop UI redesign; frozen Medium shared-prime RSA mechanism and server verification preserved.',
'live_review':{'container':'rowdy-crowns04-review','host_url':'http://localhost:18104','condev_url':'http://host.docker.internal:18104','image_id':determinism['image_id']},
'visual_references':refs,
'visual_comparison':[
{'reference':'1: generator','implemented':'Full-width illustrated gold Wizard101/Crown Generator masthead, six glossy tabs, 21.5/55.5/23 columns, parchment benefits/activity/testimonials, actual nickname/realm/amount controls, illustrated chest, glossy green button and gold medals.'},
{'reference':'2: generating','implemented':'Four distinct live green progress meters, stage icons and percentages, persistent terminal-style log with complete expandable/copyable/downloadable A and B keys.'},
{'reference':'3: verification','implemented':'Gold-framed blue-and-parchment modal, dimmed site behind, real encrypted receipt and code controls, visible errors, close/Escape/Back to log/reopen; survey/install/payment actions excluded.'},
{'reference':'4: reserved/reward','implemented':'CROWNS READY state, red verification call to action, green confirmation, chest illustration and real server-returned flag with copying.'}],
'visual_review':{'method':'Actual Chromium screenshots visually inspected by implementation and root review agents; this is not independent human playtesting.','screenshots':browser['screenshots'],'desktop_sizes':browser['layouts'],'result':'PASS','notes':'Natural-proportion supplied masthead; readable labels; both complete keys visible after expansion; no clipped controls or subtitle overlap at tested desktop sizes.'},
'historical_sources':[
{'url':'https://forums.neoseeker.com/43451/t1852115-wizard101-crown-generator/','use':'2013 community Crown-generator promotion rhetoric; exact linked blog layout was unavailable.'},
{'url':'https://www.supercheats.com/pc/questions/wizard101/198022/how-do-i-get-free-crowns.htm','use':'Period discussion of free-Crown claims and survey gates.'},
{'url':'https://kingsisleblog.com/2016/01/28/4-online-safety-tips-for-dataprivacyday/','use':'2016 primary-source acknowledgment of Crown generators.'}],
'historical_limit':'The four user-supplied images are the visual source of truth. Historical pages corroborate rhetoric and flow, not a verified pixel-perfect historical site.',
'artwork_provenance':'organizer/artwork.json contains local source usage, built-in image_gen asset paths, and complete generation prompts. The supplied image is CSS-clipped only for its masthead; functional controls are DOM elements.',
'public_solve':public_solve,
'frozen_baseline_sha256':frozen,
'http_validation':{'result':http['result'],'checks':http['checks'],'coverage':http['coverage'],'public_sha256':http['public_hashes']},
'browser_validation':{'result':browser['result'],'run_seconds':browser['run_seconds'],'checks':browser['checks'],'request_count':browser['request_count'],'page_errors':browser['page_errors'],'expected_negative_console':browser['expected_negative_console']},
'determinism':{'result':determinism['result'],'checks':determinism['checks'],'deployed_app_sha256':determinism['deployed_app_sha256']},
'documentation':{'markdown':'Description.md','docx':'Description.docx','five_sections':doc_check['sections'],'pages':doc_check['pages'],'literal_walkthrough':walkthrough['result'],'literal_bash_blocks':walkthrough['literal_bash_blocks'],'local_links_verified':walkthrough['local_links_verified'],'rendered_pages_inspected':['page-1.png','page-2.png','page-3.png'],'embedded_images_match_final_source':True,'image_sha256':images,'docx_sha256':digest(ROOT/'Description.docx')},
'source_parity':{'result':'PASS','complete_tree':str(ROOT),'manifest':str(manifest),'files':len(expected),'hash_differences':0,'deployed_app_matches_current_source':True,'method':'Whole-tree stage_tree.ps1 to fresh Public/Docker folder, host docker cp to unique Condev /tmp path, complete SHA-256 parity before validation. No /mnt/hostshare reads.'},
'anti_agent':{'placement':'Non-rendered template#legacy-claim-example only','technical_interference':'Hidden sample stays outside evidence and fails real verifier. Scripts, downloads, headless browsing and keyboard controls work.','effectiveness':'Not evaluated; no AI-proof claim.'},
'human_playtesting':{'status':'PENDING','note':'Browser automation and agent visual review are not independent human playtesting.'},
'autonomous_agent_deterrence_evaluation':{'status':'PENDING'},
'prior_reports':'ui-redesign.json is the current UI pass. Older consolidation/mobile reports remain historical.'}
(R/'ui-redesign.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'result':'PASS','report':'organizer/results/ui-redesign.json','frozen_files':len(frozen),'docx_pages':3,'embedded_images_match':True,'complete_tree_hashes_verified':len(expected),'flag':flag}))
