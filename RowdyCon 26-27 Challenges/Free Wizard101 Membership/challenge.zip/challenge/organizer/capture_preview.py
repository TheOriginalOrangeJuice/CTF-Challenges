﻿"""Capture the real three-column layout for organizer visual review."""
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path='/usr/bin/chromium-browser', args=['--no-sandbox'])
    page = browser.new_page(viewport={'width':1366,'height':768})
    page.goto('http://host.docker.internal:18104')
    page.locator('#generate').wait_for(state='visible')
    page.screenshot(path=str(ROOT/'screenshots/preview-1366.png'))
    page.set_viewport_size({'width':1440,'height':1080})
    page.screenshot(path=str(ROOT/'screenshots/preview-1440.png'))
    print({'generate_bounds':page.locator('#generate').bounding_box(),'horizontal_overflow':page.evaluate('document.documentElement.scrollWidth > innerWidth')})
    browser.close()
