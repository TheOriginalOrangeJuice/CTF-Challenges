"""Execute Description.md's literal walkthrough Bash blocks in a fresh directory."""
from pathlib import Path
import json
import os
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
doc = (ROOT / "Description.md").read_text(encoding="utf-8")
walkthrough = doc.split("## Walkthrough\n", 1)[1].split("## Flag\n", 1)[0]
blocks = re.findall(r"```bash\n(.*?)\n```", walkthrough, re.S)
assert len(blocks) == 3
with tempfile.TemporaryDirectory(prefix="crowns04-walkthrough-") as scratch:
    env = dict(os.environ, BASE="http://host.docker.internal:18104")
    result = subprocess.run(["bash", "-euc", "\n\n".join(blocks)], cwd=scratch, env=env, capture_output=True, text=True)
    assert result.returncode == 0, result.stdout + result.stderr
    expected = ["Modulus bits: 2048 2048", "Shared prime bits: 1024", "Claim code: CROWN-9e7f4937af0b6da6a9b7fa9103597453"]
    assert all(value in result.stdout for value in expected)
    redemption = json.loads((Path(scratch) / "crowns-solve/redemption.json").read_text())
    assert redemption["message"] == "Crowns delivered: 0. Flag delivered: 1."
    assert redemption["flag"] in doc
    request = json.loads((Path(scratch) / "crowns-solve/claim-request.json").read_text())
    assert request["code"] in doc
    links = re.findall(r"\]\(([^)]+)\)", doc)
    local = [link for link in links if not link.startswith(("http://", "https://", "#"))]
    assert all((ROOT / link).is_file() for link in local), local
    report = {"result": "PASS", "literal_bash_blocks": len(blocks), "local_links_verified": local, "output": result.stdout, "stderr": result.stderr, "environment": {"BASE": env["BASE"]}, "source": "Description.md Walkthrough; extracted without modifying command text"}
    target = ROOT / "organizer/results/walkthrough.json"
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"result": "PASS", "literal_bash_blocks": len(blocks), "local_links": len(local), "report": "organizer/results/walkthrough.json"}))
