"""Deterministically rebuild evidence and hash-only verifier from frozen fixtures."""
from pathlib import Path
import hashlib
import json
import math
from Crypto.Util.number import isPrime

ROOT = Path(__file__).resolve().parents[1]
f = json.loads((ROOT / "organizer/fixtures.json").read_text())
p, qa, qb = (int(f[k]) for k in ("p", "qA", "qB"))
e = f["e"]
assert len({p, qa, qb}) == 3
assert all(v.bit_length() == 1024 and isPrime(v) for v in (p, qa, qb))
na, nb = p * qa, p * qb
assert na.bit_length() == nb.bit_length() == 2048
assert math.gcd(na, nb) == p
assert all(math.gcd(e, v - 1) == 1 for v in (p, qa, qb))
m = int.from_bytes(f["code"].encode("ascii"), "big")
assert e == 65537 and m < na
c = pow(m, e, na)
public = ROOT / "challenge/public"
private = ROOT / "challenge/private"
public.mkdir(parents=True, exist_ok=True)
private.mkdir(parents=True, exist_ok=True)

def emit(path, obj):
    path.write_bytes((json.dumps(obj, indent=2) + "\n").encode("utf-8"))

emit(public / "keys.json", {"mirror_A": {"n": str(na), "e": e}, "mirror_B": {"n": str(nb), "e": e}})
emit(public / "claim.json", {
    "receipt": "WC-2011-0067", "key_id": "mirror_A", "scheme": "textbook RSA (raw RSA; no padding)",
    "message_encoding": "ASCII bytes interpreted as one unsigned big-endian integer",
    "encryption": "c = m^e mod nA", "ciphertext_decimal": str(c),
    "claim_format": "CROWN- followed by 32 lowercase hexadecimal characters",
    "redeem": "POST /api/claim with JSON {\"code\":\"your decrypted claim code\"}",
})
log = (
    "WIZARD CITY CROWN DELIVERY / GENERATION LOG\n"
    "Fixed receipt WC-2011-0067. Fictional delivery simulation.\n"
    "[000%] Connecting to Wizard City delivery gateway...\n"
    "[020%] Negotiating secure Crown delivery - Mirror A...\n"
    f"nA = {na}\neA = {e}\n"
    "[045%] Mirror A busy. Connecting to Mirror B...\n"
    f"nB = {nb}\neB = {e}\n"
    "[070%] Generating Crowns...\n"
    "[090%] Encrypting your claim receipt with Mirror A...\n"
    "[100%] Crowns generated. Verification required.\n"
    "Receipt: /claim.json; key_id: mirror_A\n"
    "Textbook RSA, no padding. Message: unsigned big-endian ASCII integer.\n"
)
(public / "generation-log.txt").write_bytes(log.encode("ascii"))
emit(private / "verifier.json", {"expected_sha256": hashlib.sha256(f["code"].encode()).hexdigest(), "flag": f["flag"]})
print("Regenerated identical public evidence and private verifier from frozen values.")
