"""One-time authoring only. Refuses to replace an existing fixture."""
from pathlib import Path
import json
import math
import secrets
from Crypto.Util.number import getPrime

target = Path(__file__).with_name("fixtures.json")
if target.exists():
    raise SystemExit("Frozen fixture already exists; use regenerate.py instead.")
e = 65537
while True:
    p, qa, qb = (getPrime(1024) for _ in range(3))
    if (len({p, qa, qb}) == 3 and (p * qa).bit_length() == (p * qb).bit_length() == 2048
            and all(math.gcd(e, x - 1) == 1 for x in (p, qa, qb))):
        break
fixture = {
    "p": str(p), "qA": str(qa), "qB": str(qb), "e": e,
    "code": "CROWN-" + secrets.token_hex(16),
    "flag": "RCC{tw0_m1rr0rs_0ne_pr1me_z3r0_cr0wns_9e7a42c1}",
}
with target.open("x", encoding="utf-8") as out:
    out.write(json.dumps(fixture, indent=2) + "\n")
print("Created one frozen organizer fixture; retain it for all copies.")
