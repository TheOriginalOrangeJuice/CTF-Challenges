"""Regeneration/restart/second-copy checks and deployed application source parity."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import time
import urllib.request
from solve_public import solve, redeem

ROOT = Path(__file__).resolve().parents[1]
base = "http://host.docker.internal:18104"
review = "rowdy-crowns04-review"
copy = "rowdy-crowns04-copy-test"
evidence = ("keys.json", "generation-log.txt", "claim.json")

def downloaded(url):
    for attempt in range(40):
        try:
            return {name: urllib.request.urlopen(url + "/" + name, timeout=5).read() for name in evidence}
        except OSError:
            time.sleep(.25)
    raise RuntimeError("container did not become ready")

def run(*args):
    return subprocess.check_output(args, text=True).strip()

before = downloaded(base)
fixture_path = ROOT / "organizer/fixtures.json"
frozen = fixture_path.read_bytes()
verifier = (ROOT / "challenge/private/verifier.json").read_bytes()
run(sys.executable, str(ROOT / "organizer/regenerate.py"))
assert frozen == fixture_path.read_bytes()
assert verifier == (ROOT / "challenge/private/verifier.json").read_bytes()
assert all(before[name] == (ROOT / "challenge/public" / name).read_bytes() for name in evidence)
refusal = subprocess.run([sys.executable, str(ROOT / "organizer/freeze_once.py")], capture_output=True, text=True)
assert refusal.returncode != 0 and "already exists" in refusal.stderr
assert fixture_path.read_bytes() == frozen
code, _ = solve(base)
flag = redeem(base, code)["flag"]
run("docker", "restart", review)
assert downloaded(base) == before
assert redeem(base, code)["flag"] == flag
try:
    run("docker", "run", "-d", "--name", copy, "-p", "8080", "--read-only", "--cap-drop", "ALL", "--security-opt", "no-new-privileges:true", "rowdy-crowns04:review")
    port = run("docker", "port", copy, "8080/tcp").splitlines()[0].rsplit(":", 1)[1]
    copy_base = "http://host.docker.internal:" + port
    assert downloaded(copy_base) == before
    copy_code, _ = solve(copy_base)
    assert copy_code == code
    assert redeem(copy_base, copy_code)["flag"] == flag
finally:
    subprocess.run(["docker", "rm", "-f", copy], capture_output=True, check=True)

# Read hashes inside the running image; compare every deployed /app file to source.
snippet = "import pathlib,hashlib,json; r=pathlib.Path('/app'); print(json.dumps({str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in r.rglob('*') if p.is_file()},sort_keys=True))"
deployed = json.loads(run("docker", "exec", review, "python", "-c", snippet))
expected_names = {"server.py", "requirements.txt", "private/verifier.json"} | {"public/" + name for name in ("index.html", "style.css", "app.js", "wizard.svg", "icons.svg", "masthead.png", "crowns.png", "reference-art.png", *evidence)}
assert set(deployed) == expected_names, deployed
for name, digest in deployed.items():
    assert hashlib.sha256((ROOT / "challenge" / name).read_bytes()).hexdigest() == digest, name
print(json.dumps({"result": "PASS", "checks": ["frozen regeneration identical", "one-time generator refuses overwrite", "restart evidence/flag identical", "second isolated Docker copy evidence/flag identical", "temporary copy removed", "all deployed /app files equal source", "no organizer/legacy/factors/plaintext code in image app tree"], "fixture_sha256": hashlib.sha256(frozen).hexdigest(), "evidence_sha256": {name: hashlib.sha256(data).hexdigest() for name, data in before.items()}, "deployed_app_sha256": deployed, "retained_container": review, "image_id": run("docker", "inspect", "--format", "{{.Image}}", review)}, indent=2))
