"""Bounded negative/shortcut/public-leak checks for this local authored challenge."""
from pathlib import Path
import hashlib
import http.client
import json
import sys
import urllib.error
import urllib.parse
import urllib.request
from solve_public import solve, redeem

ROOT = Path(__file__).resolve().parents[1]
base = sys.argv[1] if len(sys.argv) > 1 else "http://host.docker.internal:18104"
checks = []

def request(path, expected, data=None, content_type="application/json", method=None):
    req = urllib.request.Request(base + path, data=data, headers={"Content-Type": content_type}, method=method)
    try:
        response = urllib.request.urlopen(req)
    except urllib.error.HTTPError as error:
        response = error
    body = response.read()
    assert response.status == expected, (path, response.status, expected, body)
    assert "default-src 'none'" in response.headers["Content-Security-Policy"]
    checks.append({"path": path, "status": response.status})
    return body

for path in ["/private/verifier.json", "/verifier.json", "/server.py", "/Dockerfile", "/.env", "/organizer/fixtures.json", "/organizer/legacy-grass-toucher/challenge/app.py", "/../private/verifier.json", "/%2e%2e/private/verifier.json", "/public/../private/verifier.json", "/%252e%252e/private/verifier.json", "/public", "/api/flag", "/api/state", "/api/card", "/api/achievements", "/api/claim?success=true", "/api/claim"]:
    request(path, 404)
for path in ["/api/card", "/api/verify", "/api/redeem", "/api/achievement", "/api/claim?success=true"]:
    request(path, 404, b'{"success":true}')
payloads = [b"{", b"null", b"[]", b"true", b"1", b'"CROWN"', b"{}", b'{"code":1}', b'{"code":null}', b'{"code":[]}', b'{"code":{}}', b'{"code":true}', b'{"code":""}', b'{"code":"CROWN-xyz"}', b'{"success":true,"progress":100}', b'{"code":"CROWN-00000000000000000000000000000000","success":true}', b'{"code":"CROWN-00000000000000000000000000000000","code":"CROWN-11111111111111111111111111111111"}', b'{"code":"CROWN-00000000000000000000000000000000"}\x00', b'\xff']
for payload in payloads:
    request("/api/claim", 400, payload)
request("/api/claim", 413, b"X" * 257)
request("/api/claim", 415, b"{}", "text/plain")
for code in ("CROWN-" + "0" * 32, "CROWN-" + "1" * 32):
    request("/api/claim", 403, json.dumps({"code": code}).encode())

# Exercise malformed HTTP framing without involving another service.
parsed = urllib.parse.urlsplit(base)
for lengths, transfer in [(["9" * 5000], False), (["-1"], False), (["1", "1"], False), ([], False), (["2"], True)]:
    connection = http.client.HTTPConnection(parsed.hostname, parsed.port, timeout=10)
    connection.putrequest("POST", "/api/claim")
    connection.putheader("Content-Type", "application/json")
    for length in lengths:
        connection.putheader("Content-Length", length)
    if transfer:
        connection.putheader("Transfer-Encoding", "chunked")
    connection.endheaders()
    result = connection.getresponse()
    assert result.status == 400
    result.read()
    connection.close()
    checks.append({"malformed_framing": True, "status": 400})

fixture = json.loads((ROOT / "organizer/fixtures.json").read_text())
p, qa = int(fixture["p"]), int(fixture["qA"])
secrets = [fixture[k] for k in ("p", "qA", "qB", "code", "flag")]
secrets.append(str(pow(fixture["e"], -1, (p - 1) * (qa - 1))))
hashes = {}
for filename in ["index.html", "style.css", "app.js", "wizard.svg", "icons.svg", "masthead.png", "crowns.png", "reference-art.png", "keys.json", "claim.json", "generation-log.txt"]:
    public = request("/" + filename, 200)
    assert public == (ROOT / "challenge/public" / filename).read_bytes()
    assert not any(secret.encode() in public for secret in secrets), filename
    hashes[filename] = hashlib.sha256(public).hexdigest()
code, math_checks = solve(base)
assert code == fixture["code"]
result = redeem(base, code)
assert result["flag"] == fixture["flag"]
print(json.dumps({"result": "PASS", "checks": len(checks), "public_hashes": hashes, "math": math_checks, "claim_result": result, "coverage": ["explicit public allowlist", "private paths/traversal", "legacy endpoints", "wrong/sample code", "malformed type/shape/size/framing", "forged completion", "public secret scan", "deployed bytes equal source", "public-only solve and redemption"]}, indent=2))
