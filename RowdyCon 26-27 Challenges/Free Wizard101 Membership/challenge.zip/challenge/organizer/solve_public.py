"""Reference solution. Reads only the two public downloads and the claim API."""
import argparse
import json
import math
import re
import urllib.request


def solve(base):
    with urllib.request.urlopen(base + "/generation-log.txt") as response:
        log = response.read().decode("ascii")
    with urllib.request.urlopen(base + "/claim.json") as response:
        receipt = json.load(response)
    n_a = int(re.search(r"^nA = (\d+)$", log, re.M)[1])
    n_b = int(re.search(r"^nB = (\d+)$", log, re.M)[1])
    e = int(re.search(r"^eA = (\d+)$", log, re.M)[1])
    assert int(re.search(r"^eB = (\d+)$", log, re.M)[1]) == e == 65537
    assert receipt["key_id"] == "mirror_A"
    c = int(receipt["ciphertext_decimal"])
    p = math.gcd(n_a, n_b)
    assert 1 < p < min(n_a, n_b), "No nontrivial shared prime"
    q_a = n_a // p
    phi = (p - 1) * (q_a - 1)
    d = pow(e, -1, phi)
    assert (e * d) % phi == 1
    m = pow(c, d, n_a)
    assert pow(m, e, n_a) == c
    code = m.to_bytes((m.bit_length() + 7) // 8, "big").decode("ascii")
    assert re.fullmatch(r"CROWN-[0-9a-f]{32}", code)
    return code, {"nA_bits": n_a.bit_length(), "nB_bits": n_b.bit_length(), "shared_prime_bits": p.bit_length(), "qA_bits": q_a.bit_length(), "code_bytes": len(code)}


def redeem(base, code):
    request = urllib.request.Request(base + "/api/claim", data=json.dumps({"code": code}).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request) as response:
        return json.load(response)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("base", nargs="?", default="http://host.docker.internal:18104")
    args = parser.parse_args()
    code, checks = solve(args.base.rstrip("/"))
    print(json.dumps({"checks": checks, "code": code, "redemption": redeem(args.base.rstrip("/"), code)}, indent=2))
