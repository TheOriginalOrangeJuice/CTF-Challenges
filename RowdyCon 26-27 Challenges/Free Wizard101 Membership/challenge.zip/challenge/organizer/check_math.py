"""Independent arithmetic cross-check with PyCryptodome and Euclid coefficients."""
from pathlib import Path
import hashlib
import json
import math
from Crypto.PublicKey import RSA
from Crypto.Util.number import isPrime, bytes_to_long, long_to_bytes, inverse

ROOT = Path(__file__).resolve().parents[1]
fixture = json.loads((ROOT / "organizer/fixtures.json").read_text())
keys = json.loads((ROOT / "challenge/public/keys.json").read_text())
receipt = json.loads((ROOT / "challenge/public/claim.json").read_text())
verifier = json.loads((ROOT / "challenge/private/verifier.json").read_text())
na, nb = (int(keys[k]["n"]) for k in ("mirror_A", "mirror_B"))
e = keys["mirror_A"]["e"]

def euclid(a, b):
    x, y, u, v = 1, 0, 0, 1
    while b:
        quotient = a // b
        a, b = b, a % b
        x, u = u, x - quotient * u
        y, v = v, y - quotient * v
    return a, x, y

p, x, y = euclid(na, nb)
assert x * na + y * nb == p == int(fixture["p"])
qa, qb = na // p, nb // p
assert (qa, qb) == (int(fixture["qA"]), int(fixture["qB"]))
assert len({p, qa, qb}) == 3
assert all(isPrime(value) and value.bit_length() == 1024 for value in (p, qa, qb))
assert math.gcd(qa, qb) == math.gcd(p, qa) == math.gcd(p, qb) == 1
assert na.bit_length() == nb.bit_length() == 2048
assert keys["mirror_B"]["e"] == e == 65537
c = int(receipt["ciphertext_decimal"])
for n, q in ((na, qa), (nb, qb)):
    phi = (p - 1) * (q - 1)
    assert math.gcd(e, phi) == 1
    d = inverse(e, phi)
    key = RSA.construct((n, e, d, p, q), consistency_check=True)
    assert key.size_in_bits() == 2048
    if n == na:
        m = key._decrypt(c)
        assert key._encrypt(m) == c
        assert long_to_bytes(m).decode("ascii") == fixture["code"]
        assert bytes_to_long(fixture["code"].encode()) == m
assert hashlib.sha256(fixture["code"].encode()).hexdigest() == verifier["expected_sha256"]
assert fixture["flag"] == verifier["flag"] == "RCC{tw0_m1rr0rs_0ne_pr1me_z3r0_cr0wns_9e7a42c1}"
print(json.dumps({"result": "PASS", "prime_bits": [1024, 1024, 1024], "modulus_bits": [2048, 2048], "distinct_primes": 3, "shared_factor": "exactly p", "independent": "Euclid coefficients + PyCryptodome RSA consistency/encrypt/decrypt", "verifier_hash": "matches"}, indent=2))
