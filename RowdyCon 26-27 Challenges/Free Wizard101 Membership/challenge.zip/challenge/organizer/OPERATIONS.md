# Organizer maintenance

Build/run/stop/reset commands and player distribution boundaries are in [Description.md](../Description.md). The stateless service runs as UID 65534 with Python's standard-library HTTP server. Keep event network isolation; the image contains the private reward. To deploy edits, build the image, remove only `rowdy-crowns04-review` with `docker rm -f rowdy-crowns04-review`, then repeat the documented run command.

Never replace `fixtures.json` or run `freeze_once.py` as a reset. Its three primes and claim code are frozen. Deterministic regeneration updates public evidence and the private hash/flag verifier:

```bash
python3 -m venv /tmp/crowns04-tools
/tmp/crowns04-tools/bin/pip install -r organizer/requirements.txt
/tmp/crowns04-tools/bin/python organizer/regenerate.py
```

On this development machine, execute project commands inside Condev. Existing tools are `/tmp/rowdy-ctf-tools/bin/python` and `/usr/bin/chromium-browser`. Stage the complete current folder with the Condev skill and require zero hash differences. The retained site is `http://localhost:18104` on Windows and `http://host.docker.internal:18104` inside Condev. From the staged challenge root:

```bash
/tmp/rowdy-ctf-tools/bin/python organizer/run_checks.py
/tmp/rowdy-ctf-tools/bin/python organizer/check_walkthrough.py
```

Checks regenerate deterministically, verify arithmetic, solve from public downloads, reject invalid/private requests, exercise desktop controls, and compare restart/isolated-copy evidence and deployed files. They write `organizer/results/` and fresh desktop screenshots. Do not run simultaneous checks: the temporary container name is `rowdy-crowns04-copy-test`. Default checks do no mobile work. `initial-browser-incidental-mobile.json` and the mobile captures are historical only.

The experimental deterrent is a clearly labeled invalid example in non-rendered `template#legacy-claim-example`, outside required evidence. Automated checks confirm it is hidden and rejected. No independent human playtest or autonomous-agent deterrence evaluation has been performed; no dependable deterrence is claimed.
