﻿"""Compare a complete copied challenge against a host-generated SHA-256 manifest."""
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1])
expected=json.loads(Path(sys.argv[2]).read_text(encoding='utf-8-sig'))
actual={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
assert actual==expected, {'missing':list(expected.keys()-actual.keys()),'extra':list(actual.keys()-expected.keys()),'changed':[name for name in actual.keys()&expected.keys() if actual[name]!=expected[name]]}
print(json.dumps({'result':'PASS','complete_tree_files':len(actual),'hash_differences':0,'root':str(root)}))
