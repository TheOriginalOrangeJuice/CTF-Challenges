﻿"""Real browser, actual synthesized PCM, fixed-feed and twelve-second acceptance."""
from pathlib import Path
import array,json,math,sys,time,wave
from urllib.parse import urlsplit
from playwright.sync_api import sync_playwright,expect
from solve_public import solve,redeem
ROOT=Path(__file__).resolve().parents[1]
shots=ROOT/'screenshots'
base=sys.argv[1] if len(sys.argv)>1 else 'http://host.docker.internal:18104'
code,_=solve(base);expected_flag=redeem(base,code)['flag']
requests,errors,console,checks,layouts=[],[],[],[],[]
def check(label): checks.append(label)
def observe(context): context.on('request',lambda r:requests.append({'url':r.url,'method':r.method,'body':r.post_data}))
def observe_page(page):
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('console',lambda m:console.append({'type':m.type,'text':m.text}) if m.type=='error' else None)
def wait_audio(page,expression,timeout=5):
    deadline=time.monotonic()+timeout
    while not page.evaluate(expression):
        assert time.monotonic()<deadline,expression
        page.wait_for_timeout(25)
def cue(page,action,kinds):
    before=page.evaluate('CrownAudio.snapshot().scheduled');action()
    wait_audio(page,f'CrownAudio.snapshot().scheduled>={before+len(kinds)}')
    state=page.evaluate('CrownAudio.snapshot()')
    assert state['scheduled']==before+len(kinds),(kinds,state)
    assert [item['kind'] for item in state['history'][-len(kinds):]]==kinds,(kinds,state)
def feed(page):
    return page.evaluate('({tick:document.querySelector("#activity-list").dataset.tick,count:document.querySelector("#online-count").textContent,rows:[...document.querySelectorAll("#activity-list li")].map(r=>[r.querySelector("strong").textContent,r.querySelector("b").textContent,r.querySelector(".avatar").className])})')
def closed(page):
    cue(page,lambda:page.locator('#close-verification').click(),['close'])
    expect(page.locator('#verification')).not_to_be_visible()
def open_gate(page):
    cue(page,lambda:page.locator('#open-verification').click(),['open'])
    expect(page.locator('#verification')).to_be_visible()
def wait_before_completion(page,start):
    delay=11.65-(time.monotonic()-start)
    if delay>0: page.wait_for_timeout(delay*1000)
    expect(page.locator('#verification')).not_to_be_visible()
    assert int(page.locator('.progress').get_attribute('aria-valuenow'))<100
    expect(page.locator('#reset')).not_to_be_visible();expect(page.locator('#reset')).to_be_disabled()
    expect(page.locator('#verification')).to_be_visible(timeout=2500)
    elapsed=round(time.monotonic()-start,3)
    assert 12<=elapsed<=15,elapsed
    return elapsed

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium-browser',headless=True,args=['--no-sandbox',f'--unsafely-treat-insecure-origin-as-secure={base}'])
    context=browser.new_context(viewport={'width':1440,'height':1080},permissions=['clipboard-read','clipboard-write']);observe(context)
    page=context.new_page();observe_page(page);page.goto(base);expect(page.locator('#generate')).to_be_enabled()
    assert page.locator('#skip,#replay').count()==0
    assert page.locator('.skip-link').inner_text()=='Skip to generator'
    assert page.evaluate('CrownAudio.snapshot().state')=='uninitialized'
    assert page.evaluate('CrownAudio.snapshot().scheduled')==0
    assert 'CROWN-00000000000000000000000000000000' not in page.locator('body').inner_text()
    # OfflineAudioContext renders the same actual graph used by live controls.
    pcm=[];audio_metrics=[]
    for kind in page.evaluate('CrownAudio.kinds'):
        samples=page.evaluate('async kind=>Array.from((await CrownAudio.render(kind)).getChannelData(0))',kind)
        peak=max(abs(x) for x in samples);rms=math.sqrt(sum(x*x for x in samples)/len(samples))
        end=max(i for i,x in enumerate(samples) if abs(x)>1e-5)+1
        assert .001<peak<.8 and rms>.0001 and .05<end/44100<1.3
        assert max(abs(x) for x in samples[-10000:])==0
        audio_metrics.append({'cue':kind,'peak':peak,'rms':rms,'audible_seconds':round(end/44100,4),'tail_silent':True})
        pcm.extend(samples[:min(len(samples),end+5292)])
    with wave.open(str(ROOT/'organizer/audio-preview.wav'),'wb') as wav:
        wav.setnchannels(1);wav.setsampwidth(2);wav.setframerate(44100)
        wav.writeframes(array.array('h',(round(x*32767) for x in pcm)).tobytes())
    maximum=page.evaluate('async()=>Math.max(...(await CrownAudio.render("success",4)).getChannelData(0).map(Math.abs))')
    assert 0<maximum<.9
    cue(page,lambda:page.get_by_role('link',name='Home',exact=True).click(),['click'])
    wait_audio(page,'CrownAudio.snapshot().state==="running"')
    page.locator('#sound-toggle').click();muted=page.evaluate('CrownAudio.snapshot()')
    assert not muted['enabled'] and muted['active']==0 and muted['outputGain']==0
    page.get_by_role('link',name='Generate Crowns',exact=True).click()
    assert page.evaluate('CrownAudio.snapshot().scheduled')==muted['scheduled']
    assert page.evaluate('async()=>Math.max(...(await CrownAudio.render("click")).getChannelData(0).map(Math.abs))')==0
    cue(page,lambda:page.locator('#sound-toggle').click(),['select'])
    page.evaluate('()=>{for(let i=0;i<40;i++)CrownAudio.play("click");}')
    state=page.evaluate('CrownAudio.snapshot()');assert state['active']<=4 and state['maxVoices']<=4
    wait_audio(page,'CrownAudio.snapshot().active===0')
    audio_report={'result':'PASS','method':'Actual shared synthesis graph rendered with OfflineAudioContext; actual AudioContext resumed by user click. No claim of independent human listening.','cues':audio_metrics,'four_voice_peak':maximum,'voice_limit':4,'muted_pcm_peak':0,'muted_click_scheduled_no_voice':True,'preview':'organizer/audio-preview.wav','preview_seconds':round(len(pcm)/44100,3),'preview_sample_rate':44100}
    (ROOT/'organizer/results/audio.json').write_text(json.dumps(audio_report,indent=2)+'\n')
    check('actual PCM for all ten cues: nonzero, unclipped, bounded duration/silent tails; user-gesture graph running; mute silent; four-voice cap; WAV exported')
    for width,height in [(1366,768),(1440,1080),(1920,1080)]:
        page.set_viewport_size({'width':width,'height':height});page.evaluate('scrollTo(0,0)')
        assert not page.evaluate('document.documentElement.scrollWidth>innerWidth')
        bounds=page.locator('#generate').bounding_box();assert bounds['y']+bounds['height']<=height
        artwork=page.locator('.package-art img').bounding_box();subtitle=page.locator('#setup .panel-subtitle').bounding_box();assert artwork['y']>=subtitle['y']+subtitle['height']
        columns=[page.locator(s).bounding_box() for s in ('.promo','.center-column','.social-column')]
        assert columns[0]['x']+columns[0]['width']<columns[1]['x']<columns[2]['x']
        assert page.locator('.main-nav a').count()==4
        page.screenshot(path=str(shots/f'layout-{width}x{height}.png'))
        layouts.append({'width':width,'height':height,'generate_bounds':bounds,'column_widths':[round(b['width'],2) for b in columns],'horizontal_overflow':False})
    page.set_viewport_size({'width':1440,'height':1080});page.screenshot(path=str(shots/'01-desktop-generator.png'),full_page=True)
    for label,anchor in [('Home','home'),('Generate Crowns','generator'),('Recent Activity','recent-activity'),('Testimonials','testimonials')]:
        cue(page,lambda label=label:page.get_by_role('link',name=label,exact=True).click(),['click']);assert page.url.endswith('#'+anchor)
    cue(page,lambda:page.locator('#testimonials details summary').press('Enter'),['open'])
    expect(page.locator('#testimonials details blockquote p')).to_have_text('Came for the mount, stayed for the math')
    cue(page,lambda:page.locator('#testimonials details summary').click(),['close'])
    check('three desktop layouts, four nav cues, keyboard summary cue, restored exact extra testimonial, no generation Skip/Replay')
    # Independent real page clocks exhibit the same authored sequence.
    feed_contexts=[browser.new_context(viewport={'width':1440,'height':1080},reduced_motion=motion) for motion in ('no-preference','reduce')]
    feed_pages=[];initial=[];heights=[]
    for fc in feed_contexts:
        observe(fc);tab=fc.new_page();observe_page(tab);tab.goto(base);feed_pages.append(tab);initial.append(feed(tab));heights.append(tab.locator('#recent-activity').bounding_box()['height'])
    assert initial[0]==initial[1]
    for tab in feed_pages:expect(tab.locator('#activity-list')).to_have_attribute('data-tick','1',timeout=6000)
    first=[feed(tab) for tab in feed_pages];assert first[0]==first[1] and first[0]['rows']!=initial[0]['rows'] and first[0]['count']!=initial[0]['count']
    for tab in feed_pages:expect(tab.locator('#activity-list')).to_have_attribute('data-tick','2',timeout=6000)
    second=[feed(tab) for tab in feed_pages];assert second[0]==second[1] and second[0]['rows']!=first[0]['rows']
    for index,tab in enumerate(feed_pages):
        assert tab.locator('#activity-list li').count()==5
        assert tab.locator('#recent-activity').bounding_box()['height']==heights[index]
        assert tab.evaluate('CrownAudio.snapshot().scheduled')==0
    # The first new row ages while later rows arrive.
    expect(feed_pages[0].locator('#activity-list li').filter(has_text='LunaStarfall').locator('small')).to_have_text('5 seconds ago',timeout=3000)
    for fc in feed_contexts:fc.close()
    check('two independent normal/reduced-motion page clocks: same initial/4s/8s names, varied amounts, counts and avatars; fixed panel height; ages update; silent feed')
    key_data=page.request.get(base+'/keys.json').json();log_data=page.request.get(base+'/generation-log.txt').body();receipt_data=page.request.get(base+'/claim.json').body()
    page.locator('#nickname').fill('Sparkle Stormpants');cue(page,lambda:page.locator('#realm').select_option('Ravenwood'),['select'])
    start=time.monotonic();cue(page,lambda:page.locator('#generate').click(),['generate'])
    expect(page.locator('#reset')).not_to_be_visible();expect(page.locator('#reset')).to_be_disabled()
    before_claims=len([r for r in requests if r['url'].endswith('/api/claim')])
    page.evaluate('()=>{document.querySelector("#open-verification").click();document.querySelector("#generate-form").dispatchEvent(new Event("submit",{bubbles:true,cancelable:true}));document.querySelector("#claim-form").dispatchEvent(new Event("submit",{bubbles:true,cancelable:true}));}')
    expect(page.locator('#verification')).not_to_be_visible();assert len([r for r in requests if r['url'].endswith('/api/claim')])==before_claims
    expect(page.locator('#delivery-status')).to_have_text('Negotiating secure Crown delivery — Mirror A…',timeout=5000);expect(page.locator('.key-detail')).to_have_count(1)
    expect(page.locator('#delivery-status')).to_have_text('Mirror A busy. Connecting to Mirror B…',timeout=5000);expect(page.locator('.key-detail')).to_have_count(2)
    page.evaluate('scrollTo(0,0)');page.screenshot(path=str(shots/'02a-generating-desktop.png'))
    normal_seconds=wait_before_completion(page,start)
    expect(page.locator('#verification-title')).to_be_focused();assert page.locator('.stage-row>b').all_text_contents()==['100%']*4
    page.screenshot(path=str(shots/'03-verification-gate.png'))
    cue(page,lambda:page.keyboard.press('Escape'),['close'])
    page.locator('#ready').scroll_into_view_if_needed();page.screenshot(path=str(shots/'03a-crowns-reserved.png'))
    open_gate(page);cue(page,lambda:page.locator('#back-to-log').click(),['close']);expect(page.locator('#technical-log>summary')).to_be_focused()
    expect(page.locator('#log-entries .log-entry')).to_have_count(6)
    for index,mirror in enumerate(('A','B')):
        cue(page,lambda index=index:page.locator('.key-detail summary').nth(index).click(),['open'])
        key=key_data[f'mirror_{mirror}'];assert f"n{mirror} = {key['n']}" in page.locator('.key-detail p').nth(index).inner_text()
        cue(page,lambda mirror=mirror:page.get_by_role('button',name=f'Copy full n{mirror}',exact=True).click(),['copy']);assert page.evaluate('navigator.clipboard.readText()')==key['n']
    expect(page.locator('#toast')).not_to_be_visible(timeout=5000);page.locator('#technical-log').screenshot(path=str(shots/'02-generation-log.png'))
    cue(page,lambda:page.locator('#copy-log').click(),['copy']);assert page.evaluate('navigator.clipboard.readText()')==log_data.decode()
    with page.expect_download() as download:cue(page,lambda:page.get_by_role('link',name='Download generation-log.txt',exact=True).click(),['copy'])
    assert Path(download.value.path()).read_bytes()==log_data
    cue(page,lambda:page.locator('#technical-log>summary').click(),['close']);expect(page.locator('#log-entries')).not_to_be_visible()
    cue(page,lambda:page.locator('#technical-log>summary').click(),['open'])
    open_gate(page)
    with page.expect_download() as download:cue(page,lambda:page.locator('#verification').get_by_role('link',name='Save claim.json',exact=True).click(),['copy'])
    assert Path(download.value.path()).read_bytes()==receipt_data
    cue(page,lambda:page.locator('.receipt-details summary').click(),['open'])
    assert page.locator('#receipt-preview').inner_text()==receipt_data.decode()
    page.evaluate('Object.defineProperty(window,"isSecureContext",{value:false});')
    cue(page,lambda:page.locator('#copy-receipt').click(),['copy']);assert page.evaluate('navigator.clipboard.readText()')==receipt_data.decode()
    expect(page.locator('#verification #toast')).to_be_visible();cue(page,lambda:page.locator('.receipt-details summary').click(),['close'])
    check('real normal12s wait including incomplete11.65s, reentry/premature verification guarded; every log/key/receipt/download/close control has one activation cue; real clipboard fallback')
    for invalid,expected in [('CROWN-invalid','Use CROWN-'),('CROWN-'+'0'*32,'did not verify')]:
        page.locator('#claim-code').fill(invalid);cue(page,lambda:page.locator('#claim-submit').click(),['verify','error']);expect(page.locator('#claim-error')).to_contain_text(expected)
    page.route('**/api/claim',lambda route:route.abort('failed'));page.locator('#claim-code').fill(code)
    cue(page,lambda:page.locator('#claim-submit').click(),['verify','error']);expect(page.locator('#claim-error')).to_contain_text('unavailable');page.unroute('**/api/claim')
    cue(page,lambda:page.locator('#claim-code').press('Enter'),['verify','success'])
    expect(page.locator('#reward')).to_be_visible();expect(page.locator('#flag')).to_have_text(expected_flag);expect(page.locator('#reward-title')).to_be_focused()
    page.locator('#reward').screenshot(path=str(shots/'04-successful-reward.png'));page.evaluate('scrollTo(0,0)');page.screenshot(path=str(shots/'04a-reward-desktop.png'))
    cue(page,lambda:page.locator('#copy-flag').click(),['copy']);assert page.evaluate('navigator.clipboard.readText()')==expected_flag
    cue(page,lambda:page.locator('#reset').click(),['reset']);assert feed(page)==initial[0]
    expect(page.locator('#nickname')).to_have_value('');expect(page.locator('#amount')).to_have_value('67000');expect(page.locator('#realm')).to_have_value('Unicorn');expect(page.locator('#nickname')).to_be_focused()
    check('mouse/Enter claim each one activation cue plus outcome cue; malformed/sample/network errors; successful redemption/flag copy; Start over resets inputs and exact initial feed')
    for amount in (10000,25000,50000,67000,99999):
        cue(page,lambda amount=amount:page.locator('#amount').select_option(str(amount)),['select'])
        assert page.request.get(base+'/generation-log.txt').body()==log_data and page.request.get(base+'/claim.json').body()==receipt_data
    page.emulate_media(reduced_motion='reduce');page.locator('#nickname').fill('<img src=x onerror="window.xss=1">')
    page.locator('#nickname').focus();before=page.evaluate('CrownAudio.snapshot().scheduled');page.keyboard.press('Tab');expect(page.locator('#realm')).to_be_focused();page.keyboard.press('Tab');expect(page.locator('#amount')).to_be_focused();page.keyboard.press('Tab');expect(page.locator('#generate')).to_be_focused();assert page.evaluate('CrownAudio.snapshot().scheduled')==before
    start=time.monotonic();cue(page,lambda:page.keyboard.press('Enter'),['generate'])
    assert '99,999 Crowns' in page.locator('#welcome').inner_text();assert page.locator('#welcome img').count()==0 and page.evaluate('window.xss===undefined')
    page.keyboard.down('Enter');page.keyboard.down('Enter');page.keyboard.up('Enter')
    expect(page.locator('#verification')).not_to_be_visible();reduced_seconds=wait_before_completion(page,start)
    for _ in range(12):page.keyboard.press('Tab');assert page.evaluate('document.activeElement.closest("#verification")!==null')
    closed(page);cue(page,lambda:page.locator('#copy-log').click(),['copy']);assert page.evaluate('navigator.clipboard.readText()')==log_data.decode()
    cue(page,lambda:page.locator('#reset').click(),['reset']);assert feed(page)==initial[0]
    page.wait_for_timeout(4100);assert feed(page)['tick']=='1' and feed(page)['rows']==first[0]['rows']
    check('all five cosmetic amounts preserve evidence; quiet Tab; keyboard generate once; held Enter does not restart; reduced motion and fresh run still12s; inert nickname; repeated reset has one correctly phased feed timer')
    failed=browser.new_context(viewport={'width':1366,'height':768});observe(failed);tab=failed.new_page();tab.route('**/keys.json',lambda route:route.fulfill(status=503,body='{}'));tab.goto(base);expect(tab.locator('#load-error')).to_be_visible();expect(tab.locator('#generate')).to_be_disabled();failed.close()
    assert not errors,errors
    assert all(urlsplit(r['url']).netloc==urlsplit(base).netloc for r in requests)
    assert all('Sparkle Stormpants' not in r['url']+(r['body'] or '') and 'onerror' not in r['url']+(r['body'] or '') for r in requests)
    unexpected=[entry for entry in console if not any(value in entry['text'] for value in ('400 (Bad Request)','403 (Forbidden)','net::ERR_FAILED'))];assert not unexpected,unexpected
    check('evidence-load error; same-origin only; nickname never transmitted; zero JS/unexpected console errors')
    browser.close()
print(json.dumps({'result':'PASS','browser':'Chromium / Playwright','normal_run_seconds':normal_seconds,'reduced_motion_run_seconds':reduced_seconds,'checks':checks,'layouts':layouts,'audio_report':'audio.json','feed_snapshots':{'initial':initial[0],'4_seconds':first[0],'8_seconds':second[0]},'request_count':len(requests),'page_errors':errors,'expected_negative_console':console,'screenshots':sorted(path.name for path in shots.glob('*.png') if 'mobile' not in path.name and 'preview' not in path.name),'scope':'Automated technical and PCM checks only; independent human playtesting/listening and deterrence evaluation remain pending.'},indent=2))
