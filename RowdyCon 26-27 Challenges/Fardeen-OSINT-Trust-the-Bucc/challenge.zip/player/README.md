# Trust-the-Bucc

My friend works at Buc-ee's now as their mascot. We were road-tripping and stopped at a gas station; which he then claims was the first Buc-ee's location he worked at.... but then why isn't is still a Buc-ee's? He couldn't answer so I'm having a hard time beleiving him. Here's a picture of the building, can you tell me the store number of this Buc-ee's location... if it even was one.  

![The storefront from our road-trip debate](storefront.jpg)

Submit `RCC{number}`.
