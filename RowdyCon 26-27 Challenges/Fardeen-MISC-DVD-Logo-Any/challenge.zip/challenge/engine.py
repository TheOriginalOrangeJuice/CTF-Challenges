"""Exact integer reflection and generalized CRT; server use only."""
from math import gcd, lcm


def reflected(start, velocity, tick, bound):
    phase = (start + velocity * tick) % (2 * bound)
    return min(phase, 2 * bound - phase)


def condition(start, velocity, bound):
    divisor = gcd(velocity, bound)
    if start % divisor:
        return None
    period = bound // divisor
    if period == 1:
        return 0, 1
    residue = (-start // divisor * pow(velocity // divisor, -1, period)) % period
    return residue, period


def first_corner(round_data):
    r = {key: int(value) for key, value in round_data.items() if key not in ('id', 'title')}
    width = r['screen_width'] - r['logo_width']
    height = r['screen_height'] - r['logo_height']
    assert width > 0 and height > 0 and r['vx'] and r['vy']
    assert 0 <= r['x0'] <= width and 0 <= r['y0'] <= height
    x = condition(r['x0'], r['vx'], width)
    y = condition(r['y0'], r['vy'], height)
    if x is None or y is None:
        return None
    a, m = x
    b, n = y
    divisor = gcd(m, n)
    if (b - a) % divisor:
        return None
    reduced_n = n // divisor
    k = 0 if reduced_n == 1 else ((b - a) // divisor * pow(m // divisor, -1, reduced_n)) % reduced_n
    period = lcm(m, n)
    return (a + m * k) % period or period
