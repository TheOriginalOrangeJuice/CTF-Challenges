"""Self-contained challenge service. Only explicit public assets are served."""
import json
import os
import re
import secrets
import threading
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

from engine import first_corner

ROOT = Path(__file__).resolve().parent
ROUNDS = json.loads((ROOT / 'private/rounds.json').read_text())
ANSWERS = [first_corner(r) for r in ROUNDS]
FLAG = (ROOT / 'private/flag.txt').read_text().strip()
EXPORT = {'format': 'dvd-any-percent-v1', 'units': 'integer pixels per integer tick',
          'origin': 'top left; positive x right, positive y down',
          'objective': 'smallest strictly positive integer tick, or never', 'rounds': ROUNDS}
PUBLIC = {'/': ('index.html', 'text/html; charset=utf-8'),
          '/app.js': ('app.js', 'text/javascript; charset=utf-8'),
          '/motion.js': ('motion.js', 'text/javascript; charset=utf-8'),
          '/style.css': ('style.css', 'text/css; charset=utf-8'),
          '/scene.svg': ('scene.svg', 'image/svg+xml'),
          '/favicon.svg': ('favicon.svg', 'image/svg+xml')}
SESSIONS = {}
LOCK = threading.RLock()


class Handler(BaseHTTPRequestHandler):
    server_version = 'CornerCast/1.0'

    def reply(self, status, body, content_type='application/json; charset=utf-8', cookie=None):
        data = body if isinstance(body, bytes) else json.dumps(body, separators=(',', ':')).encode()
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'same-origin')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'")
        if cookie:
            self.send_header('Set-Cookie', f'dvd_session={cookie}; Path=/; HttpOnly; SameSite=Lax')
        self.end_headers()
        self.wfile.write(data)

    def session(self, create=False):
        try:
            cookies = SimpleCookie(self.headers.get('Cookie', ''))
            token = cookies.get('dvd_session')
            token = token.value if token else ''
        except Exception:
            token = ''
        if token in SESSIONS:
            return SESSIONS[token], None
        if create:
            token = secrets.token_urlsafe(32)
            SESSIONS[token] = {'progress': 0, 'receipts': []}
            return SESSIONS[token], token
        return None, None

    @staticmethod
    def state(session):
        progress = session['progress']
        result = {'progress': progress, 'total': len(ROUNDS), 'complete': progress == len(ROUNDS),
                  'round': ROUNDS[progress] if progress < len(ROUNDS) else None,
                  'receipts': session['receipts']}
        if result['complete']:
            result['flag'] = FLAG
        return result

    def do_GET(self):
        path = urlsplit(self.path).path
        if path in PUBLIC:
            name, mime = PUBLIC[path]
            return self.reply(200, (ROOT / 'public' / name).read_bytes(), mime)
        if path == '/api/rounds':
            return self.reply(200, EXPORT)
        if path == '/api/state':
            with LOCK:
                session, cookie = self.session(create=True)
                return self.reply(200, self.state(session), cookie=cookie)
        if path == '/healthz':
            return self.reply(200, {'ok': True})
        return self.reply(404, {'error': 'Not found.'})

    def do_POST(self):
        # Cross-site forms cannot change progress. Normal scripts need no Origin header.
        origin = self.headers.get('Origin')
        if origin and urlsplit(origin).netloc != self.headers.get('Host'):
            return self.reply(403, {'error': 'Use this stream origin.'})
        if self.headers.get_content_type() != 'application/json':
            return self.reply(415, {'error': 'Send application/json.'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 1 <= length <= 4096:
                return self.reply(400, {'error': 'Request must be 1–4096 bytes.'})
            body = json.loads(self.rfile.read(length))
            if not isinstance(body, dict):
                raise ValueError('object required')
        except (ValueError, UnicodeDecodeError):
            return self.reply(400, {'error': 'Invalid JSON object.'})
        with LOCK:
            session, _ = self.session()
            if session is None:
                return self.reply(401, {'error': 'Open /api/state to start a run.'})
            path = urlsplit(self.path).path
            if path == '/api/reset':
                if body:
                    return self.reply(400, {'error': 'Reset accepts an empty object.'})
                session.update(progress=0, receipts=[])
                return self.reply(200, self.state(session))
            if path != '/api/answer':
                return self.reply(404, {'error': 'Not found.'})
            progress = session['progress']
            if progress >= len(ROUNDS):
                return self.reply(409, {'error': 'Run complete. Reset to play again.'})
            if set(body) != {'round_id', 'answer'}:
                return self.reply(400, {'error': 'Send only round_id and answer.'})
            if body['round_id'] != ROUNDS[progress]['id']:
                return self.reply(409, {'error': 'That is not your current round. Refresh the stream.'})
            answer = body['answer']
            if not isinstance(answer, str) or len(answer) > 256:
                return self.reply(400, {'error': 'Use a decimal string, or never.'})
            answer = answer.strip().lower()
            if answer == 'never':
                guess = None
            elif re.fullmatch(r'[0-9]{1,200}', answer):
                guess = int(answer)
                if guess <= 0:
                    return self.reply(400, {'error': 'Tick must be strictly positive; tick 0 does not count.'})
            else:
                return self.reply(400, {'error': 'Use a positive integer in decimal, or never.'})
            if guess != ANSWERS[progress]:
                return self.reply(422, {'error': 'No corner confirmed. Check both axes and the first positive tick.'})
            receipt = {'round_id': ROUNDS[progress]['id'], 'answer': 'never' if guess is None else str(guess)}
            session['receipts'].append(receipt)
            session['progress'] += 1
            return self.reply(200, {'receipt': receipt, 'state': self.state(session)})


if __name__ == '__main__':
    port = int(os.environ.get('PORT', '18110'))
    print(f'CornerCast listening on 0.0.0.0:{port}', flush=True)
    ThreadingHTTPServer(('0.0.0.0', port), Handler).serve_forever()
