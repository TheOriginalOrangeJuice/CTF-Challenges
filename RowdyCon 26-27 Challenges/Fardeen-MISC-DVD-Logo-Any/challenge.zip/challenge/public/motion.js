// Display geometry, not a predictor. All decisions precede conversion to CSS pixels.
export function mod(a, b) { return ((a % b) + b) % b; }
export function reflected(start, velocity, tick, bound) {
  const phase = mod(start + velocity * tick, 2n * bound);
  return phase <= bound ? phase : 2n * bound - phase;
}
export function position(round, tick) {
  const W = BigInt(round.screen_width) - BigInt(round.logo_width);
  const H = BigInt(round.screen_height) - BigInt(round.logo_height);
  const x = reflected(BigInt(round.x0), BigInt(round.vx), tick, W);
  const y = reflected(BigInt(round.y0), BigInt(round.vy), tick, H);
  return {x, y, W, H, corner: (x === 0n || x === W) && (y === 0n || y === H)};
}
export function ratio(numerator, denominator) {
  return Number(numerator * 1000000000n / denominator) / 1000000000;
}
