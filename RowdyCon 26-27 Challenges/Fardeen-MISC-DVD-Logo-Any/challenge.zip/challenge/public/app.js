import {mod, reflected, ratio, position} from './motion.js';
const $ = id => document.getElementById(id);
const reduced = matchMedia('(prefers-reduced-motion: reduce)');
const colors = ['#c1adff','#a7e6c8','#ffd399','#f39fce','#a4d7ef'];
let rounds=[],state,round,tick=0n,subTick=0n,pendingNext=false,geometry;
let playing=false,sound=false,audio,master,anchorTime=performance.now(),anchorMillis=0n,lastPhases,lastTone=-Infinity;
const activeNotes=new Set();
function message(text,kind=''){$('feedback').textContent=text;$('feedback').className='feedback '+kind;}
async function api(path,data){
 const response=await fetch(path,data===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
 const body=await response.json();if(!response.ok)throw new Error(body.error||'That request could not be completed. Try again.');return body;
}
function reanchor(){anchorTime=performance.now();anchorMillis=tick*1000n+subTick;}
function setPlaying(value){
 playing=Boolean(value&&!pendingNext&&!state?.complete);reanchor();
 $('play').textContent=playing?'Ⅱ':'▶';$('play').setAttribute('aria-label',playing?'Pause preview':'Play preview');
 $('playback-label').textContent=pendingNext?'PREDICTION ACCEPTED':playing?'PLAYING':'PAUSED';
 if(!playing)stopTones();
}
function moveTo(value){tick=value;subTick=0n;lastPhases=undefined;reanchor();render();}
function gainValue(){return sound?Number($('volume').value)/100:0;}
function updateGain(){if(master)master.gain.setTargetAtTime(gainValue(),audio.currentTime,.015);}
function stopTones(){
 if(!audio)return;
 for(const note of activeNotes){note.envelope.gain.cancelScheduledValues(audio.currentTime);note.envelope.gain.setTargetAtTime(.00001,audio.currentTime,.005);try{note.oscillator.stop(audio.currentTime+.02);}catch(_){}}
}
function tone(kind='button'){
 if(!sound||!audio||audio.state!=='running'||Number($('volume').value)===0)return;
 stopTones();
 const notes=kind==='success'?[523.25,659.25,783.99]:kind==='start'?[392,523.25]:kind==='bounce'?[330]:[440];
 const duration=kind==='success'||kind==='start'?.28:.065;
 notes.forEach((frequency,index)=>{
  const oscillator=audio.createOscillator(),envelope=audio.createGain(),start=audio.currentTime+index*.095;
  oscillator.type='sine';oscillator.frequency.value=frequency;
  envelope.gain.setValueAtTime(.00001,start);envelope.gain.exponentialRampToValueAtTime(kind==='bounce'?.035:.10,start+.009);envelope.gain.exponentialRampToValueAtTime(.00001,start+duration);
  oscillator.connect(envelope);envelope.connect(master);oscillator.start(start);oscillator.stop(start+duration+.02);
  const note={oscillator,envelope};activeNotes.add(note);
  oscillator.onended=()=>{oscillator.disconnect();envelope.disconnect();activeNotes.delete(note);};
 });
}
function resize(){
 if(!round)return;
 const stage=$('stage'),sw=BigInt(round.screen_width),sh=BigInt(round.screen_height),aspect=ratio(sw,sh);
 const height=Math.max(0,Math.min(stage.clientHeight-8,(stage.clientWidth-8)/aspect)),width=height*aspect;
 geometry={width,height,sw,sh};
 Object.assign($('playfield').style,{width:width+'px',height:height+'px',left:(stage.clientWidth-width)/2+'px',top:(stage.clientHeight-height)/2+'px'});
 $('dvd').style.width=ratio(BigInt(round.logo_width),sw)*width+'px';$('dvd').style.height=ratio(BigInt(round.logo_height),sh)*height+'px';
 const abs=n=>n<0n?-n:n,v=abs(BigInt(round.vx))+abs(BigInt(round.vy));
 $('scale-note').textContent=ratio(v,sw)*width<.01?'MOTION BELOW ONE PIXEL / TICK · 1 TICK / SECOND':'1 TICK / SECOND · ORIGINAL PROPORTIONS';
 render();
}
function flashEdge(axis,phase,coordinate,color){
 if(reduced.matches)return;
 const edge=$('edge-'+axis),positive=mod(phase,2n)===1n;
 edge.style.setProperty('--edge-color',color);
 if(axis==='x'){edge.style.left=positive?'calc(100% - 1px)':'0';edge.style.top=Math.max(0,Math.min(geometry.height-80,coordinate-40))+'px';}
 else{edge.style.top=positive?'calc(100% - 1px)':'0';edge.style.left=Math.max(0,Math.min(geometry.width-80,coordinate-40))+'px';}
 edge.classList.remove('hit');void edge.offsetWidth;edge.classList.add('hit');
}
function render(){
 if(!round||!geometry)return;
 // Interpolate only the actual reflected path. Conversion to CSS happens last.
 const millis=tick*1000n+subTick,W=(geometry.sw-BigInt(round.logo_width))*1000n,H=(geometry.sh-BigInt(round.logo_height))*1000n;
 const sx=BigInt(round.x0)*1000n,sy=BigInt(round.y0)*1000n,vx=BigInt(round.vx),vy=BigInt(round.vy);
 const x=reflected(sx,vx,millis,W),y=reflected(sy,vy,millis,H);
 const px=ratio(x,geometry.sw*1000n)*geometry.width,py=ratio(y,geometry.sh*1000n)*geometry.height;
 $('dvd').style.transform='translate('+px+'px,'+py+'px)';
 const floorDiv=(a,b)=>(a-mod(a,b))/b,phaseX=floorDiv(sx+vx*millis,W),phaseY=floorDiv(sy+vy*millis,H);
 const color=colors[Number(mod(phaseX+phaseY,BigInt(colors.length)))];$('dvd').style.color=color;
 if(playing&&lastPhases&&(phaseX!==lastPhases.x||phaseY!==lastPhases.y)){
  if(phaseX!==lastPhases.x)flashEdge('x',vx>0n?phaseX:phaseX+1n,py+ratio(BigInt(round.logo_height),geometry.sh)*geometry.height/2,color);
  if(phaseY!==lastPhases.y)flashEdge('y',vy>0n?phaseY:phaseY+1n,px+ratio(BigInt(round.logo_width),geometry.sw)*geometry.width/2,color);
  if(performance.now()-lastTone>800){tone('bounce');lastTone=performance.now();}
 }
 lastPhases={x:phaseX,y:phaseY};
 const tickText=tick.toString();
 if($('tick').textContent!==tickText||!$('motion-note').dataset.ready){
  $('tick').textContent=tickText;$('tick').title=tickText;
  const p=position(round,tick);
  $('motion-note').textContent='At this tick: x '+p.x+' · y '+p.y;
  $('motion-note').dataset.ready='true';
 }
}
function progress(){
 $('solved-count').textContent=state.progress+' / '+state.total;$('round-list').replaceChildren();
 rounds.forEach((r,i)=>{const li=document.createElement('li');li.className=i<state.progress?'done':i===state.progress?'current':'';li.textContent=r.id;li.title=r.title;li.setAttribute('aria-label','Round '+r.id+', '+r.title+': '+(i<state.progress?'cleared':i===state.progress?'current':'up next'));$('round-list').append(li);});
 $('history-count').textContent=state.receipts.length;$('history-empty').hidden=state.receipts.length>0;$('copy-history').disabled=!state.receipts.length;$('history-list').replaceChildren();
 state.receipts.forEach(receipt=>{const li=document.createElement('li'),title=document.createElement('span'),answer=document.createElement('code');title.textContent=receipt.round_id+' · '+rounds.find(r=>r.id===receipt.round_id).title;answer.textContent=receipt.answer;li.append(title,answer);$('history-list').append(li);});
 $('reward').hidden=!state.complete;$('flag').textContent=state.flag||'';
}
function showRound(value){
 round=value;pendingNext=false;tick=0n;subTick=0n;lastPhases=undefined;
 $('round-title').textContent=round.title;$('round-count').textContent='ROUND '+round.id+' / 08';
 for(const [id,key] of Object.entries({'screen-width':'screen_width','screen-height':'screen_height','logo-width':'logo_width','logo-height':'logo_height','start-x':'x0','start-y':'y0','velocity-x':'vx','velocity-y':'vy'}))$(id).textContent=round[key];
 $('answer').value='';$('answer').disabled=false;$('answer').removeAttribute('aria-invalid');$('submit').disabled=false;$('play').disabled=false;$('rewind').disabled=false;
 $('accepted').hidden=true;$('stage').classList.remove('confirmed');document.querySelector('.prediction').classList.remove('accepting','finished');
 $('tick-label').textContent='PREVIEW TICK';delete $('motion-note').dataset.ready;
 message('Eight correct calls unlock the flag.');setPlaying(!reduced.matches);resize();progress();
}
function accept(receipt,restored=false){
 pendingNext=true;setPlaying(false);
 if(receipt.answer!=='never')moveTo(BigInt(receipt.answer));
 $('stage').classList.toggle('confirmed',receipt.answer!=='never');
 $('tick-label').textContent=receipt.answer==='never'?'PREVIEW TICK':'ACCEPTED TICK';
 $('playback-label').textContent=receipt.answer==='never'?'NO INTEGER-TICK CORNER':'CORNER CONFIRMED';
 $('accepted').hidden=state.complete;
 $('accepted-title').textContent=receipt.answer==='never'?'No integer-tick corner.':'Corner confirmed.';
 $('accepted-detail').textContent=receipt.answer==='never'?'No positive integer tick reaches both edges together.':'Tick '+receipt.answer+' · '+(position(round,BigInt(receipt.answer)).x===0n?'left':'right')+' / '+(position(round,BigInt(receipt.answer)).y===0n?'top':'bottom');
 document.querySelector('.prediction').classList.add('accepting');document.querySelector('.prediction').classList.toggle('finished',state.complete);
 $('answer').disabled=true;$('submit').disabled=true;$('play').disabled=true;$('rewind').disabled=true;
 message('Round '+receipt.round_id+' cleared.','success');progress();
 if(!restored)tone('success');
 (state.complete?$('copy-flag'):$('next')).focus({preventScroll:true});
}
async function copy(text){
 try{if(navigator.clipboard){await navigator.clipboard.writeText(text);return true;}}catch(_){}
 const previous=document.activeElement,area=document.createElement('textarea');area.value=text;area.className='sr-only';(document.querySelector('dialog[open]')||document.body).append(area);area.select();const ok=document.execCommand('copy');area.remove();previous?.focus({preventScroll:true});return ok;
}
$('play').addEventListener('click',()=>{setPlaying(!playing);if(playing)tone();});
$('rewind').addEventListener('click',()=>{setPlaying(false);moveTo(0n);tone();});
$('sound').addEventListener('click',async()=>{
 try{
  if(!audio){audio=new(window.AudioContext||window.webkitAudioContext)();master=audio.createGain();master.gain.value=0;master.connect(audio.destination);}
  await audio.resume();sound=!sound;updateGain();$('sound-label').textContent=sound?'Sound on':'Muted';$('sound').setAttribute('aria-label',sound?'Mute sound':'Enable sound');$('sound').setAttribute('aria-pressed',String(sound));if(sound)tone('start');else stopTones();
 }catch(_){message('Audio is unavailable in this browser. Predictions still work.','error');}
});
$('volume').addEventListener('input',()=>{$('volume-value').textContent=$('volume').value+'%';updateGain();});
$('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await $('experience').requestFullscreen();}catch(_){message('Fullscreen is unavailable in this browser.','error');}});
new ResizeObserver(resize).observe($('stage'));
document.addEventListener('fullscreenchange',()=>{$('fullscreen').setAttribute('aria-label',document.fullscreenElement?'Exit fullscreen':'Enter fullscreen');resize();});
$('answer-form').addEventListener('submit',async event=>{
 event.preventDefault();if(!round||pendingNext||state.complete)return;$('submit').disabled=true;$('answer').removeAttribute('aria-invalid');
 try{const response=await api('/api/answer',{round_id:round.id,answer:$('answer').value});state=response.state;accept(response.receipt);}
 catch(error){message(error.message,'error');$('submit').disabled=false;$('answer').setAttribute('aria-invalid','true');$('answer').focus({preventScroll:true});}
});
$('answer').addEventListener('input',()=>$('answer').removeAttribute('aria-invalid'));
$('next').addEventListener('click',()=>{if(state.complete)return;showRound(state.round);$('answer').focus({preventScroll:true});});
$('copy-round').addEventListener('click',async()=>message(await copy(JSON.stringify(round,null,2))?'Exact round data copied.':'Clipboard unavailable. Export all rounds to save the data.'));
$('copy-history').addEventListener('click',async()=>{$('history-feedback').textContent=await copy(JSON.stringify(state.receipts,null,2))?'Accepted predictions copied.':'Clipboard unavailable. Select the displayed predictions.';});
$('copy-flag').addEventListener('click',async()=>{$('copy-flag').textContent=await copy(state.flag)?'Flag copied':'Select the flag to copy';});
for(const name of ['help','history','reset'])$(name+'-open').addEventListener('click',()=>{setPlaying(false);$(name+'-dialog').showModal();});
$('reset-cancel').addEventListener('click',()=>$('reset-dialog').close());
$('reset-confirm').addEventListener('click',async()=>{
 $('reset-confirm').disabled=true;
 try{state=await api('/api/reset',{});$('reset-dialog').close();$('copy-flag').textContent='Copy flag';showRound(state.round);$('answer').focus({preventScroll:true});}
 catch(error){$('reset-dialog').close();message(error.message,'error');}finally{$('reset-confirm').disabled=false;}
});
reduced.addEventListener('change',event=>{if(event.matches)setPlaying(false);});
document.addEventListener('visibilitychange',()=>{if(document.hidden){setPlaying(false);stopTones();}});
document.addEventListener('keydown',event=>{
 if(event.ctrlKey||event.metaKey||event.altKey||event.target.closest('input,select,textarea,button,a,summary')||document.querySelector('dialog[open]'))return;
 if(event.code==='Space'){event.preventDefault();$('play').click();}else if(event.key.toLowerCase()==='m')$('sound').click();
});
function animate(now){if(playing&&round){const millis=anchorMillis+BigInt(Math.max(0,Math.floor(now-anchorTime)));tick=millis/1000n;subTick=millis%1000n;render();}requestAnimationFrame(animate);}
try{const[exported,initial]=await Promise.all([api('/api/rounds'),api('/api/state')]);rounds=exported.rounds;state=initial;showRound(state.round||rounds.at(-1));if(state.complete)accept(state.receipts.at(-1),true);}
catch(error){message(error.message+' Reload to try again.','error');$('submit').disabled=true;}
requestAnimationFrame(animate);
