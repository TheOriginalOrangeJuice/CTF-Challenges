#!/usr/bin/env python3
"""Compare deployed source hashes, then verify an actual owned-container restart."""
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen

from solve import Client, predict

ROOT = Path(__file__).resolve().parents[1]
base = (sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:18110').rstrip('/')
container = 'rowdy-dvd10-review'
source = ROOT / 'challenge'
files = [source / 'server.py', source / 'engine.py'] + list((source / 'public').glob('*')) + list((source / 'private').glob('*'))
expected = {p.relative_to(source).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
program = "import pathlib,hashlib,json; root=pathlib.Path('/app'); print(json.dumps({p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}))"
actual = json.loads(subprocess.check_output(['docker', 'exec', container, 'python', '-c', program], text=True))
assert expected == actual, 'Deployed application differs from the staged source'
before = urlopen(base + '/api/rounds').read()
client = Client(base)
initial = client.request('/api/state')
assert initial['progress'] == 0
r = initial['round']
assert client.request('/api/answer', {'round_id': r['id'], 'answer': predict(r)})['state']['progress'] == 1
subprocess.run(['docker', 'restart', container], check=True, stdout=subprocess.DEVNULL)
for attempt in range(50):
    try:
        if json.load(urlopen(base + '/healthz', timeout=2)) == {'ok': True}:
            break
    except (URLError, OSError):
        time.sleep(.2)
else:
    raise AssertionError('Service failed to restart')
assert before == urlopen(base + '/api/rounds').read()
assert initial == client.request('/api/state'), 'Restart did not restore identical session content'
report = {'container': container, 'source_files_compared': len(actual), 'hash_differences': 0,
          'raw_export_sha256': hashlib.sha256(before).hexdigest(),
          'restart_resets_progress': True, 'restart_preserves_export_bytes': True,
          'container_contains_only_application_files': True, 'healthz': True}
(ROOT / 'organizer/runtime-result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
