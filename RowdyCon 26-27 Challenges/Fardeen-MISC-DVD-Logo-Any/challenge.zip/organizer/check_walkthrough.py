#!/usr/bin/env python3
"""Execute the canonical walkthrough shell blocks in a temporary working directory."""
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
text = (ROOT / 'Description.md').read_text().split('## Walkthrough\n', 1)[1].split('## Flag\n', 1)[0]
base = (sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:18110').rstrip('/')
blocks = re.findall(r'```sh\n(.*?)```', text, re.S)
with tempfile.TemporaryDirectory(prefix='dvd10-walkthrough-') as tmp:
    Path(tmp, 'organizer').symlink_to(ROOT / 'organizer', target_is_directory=True)
    commands = '\n'.join(blocks).replace('BASE=http://localhost:18110', 'BASE=' + base)
    result = subprocess.run(['/bin/bash', '-e', '-c', commands], cwd=tmp, text=True, capture_output=True)
    assert result.returncode == 0, result.stderr
    first = json.loads(Path(tmp, 'dvd-rounds.json').read_text())['rounds'][0]
    assert [first[key] for key in ['screen_width', 'screen_height', 'logo_width', 'logo_height', 'x0', 'y0', 'vx', 'vy']] == ['14', '9', '2', '1', '3', '3', '1', '1']
    for expected in ['W=12, H=8; x=(9, 12), y=(5, 8)',
                     'prediction: 21', 'prediction: 22', 'prediction: never',
                     'prediction: 128', 'prediction: 537117701399620543',
                     'prediction: 4000000025',
                     'prediction: 7000000000000000003430000000000000000273',
                     'cleared: 8', 'FLAG: RCC{c0rn3r_h1t_n0_w41t_crt_any_percent}']:
        assert expected in result.stdout, expected
    print(result.stdout)
assert len(blocks) == 2
print(f'PASS: {len(blocks)} literal walkthrough shell blocks; all eight predictions and exact flag.')
