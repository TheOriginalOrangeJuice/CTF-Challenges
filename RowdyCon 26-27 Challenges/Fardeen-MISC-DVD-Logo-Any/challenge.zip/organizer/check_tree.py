#!/usr/bin/env python3
"""Compare this entire staged challenge with an external Windows SHA manifest."""
import hashlib
import json
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
expected = json.loads(Path(sys.argv[1]).read_text(encoding='utf-8-sig'))
actual = {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
          for p in root.rglob('*') if p.is_file()}
differences = [name for name in sorted(expected.keys() | actual.keys())
               if expected.get(name) != actual.get(name)]
assert not differences, differences
print(json.dumps({'files': len(actual), 'hash_differences': 0, 'root': str(root)}))
