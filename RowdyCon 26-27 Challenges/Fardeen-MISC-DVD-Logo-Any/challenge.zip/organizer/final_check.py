#!/usr/bin/env python3
"""Read-only check of the completed package and retained review container."""
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path
from urllib.request import urlopen

root = Path(__file__).resolve().parents[1]
base = (sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:18110').rstrip('/')
links = 0
for doc in root.rglob('*.md'):
    for target in re.findall(r'\]\(([^)]+)\)', doc.read_text()):
        if '://' not in target and not target.startswith('#'):
            assert (doc.parent / target.split('#')[0]).exists(), (doc, target)
            links += 1
source = root / 'challenge'
files = [source / 'server.py', source / 'engine.py'] + list((source / 'public').glob('*')) + list((source / 'private').glob('*'))
expected = {p.relative_to(source).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}
program = "import pathlib,hashlib,json; r=pathlib.Path('/app'); print(json.dumps({p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in r.rglob('*') if p.is_file()}))"
actual = json.loads(subprocess.check_output(['docker', 'exec', 'rowdy-dvd10-review', 'python', '-c', program], text=True))
assert expected == actual
protected = {
    'server.py': '65e75617a37c56042bd7fa2640f781217ddf5205ca4dfb12628bafa5f325135c',
    'engine.py': 'e9fa50b9eceea588ca5647e35f7ffc580f2ea9da2b49de4ef504a35ba7003bd0',
    'private/rounds.json': '3407ac0db177e426b4d26f94dc54e4485007ada4f18f5522c25e47e26df0e7f5',
    'private/flag.txt': 'a38dda0074ae03ab00751a10586d42f7256185438adca00819db112be75d3dfa',
    'public/motion.js': 'a40b9ced1678c768802f60e2c3eaa97b8ee09f938a80286805622b8210dd39f9',
}
assert all(expected[path] == digest for path, digest in protected.items())
assert hashlib.sha256((root / 'organizer/solve.py').read_bytes()).hexdigest() == 'b293c6ab67e93baf3f8c35a01fff1c397e0d0e870ac0a0e8ef9aab7a4b4242ec'
assert json.load(urlopen(base + '/healthz')) == {'ok': True}
assert json.loads((root / 'organizer/browser-result.json').read_text())['unexpected_console_errors'] == []
assert json.loads((root / 'organizer/verification-result.json').read_text())['negative_cases'] == 32
assert json.loads((root / 'organizer/runtime-result.json').read_text())['restart_preserves_export_bytes']
doc_text = (root / 'Description.md').read_text()
assert re.findall(r'^## (.+)$', doc_text, re.M) == ['Description', 'Files', 'Hint(s)', 'Walkthrough', 'Flag']
assert (root / 'Description.docx').is_file()
assert all(not (root / name).exists() for name in ['README.md', 'DEPLOYMENT.md', 'QA.md', 'SOLTION.md'])
rounds_hash = hashlib.sha256((source / 'private/rounds.json').read_bytes()).hexdigest()
assert rounds_hash == '3407ac0db177e426b4d26f94dc54e4485007ada4f18f5522c25e47e26df0e7f5'
flag = (source / 'private/flag.txt').read_text().strip()
assert flag == 'RCC{c0rn3r_h1t_n0_w41t_crt_any_percent}'
assert flag in doc_text
review = json.loads((root / 'organizer/document-review/document-check.json').read_text())
assert review['flag'] == flag
assert len(list((root / 'organizer/document-review').glob('page-*.png'))) == review['pages']
assert all((root / image).is_file() for image in review['images'])
assert json.loads((root / 'organizer/browser-result.json').read_text())['flag'] == flag
assert json.loads((root / 'organizer/verification-result.json').read_text())['returned_flag'] == flag
browser_report = json.loads((root / 'organizer/browser-result.json').read_text())
public_text = '\n'.join(p.read_text() for p in (source / 'public').iterdir() if p.is_file())
assert flag not in public_text
assert all(answer not in public_text for answer in browser_report['predictions'] if len(answer) >= 10)
fresh_state = json.load(urlopen(base + '/api/state'))
assert 'flag' not in fresh_state and fresh_state['receipts'] == [] and fresh_state['progress'] == 0
report = {'revision': '2026-10-27 focused optical redesign',
                  'final_files': len([p for p in root.rglob('*') if p.is_file()]) + int(not (root / 'organizer/final-parity.json').exists()),
                  'all_markdown_local_links': links, 'deployed_source_files': len(actual),
                  'hash_differences': 0, 'health': 'ready', 'updated_desktop_screenshots': len(browser_report['screenshots']),
                  'embedded_screenshots': review['images'], 'pages': review['pages'],
                  'flag': flag, 'unchanged_rounds_sha256': rounds_hash,
                  'unchanged_server_engine_motion_flag': protected,
                  'baseline_verifier_report': 'verification-result.json predates this presentation pass; the server, engine, authored rounds and flag remain byte-identical. No claim that its broad suite was rerun for cosmetic changes.',
                  'current_public_assets_reward_scan': 'flag and large accepted predictions absent',
                  'fresh_session_reward_absent': True,
                  'superseded_documents_removed': True,
                  'human_playtest': False, 'autonomous_deterrence_evaluated': False}
print(json.dumps(report, indent=2))
if '--read-only' not in sys.argv:
    (root / 'organizer/final-parity.json').write_text(json.dumps(report, indent=2) + '\n')
