# Fixed round authoring

Deployment and the player solve are consolidated in [../Description.md](../Description.md). This is a single-process, standard-library Python 3.12 service. Sessions are in memory; do not use multiple workers without sticky sessions. For public hosting, use the event's TLS proxy and preserve the Host header for same-origin POST checks. Apply Secure cookies at that proxy if required. There is no persistent storage or session garbage collection.

Build/run commands are in the canonical document. Stop with `docker stop rowdy-dvd10-review`; start with `docker start rowdy-dvd10-review`. To replace an existing review instance, build the image first, remove only `rowdy-dvd10-review` with `docker rm -f rowdy-dvd10-review`, then repeat the documented run command. Restarting it clears every review session. The public health endpoint is `/healthz`.

Windows development uses the condev-development skill. Stage this entire folder with `stage_tree.ps1` and require zero SHA-256 differences. After the runtime recovery, use the complete verified stage directly under `/mnt/hostshare` and compare every file hash with its external Windows manifest before running through `condev exec`. Do not copy files into the running Condev container with host `docker cp`; that transfer stalled the shared runtime during this pass. Inside Condev, the URL is `http://host.docker.internal:18110`.

From the verified challenge folder, run `python3 -B organizer/verify.py URL`, `python3 -B organizer/check_walkthrough.py URL`, and `python3 -B organizer/runtime_check.py URL`. The runtime check restarts only the owned review container and compares deployed hashes plus export bytes. Browser captures use `/tmp/rowdy-ctf-tools/bin/python -B organizer/browser_check.py URL`; new QA machines need [requirements.txt](requirements.txt) and Chromium. The current capture pass is desktop only; the older television/chat captures, including the October 23 mobile capture, are retained under `screenshots/historical-20261027`. Rebuild Word/PDF review outputs with the shared `build_description.py Description.md --render-dir organizer/document-review`, then inspect every page and copy outputs back. Finish with `python3 -B organizer/final_check.py URL` and complete-tree parity.

All current graphics are locally authored CSS/SVG; sound is synthesized after a user gesture. The focused redesign is a dark optical-disc menu with the genuine motion surface, integrated prediction console, and original decimal data visible together. Playback has play/pause and restart, one tick per second, no seek/speed or future-corner calculator. Actual edge hits trigger restrained reflections. Fullscreen includes the entire interface. Accepted ticks show the real logo position without an overlay; never means no positive integer-tick corner. Large screens retain true proportions and show their current integer-tick position even when visible motion is below one pixel. Current provenance, checks, screenshots and limitations are in [focused-redesign.json](focused-redesign.json). Earlier reports and their captures are historical and do not approve this revision. The old scene.svg is unused by the interface and retained only because the frozen server explicitly allowlists its URL.

The canonical authored inputs are [../challenge/private/rounds.json](../challenge/private/rounds.json). This manifest is committed source data, not generated from a changing seed. The public export contains the same round objects with a fixed format/units description. No timestamp, random number, or session identifier enters the rounds.

Every numeric field is a decimal string. Screen dimensions must exceed positive logo dimensions. Initial x/y must be within the effective bounds, inclusive; each velocity must be a nonzero integer. Preserve the accepted eight-round sequence and fixed flag across deployments.

| Round | Purpose |
|---|---|
| 01 | Small compatible non-coprime periods; first answer can be simulated. |
| 02 | Velocity gcd reduction, negative vertical motion, compatible non-coprime periods. |
| 03 | Each axis works separately, but periods have incompatible residues. |
| 04 | One axis is impossible because its velocity gcd cannot divide its start. |
| 05 | Speeds larger than bounds test multiple reflections/overshoot per tick. |
| 06 | Exact CRT answer exceeds JavaScript's safe Number range. |
| 07 | Large compatible non-coprime periods with both velocities greater than one. |
| 08 | Starts in a corner; smallest positive recurrence exceeds 2^100. |

[solve.py](solve.py) uses a separate extended-Euclid implementation and reads only the public HTTP API. [verify.py](verify.py) additionally imports the private engine for a comparison against repeated physical reflection in 2,500 deterministic small cases. [browser_check.py](browser_check.py) tests exported BigInt motion through Chromium and submits all eight publicly calculated predictions through the visible UI.

The non-rendered `screensaver-legacy-note` metadata in the HTML contains the experimental agent stop notice. It is outside round data, input validation, visible text, and accessibility labels. It adds no solve step and has no demonstrated deterrence effectiveness. Normal headless browsing, script solving, downloads, developer tools, and manual source inspection remain available.
