#!/usr/bin/env python3
"""Meaningful math, public API, progress, disclosure, reset, and document checks."""
import concurrent.futures
import hashlib
import json
import math
import random
import re
import sys
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'challenge'))
from engine import first_corner, reflected
from solve import Client, predict


def brute(r):
    W = int(r['screen_width']) - int(r['logo_width'])
    H = int(r['screen_height']) - int(r['logo_height'])
    x, y, vx, vy = (int(r[key]) for key in ['x0', 'y0', 'vx', 'vy'])
    # Independent physical simulator: reflect repeatedly, retaining each overshoot.
    for tick in range(1, math.lcm(2 * W, 2 * H) + 1):
        x += vx
        y += vy
        while x < 0 or x > W:
            x, vx = (-x, -vx) if x < 0 else (2 * W - x, -vx)
        while y < 0 or y > H:
            y, vy = (-y, -vy) if y < 0 else (2 * H - y, -vy)
        assert x == reflected(int(r['x0']), int(r['vx']), tick, W)
        assert y == reflected(int(r['y0']), int(r['vy']), tick, H)
        if x in (0, W) and y in (0, H):
            return tick
    return None


def expect(client, path, body, code):
    try:
        client.request(path, body)
    except HTTPError as error:
        assert error.code == code, (path, error.code, code)
        return json.load(error)
    raise AssertionError(f'{path} unexpectedly succeeded')


def run(base):
    result = {}
    rng = random.Random(2010)
    for _ in range(2500):
        W, H = rng.randint(1, 18), rng.randint(1, 18)
        r = dict(screen_width=str(W + 2), screen_height=str(H + 1), logo_width='2', logo_height='1',
                 x0=str(rng.randint(0, W)), y0=str(rng.randint(0, H)),
                 vx=str(rng.choice([i for i in range(-60, 61) if i])),
                 vy=str(rng.choice([i for i in range(-60, 61) if i])))
        assert first_corner(r) == brute(r)
        assert predict(r) == ('never' if first_corner(r) is None else str(first_corner(r)))
    result['independent_simulated_cases'] = 2500
    client = Client(base)
    exported = client.request('/api/rounds')
    rounds = exported['rounds']
    assert len(rounds) == 8
    for r in rounds[:5]:
        assert first_corner(r) == brute(r)
    predictions = [predict(r) for r in rounds]
    assert int(predictions[-1]) > 2 ** 100
    for r, answer in zip(rounds, predictions):
        assert answer == ('never' if first_corner(r) is None else str(first_corner(r)))
        if answer != 'never':
            t = int(answer)
            W, H = int(r['screen_width']) - int(r['logo_width']), int(r['screen_height']) - int(r['logo_height'])
            assert (int(r['x0']) + int(r['vx']) * t) % W == 0
            assert (int(r['y0']) + int(r['vy']) * t) % H == 0
    result['authored_predictions'] = predictions
    fresh = Client(base)
    expect(fresh, '/api/answer', {'round_id': '01', 'answer': predictions[0]}, 401)
    initial = client.request('/api/state')
    assert initial['progress'] == 0 and 'flag' not in initial
    bad = [({'round_id': '08', 'answer': predictions[-1]}, 409),
           ({'round_id': '01', 'answer': predictions[0], 'progress': 8}, 400)]
    for value, code in [(0, 400), (True, 400), ('0', 400), ('-1', 400), ('1.0', 400), ('1e2', 400), ('1', 422), ('never', 422), ('9' * 201, 400), (None, 400), ('NaN', 400)]:
        bad.append(({'round_id': '01', 'answer': value}, code))
    for body, code in bad:
        expect(client, '/api/answer', body, code)
    raw_cases = [(b'{bad', 'application/json', None, 400),
                 (b'[]', 'application/json', None, 400),
                 (b'{}', 'text/plain', None, 415),
                 (b'{}', 'application/json', 'https://unrelated.example', 403),
                 (b' ' * 5000, 'application/json', None, 400)]
    for data, content_type, origin, status in raw_cases:
        headers = {'Content-Type': content_type}
        if origin:
            headers['Origin'] = origin
        req = Request(base + '/api/answer', data=data, headers=headers)
        try:
            client.opener.open(req)
            raise AssertionError('raw bad request succeeded')
        except HTTPError as error:
            assert error.code == status
    assert client.request('/api/state')['progress'] == 0
    paths = ['/private/flag.txt', '/private/rounds.json', '/server.py', '/engine.py', '/organizer/solve.py', '/api/flag', '/flag', '/api/answers', '/app.js.map', '/../private/flag.txt', '/%2e%2e/private/flag.txt', '/public/../private/flag.txt', '/%2fprivate%2fflag.txt']
    for path in paths:
        expect(client, path, None, 404)
    for path in ['/', '/app.js', '/motion.js', '/style.css', '/api/rounds', '/api/state']:
        with urlopen(base + path) as response:
            data = response.read().decode()
            assert 'RCC{' not in data
            assert "script-src 'self'" in response.headers['Content-Security-Policy']
            assert 'Access-Control-Allow-Origin' not in response.headers
    result['negative_cases'] = len(bad) + len(paths) + len(raw_cases) + 1
    # Two simultaneous copies of the same legitimate answer must advance once.
    def race(_):
        try:
            return client.request('/api/answer', {'round_id': '01', 'answer': predictions[0]})['state']['progress']
        except HTTPError as error:
            assert error.code == 409
            return 'stale'
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        assert sorted(map(str, pool.map(race, range(2)))) == ['1', 'stale']
    for r, answer in zip(rounds[1:], predictions[1:]):
        response = client.request('/api/answer', {'round_id': r['id'], 'answer': answer})
        if r != rounds[-1]:
            assert 'flag' not in response['state']
    assert response['state']['complete'] and response['state']['flag'] == 'RCC{c0rn3r_h1t_n0_w41t_crt_any_percent}'
    result['returned_flag'] = response['state']['flag']
    result['public_only_full_solve'] = True
    assert client.request('/api/state')['flag'] == response['state']['flag']
    expect(client, '/api/answer', {'round_id': '08', 'answer': predictions[-1]}, 409)
    unrelated = Client(base).request('/api/state')
    assert unrelated['progress'] == 0 and 'flag' not in unrelated
    reset = client.request('/api/reset', {})
    assert reset == initial
    assert exported == client.request('/api/rounds')
    result['reset_and_session_isolation'] = True
    result['round_export_sha256'] = hashlib.sha256(json.dumps(exported, sort_keys=True).encode()).hexdigest()
    # Local documentation links; external links are not traversed.
    link_count = 0
    for doc in ROOT.glob('*.md'):
        for target in re.findall(r'\]\(([^)]+)\)', doc.read_text()):
            if '://' not in target and not target.startswith('#'):
                assert (doc.parent / target.split('#')[0]).exists(), (doc, target)
                link_count += 1
    result['local_doc_links'] = link_count
    print(json.dumps(result, indent=2))
    (ROOT / 'organizer/verification-result.json').write_text(json.dumps(result, indent=2) + '\n')


if __name__ == '__main__':
    run((sys.argv[1] if len(sys.argv) > 1 else 'http://localhost:18110').rstrip('/'))
