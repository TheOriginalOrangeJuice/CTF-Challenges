#!/usr/bin/env python3
"""Capture the current desktop composition before the focused acceptance pass."""
import sys
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
ROOT=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium-browser',args=['--no-sandbox'])
    context=browser.new_context(viewport={'width':1366,'height':768},reduced_motion='reduce')
    page=context.new_page()
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto(sys.argv[1])
    expect(page.locator('#round-title')).to_have_text('The office is watching')
    page.screenshot(path=str(ROOT/'screenshots/10-optical-1366.png'))
    page.set_viewport_size({'width':1920,'height':1080})
    page.screenshot(path=str(ROOT/'screenshots/11-optical-1920.png'))
    print({'errors':errors,'captures':['10-optical-1366.png','11-optical-1920.png']})
    assert not errors
    browser.close()
