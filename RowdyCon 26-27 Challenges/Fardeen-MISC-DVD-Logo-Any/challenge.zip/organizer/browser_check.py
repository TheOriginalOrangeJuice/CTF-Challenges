#!/usr/bin/env python3
"""Focused public-data acceptance and real screenshots for the optical-disc UI."""
import hashlib,json,os,sys
from pathlib import Path
from playwright.sync_api import sync_playwright,expect
from solve import Client,predict
ROOT=Path(__file__).resolve().parents[1]
AUDIO_PROBE="""(() => {
 const connect=AudioNode.prototype.connect;
 AudioNode.prototype.connect=function(destination,...args){
  const result=connect.call(this,destination,...args);
  if(destination instanceof AudioDestinationNode){
   const analyser=this.context.createAnalyser();analyser.fftSize=2048;
   connect.call(this,analyser);window.__audioProbe=analyser;
  }return result;
 };
 window.sampleOutput=async()=>{
  const a=window.__audioProbe;if(!a)return {peak:0,rms:0,state:'absent'};
  const values=new Float32Array(a.fftSize);let peak=0,sum=0,count=0;
  for(let i=0;i<32;i++){a.getFloatTimeDomainData(values);for(const v of values){peak=Math.max(peak,Math.abs(v));sum+=v*v;count++;}await new Promise(r=>setTimeout(r,10));}
  return {peak,rms:Math.sqrt(sum/count),state:a.context.state};
 };
 const original=document.execCommand.bind(document);
 document.execCommand=(command,...args)=>{if(command==='copy')window.__copied=document.activeElement.value;return original(command,...args);};
})();"""
DATA={'screen-width':'screen_width','screen-height':'screen_height','logo-width':'logo_width','logo-height':'logo_height','start-x':'x0','start-y':'y0','velocity-x':'vx','velocity-y':'vy'}

def within(page,selectors):
    boxes={}
    for selector in selectors:
        box=page.locator(selector).bounding_box()
        assert box is not None,selector
        assert box['x']>=0 and box['y']>=0 and box['x']+box['width']<=page.viewport_size['width']+.5 and box['y']+box['height']<=page.viewport_size['height']+.5,(selector,box)
        boxes[selector]={k:round(v,2) for k,v in box.items()}
    return boxes

def check(base):
    shots=ROOT/'screenshots';shots.mkdir(exist_ok=True)
    rounds=Client(base).request('/api/rounds')['rounds']
    errors=[];console=[];failed=[];bad_http=[];checks=[];audio={};layouts={};captures=[]
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM','/usr/bin/chromium-browser'),args=['--no-sandbox'])
        ctx=browser.new_context(viewport={'width':1366,'height':768},reduced_motion='reduce',accept_downloads=True)
        ctx.add_init_script(AUDIO_PROBE);page=ctx.new_page()
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.on('console',lambda e:console.append(e.text) if e.type=='error' else None)
        page.on('requestfailed',lambda r:failed.append(r.url))
        page.on('response',lambda r:bad_http.append([r.status,r.url]) if r.status>=400 and '/api/answer' not in r.url else None)
        page.goto(base);expect(page.locator('#round-title')).to_have_text(rounds[0]['title'])
        expect(page.locator('#play')).to_have_attribute('aria-label','Play preview')
        expect(page.locator('#tick')).to_have_text('0')
        assert page.locator('[id*=chat],.sidebar,[data-reaction],#theater').count()==0
        assert page.locator('input[type=range]').count()==1
        assert page.locator('#dvd use').get_attribute('href')=='#dvd-mark'
        assert page.evaluate('sampleOutput()')['state']=='absent'
        def shot(name):
            page.screenshot(path=str(shots/name));captures.append(name)
        for width,height in [(1366,768),(1920,1080)]:
            page.set_viewport_size({'width':width,'height':height})
            layouts[str(width)]=within(page,['#stage','#question','#answer','#submit','.data-grid','#export'])
            assert page.evaluate('document.documentElement.scrollHeight')==height
            for element,key in DATA.items():expect(page.locator('#'+element)).to_have_text(rounds[0][key])
            shot('10-optical-1366.png' if width==1366 else '11-optical-1920.png')
        checks.append('1366x768 and 1920x1080: question, input, all original numbers and export visible together without scrolling')
        page.set_viewport_size({'width':1366,'height':768})
        page.locator('#copy-round').click();expect(page.locator('#feedback')).to_have_text('Exact round data copied.')
        assert json.loads(page.evaluate('window.__copied'))==rounds[0]
        with page.expect_download() as download:page.locator('#export').click()
        data=json.loads(Path(download.value.path()).read_text());assert data['rounds']==rounds
        checks.append('copy preserves full round decimal strings; real JSON download matches public API')
        page.locator('#answer').fill('draft')
        page.locator('#play').click();page.wait_for_timeout(1120)
        t=int(page.locator('#tick').inner_text());assert 1<=t<=2
        page.locator('#play').click()
        transform=page.locator('#dvd').get_attribute('style');page.wait_for_timeout(150)
        assert page.locator('#dvd').get_attribute('style')==transform
        page.locator('#rewind').click();expect(page.locator('#tick')).to_have_text('0');expect(page.locator('#answer')).to_have_value('draft')
        page.locator('h1').click();page.keyboard.press('Space');expect(page.locator('#play')).to_have_attribute('aria-label','Pause preview')
        page.keyboard.press('Space');expect(page.locator('#play')).to_have_attribute('aria-label','Play preview')
        page.locator('#answer').focus();page.keyboard.type(' m');expect(page.locator('#sound')).to_have_attribute('aria-pressed','false')
        checks.append('one tick per second, pause freezes genuine motion, preview restart preserves draft, keyboard shortcuts avoid inputs')
        page.locator('#sound').click();audio['enabled']=page.evaluate('sampleOutput()');assert audio['enabled']['peak']>.003 and audio['enabled']['state']=='running'
        def volume(n):
            page.locator('#volume').focus();page.keyboard.press('Home')
            for _ in range(n):page.keyboard.press('ArrowRight')
            expect(page.locator('#volume')).to_have_value(str(n));page.wait_for_timeout(80)
        volume(100);page.locator('#sound').click();page.locator('#sound').click();audio['full']=page.evaluate('sampleOutput()');assert audio['full']['peak']>.02
        volume(10);page.locator('#sound').click();page.locator('#sound').click();audio['quiet']=page.evaluate('sampleOutput()');assert .0001<audio['quiet']['peak']<audio['full']['peak']*.3
        volume(0);page.wait_for_timeout(200);page.locator('#rewind').click();audio['zero']=page.evaluate('sampleOutput()');assert audio['zero']['peak']<.0001
        volume(35);page.locator('#sound').click();page.wait_for_timeout(200);page.locator('#rewind').click();audio['muted']=page.evaluate('sampleOutput()');assert audio['muted']['peak']<.0001
        checks.append('actual WebAudio signal, user activation, volume attenuation, zero and muted silence; independent human listening not performed')
        page.locator('#fullscreen').click();assert page.evaluate('document.fullscreenElement.id')=='experience'
        within(page,['#answer','#submit','#play','#rewind','#sound','#volume','#fullscreen','.data-grid'])
        page.locator('#play').click();expect(page.locator('#play')).to_have_attribute('aria-label','Pause preview');page.locator('#play').click()
        page.locator('#help-open').click();expect(page.locator('#help-dialog')).to_be_visible();page.keyboard.press('Escape');expect(page.locator('#help-open')).to_be_focused()
        page.locator('#fullscreen').click();assert page.evaluate('!document.fullscreenElement')
        page.locator('#help-open').click()
        for summary in page.locator('#help-dialog summary').all():summary.click()
        assert page.locator('#help-dialog details[open]').count()==3
        page.keyboard.press('Escape');expect(page.locator('#help-open')).to_be_focused()
        page.locator('#history-open').click();expect(page.locator('#history-empty')).to_be_visible();expect(page.locator('#copy-history')).to_be_disabled();page.keyboard.press('Escape')
        checks.append('fullscreen retains ordinary controls, question and numbers; modal Escape/focus restoration, three hints and empty history')
        for answer,expected in [('0','strictly positive'),('1.5','positive integer'),('1','No corner confirmed')]:
            page.locator('#answer').fill(answer);page.locator('#submit').click();expect(page.locator('#feedback')).to_contain_text(expected);expect(page.locator('#answer')).to_have_value(answer);expect(page.locator('#answer')).to_be_focused();expect(page.locator('#answer')).to_have_attribute('aria-invalid','true')
        page.locator('#reset-open').click();page.locator('#reset-cancel').click();expect(page.locator('#answer')).to_have_value('1')
        checks.append('zero, fractional and incorrect answer recovery retains draft and input focus; cancelled reset preserves run')
        predictions=[];accepted_geometry=[]
        for index,r in enumerate(rounds):
            for element,key in DATA.items():expect(page.locator('#'+element)).to_have_text(r[key])
            within(page,['#question','#answer','#submit','.data-grid'])
            assert page.locator('.datum dd').evaluate_all('(items)=>items.every(el=>el.scrollWidth<=el.clientWidth+1)'),r['id']
            assert page.evaluate("""()=>{const d=document.querySelector('.data-grid').getBoundingClientRect(),p=document.querySelector('.prediction').getBoundingClientRect();return d.left>=p.left&&d.right<=p.right&&d.top>=p.top&&d.bottom<=p.bottom;}"""),r['id']
            answer=predict(r);predictions.append(answer)
            if index==5:
                expect(page.locator('#scale-note')).to_contain_text('BELOW ONE PIXEL')
                shot('14-large-round.png')
            if index==7:shot('15-final-round.png')
            page.locator('#answer').fill(answer);page.locator('#submit').click()
            expect(page.locator('#solved-count')).to_have_text(str(index+1)+' / 8')
            expect(page.locator('#play')).to_be_disabled()
            assert page.evaluate("""()=>{const d=document.querySelector('.data-grid').getBoundingClientRect(),p=document.querySelector('.prediction').getBoundingClientRect();return d.bottom<=p.bottom&&parseFloat(getComputedStyle(document.querySelector('.data-heading h2')).fontSize)<=14;}"""),r['id']
            if answer!='never':
                expect(page.locator('#tick')).to_have_text(answer)
                geometry=page.evaluate("""()=>{const f=document.getElementById('playfield').getBoundingClientRect(),d=document.getElementById('dvd').getBoundingClientRect();return {x:d.left-f.left,y:d.top-f.top,w:f.width-d.width,h:f.height-d.height,logoWidth:d.width,fieldWidth:f.width};}""")
                assert min(abs(geometry['x']),abs(geometry['x']-geometry['w']))<.025,geometry
                assert min(abs(geometry['y']),abs(geometry['y']-geometry['h']))<.025,geometry
                assert abs(geometry['logoWidth']/geometry['fieldWidth']-int(r['logo_width'])/int(r['screen_width']))<.0001
                accepted_geometry.append(geometry)
                # The accepted console never covers any point in the visible logo rectangle.
                assert page.evaluate("""()=>{const d=document.getElementById('dvd').getBoundingClientRect(),c=document.querySelector('.prediction').getBoundingClientRect();return d.right<=c.left;}""")
            else:
                expect(page.locator('#accepted-title')).to_have_text('No integer-tick corner.')
            if index==0:shot('12-first-corner.png')
            if index==2:shot('13-no-integer-corner.png')
            if index<7:page.locator('#next').click()
        expect(page.locator('#flag')).to_have_text('RCC{c0rn3r_h1t_n0_w41t_crt_any_percent}')
        within(page,['#flag','#copy-flag','.data-grid','#dvd'])
        shot('16-complete.png')
        page.locator('#copy-flag').click();expect(page.locator('#copy-flag')).to_have_text('Flag copied');assert page.evaluate('window.__copied')==page.locator('#flag').inner_text()
        page.locator('#history-open').click();assert page.locator('#history-list code').all_text_contents()==predictions
        page.locator('#copy-history').click();expect(page.locator('#history-feedback')).to_contain_text('copied')
        assert [r['answer'] for r in json.loads(page.evaluate('window.__copied'))]==predictions
        page.keyboard.press('Escape');page.reload();expect(page.locator('#flag')).to_contain_text('RCC{');assert page.locator('#history-list li').count()==8
        checks.append('all eight independently computed public-data answers submitted through UI; exact accepted corner geometry, unobscured logo, never wording, history and reward copying, completed-session reload')
        page.locator('#reset-open').click();page.locator('#reset-confirm').click()
        expect(page.locator('#round-title')).to_have_text(rounds[0]['title']);expect(page.locator('#solved-count')).to_have_text('0 / 8');expect(page.locator('#reward')).to_be_hidden();expect(page.locator('#tick')).to_have_text('0')
        assert page.locator('#history-list li').count()==0
        assert Client(base).request('/api/rounds')['rounds']==rounds
        checks.append('reset removes receipts/reward/draft and restores identical round 1 and export')
        vectors=[{'round':r,'millis':str(t)} for r in rounds for t in [0,1,999,4321,17005,9007199254740993250,10**43+39]]
        actual=page.evaluate("""async vectors=>{const {reflected}=await import('/motion.js');return vectors.map(({round:r,millis:t})=>['x','y'].map((axis,i)=>reflected(BigInt(r[axis+'0'])*1000n,BigInt(r['v'+axis]),BigInt(t),(BigInt(r[i?'screen_height':'screen_width'])-BigInt(r[i?'logo_height':'logo_width']))*1000n).toString()));}""",vectors)
        for vector,coordinates in zip(vectors,actual):
            r=vector['round'];t=int(vector['millis'])
            for axis,suffix,coordinate in zip(['x','y'],['width','height'],coordinates):
                bound=(int(r['screen_'+suffix])-int(r['logo_'+suffix]))*1000
                phase=(int(r[axis+'0'])*1000+int(r['v'+axis])*t)%(2*bound)
                assert int(coordinate)==min(phase,2*bound-phase)
        checks.append(str(len(vectors))+' exact motion vectors: negative velocities, overshoot, sub-ticks and huge integers')
        live=browser.new_context(viewport={'width':1366,'height':768},reduced_motion='no-preference')
        lp=live.new_page();lp.goto(base);expect(lp.locator('#play')).to_have_attribute('aria-label','Pause preview')
        lp.wait_for_timeout(5100)
        assert 5<=int(lp.locator('#tick').inner_text())<=6
        assert lp.locator('#edge-y').get_attribute('class').endswith('hit')
        assert lp.locator('#edge-y').evaluate('(el)=>el.style.top')=='calc(100% - 1px)'
        lp.emulate_media(reduced_motion='reduce');expect(lp.locator('#play')).to_have_attribute('aria-label','Play preview')
        live.close();checks.append('ordinary arrival plays; actual first lower-edge collision drives edge reflection; reduced-motion change pauses')
        unexpected=[e for e in console if not ('400 (Bad Request)' in e or '422 (Unprocessable Entity)' in e)]
        assert not errors and not unexpected and not failed and not bad_http,(errors,unexpected,failed,bad_http)
        report={'revision':'2026-10-27 focused optical redesign','result':'PASS','checks':checks,'layouts':layouts,'predictions':predictions,'accepted_geometry':accepted_geometry,'audio_signal':audio,'page_errors':errors,'unexpected_console_errors':unexpected,'unexpected_http_errors':bad_http,'failed_requests':failed,'intentional_negative_http_statuses':[400,422],'screenshots':captures,'flag':'RCC{c0rn3r_h1t_n0_w41t_crt_any_percent}','human_playtest':False,'independent_human_listening':False,'deterrence_effectiveness':'Not evaluated'}
        (ROOT/'organizer/browser-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
        browser.close()
if __name__=='__main__':check((sys.argv[1] if len(sys.argv)>1 else 'http://localhost:18110').rstrip('/'))
