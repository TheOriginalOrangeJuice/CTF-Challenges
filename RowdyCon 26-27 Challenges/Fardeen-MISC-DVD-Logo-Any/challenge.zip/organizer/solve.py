#!/usr/bin/env python3
"""Reference solve: read only the public API, compute all answers, submit in order.

Usage: python organizer/solve.py http://localhost:18110
No private files or expected answers are read.
"""
import argparse
import http.cookiejar
import json
from math import gcd
from urllib.request import Request, build_opener, HTTPCookieProcessor


def extended_gcd(a, b):
    """Return g, u, v with a*u + b*v == g == gcd(a,b)."""
    old_r, r, old_u, u, old_v, v = a, b, 1, 0, 0, 1
    while r:
        q = old_r // r
        old_r, r = r, old_r - q * r
        old_u, u = u, old_u - q * u
        old_v, v = v, old_v - q * v
    return old_r, old_u, old_v


def axis(start, velocity, bound):
    g = gcd(velocity, bound)
    if start % g:
        return None
    period = bound // g
    if period == 1:
        return 0, 1
    _, inverse, _ = extended_gcd((velocity // g) % period, period)
    return ((-start // g) * inverse) % period, period


def predict(r, explain=False):
    W = int(r['screen_width']) - int(r['logo_width'])
    H = int(r['screen_height']) - int(r['logo_height'])
    x = axis(int(r['x0']), int(r['vx']), W)
    y = axis(int(r['y0']), int(r['vy']), H)
    if explain:
        print(f"{r['id']} {r['title']}: W={W}, H={H}; x={x}, y={y}")
    if x is None or y is None:
        return 'never'
    a, m = x
    b, n = y
    g, u, _ = extended_gcd(m, n)
    if (b - a) % g:
        return 'never'
    # m*u == g modulo n, so multiplying by (b-a)/g gives a CRT offset.
    k = ((b - a) // g * u) % (n // g)
    period = m * (n // g)
    t = (a + m * k) % period
    return str(t if t else period)


class Client:
    def __init__(self, base):
        self.base = base.rstrip('/')
        self.opener = build_opener(HTTPCookieProcessor(http.cookiejar.CookieJar()))

    def request(self, path, data=None):
        body = None if data is None else json.dumps(data).encode()
        req = Request(self.base + path, data=body, headers={'Content-Type': 'application/json'} if body is not None else {})
        with self.opener.open(req, timeout=10) as response:
            return json.load(response)


def solve(base):
    client = Client(base)
    rounds = client.request('/api/rounds')['rounds']
    client.request('/api/state')
    for r in rounds:
        answer = predict(r, explain=True)
        print('  prediction:', answer)
        response = client.request('/api/answer', {'round_id': r['id'], 'answer': answer})
        print('  cleared:', response['state']['progress'])
    print('FLAG:', response['state']['flag'])
    return response['state']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('url', nargs='?', default='http://localhost:18110')
    solve(parser.parse_args().url)
