#!/usr/bin/env python3
"""Reference solve from the public diagnostic kit alone; no organizer answers.

The recovered ISA and address translation are encoded here as the product of
reversing ramcloud-host.wasm. Trace the VM, invert its coupled Feistel rounds,
then submit the independently reconstructed code to the original service.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import struct
from urllib.request import Request, urlopen
import zipfile

NAMES = {0x17:'INPUT',0x2d:'IMM',0x53:'MOV',0x84:'ADD',0xa6:'XOR',0x39:'ROL',
         0x62:'LDW',0x71:'ADDI',0xc3:'JNZ',0xe1:'EQ',0x46:'SWAP',0x99:'DEC',0xbd:'JMP',0xf0:'RETURN'}

def rol(value, amount):
    amount &= 15
    return ((value << amount) | (value >> ((16-amount)&15))) & 65535

def reconstruct(files):
    index = files['pages.rci']
    assert len(index)==144 and index[:4]==b'RCI2', 'Unexpected page index'
    entry, count=struct.unpack_from('<HH', index,4)
    memory=bytearray(count*256)
    seen=set()
    for row_start in range(16,16+count*8,8):
        row=index[row_start:row_start+8]
        page=row[0]^0xa7; package=row[1]; slot=row[2]^((page*7+0x39)&255)
        assert page not in seen and page<count and slot<4 and 1<=row[4]<=7
        seen.add(page)
        backing=files[f'bank-{package}.dimm']
        for offset in range(256):
            lane=(((offset<<row[4])|(offset>>(8-row[4])))&255)^row[3]
            raw=backing[32+slot*256+lane]
            memory[page*256+offset]=raw^((page*29+offset*7+0x5d)&255)
    assert len(seen)==count
    return bytes(memory), entry

def emulate(memory, entry, inputs):
    """Instrument only the recovered ISA; constants come from mapped memory."""
    r=[0]*16;pc=entry;ok=True;events=[];listing={}
    def word(addr):return struct.unpack_from('<H',memory,addr)[0]
    for step in range(10000):
        old_pc=pc;op=memory[pc];pc+=1
        if op==0xf0:
            listing[old_pc]='RETURN';return ok,events,listing
        if op==0xbd:
            distance=struct.unpack_from('<h',memory,pc)[0];pc+=2
            listing[old_pc]=f'JMP 0x{pc+distance:04x}';pc+=distance;continue
        a=memory[pc];pc+=1
        if op==0x99:
            listing[old_pc]=f'DEC r{a}';r[a]=(r[a]-1)&65535;continue
        if op in (0x2d,0x71,0xc3):
            n=word(pc);pc+=2
            if op==0x2d:r[a]=n
            elif op==0x71:r[a]=(r[a]+n)&65535
            else:
                distance=n if n<32768 else n-65536
                listing[old_pc]=f'JNZ r{a}, 0x{pc+distance:04x}'
                if r[a]:pc+=distance
                continue
            listing[old_pc]=f'{NAMES[op]} r{a}, 0x{n:04x}';continue
        b=memory[pc];pc+=1
        listing[old_pc]=f'{NAMES[op]} r{a}, '+(str(b) if op in (0x17,0x39) else f'r{b}')
        if op==0x17:r[a]=inputs[b]
        elif op==0x53:r[a]=r[b]
        elif op==0x84:r[a]=(r[a]+r[b])&65535
        elif op==0xa6:r[a]^=r[b]
        elif op==0x39:r[a]=rol(r[a],b);events.append(('rotate',a,b))
        elif op==0x62:
            r[a]=word(r[b]);events.append(('load',r[b],r[a]))
        elif op==0xe1:
            ok &= r[a]==r[b];events.append(('compare',a,r[b]))
        elif op==0x46:r[a],r[b]=r[b],r[a]
        else:raise ValueError(f'Unknown opcode at {old_pc:04x}: {op:02x}')
    raise ValueError('Instruction budget exceeded')

def recover(files):
    memory,entry=reconstruct(files)
    _,events,listing=emulate(memory,entry,[0]*8)
    loads=[event[2] for event in events if event[0]=='load']
    rotations=[event[2] for event in events if event[0]=='rotate']
    compares=[event[2] for event in events if event[0]=='compare']
    assert len(compares)==8 and len(rotations)%4==0
    rounds=len(rotations)//4;keys=loads[:-8]
    assert len(keys)==rounds*4 and rotations==rotations[:4]*rounds
    state=compares[:]
    for round_no in reversed(range(rounds)):
        old_right,new_right=state[:4],state[4:]
        f=[rol((old_right[i]+keys[round_no*4+i])&65535,rotations[i])^old_right[(i+1)%4] for i in range(4)]
        state=[new_right[i]^f[i] for i in range(4)]+old_right
    accepted,_,_=emulate(memory,entry,state)
    assert accepted,'Recovered code does not satisfy the reconstructed bytecode'
    code='-'.join(f'{value:04X}' for value in state)
    details={'entry':entry,'rounds':rounds,'rotations':rotations[:4],
             'memory_sha256':hashlib.sha256(memory).hexdigest(),
             'targets':[f'{v:04X}' for v in compares], 'license':code}
    return code,memory,listing,details

def load_bundle(source):
    blob=urlopen(source,timeout=15).read() if source.startswith(('http://','https://')) else Path(source).read_bytes()
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        return {name:archive.read(name) for name in archive.namelist()}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--url',default='http://127.0.0.1:18102')
    parser.add_argument('--bundle',help='Optional local ramcloud-player.zip')
    parser.add_argument('--output',type=Path,default=Path('/tmp/ramcloud-solve'))
    parser.add_argument('--offline',action='store_true',help='Do not submit to the server')
    args=parser.parse_args()
    files=load_bundle(args.bundle or args.url.rstrip('/')+'/downloads/ramcloud-player.zip')
    code,memory,listing,details=recover(files)
    args.output.mkdir(parents=True,exist_ok=True)
    (args.output/'memory.bin').write_bytes(memory)
    (args.output/'disassembly.txt').write_text('\n'.join(f'{pc:04x}  {line}' for pc,line in sorted(listing.items()))+'\n')
    (args.output/'solution.json').write_text(json.dumps(details,indent=2)+'\n')
    print(json.dumps(details,indent=2))
    if not args.offline:
        request=Request(args.url.rstrip('/')+'/api/activate',data=json.dumps({'license':code}).encode(),headers={'Content-Type':'application/json'})
        result=json.load(urlopen(request,timeout=15))
        assert result.get('accepted') is True
        print('Server receipt:',result['receipt'])

if __name__=='__main__':main()
