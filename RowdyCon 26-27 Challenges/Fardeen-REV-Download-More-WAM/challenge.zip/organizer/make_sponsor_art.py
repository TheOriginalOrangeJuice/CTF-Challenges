#!/usr/bin/env python3
"""Build the optional, self-contained Rem sticker sheets; never touch puzzle bytes."""
from pathlib import Path
import math
import re

ART = Path(__file__).resolve().parents[1] / 'challenge/public/assets/rem'
portrait = (ART / 'rem-portrait.svg').read_text(encoding='utf-8')
body = re.search(r'<svg[^>]*>([\s\S]*)</svg>', portrait).group(1)
body = re.sub(r'<(?:title|desc)[^>]*>[\s\S]*?</(?:title|desc)>', '', body)
for count in (1, 5, 10, 50):
    columns = min(count, 10 if count == 50 else 5)
    rows = math.ceil(count / columns)
    width, height = max(800, columns * 240 + 80), rows * 240 + 180
    start_x = (width - columns * 240) / 2
    copies = '\n'.join(
        f'<use href="#rem" x="{start_x + i % columns * 240:g}" y="{100 + i // columns * 240}" width="240" height="240"/>'
        for i in range(count))
    sheet = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}">
<title>{count} Rem — Download More Rem!</title>
<desc>{count} original Rem portrait stickers. A RAMCloud nod to DownloadMoreRem.com. Rem is from Re:Zero.</desc>
<defs><symbol id="rem" viewBox="0 0 240 240">{body}</symbol></defs>
<rect width="{width}" height="{height}" rx="26" fill="#edf8ff"/>
<rect x="12" y="12" width="{width-24}" height="{height-24}" rx="20" fill="none" stroke="#bedcec" stroke-width="2"/>
<text x="{width/2:g}" y="64" text-anchor="middle" font-family="Segoe UI,Arial,sans-serif" font-size="32" fill="#357a9e">Download More Rem! · {count} Rem</text>
{copies}
<text x="{width/2:g}" y="{height-28}" text-anchor="middle" font-family="Segoe UI,Arial,sans-serif" font-size="16" fill="#5a849a">Some memories are worth keeping. · RAMCloud × DownloadMoreRem.com</text>
</svg>
'''
    (ART / f'rem-{count}.svg').write_text(sheet, encoding='utf-8')
print('Created four local Rem sticker sheets: 1, 5, 10, 50 portraits.')
