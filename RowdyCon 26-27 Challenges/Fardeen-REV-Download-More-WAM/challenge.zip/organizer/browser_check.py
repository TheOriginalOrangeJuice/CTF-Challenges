#!/usr/bin/env python3
"""Playwright feature checks and real screenshots; run only inside Condev."""
import argparse
import json
import random
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
from solve import load_bundle,recover,emulate
from capture_documentation import capture_region

ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--url',default='http://127.0.0.1:18102')
    parser.add_argument('--browser',default='/usr/bin/chromium-browser');args=parser.parse_args()
    code,memory,_,details=recover(load_bundle(args.url+'/downloads/ramcloud-player.zip'))
    output=ROOT/'screenshots';output.mkdir(exist_ok=True)
    errors=[]
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path=args.browser,headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        context=browser.new_context(viewport={'width':1440,'height':1200},device_scale_factor=1,permissions=['clipboard-read','clipboard-write'])
        page=context.new_page()
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.on('console',lambda msg:errors.append(msg.text) if msg.type=='error' and 'status of 4' not in msg.text else None)
        page.goto(args.url);page.wait_for_selector('#hero-install')
        page.screenshot(path=str(output/'01-overview.png'),full_page=True)
        page.click('#hero-install');expect(page.locator('#memory-state')).to_have_text('All banks online')
        assert page.locator('#ram-banks .mounted').count()==4
        page.click('[data-view="diagnostics"]')
        page.fill('#probe-address','02F3');page.click('#probe-form button');assert 'bank-' in page.locator('#probe-output').inner_text()
        page.fill('#probe-address','FFFF');page.click('#probe-form button');assert 'between' in page.locator('#probe-output').inner_text()
        page.fill('#probe-address','02F3');page.click('#probe-form button')
        page.click('#clear-faults');assert page.locator('#fault-count').inner_text()=='0'
        page.click('#benchmark');expect(page.locator('#bench-status')).to_have_text('Complete. 2,560 calibration checks. More WAM, fewer excuses.')
        assert int(page.locator('#fault-count').inner_text())>0
        capture_region(page,'#probe-form','#probe-output',output/'02-diagnostics.png')
        page.click('[data-view="downloads"]')
        assert page.locator('.download-row').count()==9
        with page.expect_download() as download_info:page.click('a.bundle')
        assert download_info.value.suggested_filename=='ramcloud-player.zip'
        page.screenshot(path=str(output/'03-downloads.png'),full_page=True)
        page.click('[data-view="sponsor"]')
        expect(page.locator('#sponsor h1')).to_have_text('Download More Rem!')
        assert page.locator('.sponsor-plan').count()==4
        sponsor_downloads=[]
        for amount in (1,5,10,50):
            with page.expect_download() as sponsor_info:
                page.click(f'a[download="{amount}-Rem.svg"]')
            saved=sponsor_info.value
            assert saved.suggested_filename==f'{amount}-Rem.svg'
            assert saved.failure() is None
            data=Path(saved.path()).read_text()
            assert data.count('<use href="#rem"')==amount
            assert '<script' not in data and 'https://' not in data
            sponsor_downloads.append({'portraits':amount,'filename':saved.suggested_filename})
        source=page.locator('.sponsor-source')
        assert source.get_attribute('href')=='https://downloadmorerem.com/'
        assert source.get_attribute('target')=='_blank'
        assert source.get_attribute('rel')=='noopener noreferrer'
        assert page.locator('#sponsor img').evaluate('(img)=>img.complete&&img.naturalWidth>0')
        page.screenshot(path=str(output/'06-sponsor.png'),full_page=True)
        page.click('[data-view="overview"]')
        page.fill('#license','BAD');page.click('#activate')
        expect(page.locator('#activation-status')).to_have_text('Use eight groups of four hexadecimal digits.')
        page.evaluate('() => { globalThis.savedHost=host; host={...host,check:()=>1}; }')
        page.fill('#license','0000-0000-0000-0000-0000-0000-0000-0000');page.click('#activate')
        expect(page.locator('#activation-status')).to_have_class('status-line error')
        assert page.locator('#receipt').is_hidden()
        page.evaluate('() => { host=globalThis.savedHost; delete globalThis.savedHost; }')
        # Compare independently solved code in the real WASM host as well as service.
        rng=random.Random(20101023)
        random_inputs=[[rng.randrange(65536) for _ in range(8)] for _ in range(24)]
        expected=[int(emulate(memory,details['entry'],candidate)[0]) for candidate in random_inputs]
        wasm_result=page.evaluate('''async ({code,randomInputs})=>{
          const exports=(await WebAssembly.instantiate(await (await fetch('/downloads/ramcloud-host.wasm')).arrayBuffer(),{})).instance.exports;
          new Uint8Array(exports.memory.buffer,exports.index_buffer(),144).set(new Uint8Array(await(await fetch('/downloads/pages.rci')).arrayBuffer()));
          for(let i=0;i<4;i++)new Uint8Array(exports.memory.buffer,exports.package_buffer(i),1056).set(new Uint8Array(await(await fetch('/downloads/bank-'+i+'.dimm')).arrayBuffer()));
          const view=new DataView(exports.memory.buffer),words=code.split('-').map(v=>parseInt(v,16));
          function check(vals){vals.forEach((v,i)=>view.setUint16(exports.license_buffer()+i*2,v,true));return exports.check();}
          const accepted=check(words);let rejected=0;
          for(let i=0;i<8;i++)for(let bit=0;bit<16;bit++){const mutated=[...words];mutated[i]^=1<<bit;if(!check(mutated))rejected++;}
          return {accepted,rejected,random:randomInputs.map(check),invalid:exports.translate(4096)>>>0};
        }''',{'code':code,'randomInputs':random_inputs})
        assert wasm_result=={'accepted':1,'rejected':128,'random':expected,'invalid':4294967295},wasm_result
        page.fill('#license',code);page.click('#activate');page.wait_for_selector('#receipt:not([hidden])')
        assert page.locator('#flag').inner_text()=='RCC{d3d0t4t3d_w4m_h4s_p4g3_t4bl3s}'
        capture_region(page,'#activation-status','#receipt',output/'04-activation.png')
        # Local DOM state cannot mint a service receipt.
        forged=page.evaluate("async()=>{const r=await fetch('/api/activate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({license:'0000-0000-0000-0000-0000-0000-0000-0000',accepted:true})});return r.status}")
        assert forged==403
        receipt=page.locator('#flag').inner_text()
        page.click('#copy-receipt')
        if page.evaluate('window.isSecureContext'):
            expect(page.locator('#copy-receipt')).to_have_text('Copied!')
            assert page.evaluate('() => navigator.clipboard.readText()')==receipt
            copy_result='clipboard copied on secure origin'
        else:
            expect(page.locator('#activation-status')).to_have_text('Select the receipt text to copy it.')
            copy_result='manual-copy fallback on insecure origin'
        page.click('#reset')
        page.wait_for_selector('#hero-install');assert page.locator('#receipt').is_hidden()
        assert page.locator('#memory-value').inner_text()=='0 GB'
        # All navigation and sponsor downloads are reachable without a pointer.
        page.locator('.brand').focus()
        page.keyboard.press('Tab');expect(page.locator('[data-view="overview"]')).to_be_focused()
        for name in ('diagnostics','downloads','sponsor'):
            page.keyboard.press('Tab')
            expect(page.locator(f'[data-view="{name}"]')).to_be_focused()
            page.keyboard.press('Enter')
            expect(page.locator(f'#{name}')).to_be_visible()
            assert page.locator(f'[data-view="{name}"]').get_attribute('aria-current')=='page'
        page.keyboard.press('Tab');expect(source).to_be_focused()
        for amount in (1,5,10,50):
            page.keyboard.press('Tab')
            expect(page.locator(f'a[download="{amount}-Rem.svg"]')).to_be_focused()
        page.keyboard.press('Enter')
        page.screenshot(path=str(output/'08-sponsor-keyboard.png'),full_page=True)
        for width in (1280,1440,1920):
            page.set_viewport_size({'width':width,'height':1000})
            for name in ('overview','diagnostics','downloads','sponsor'):
                page.click(f'[data-view="{name}"]')
                assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'),(width,name)
                for item in page.locator(f'#{name} button:visible, #{name} a:visible, #{name} input:visible').all():
                    box=item.bounding_box();assert box and box['width']>0 and box['x']>=0 and box['x']+box['width']<=width,(width,name)
        reduced=browser.new_context(viewport={'width':1440,'height':1000},reduced_motion='reduce')
        quiet=reduced.new_page();quiet.goto(args.url+'/#sponsor')
        expect(quiet.locator('#sponsor')).to_be_visible()
        assert quiet.evaluate('matchMedia("(prefers-reduced-motion: reduce)").matches')
        assert quiet.locator('.sponsor-plan .gloss').first.evaluate('(el)=>getComputedStyle(el).transitionDuration')=='0s'
        quiet.click('[data-view="overview"]');quiet.click('#hero-install')
        expect(quiet.locator('#memory-state')).to_have_text('All banks online')
        quiet.click('[data-view="diagnostics"]');quiet.click('#benchmark')
        expect(quiet.locator('#bench-status')).to_have_text('Complete. 2,560 calibration checks. More WAM, fewer excuses.')
        quiet.screenshot(path=str(output/'07-diagnostics-desktop.png'),full_page=True)
        reduced.close()
        browser.close()
    assert not errors,errors
    (output/'browser-results.json').write_text(json.dumps({'console_errors':errors,'wasm_checks':wasm_result,'receipt':receipt,'copy_result':copy_result,'sponsor_downloads':sponsor_downloads,'desktop_widths':[1280,1440,1920],'keyboard_navigation':'passed','reduced_motion':'installation and benchmark passed','features':'desktop tabs, installation, all banks, probe, invalid probe, page counter, benchmark, downloads, sponsor, rejected activation, accepted activation, copy control, reset','human_playtesting':'not performed'},indent=2)+'\n')
    print('PASS desktop browser features, 128 WASM rejection vectors, activation; no unexpected console errors')

if __name__=='__main__':main()
