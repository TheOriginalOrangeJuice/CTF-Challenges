#!/usr/bin/env python3
"""Capture two focused regions of the live app after solving its public kit."""
import argparse
import json
from pathlib import Path
from playwright.sync_api import sync_playwright, expect
from solve import load_bundle, recover

ROOT = Path(__file__).resolve().parents[1]

def capture_region(page, first, last, destination):
    page.locator(first).scroll_into_view_if_needed()
    a, b = page.locator(first).bounding_box(), page.locator(last).bounding_box()
    assert a and b
    x, y = min(a['x'], b['x']), min(a['y'], b['y'])
    right = max(a['x'] + a['width'], b['x'] + b['width'])
    bottom = max(a['y'] + a['height'], b['y'] + b['height'])
    page.screenshot(path=str(destination), clip={
        'x': x, 'y': y, 'width': right - x, 'height': bottom - y})

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--url', default='http://127.0.0.1:18102')
    args = parser.parse_args()
    code, _, _, _ = recover(load_bundle(args.url + '/downloads/ramcloud-player.zip'))
    errors = []
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path='/usr/bin/chromium-browser',
                                    headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1200})
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.on('console', lambda msg: errors.append(msg.text) if msg.type == 'error' else None)
        page.goto(args.url)
        page.click('#hero-install')
        expect(page.locator('#memory-state')).to_have_text('All banks online', timeout=15000)
        page.click('[data-view="diagnostics"]')
        page.fill('#probe-address', '02F3')
        page.click('#probe-form button')
        expect(page.locator('#probe-output')).to_contain_text('0x01DA')
        capture_region(page, '#probe-form', '#probe-output', ROOT/'screenshots/02-diagnostics.png')
        page.click('[data-view="overview"]')
        page.fill('#license', code)
        page.click('#activate')
        expect(page.locator('#flag')).to_have_text('RCC{d3d0t4t3d_w4m_h4s_p4g3_t4bl3s}')
        capture_region(page, '#activation-status', '#receipt', ROOT/'screenshots/04-activation.png')
        receipt = page.locator('#flag').inner_text()
        browser.close()
    assert not errors, errors
    result = {'receipt': receipt, 'console_errors': errors, 'capture': 'live address input/result and accepted receipt'}
    (ROOT/'organizer/consolidation-captures.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))

if __name__ == '__main__':
    main()
