#!/usr/bin/env python3
"""Execute the walkthrough's two Python snippets against the public bundle."""
import argparse
import hashlib
import io
import re
from pathlib import Path
import subprocess
import sys
import tempfile
from urllib.request import urlopen
import zipfile

ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--url',default='http://127.0.0.1:18102');args=parser.parse_args()
    document=(ROOT/'Description.md').read_text(encoding='utf-8')
    snippets=re.findall(r'```python\n(.*?)\n```',document,re.S)
    assert len(snippets)==2
    with tempfile.TemporaryDirectory(prefix='rowdy02-walkthrough-') as temp:
        work=Path(temp);evidence=work/'evidence';evidence.mkdir()
        with zipfile.ZipFile(io.BytesIO(urlopen(args.url+'/downloads/ramcloud-player.zip').read())) as archive:
            for name in archive.namelist():
                assert '/' not in name and '\\' not in name
                (evidence/name).write_bytes(archive.read(name))
        for filename,script,cwd in [('reconstruct.py',snippets[0],evidence),('invert.py',snippets[1],work)]:
            path=work/filename;path.write_text(script+'\n')
            result=subprocess.run([sys.executable,str(path)],cwd=cwd,check=True,capture_output=True,text=True)
            print(result.stdout.strip())
        assert hashlib.sha256((work/'memory.bin').read_bytes()).hexdigest()=='0a8b0ee8764114deae9d7db71f04722d1434e42915ef5eeaf978891948b4c8be'
        assert result.stdout.strip()=='6662-49A2-5584-455E-732C-DF46-6606-121A'
    for document in ROOT.glob('*.md'):
        for target in re.findall(r'\]\(([^)]+)\)',document.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'):continue
            assert (document.parent/target.split('#')[0]).is_file(),(document.name,target)
    print('PASS exact walkthrough Python snippets and local Markdown links')

if __name__=='__main__':main()
