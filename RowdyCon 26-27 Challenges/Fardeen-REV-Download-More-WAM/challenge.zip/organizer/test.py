#!/usr/bin/env python3
"""Live service and artifact tests. Starts a temporary second service for reset QA."""
import argparse
import hashlib
import json
from pathlib import Path
import random
import struct
import subprocess
import sys
import time
from urllib.error import HTTPError
from urllib.request import Request,urlopen
from solve import load_bundle,recover,emulate

ROOT=Path(__file__).resolve().parents[1]

def request(url,body=None,raw=False,headers=None):
    if body is not None and not raw:body=json.dumps(body).encode()
    try:
        response=urlopen(Request(url,data=body,headers=headers or ({'Content-Type':'application/json'} if body is not None else {})),timeout=15)
    except HTTPError as error:response=error
    return response.status,response.read()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--url',default='http://127.0.0.1:18102');args=parser.parse_args()
    files=load_bundle(args.url+'/downloads/ramcloud-player.zip')
    code,memory,_,details=recover(files)
    status,body=request(args.url+'/api/activate',{'license':code})
    assert status==200 and json.loads(body)['accepted']
    assert json.loads(body)['receipt']=='RCC{d3d0t4t3d_w4m_h4s_p4g3_t4bl3s}'
    receipt=json.loads(body)['receipt'].encode()
    print('PASS public-artifact reconstruction, inversion, and live receipt')
    for name,data in files.items():
        assert code.encode() not in data and receipt not in data,name
        status,served=request(args.url+'/downloads/'+name);assert status==200 and served==data,name
    for path in ('/','/app.js','/style.css','/api/status'):
        status,data=request(args.url+path);assert status==200 and receipt not in data and code.encode() not in data
    packed=struct.pack('<8H',*[int(x,16) for x in code.split('-')])
    public=ROOT/'challenge/public'
    for file in public.rglob('*'):
        if not file.is_file():continue
        status,data=request(args.url+'/'+file.relative_to(public).as_posix())
        assert status==200 and data==file.read_bytes()
        assert receipt not in data and code.encode() not in data and code.lower().encode() not in data and packed not in data,file
    print('PASS every public asset matches its served bytes; no plaintext/packed answer or receipt')
    for path in ('/private/flag.txt','/runtime.py','/server.py','/src/host.c','/organizer/solve.py','/.git/config','/app.js.map',
                 '/downloads/../private/flag.txt','/downloads/%2e%2e/%2e%2e/private/flag.txt','/%2e%2e/private/flag.txt',
                 '/downloads/%252e%252e/private/flag.txt','/api/receipt','/api/flag'):
        status,data=request(args.url+path);assert status==404 and receipt not in data,(path,status)
    print('PASS private-file and traversal probes; guessed flag/receipt endpoints rejected')
    for body in ({},{'license':None},{'license':123},{'license':[]},{'license':'RCC{sample_not_a_receipt}'},[],
                 {'accepted':True,'win':True,'license':'AAAA'},{'license':'A'*500}):
        status,data=request(args.url+'/api/activate',body);assert status==400 and receipt not in data,body
    for data,expected in ((b'{',400),(b'x'*2049,413)):
        status,_=request(args.url+'/api/activate',data,True,{'Content-Type':'application/json'});assert status==expected
    status,_=request(args.url+'/api/activate',b'license='+code.encode(),True,{'Content-Type':'text/plain'});assert status==415
    print('PASS malformed JSON, bad types, client success claims, body size, content type')
    words=[int(x,16) for x in code.split('-')]
    candidates=[[0]*8,[65535]*8]
    for word in range(8):
        for bit in range(16):
            changed=words[:];changed[word]^=1<<bit;candidates.append(changed)
    rng=random.Random(20101023)
    candidates.extend([[rng.randrange(65536) for _ in range(8)] for _ in range(24)])
    for candidate in candidates:
        altered='-'.join(f'{x:04X}' for x in candidate)
        assert not emulate(memory,details['entry'],candidate)[0]
        status,data=request(args.url+'/api/activate',{'license':altered,'accepted':True,'score':999999})
        assert status==403 and receipt not in data
    print(f'PASS {len(candidates)} invalid codes: every single-bit mutation, sample license, random vectors')
    # Intended evidence is essential; each bank affects required bytes.
    for bank in range(4):
        damaged=dict(files);damaged[f'bank-{bank}.dimm']=bytes(1056)
        try:recovered=recover(damaged)
        except (AssertionError,ValueError,IndexError,KeyError):continue
        assert recovered[0]!=code
    print('PASS missing/corrupt backing banks cannot recover the valid code')
    original_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'challenge/public/downloads').iterdir()}
    subprocess.run([sys.executable,str(ROOT/'organizer/generate.py')],check=True,stdout=subprocess.DEVNULL)
    new_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'challenge/public/downloads').iterdir()}
    assert original_hashes==new_hashes
    print('PASS regeneration is byte-identical, including ZIP and WASM')
    process=subprocess.Popen([sys.executable,str(ROOT/'challenge/server.py'),'--port','19102'],stdout=subprocess.DEVNULL)
    try:
        for _ in range(50):
            try:
                status,_=request('http://127.0.0.1:19102/api/status')
                if status==200:break
            except OSError:time.sleep(.1)
        restarted=load_bundle('http://127.0.0.1:19102/downloads/ramcloud-player.zip');assert restarted==files
        status,other=request('http://127.0.0.1:19102/api/activate',{'license':code});assert status==200
        assert json.loads(other)['receipt'].encode()==receipt
    finally:process.terminate();process.wait(timeout=5)
    print('PASS fresh service instance returns identical puzzle and receipt')
    print('All service and artifact checks passed.')

if __name__=='__main__':main()
