# RAMCloud maintenance

Run project tools inside the configured Condev workspace. Stage this entire challenge folder with the `condev-development` skill's `stage_tree.ps1` and require zero SHA-256 differences before testing. Copy generated artifacts and screenshots back, then stage the final tree again.

The committed player kit needs no compiler at deployment. Regeneration uses Python 3.12 and Clang/LLD 21.1.8 for byte-identical WASM. From this challenge folder:

```bash
python3 organizer/generate.py
python3 organizer/solve.py --url http://host.docker.internal:18102
python3 organizer/test.py --url http://host.docker.internal:18102
python3 organizer/check_walkthrough.py --url http://host.docker.internal:18102
/tmp/rowdy-ctf-tools/bin/python organizer/browser_check.py \
  --url http://host.docker.internal:18102 --browser /usr/bin/chromium-browser
```

Use `http://localhost:18102` for a server in the same network namespace. The artifact test temporarily uses port 19102 for fresh-instance comparison and stops that process afterward. Browser tools require `organizer/requirements.txt` and Chromium; screenshots are organizer-only. Use an HTTPS reverse proxy for remote hosting, including clipboard support.

The metadata advisory and explicitly invalid calibration receipt in `package-index.json` are experimental challenge content. They are outside mapped memory and checker inputs. Keep their sample labels; they do not provide access control. Scripted checks are not human playtesting, and deterrent effectiveness remains unproven.
