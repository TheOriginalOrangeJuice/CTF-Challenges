#include <stdint.h>
#define EXPORT __attribute__((visibility("default")))
static uint8_t index_data[144];
static uint8_t packages[4][1056];
static uint8_t license_data[16];
static uint32_t faults;
static uint16_t touched;
static int valid;
EXPORT uint8_t *index_buffer(void) { return index_data; }
EXPORT uint8_t *package_buffer(uint32_t p) { return p < 4 ? packages[p] : (uint8_t *)0; }
EXPORT uint8_t *license_buffer(void) { return license_data; }
static uint16_t little(const uint8_t *p) { return p[0] | ((uint16_t)p[1] << 8); }
static uint8_t rol8(uint8_t x, uint8_t n) { return (uint8_t)((x << n) | (x >> (8-n))); }
static uint16_t rol16(uint16_t x, uint8_t n) { n &= 15; return n ? (uint16_t)((x << n) | (x >> (16-n))) : x; }
EXPORT uint32_t translate(uint32_t address) {
    if (address >= 4096) return 0xffffffff;
    uint8_t page = address >> 8, off = address & 255;
    for (unsigned i = 0; i < 16; i++) {
        uint8_t *d = index_data + 16 + i * 8;
        if ((uint8_t)(d[0] ^ 0xa7) != page) continue;
        uint8_t p = d[1], slot = d[2] ^ (uint8_t)(page * 7 + 0x39);
        if (p >= 4 || slot >= 4 || d[4] < 1 || d[4] > 7) return 0xffffffff;
        uint8_t lane = rol8(off, d[4]) ^ d[3];
        if (!(touched & (1u << page))) { touched |= 1u << page; faults++; }
        return ((uint32_t)p << 24) | (32 + (uint32_t)slot * 256 + lane);
    }
    return 0xffffffff;
}
static uint8_t read8(uint32_t a) {
    uint32_t loc = translate(a);
    if (loc == 0xffffffff) { valid = 0; return 0; }
    return packages[loc >> 24][loc & 0xffffff] ^ (uint8_t)((a >> 8) * 29 + (a & 255) * 7 + 0x5d);
}
static uint16_t read16(uint32_t a) { return read8(a) | ((uint16_t)read8(a+1) << 8); }
EXPORT uint32_t page_faults(void) { return faults; }
EXPORT void clear_faults(void) { faults = 0; touched = 0; }
EXPORT uint32_t check(void) {
    uint16_t r[16] = {0};
    uint32_t pc = little(index_data + 4), steps = 0;
    valid = 1;
    if (little(index_data+6) != 16) return 0;
    while (pc < 4096 && ++steps < 10000) {
        uint8_t op = read8(pc++), a, b;
        uint16_t n;
        switch (op) {
            case 0x17: a=read8(pc++); b=read8(pc++); if(a>15||b>7)return 0; r[a]=little(license_data+b*2); break;
            case 0x2d: a=read8(pc++); n=read16(pc); pc+=2; if(a>15)return 0; r[a]=n; break;
            case 0x53: a=read8(pc++); b=read8(pc++); if(a>15||b>15)return 0; r[a]=r[b]; break;
            case 0x84: a=read8(pc++); b=read8(pc++); if(a>15||b>15)return 0; r[a]+=r[b]; break;
            case 0xa6: a=read8(pc++); b=read8(pc++); if(a>15||b>15)return 0; r[a]^=r[b]; break;
            case 0x39: a=read8(pc++); b=read8(pc++); if(a>15)return 0; r[a]=rol16(r[a],b); break;
            case 0x62: a=read8(pc++); b=read8(pc++); if(a>15||b>15)return 0; r[a]=read16(r[b]); break;
            case 0x71: a=read8(pc++); n=read16(pc); pc+=2; if(a>15)return 0; r[a]+=n; break;
            case 0xc3: a=read8(pc++); n=read16(pc); pc+=2; if(a>15)return 0; if(r[a])pc+=(int16_t)n; break;
            case 0xe1: a=read8(pc++); b=read8(pc++); if(a>15||b>15)return 0; valid &= r[a]==r[b]; break;
            case 0x46: a=read8(pc++); b=read8(pc++); if(a>15||b>15)return 0; n=r[a]; r[a]=r[b]; r[b]=n; break;
            case 0x99: a=read8(pc++); if(a>15)return 0; r[a]--; break;
            case 0xbd: n=read16(pc); pc+=2; pc+=(int16_t)n; break;
            case 0xf0: return valid;
            default: return 0;
        }
    }
    return 0;
}
