'use strict';
const $ = selector => document.querySelector(selector);
let host = null, mounted = false, busy = false;
const banks = ['bank-0.dimm','bank-1.dimm','bank-2.dimm','bank-3.dimm'];
const downloads = [
  ['ramcloud-host.wasm','The diagnostic host interpreter'],['pages.rci','RAMCloud page index'],
  ...banks.map((name,i)=>[name,`Downloaded memory bank ${i+1} / 4 GB virtual capacity`]),
  ['package-index.json','Package inventory and diagnostic metadata'],['diagnostic-trace.txt','Reference capture from the memory bus'],['START_HERE.txt','Diagnostic kit introduction']
];
function view(name) {
  if (!['overview','diagnostics','downloads','sponsor'].includes(name)) name='overview';
  document.querySelectorAll('.view').forEach(el=>el.hidden=el.id!==name);
  document.querySelectorAll('.nav').forEach(el=>{
    const current=el.dataset.view===name;
    el.classList.toggle('active',current);
    if(current)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current');
  });
  history.replaceState(null,'','#'+name);
  if (name==='diagnostics') drawChart([]);
}
document.querySelectorAll('[data-view],[data-switch]').forEach(button=>button.addEventListener('click',()=>view(button.dataset.view||button.dataset.switch)));
$('.brand').addEventListener('click',()=>view('overview'));
view(location.hash.slice(1));
for (const [name,description] of downloads) {
  const row=document.createElement('div');row.className='download-row';
  const title=document.createElement('strong');title.textContent=name;
  const details=document.createElement('span');details.textContent=description;
  const link=document.createElement('a');link.href='/downloads/'+name;link.download=name;link.textContent='Save ↓';
  row.append(title,details,link);$('#download-list').append(row);
}
async function fetchBytes(name) {
  const response=await fetch('/downloads/'+name);
  if(!response.ok)throw Error('A memory package could not be downloaded. Please try again.');
  return new Uint8Array(await response.arrayBuffer());
}
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function updateFaults() { $('#fault-count').textContent=host?host.page_faults():0; }
async function install() {
  if(busy)return;
  busy=true;$('#install').disabled=true;$('#hero-install').disabled=true;
  $('#install-status').classList.remove('error');
  try {
    $('#install-status').textContent='Connecting to the imaginary memory cloud…';
    const wasm=await fetchBytes('ramcloud-host.wasm');
    host=(await WebAssembly.instantiate(wasm,{})).instance.exports;
    new Uint8Array(host.memory.buffer,host.index_buffer(),144).set(await fetchBytes('pages.rci'));
    for(let i=0;i<4;i++) {
      $('#install-status').textContent=`Downloading and mounting DIMM ${i+1} of 4…`;
      const bytes=await fetchBytes(banks[i]);
      new Uint8Array(host.memory.buffer,host.package_buffer(i),1056).set(bytes);
      await sleep(180);
      const bank=$('#ram-banks').children[i];bank.classList.add('mounted');bank.querySelector('small').textContent='4 GB • mounted';
      $('#install-progress').value=(i+1)*25;$('#memory-value').innerHTML=`${(i+1)*4} <small>GB</small>`;
    }
    mounted=true;host.clear_faults();$('#diag-capacity').textContent='16 GB';
    $('#memory-state').textContent='All banks online';$('#memory-state').classList.add('ready');
    $('#install-status').textContent='16 GB of WAM mounted. Your virtual memory is ready.';
    $('#install').textContent='Reinstall memory';$('#hero-install').textContent='✓ 16 GB downloaded';
    probe();updateFaults();
  } catch(error) { $('#install-status').textContent=error.message;$('#install-status').classList.add('error'); }
  finally { busy=false;$('#install').disabled=false;$('#hero-install').disabled=false; }
}
$('#install').addEventListener('click',install);$('#hero-install').addEventListener('click',install);
function probe() {
  if(!mounted) { $('#probe-output').textContent='Install your WAM from the Overview tab first.';return; }
  const value=$('#probe-address').value.trim().replace(/^0x/i,'');
  if(!/^[0-9a-f]{1,4}$/i.test(value)||parseInt(value,16)>4095) { $('#probe-output').textContent='Address must be between 0x0000 and 0x0FFF.';return; }
  const addr=parseInt(value,16), loc=host.translate(addr)>>>0, bank=loc>>>24, offset=loc&0xffffff;
  if(loc===0xffffffff){$('#probe-output').textContent='Page mapping is unavailable.';return;}
  const raw=new Uint8Array(host.memory.buffer,host.package_buffer(bank)+offset,1)[0];
  $('#probe-output').textContent=`Virtual address  0x${addr.toString(16).padStart(4,'0').toUpperCase()}\nBacking package  bank-${bank}.dimm\nFile offset      0x${offset.toString(16).padStart(4,'0').toUpperCase()}\nBacking byte     0x${raw.toString(16).padStart(2,'0').toUpperCase()}`;
  updateFaults();
}
$('#probe-form').addEventListener('submit',event=>{event.preventDefault();probe();});
$('#clear-faults').addEventListener('click',()=>{if(host)host.clear_faults();updateFaults();});
function drawChart(values) {
  const canvas=$('#benchmark-chart'),ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;
  ctx.clearRect(0,0,w,h);ctx.fillStyle='#f8fcfe';ctx.fillRect(0,0,w,h);ctx.strokeStyle='#dfedf3';ctx.lineWidth=1;
  for(let y=20;y<h;y+=30){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
  for(let x=20;x<w;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,h);ctx.stroke();}
  if(!values.length){ctx.fillStyle='#9ab2bf';ctx.font='12px Segoe UI';ctx.fillText('WAMBench • license checks / second',20,h/2);return;}
  const max=Math.max(...values)*1.2;ctx.beginPath();ctx.moveTo(0,h);
  values.forEach((v,i)=>ctx.lineTo(i*w/19,h-15-v/max*(h-30)));ctx.lineTo((values.length-1)*w/19,h);ctx.closePath();
  const fill=ctx.createLinearGradient(0,0,0,h);fill.addColorStop(0,'#75bd6c99');fill.addColorStop(1,'#75bd6c10');ctx.fillStyle=fill;ctx.fill();
  ctx.beginPath();values.forEach((v,i)=>i?ctx.lineTo(i*w/19,h-15-v/max*(h-30)):ctx.moveTo(0,h-15-v/max*(h-30)));ctx.strokeStyle='#5ca65c';ctx.lineWidth=2;ctx.stroke();
}
$('#benchmark').addEventListener('click',async()=>{
  if(!mounted){$('#bench-status').textContent='Install your WAM from the Overview tab first.';return;}
  if(busy)return;busy=true;$('#benchmark').disabled=true;const values=[];
  new Uint8Array(host.memory.buffer,host.license_buffer(),16).fill(0);
  for(let sample=0;sample<20;sample++) {
    const start=performance.now();for(let i=0;i<128;i++)host.check();const elapsed=performance.now()-start;
    values.push(128000/Math.max(elapsed,.01));drawChart(values);$('#bench-status').textContent=`Testing virtual memory… ${Math.round((sample+1)/20*100)}%`;
    updateFaults();await sleep(35);
  }
  $('#bench-result').textContent=Math.round(values.reduce((a,b)=>a+b,0)/values.length).toLocaleString()+' checks / sec';
  $('#bench-status').textContent='Complete. 2,560 calibration checks. More WAM, fewer excuses.';
  $('#benchmark').disabled=false;busy=false;
});
$('#activation-form').addEventListener('submit',async event=>{
  event.preventDefault();const value=$('#license').value.trim().toUpperCase(),status=$('#activation-status');status.classList.remove('error','success');
  if(!/^[0-9A-F]{4}(?:-[0-9A-F]{4}){7}$/.test(value)){status.textContent='Use eight groups of four hexadecimal digits.';status.classList.add('error');return;}
  if(!mounted){status.textContent='Install your WAM before running the license checker.';return;}
  if(busy){status.textContent='Please wait for the current diagnostic to finish.';return;}
  $('#activate').disabled=true;
  try {
    const data=new DataView(host.memory.buffer);value.split('-').forEach((word,i)=>data.setUint16(host.license_buffer()+i*2,parseInt(word,16),true));
    const local=host.check();updateFaults();status.textContent=local?'Local check passed. Contacting activation service…':'Checking with the activation service…';
    const response=await fetch('/api/activate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({license:value})});
    const result=await response.json();
    if(!response.ok||!result.accepted)throw Error(result.error||'Activation was not accepted.');
    $('#flag').textContent=result.receipt;$('#receipt').hidden=false;status.textContent=result.message;status.classList.add('success');
    $('#memory-state').textContent='Unlimited activated';$('#activate').textContent='✓ Unlimited WAM activated';
  }catch(error){status.textContent=error.message;status.classList.add('error');$('#receipt').hidden=true;}
  finally{$('#activate').disabled=false;}
});
$('#copy-receipt').addEventListener('click',async()=>{try{await navigator.clipboard.writeText($('#flag').textContent);$('#copy-receipt').textContent='Copied!';}catch{$('#activation-status').textContent='Select the receipt text to copy it.';}});
$('#reset').addEventListener('click',()=>location.assign(location.pathname));
fetch('/downloads/diagnostic-trace.txt').then(r=>r.text()).then(trace=>$('#reference-trace').textContent=trace).catch(()=>$('#reference-trace').textContent='The reference trace is available in Downloads.');
drawChart([]);
