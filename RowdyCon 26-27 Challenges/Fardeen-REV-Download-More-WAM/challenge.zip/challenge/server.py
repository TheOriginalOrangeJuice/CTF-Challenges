#!/usr/bin/env python3
"""RAMCloud: standard library HTTP server with a strict public-file boundary."""
import argparse
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit
from runtime import Memory, parse_license, verify

ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT / 'public'
MEMORY = Memory(PUBLIC / 'downloads')
FLAG = (ROOT / 'private' / 'flag.txt').read_text().strip()
MIMES = {'.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript',
         '.svg': 'image/svg+xml', '.wasm': 'application/wasm', '.json': 'application/json',
         '.txt': 'text/plain; charset=utf-8', '.zip': 'application/zip'}
FILES = {'/' + p.relative_to(PUBLIC).as_posix(): p for p in PUBLIC.rglob('*') if p.is_file() and not p.is_symlink()}
FILES['/'] = PUBLIC / 'index.html'

class Handler(BaseHTTPRequestHandler):
    server_version = 'RAMCloud/2.0'

    def respond(self, status, body, mime='application/json'):
        if not isinstance(body, bytes): body = json.dumps(body, separators=(',', ':')).encode()
        self.send_response(status)
        self.send_header('Content-Type', mime)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers()
        if self.command != 'HEAD': self.wfile.write(body)

    def do_GET(self):
        path = unquote(urlsplit(self.path).path)
        if path == '/api/status':
            return self.respond(200, {'service': 'RAMCloud', 'build': '2010.10.23', 'available': True})
        file = FILES.get(path)
        if file is None: return self.respond(404, {'error': 'Not found'})
        return self.respond(200, file.read_bytes(), MIMES.get(file.suffix, 'application/octet-stream'))

    do_HEAD = do_GET

    def do_POST(self):
        if urlsplit(self.path).path != '/api/activate': return self.respond(404, {'error': 'Not found'})
        try:
            size = int(self.headers.get('Content-Length', '0'))
            if not 0 < size <= 2048: return self.respond(413, {'error': 'Request body must be 1–2048 bytes.'})
            if self.headers.get('Content-Type', '').split(';')[0].strip() != 'application/json':
                return self.respond(415, {'error': 'Send JSON.'})
            body = json.loads(self.rfile.read(size))
            words = parse_license(body.get('license')) if isinstance(body, dict) else None
        except (ValueError, UnicodeDecodeError):
            return self.respond(400, {'error': 'Invalid request.'})
        if words is None:
            return self.respond(400, {'error': 'Use eight groups of four hexadecimal digits.'})
        if not verify(MEMORY, words):
            return self.respond(403, {'accepted': False, 'error': 'This activation code does not match your downloaded WAM.'})
        return self.respond(200, {'accepted': True, 'tier': 'Unlimited WAM', 'receipt': FLAG,
                                  'message': 'You finally have enough dedotated WAM.'})

    def log_message(self, fmt, *args):
        # Never log activation requests or receipts.
        print('[RAMCloud] ' + fmt % args, flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=18102)
    args = parser.parse_args()
    server = ThreadingHTTPServer(('0.0.0.0', args.port), Handler)
    server.daemon_threads = True
    print(f'RAMCloud listening on {args.port}', flush=True)
    server.serve_forever()
