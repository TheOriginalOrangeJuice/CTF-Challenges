"""Private service VM. Nothing in this module is served as a download."""
from pathlib import Path
import re
import struct

ROOT = Path(__file__).resolve().parent

class Memory:
    def __init__(self, directory):
        directory = Path(directory)
        self.index = (directory / 'pages.rci').read_bytes()
        self.packages = [(directory / f'bank-{i}.dimm').read_bytes() for i in range(4)]
        self.entry = struct.unpack_from('<H', self.index, 4)[0]
        self.rows = {self.index[i] ^ 0xa7: self.index[i:i+8] for i in range(16, 144, 8)}

    def byte(self, address):
        if not 0 <= address < 4096:
            raise ValueError('Unmapped address')
        page, offset = divmod(address, 256)
        d = self.rows[page]
        slot = d[2] ^ ((page * 7 + 0x39) & 255)
        lane = (((offset << d[4]) | (offset >> (8 - d[4]))) & 255) ^ d[3]
        raw = self.packages[d[1]][32 + slot * 256 + lane]
        return raw ^ ((page * 29 + offset * 7 + 0x5d) & 255)

    def word(self, address):
        return self.byte(address) | (self.byte(address+1) << 8)

def parse_license(value):
    if not isinstance(value, str) or not re.fullmatch(r'[0-9A-Fa-f]{4}(?:-[0-9A-Fa-f]{4}){7}', value.strip()):
        return None
    return [int(part, 16) for part in value.strip().split('-')]

def verify(memory, words):
    if not isinstance(words, list) or len(words) != 8 or any(type(x) is not int or not 0 <= x <= 65535 for x in words):
        return False
    r, pc, valid = [0] * 16, memory.entry, True
    try:
        for _ in range(10000):
            op = memory.byte(pc)
            pc += 1
            if op == 0xf0:
                return valid
            if op == 0xbd:
                n = memory.word(pc); pc += 2
                pc += n if n < 32768 else n - 65536
                continue
            a = memory.byte(pc); pc += 1
            if a >= 16:
                return False
            if op == 0x99:
                r[a] = (r[a] - 1) & 65535
                continue
            if op in (0x2d, 0x71, 0xc3):
                n = memory.word(pc); pc += 2
                if op == 0x2d: r[a] = n
                elif op == 0x71: r[a] = (r[a] + n) & 65535
                elif r[a]: pc += n if n < 32768 else n - 65536
                continue
            b = memory.byte(pc); pc += 1
            if op == 0x17:
                if b >= 8: return False
                r[a] = words[b]
                continue
            if op == 0x39:
                n = b & 15
                r[a] = ((r[a] << n) | (r[a] >> ((16 - n) & 15))) & 65535
                continue
            if b >= 16: return False
            if op == 0x53: r[a] = r[b]
            elif op == 0x84: r[a] = (r[a] + r[b]) & 65535
            elif op == 0xa6: r[a] ^= r[b]
            elif op == 0x62: r[a] = memory.word(r[b])
            elif op == 0xe1: valid &= r[a] == r[b]
            elif op == 0x46: r[a], r[b] = r[b], r[a]
            else: return False
    except (ValueError, IndexError, KeyError):
        return False
    return False
