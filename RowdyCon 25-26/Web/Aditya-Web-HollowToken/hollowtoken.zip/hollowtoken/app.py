# app.py -- RowdyToken (RowdyCon edition)
# Intentionally vulnerable CTF challenge demonstrating JWT algorithm confusion / alg:none

from flask import Flask, request, jsonify, render_template_string
import os
import jwt
from jwt import InvalidTokenError
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

# generate ephemeral RSA keypair at startup
def generate_rsa_keypair():
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    priv_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.TraditionalOpenSSL,
        encryption_algorithm=serialization.NoEncryption()
    )
    pub_pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return priv_pem.decode("utf-8"), pub_pem.decode("utf-8")

PRIVATE_PEM, PUBLIC_PEM = generate_rsa_keypair()

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "rowdytoken_secret_change_me")

# visible accounts; admin flag is hidden behind token abuse
USERS = {
    "volunteer": {"password": "birdsup", "role": "user"},
    "speaker":   {"password": "keynote", "role": "user"},
    "admin":     {"password": "adminpw?", "role": "admin", "flag": "RCCTF{r0wdyt0k3n_alg_c0nfus10n}"}
}

INDEX_HTML = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>UTSA RowdyCon — RowdyToken Auth</title>
  <style>
    body {
      background: linear-gradient(180deg, #0a0f1f, #111827);
      color: #f3f4f6;
      font-family: "Segoe UI", Roboto, Arial, sans-serif;
      padding: 28px;
    }
    .card {
      background: #0f172a;
      border-radius: 10px;
      padding: 20px;
      max-width: 960px;
      margin: auto;
      box-shadow: 0 12px 36px rgba(0,0,0,0.55);
      border: 1px solid #e87511;
    }
    h1 {
      color: #e87511;
      letter-spacing: 1px;
    }
    code {
      background: #020617;
      color: #f59e0b;
      padding: 3px 6px;
      border-radius: 4px;
    }
    .creds {
      background: #111827;
      padding: 10px;
      border-radius: 6px;
    }
    .small {
      color: #d1d5db;
      font-size: 0.95em;
    }
    pre.pem {
      background: #020617;
      color: #bbf7d0;
      padding: 8px;
      border-radius: 6px;
      overflow: auto;
      max-height: 160px;
    }
    a {
      color: #f59e0b;
      text-decoration: none;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>UTSA RowdyCon — RowdyToken Auth</h1>
    <p class="small">
      The RowdyCon authentication service issues cryptographic tokens for conference staff and speakers.
      The backend looks modern, but one weak validation path may let you forge more than you should.
    </p>

    <h3>Visible test accounts</h3>
    <div class="creds">
      <ul>
        <li><code>volunteer / birdsup</code></li>
        <li><code>speaker / keynote</code></li>
      </ul>
    </div>

    <p class="small">API endpoints:</p>
    <ul class="small">
      <li><code>POST /login</code> — JSON <code>{"username","password"}</code></li>
      <li><code>GET /pubkey</code> — returns public RSA key (PEM)</li>
      <li><code>GET /secrets</code> — admin-only endpoint</li>
    </ul>

    <hr>
    <p class="small">
      Your goal: obtain admin access and retrieve the protected RowdyCon secret.
    </p>
  </div>
</body>
</html>
"""

@app.route("/")
def index():
    return render_template_string(INDEX_HTML)

@app.route("/pubkey")
def pubkey():
    return jsonify({"public_key": PUBLIC_PEM})

@app.route("/login", methods=["POST"])
def login():
    data = request.get_json(force=True, silent=True) or {}
    username = data.get("username", "")
    password = data.get("password", "")
    user = USERS.get(username)

    if not user or user.get("password") != password:
        return "Bad credentials", 401

    payload = {"user": username, "role": user.get("role", "user")}
    token = jwt.encode(payload, PRIVATE_PEM, algorithm="RS256")
    return jsonify({"token": token})

def verify_vulnerable(token):
    """
    Intentionally insecure verification for CTF:
    - Accepts alg == "none"
    - If alg == HS256, uses the RSA public key PEM as the HMAC secret
    - If alg == RS256, verifies normally with the public key
    """
    try:
      header = jwt.get_unverified_header(token)
    except Exception:
      raise InvalidTokenError("Invalid token header")

    alg = header.get("alg", "")

    if alg == "none":
        payload = jwt.decode(token, options={"verify_signature": False})
        return payload

    if alg == "RS256":
        payload = jwt.decode(token, PUBLIC_PEM, algorithms=["RS256"])
        return payload

    if alg == "HS256":
        payload = jwt.decode(token, PUBLIC_PEM, algorithms=["HS256"])
        return payload

    raise InvalidTokenError("unsupported alg")

@app.route("/secrets")
def secrets():
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return "Missing token", 401

    token = auth.split(None, 1)[1].strip()

    try:
        payload = verify_vulnerable(token)
    except Exception as e:
        return f"Invalid token: {str(e)}", 403

    if payload.get("role") != "admin":
        return "forbidden: admin only", 403

    flag = USERS.get("admin", {}).get("flag", "RCCTF{MISSING_FLAG}")
    return jsonify({
        "user": payload.get("user"),
        "role": payload.get("role"),
        "secret": flag
    })

if __name__ == "__main__":
    print("[boot] RowdyToken Auth running on :5010")
    app.run(host="0.0.0.0", port=9003, debug=False)