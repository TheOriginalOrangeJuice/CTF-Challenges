/*
 * RowdyCon Systems Corporate Intranet Portal
 * Version 4.0.1
 * (c) 1998 RowdyCon Systems, Inc.
 *
 * Developed by: Dave from IT
 * Last modified: 11/15/1998
 *
 * "If it ain't broke, don't fix it!" - Dave
 */

const express = require('express');
const cookieParser = require('cookie-parser');
const crypto = require('crypto');
const path = require('path');

const app = express();
const PORT = process.env.PORT;
const BOT_URL = process.env.BOT_URL || 'http://bot:3000';

if (!PORT) {
    console.error('ERROR: PORT environment variable is required.');
    console.error('Run via: docker compose up --build');
    process.exit(1);
}

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(cookieParser());

// ============================================
// In-Memory Database
// Dave says SQLite is "overkill for an intranet"
//
// Passwords are generated at startup for security.
// The bot service authenticates via shared env credentials.
// ============================================

function randomPassword() {
    return crypto.randomBytes(16).toString('hex');
}

const BOT_USERNAME = process.env.BOT_USERNAME || 'sarah_IT';
const BOT_PASSWORD = process.env.BOT_PASSWORD || crypto.randomBytes(16).toString('hex');

const users = [
    {
        id: 1,
        username: 'dave_IT',
        password: randomPassword(),
        display_name: 'Dave (IT Department)',
        department: 'Information Technology',
        role: 'admin',
        status_message: 'Deploying the new intranet portal!',
    },
    {
        id: 2,
        username: 'jenny_hr',
        password: randomPassword(),
        display_name: 'Jenny Martinez',
        department: 'Human Resources',
        role: 'employee',
        status_message: 'Organizing the company picnic!',
    },
    {
        id: 3,
        username: 'bob_accounting',
        password: randomPassword(),
        display_name: 'Bob Smith',
        department: 'Accounting',
        role: 'employee',
        status_message: 'Has anyone seen my TPS reports?',
    },
    {
        id: 4,
        username: 'susan_marketing',
        password: randomPassword(),
        display_name: 'Susan Chen',
        department: 'Marketing',
        role: 'employee',
        status_message: 'Working on the new company website!',
    },
    {
        id: 5,
        username: BOT_USERNAME,
        password: BOT_PASSWORD,
        display_name: 'Sarah Lopez (IT Support)',
        department: 'Information Technology',
        role: 'employee',
        status_message: 'Reviewing help desk tickets as usual...',
    },
];

const announcements = [
    {
        id: 1,
        title: 'Welcome to the New Intranet Portal!',
        content: 'The IT department is proud to announce our new intranet portal. Report any issues to the IT Help Desk.',
        author: 'Dave (IT Department)',
        date: '11/10/1998',
        priority: 'normal',
    },
    {
        id: 2,
        title: 'Company Picnic This Friday!',
        content: 'Bring your own floppy disks and don\'t forget sunscreen. RSVP to Jenny in HR.',
        author: 'Jenny Martinez (HR)',
        date: '11/12/1998',
        priority: 'normal',
    },
    {
        id: 3,
        title: 'Y2K Compliance Update',
        content: 'All systems are being tested for Y2K readiness. Please do NOT change your system clocks.',
        author: 'Dave (IT Department)',
        date: '11/14/1998',
        priority: 'high',
    },
    {
        id: 4,
        title: 'SECURITY REMINDER',
        content: 'Please stop downloading screensavers from the internet. We\'ve had 3 virus incidents this month.',
        author: 'Dave (IT Department)',
        date: '11/15/1998',
        priority: 'high',
    },
];

const helpdeskTickets = [
    {
        id: 1,
        subject: 'Search page showing weird characters',
        submitter: 'jenny_hr',
        status: 'resolved',
        date: '11/08/1998',
        notes: 'Resolved: User clicked a link from an email that had special characters in the URL fragment. No action needed.',
    },
    {
        id: 2,
        subject: 'Cannot access Admin Panel',
        submitter: 'bob_accounting',
        status: 'closed',
        date: '11/09/1998',
        notes: 'Closed: Admin panel is restricted to IT department. This is by design.',
    },
    {
        id: 3,
        subject: 'Printer on 3rd floor not responding',
        submitter: 'bob_accounting',
        status: 'resolved',
        date: '11/11/1998',
        notes: 'Resolved: Printer was unplugged. Plugged it back in.',
    },
];

// ============================================
// Session Management
// Using secure random tokens (Dave's finest work)
//
// Sessions store a COPY of the user's data at login time.
// Profile updates modify the session, not the shared user record.
// This isolates each login from others.
// ============================================

const sessions = new Map();

function createSession(user) {
    const token = crypto.randomBytes(32).toString('hex');
    sessions.set(token, {
        userId: user.id,
        username: user.username,
        display_name: user.display_name,
        department: user.department,
        role: user.role,
        status_message: user.status_message,
        createdAt: Date.now(),
    });
    return token;
}

function getSession(req) {
    const token = req.cookies.session;
    if (!token) return null;
    return sessions.get(token) || null;
}

// ============================================
// Auth Middleware
// ============================================

function requireAuth(req, res, next) {
    const session = getSession(req);
    if (!session) {
        return res.status(401).json({ error: 'Authentication required. Please sign in.' });
    }
    req.session = session;
    next();
}

function requireAdmin(req, res, next) {
    requireAuth(req, res, function() {
        if (req.session.role !== 'admin') {
            return res.status(403).json({
                error: 'Access denied. Administrator privileges required.',
                message: 'Contact Dave in IT if you believe this is an error.',
            });
        }
        next();
    });
}

// ============================================
// Rate Limiting (simple per-IP)
// ============================================

const rateLimits = new Map();

function rateLimit(windowMs, maxRequests) {
    return function(req, res, next) {
        const ip = req.ip;
        const now = Date.now();
        const key = ip + ':' + req.path;

        if (!rateLimits.has(key)) {
            rateLimits.set(key, { count: 1, resetAt: now + windowMs });
            return next();
        }

        const entry = rateLimits.get(key);
        if (now > entry.resetAt) {
            entry.count = 1;
            entry.resetAt = now + windowMs;
            return next();
        }

        if (entry.count >= maxRequests) {
            return res.status(429).json({
                error: 'Too many requests. Please wait before trying again.',
            });
        }

        entry.count++;
        next();
    };
}

// ============================================
// Public Routes
// ============================================

app.get('/api/health', function(req, res) {
    res.json({ status: 'ok', service: 'RowdyCon Intranet Portal' });
});

// Employee Directory - public, no auth required
// Shows canonical user data (not session-modified data)
app.get('/api/directory', function(req, res) {
    var directory = users.map(function(u) {
        return {
            id: u.id,
            username: u.username,
            display_name: u.display_name,
            department: u.department,
            status_message: u.status_message,
        };
    });
    res.json(directory);
});

app.get('/api/announcements', function(req, res) {
    res.json(announcements);
});

app.get('/api/helpdesk/tickets', function(req, res) {
    res.json(helpdeskTickets);
});

// ============================================
// Authentication Routes
// Using parameterized lookups for safety (Dave learned this the hard way)
// ============================================

app.post('/api/login', function(req, res) {
    var username = req.body.username;
    var password = req.body.password;

    if (!username || !password) {
        return res.status(400).json({ error: 'Username and password are required.' });
    }

    var user = users.find(function(u) {
        return u.username === username && u.password === password;
    });

    if (!user) {
        return res.status(401).json({ error: 'Invalid credentials. Please try again.' });
    }

    var token = createSession(user);
    res.cookie('session', token, {
        httpOnly: false,
        secure: false,
        sameSite: 'Lax',
        maxAge: 24 * 60 * 60 * 1000,
    });

    res.json({
        success: true,
        message: 'Welcome back, ' + user.display_name + '!',
        user: sessionToProfile(sessions.get(token)),
    });
});

app.post('/api/logout', requireAuth, function(req, res) {
    var token = req.cookies.session;
    sessions.delete(token);
    res.clearCookie('session');
    res.json({ success: true, message: 'Signed out successfully.' });
});

app.get('/api/profile', requireAuth, function(req, res) {
    res.json(sessionToProfile(req.session));
});

// Profile update endpoint
// TODO: add input validation - only allow display_name, department, status_message
// For now, just merge everything (Dave says it's fine since it's an internal app)
app.put('/api/profile', requireAuth, function(req, res) {
    var updates = req.body;

    // Don't allow changing id, username, or password
    delete updates.userId;
    delete updates.username;
    delete updates.password;
    delete updates.createdAt;

    Object.assign(req.session, updates);

    res.json({
        success: true,
        message: 'Profile updated successfully!',
        user: sessionToProfile(req.session),
    });
});

// ============================================
// IT Help Desk - URL Report (Bot Integration)
// ============================================

app.post('/api/helpdesk/report', rateLimit(5000, 1), async function(req, res) {
    var url = req.body.url;

    if (!url || typeof url !== 'string') {
        return res.status(400).json({ error: 'URL is required.' });
    }

    // Must be a valid HTTP(S) URL
    if (!url.match(/^https?:\/\//i)) {
        return res.status(400).json({ error: 'Please provide a valid HTTP or HTTPS URL.' });
    }

    // Rewrite the hostname to Docker-internal name so the bot can reach it
    try {
        var parsedUrl = new URL(url);
        parsedUrl.hostname = 'main-app';
        parsedUrl.port = PORT;
        var internalUrl = parsedUrl.toString();
    } catch (e) {
        return res.status(400).json({ error: 'Invalid URL format.' });
    }

    try {
        await fetch(BOT_URL + '/visit', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url: internalUrl }),
        });
        res.json({
            success: true,
            message: 'Thank you! An IT staff member will review this page shortly.',
        });
    } catch (err) {
        console.error('[Helpdesk] Bot service error:', err.message);
        res.json({
            success: true,
            message: 'Thank you! An IT staff member will review this page shortly.',
        });
    }
});

// ============================================
// Admin Routes
// ============================================

app.get('/api/admin/dashboard', requireAdmin, function(req, res) {
    res.json({
        uptime: process.uptime(),
        users: users.length,
        sessions: sessions.size,
        tickets: helpdeskTickets.length,
        systemInfo: {
            os: 'Windows NT 4.0',
            server: 'IIS 4.0 (just kidding, it\'s Node.js)',
            network: 'RowdyCon Corporate LAN',
        },
        // Internal network topology - for IT reference
        // Services: main-app (this server), internal-app:5000 (program launcher)
        networkTopology: [
            { name: 'main-app', host: 'main-app', port: PORT, status: 'online', description: 'Corporate Intranet Portal' },
            { name: 'internal-app', host: 'internal-app', port: 5000, status: 'online', description: 'System Program Launcher' },
        ],
    });
});

app.get('/api/admin/users', requireAdmin, function(req, res) {
    res.json(users.map(function(u) {
        return {
            id: u.id,
            username: u.username,
            display_name: u.display_name,
            department: u.department,
            role: u.role,
            status_message: u.status_message,
        };
    }));
});

// Website Availability Checker
// Useful for verifying that intranet services are responding
app.post('/api/admin/check-website', requireAdmin, async function(req, res) {
    var url = req.body.url;

    if (!url || typeof url !== 'string') {
        return res.status(400).json({ error: 'URL is required.' });
    }

    // Validate URL format
    var parsedUrl;
    try {
        parsedUrl = new URL(url);
    } catch (e) {
        return res.status(400).json({ error: 'Invalid URL format.' });
    }

    // Security: Block requests to localhost and internal networks
    var hostname = parsedUrl.hostname.toLowerCase();
    var blockedHosts = ['localhost', '127.0.0.1', '::1', '0.0.0.0'];

    if (blockedHosts.includes(hostname)) {
        return res.status(403).json({
            error: 'Access denied: Cannot check localhost or loopback addresses.',
        });
    }

    // Block private IP ranges
    if (hostname.match(/^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/)) {
        return res.status(403).json({
            error: 'Access denied: Cannot check internal network addresses.',
        });
    }

    try {
        var controller = new AbortController();
        var timeout = setTimeout(function() { controller.abort(); }, 5000);

        var response = await fetch(url, {
            signal: controller.signal,
            redirect: 'follow',
        });
        clearTimeout(timeout);

        var text = await response.text();

        res.json({
            status: response.status,
            statusText: response.statusText,
            contentLength: text.length,
            preview: text.substring(0, 500),
            headers: Object.fromEntries(response.headers.entries()),
        });
    } catch (err) {
        res.status(500).json({
            error: 'Could not reach the specified URL: ' + err.message,
        });
    }
});

// ============================================
// Utility Functions
// ============================================

function sessionToProfile(session) {
    return {
        id: session.userId,
        username: session.username,
        display_name: session.display_name,
        department: session.department,
        role: session.role,
        status_message: session.status_message,
    };
}

// ============================================
// Start Server
// ============================================

app.listen(PORT, '0.0.0.0', function() {
    console.log('\n' +
        '    +==============================================+\n' +
        '    |     RowdyCon Corporate Intranet Portal       |\n' +
        '    |     Version 4.0.1                            |\n' +
        '    |     (c) 1998 RowdyCon Systems, Inc.          |\n' +
        '    |                                              |\n' +
        '    |     Running on port ' + PORT + '                    |\n' +
        '    |     http://localhost:' + PORT + '                    |\n' +
        '    +==============================================+\n'
    );
});
