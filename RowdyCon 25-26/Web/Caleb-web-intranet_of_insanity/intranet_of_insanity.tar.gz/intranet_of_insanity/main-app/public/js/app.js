/*
 * RowdyCon Corporate Intranet Portal
 * Version 4.0.1
 * (c) 1998 RowdyCon Systems, Inc.
 *
 * Developed by: Dave from IT
 * Last modified: 11/15/1998
 *
 * NOTE: Do NOT modify this file unless you have
 * written approval from the IT department.
 *
 * CHANGE LOG:
 * v4.0.1 - Added client-side search filtering for Employee Directory
 * v4.0.0 - New intranet portal with SPA navigation
 * v3.5.0 - Added admin panel with website checker
 * v3.4.0 - Added IT Help Desk page
 * v3.3.0 - Added profile management
 * v3.2.0 - Fixed Y2K compliance issues
 * v3.0.0 - Migrated from Netscape to IE support
 *
 * API ROUTES:
 * GET  /api/directory          - employee directory listing
 * GET  /api/announcements      - company announcements
 * GET  /api/helpdesk/tickets   - help desk tickets
 * POST /api/helpdesk/report    - report a problem page
 * POST /api/login              - authenticate
 * POST /api/logout             - sign out
 * GET  /api/profile            - current user profile
 * PUT  /api/profile            - update profile
 * GET  /api/admin/dashboard    - admin panel data
 * GET  /api/admin/users        - admin user list
 * POST /api/admin/check-website - website availability checker
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize system clock
    updateClock();
    setInterval(updateClock, 1000);

    // Set visitor counter
    document.getElementById('visitor-count').textContent =
        Math.floor(Math.random() * 9000) + 1000;

    // Initialize Clippy
    initClippy();

    // Wire up window controls
    initWindowControls();

    // Wire up forms
    document.getElementById('login-form').addEventListener('submit', doLogin);
    document.getElementById('profile-edit-form').addEventListener('submit', doProfileUpdate);
    document.getElementById('helpdesk-form').addEventListener('submit', doHelpdeskReport);
    document.getElementById('suggestion-form').addEventListener('submit', doSuggestion);

    // Load initial data
    loadDirectory();
    loadAnnouncements();
    loadTickets();

    // Check if user is already logged in
    checkSession();

    // Handle hash-based navigation and search
    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
});


// ============================================
// Navigation (SPA-style routing)
// ============================================

function navigate(page) {
    // Hide all pages
    var pages = document.querySelectorAll('.page');
    for (var i = 0; i < pages.length; i++) {
        pages[i].classList.remove('active');
    }

    // Show target page
    var target = document.getElementById('page-' + page);
    if (target) {
        target.classList.add('active');
    }

    // Update sidebar active state
    var links = document.querySelectorAll('.sidebar-link');
    for (var j = 0; j < links.length; j++) {
        links[j].classList.remove('active');
        if (links[j].textContent.toLowerCase().indexOf(page) !== -1) {
            links[j].classList.add('active');
        }
    }

    // Update address bar
    var addressField = document.getElementById('address-bar-url');
    if (addressField) {
        addressField.value = 'http://intranet.rowdycon.local/' + page;
    }

    // Load admin data if navigating to admin page
    if (page === 'admin') {
        loadAdminPanel();
    }

    // Load profile if navigating to profile page
    if (page === 'profile') {
        checkSession();
    }
}


// ============================================
// Hash-based Search Handler
// Employee Directory search - reads from URL hash
// ============================================

function handleHashChange() {
    var hash = location.hash;
    if (!hash) return;

    // Parse hash parameters (e.g., #search=query)
    var hashParams = new URLSearchParams(hash.substring(1));
    var searchQuery = hashParams.get('search');

    if (searchQuery) {
        // Navigate to directory page if not already there
        navigate('directory');

        // Display the search query
        var resultsHeader = document.getElementById('search-results-header');

        // Client-side XSS filter (Dave's "security" measure)
        var sanitized = sanitizeSearch(searchQuery);

        resultsHeader.style.display = 'block';
        resultsHeader.innerHTML = 'Search results for: <b>' + sanitized + '</b>';

        // Also filter the directory table
        filterDirectoryTable(searchQuery);
    }
}

/*
 * sanitizeSearch() - Client-side input sanitization for the search feature
 *
 * Security: Removes dangerous HTML patterns to prevent XSS attacks.
 * Dave added this after the security audit in Q3.
 *
 * Blocks:
 * - <script> tags (case-insensitive)
 * - Common event handlers: onerror, onload, onclick, onmouseover, onfocus, onblur
 * - javascript: URI protocol
 */
function sanitizeSearch(input) {
    var cleaned = input;
    // Remove <script> tags
    cleaned = cleaned.replace(/<script[\s>]/gi, '');
    cleaned = cleaned.replace(/<\/script>/gi, '');
    // Remove common dangerous event handlers
    cleaned = cleaned.replace(/onerror/gi, '');
    cleaned = cleaned.replace(/onload/gi, '');
    cleaned = cleaned.replace(/onclick/gi, '');
    cleaned = cleaned.replace(/onmouseover/gi, '');
    cleaned = cleaned.replace(/onfocus/gi, '');
    cleaned = cleaned.replace(/onblur/gi, '');
    // Remove javascript: URIs
    cleaned = cleaned.replace(/javascript\s*:/gi, '');
    return cleaned;
}

function doDirectorySearch() {
    var query = document.getElementById('directory-search-input').value;
    if (query) {
        location.hash = 'search=' + encodeURIComponent(query);
    }
}

function filterDirectoryTable(query) {
    var rows = document.querySelectorAll('#directory-tbody tr');
    var lowerQuery = query.toLowerCase();
    for (var i = 0; i < rows.length; i++) {
        var text = rows[i].textContent.toLowerCase();
        rows[i].style.display = text.indexOf(lowerQuery) !== -1 ? '' : 'none';
    }
}


// ============================================
// Employee Directory
// ============================================

function loadDirectory() {
    fetch('/api/directory')
        .then(function(r) { return r.json(); })
        .then(function(employees) {
            var tbody = document.getElementById('directory-tbody');
            tbody.innerHTML = '';
            employees.forEach(function(emp) {
                var tr = document.createElement('tr');
                tr.innerHTML =
                    '<td>' + escapeHtml(emp.display_name) + '</td>' +
                    '<td>' + escapeHtml(emp.department) + '</td>' +
                    '<td>' + escapeHtml(emp.status_message) + '</td>';
                tbody.appendChild(tr);
            });
        });
}


// ============================================
// Announcements
// ============================================

function loadAnnouncements() {
    fetch('/api/announcements')
        .then(function(r) { return r.json(); })
        .then(function(items) {
            var container = document.getElementById('announcements-container');
            container.innerHTML = '';
            items.forEach(function(item) {
                var card = document.createElement('div');
                card.className = 'announcement-card' + (item.priority === 'high' ? ' priority-high' : '');
                card.innerHTML =
                    '<div class="announcement-card-header">' +
                        '<strong>' + escapeHtml(item.title) + '</strong>' +
                        '<span class="announcement-card-date">' + escapeHtml(item.date) + '</span>' +
                    '</div>' +
                    '<div class="announcement-card-body">' +
                        escapeHtml(item.content) +
                        '<br><i style="color:#808080; font-size:10px;">— ' + escapeHtml(item.author) + '</i>' +
                    '</div>';
                container.appendChild(card);
            });
        });
}


// ============================================
// Help Desk
// ============================================

function loadTickets() {
    fetch('/api/helpdesk/tickets')
        .then(function(r) { return r.json(); })
        .then(function(tickets) {
            var container = document.getElementById('tickets-container');
            container.innerHTML = '';
            tickets.forEach(function(t) {
                var div = document.createElement('div');
                div.className = 'ticket';
                div.innerHTML =
                    '<span class="ticket-status ' + escapeHtml(t.status) + '">' + escapeHtml(t.status).toUpperCase() + '</span> ' +
                    '<b>#' + t.id + '</b> — ' + escapeHtml(t.subject) +
                    '<br><span style="color:#808080; font-size:10px;">' + escapeHtml(t.date) + ' | ' + escapeHtml(t.submitter) + '</span>' +
                    (t.notes ? '<br><i style="font-size:10px; color:#606060;">' + escapeHtml(t.notes) + '</i>' : '');
                container.appendChild(div);
            });
        });
}

function doHelpdeskReport(e) {
    e.preventDefault();
    var url = document.getElementById('helpdesk-url').value;
    var status = document.getElementById('helpdesk-status');

    if (!url) return;

    status.style.display = 'block';
    status.style.color = '#808080';
    status.textContent = 'Submitting report...';

    fetch('/api/helpdesk/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url }),
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (data.success) {
            status.style.color = '#008000';
            status.textContent = data.message;
            document.getElementById('helpdesk-url').value = '';
        } else {
            status.style.color = '#800000';
            status.textContent = data.error || 'Failed to submit report.';
        }
    })
    .catch(function() {
        status.style.color = '#800000';
        status.textContent = 'Error submitting report. Please try again.';
    });
}


// ============================================
// Authentication & Profile
// ============================================

function checkSession() {
    fetch('/api/profile')
        .then(function(r) {
            if (r.ok) return r.json();
            throw new Error('Not authenticated');
        })
        .then(function(user) {
            showProfileLoggedIn(user);
        })
        .catch(function() {
            showProfileLoggedOut();
        });
}

function showProfileLoggedIn(user) {
    document.getElementById('profile-logged-out').style.display = 'none';
    document.getElementById('profile-logged-in').style.display = 'block';

    document.getElementById('profile-username').textContent = user.username;
    document.getElementById('profile-displayname').textContent = user.display_name;
    document.getElementById('profile-department').textContent = user.department;
    document.getElementById('profile-role').textContent = user.role;
    document.getElementById('profile-status').textContent = user.status_message;

    document.getElementById('edit-displayname').value = user.display_name;
    document.getElementById('edit-department').value = user.department;
    document.getElementById('edit-status').value = user.status_message;
}

function showProfileLoggedOut() {
    document.getElementById('profile-logged-out').style.display = 'block';
    document.getElementById('profile-logged-in').style.display = 'none';
}

function doLogin(e) {
    e.preventDefault();
    var username = document.getElementById('login-username').value;
    var password = document.getElementById('login-password').value;
    var status = document.getElementById('login-status');

    fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username, password: password }),
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (data.success) {
            showNotification(data.message, 'success');
            checkSession();
        } else {
            status.style.display = 'block';
            status.textContent = data.error;
        }
    })
    .catch(function() {
        status.style.display = 'block';
        status.textContent = 'Connection error. Please try again.';
    });
}

function doLogout() {
    fetch('/api/logout', { method: 'POST' })
        .then(function() {
            showProfileLoggedOut();
            showNotification('Signed out successfully.', 'success');
        });
}

function doProfileUpdate(e) {
    e.preventDefault();

    fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            display_name: document.getElementById('edit-displayname').value,
            department: document.getElementById('edit-department').value,
            status_message: document.getElementById('edit-status').value,
        }),
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (data.success) {
            showNotification('Profile updated!', 'success');
            showProfileLoggedIn(data.user);
            loadDirectory(); // Refresh directory with new info
        } else {
            showNotification(data.error || 'Update failed.', 'error');
        }
    })
    .catch(function() {
        showNotification('Error updating profile.', 'error');
    });
}


// ============================================
// Suggestion Box
// ============================================

function doSuggestion(e) {
    e.preventDefault();
    var text = document.getElementById('suggestion-text').value;
    if (text) {
        showNotification('Thank you for your suggestion!', 'success');
        document.getElementById('suggestion-text').value = '';
    }
}


// ============================================
// Admin Panel
// ============================================

function loadAdminPanel() {
    fetch('/api/admin/dashboard')
        .then(function(r) {
            if (r.status === 403) {
                document.getElementById('admin-denied').style.display = 'block';
                document.getElementById('admin-content').style.display = 'none';
                return null;
            }
            if (r.status === 401) {
                document.getElementById('admin-denied').style.display = 'block';
                document.getElementById('admin-content').style.display = 'none';
                return null;
            }
            return r.json();
        })
        .then(function(data) {
            if (!data) return;

            document.getElementById('admin-denied').style.display = 'none';
            document.getElementById('admin-content').style.display = 'block';

            // System info
            var sysinfo = document.getElementById('admin-sysinfo');
            sysinfo.innerHTML =
                '<div class="info-item"><span class="info-item-label">Uptime:</span> ' + Math.floor(data.uptime) + ' seconds</div>' +
                '<div class="info-item"><span class="info-item-label">Users:</span> ' + data.users + '</div>' +
                '<div class="info-item"><span class="info-item-label">Sessions:</span> ' + data.sessions + '</div>' +
                '<div class="info-item"><span class="info-item-label">OS:</span> ' + escapeHtml(data.systemInfo.os) + '</div>';

            // Network topology
            var topo = document.getElementById('admin-topology');
            topo.innerHTML = '';
            data.networkTopology.forEach(function(svc) {
                var div = document.createElement('div');
                div.className = 'info-item';
                div.style.marginBottom = '4px';
                div.innerHTML =
                    '<span class="info-item-label">' + escapeHtml(svc.name) + '</span> — ' +
                    escapeHtml(svc.description) +
                    '<br><span style="color:#808080; font-size:10px;">Host: ' + escapeHtml(svc.host) + ':' + svc.port + ' [' + svc.status + ']</span>';
                topo.appendChild(div);
            });

            // Load user table
            loadAdminUsers();
        })
        .catch(function() {
            document.getElementById('admin-denied').style.display = 'block';
            document.getElementById('admin-content').style.display = 'none';
        });
}

function loadAdminUsers() {
    fetch('/api/admin/users')
        .then(function(r) { return r.json(); })
        .then(function(users) {
            var tbody = document.getElementById('admin-users-tbody');
            tbody.innerHTML = '';
            users.forEach(function(u) {
                var tr = document.createElement('tr');
                tr.innerHTML =
                    '<td>' + escapeHtml(u.username) + '</td>' +
                    '<td>' + escapeHtml(u.display_name) + '</td>' +
                    '<td>' + escapeHtml(u.department) + '</td>' +
                    '<td>' + escapeHtml(u.role) + '</td>';
                tbody.appendChild(tr);
            });
        });
}

function doCheckWebsite() {
    var url = document.getElementById('checker-url').value;
    var result = document.getElementById('checker-result');

    if (!url) return;

    result.style.display = 'block';
    result.textContent = 'Checking...';

    fetch('/api/admin/check-website', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: url }),
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        if (data.error) {
            result.textContent = 'ERROR: ' + data.error;
        } else {
            result.textContent =
                'Status: ' + data.status + ' ' + data.statusText + '\n' +
                'Content-Length: ' + data.contentLength + '\n' +
                '--- Preview (first 500 chars) ---\n' +
                data.preview;
        }
    })
    .catch(function(err) {
        result.textContent = 'ERROR: ' + err.message;
    });
}


// ============================================
// Utility Functions
// ============================================

function escapeHtml(text) {
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function updateClock() {
    var now = new Date();
    var hours = now.getHours();
    var minutes = now.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12;
    minutes = minutes < 10 ? '0' + minutes : minutes;
    document.getElementById('clock').textContent = hours + ':' + minutes + ' ' + ampm;
}

function showNotification(message, type) {
    var notif = document.getElementById('notification');
    notif.textContent = message;
    notif.className = 'notification ' + (type || '');
    notif.style.display = 'block';
    setTimeout(function() {
        notif.style.display = 'none';
    }, 3000);
}


// ============================================
// Clippy Helper System
// ============================================

var clippyTips = [
    "Welcome to the RowdyCon Intranet! Use the sidebar to navigate.",
    "It looks like you're exploring the intranet! Did you know the <b>Employee Directory</b> has a search feature?",
    "Tip: The search feature reads from the <b>URL hash</b>. Try adding <b>#search=something</b> to the URL!",
    "I notice Dave's search filter blocks some things... but not <b>everything</b>! Have you checked ALL the event handlers?",
    "The <b>IT Help Desk</b> is staffed by real employees who use real browsers. I wonder what cookies they have...",
    "Profile updates are so convenient! I wonder what <b>other fields</b> you could update besides your name...",
    "The admin panel has some powerful tools. What if you could check a website that <b>isn't on the internet</b>?",
    "Some services are only accessible from <b>inside the network</b>. Docker containers have special hostnames...",
    "Not all characters are created equal. Some are <b>invisible</b> but the shell still sees them!",
];

var currentTip = 0;

function initClippy() {
    rotateTip();
    setInterval(rotateTip, 15000);
}

function rotateTip() {
    var textEl = document.getElementById('clippy-text');
    if (textEl) {
        textEl.innerHTML = clippyTips[currentTip % clippyTips.length];
        currentTip++;
    }
}

function dismissClippy() {
    document.getElementById('clippy').style.display = 'none';
    setTimeout(function() {
        document.getElementById('clippy').style.display = 'flex';
    }, 20000);
}


// ============================================
// Window Controls & Easter Eggs
// ============================================

function initWindowControls() {
    var closeBtn = document.querySelector('.title-bar-btn.close');
    if (closeBtn) {
        closeBtn.addEventListener('click', showBSOD);
    }

    var minimizeBtn = document.querySelector('.title-bar-btn.minimize');
    if (minimizeBtn) {
        minimizeBtn.addEventListener('click', function() {
            var win = document.getElementById('browser-window');
            win.style.display = 'none';
            setTimeout(function() { win.style.display = 'flex'; }, 2000);
        });
    }
}

function showBSOD() {
    var bsod = document.createElement('div');
    bsod.className = 'bsod';
    bsod.innerHTML =
        '<div class="bsod-content">' +
            '<p class="bsod-title">Windows</p>' +
            '<br>' +
            '<p>A fatal exception 0E has occurred at 0028:C0034B03 in VXD VFAT(01) +</p>' +
            '<p>00000803. The current application will be terminated.</p>' +
            '<br>' +
            '<p>All unsaved intranet data will be lost.</p>' +
            '<br>' +
            '<p>*  Press any key to restart your computer. You will</p>' +
            '<p>   lose any unsaved information in all applications.</p>' +
            '<br>' +
            '<p>Press any key to continue <span class="bsod-cursor">_</span></p>' +
        '</div>';
    document.body.appendChild(bsod);

    var reboot = function() {
        document.removeEventListener('keydown', reboot);
        bsod.querySelector('.bsod-content').innerHTML =
            '<br><br><p>Rebooting system...</p>';
        setTimeout(function() { location.reload(); }, 1500);
    };
    document.addEventListener('keydown', reboot);
    bsod.addEventListener('click', reboot);
}
