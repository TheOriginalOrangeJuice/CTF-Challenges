/*
 * IT Help Desk Bot Service
 * RowdyCon Systems, Inc.
 *
 * This service simulates an IT staff member visiting reported URLs.
 * It authenticates as sarah_IT before each visit (fresh session per visit)
 * to ensure each player gets an isolated session.
 */

const puppeteer = require('puppeteer');
const express = require('express');

const MAIN_APP_PORT = process.env.PORT || '1339';
const MAIN_APP_URL = process.env.MAIN_APP_URL || ('http://main-app:' + MAIN_APP_PORT);
const BOT_USERNAME = process.env.BOT_USERNAME || 'sarah_IT';
const BOT_PASSWORD = process.env.BOT_PASSWORD;

if (!BOT_PASSWORD) {
    console.error('[Bot] ERROR: BOT_PASSWORD environment variable is required.');
    process.exit(1);
}

// Concurrency control — one browser at a time to prevent OOM
let visiting = false;

// Wait for main-app to be ready
async function waitForMainApp() {
    console.log('[Bot] Waiting for main-app to be ready...');
    while (true) {
        try {
            const res = await fetch(MAIN_APP_URL + '/api/health');
            if (res.ok) {
                console.log('[Bot] main-app is ready.');
                return;
            }
        } catch (e) {
            // Not ready yet
        }
        await new Promise(function(r) { setTimeout(r, 2000); });
    }
}

// Authenticate and return a fresh session token
async function authenticate() {
    const res = await fetch(MAIN_APP_URL + '/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: BOT_USERNAME, password: BOT_PASSWORD }),
    });

    const cookies = res.headers.get('set-cookie');
    if (!cookies) {
        throw new Error('No session cookie received from login');
    }

    const match = cookies.match(/session=([^;]+)/);
    if (!match) {
        throw new Error('Could not parse session cookie');
    }

    return match[1];
}

// Express server to receive visit requests from main-app
const app = express();
app.use(express.json());

app.post('/visit', async function(req, res) {
    var url = req.body.url;
    if (!url) {
        return res.status(400).json({ error: 'URL required' });
    }

    if (visiting) {
        console.log('[Bot] Busy, queued request dropped');
        return res.json({ success: true });
    }

    console.log('[Bot] Visiting: ' + url);

    // Respond immediately, visit in background
    res.json({ success: true });

    visiting = true;
    var browser;
    try {
        // Fresh authentication per visit
        var sessionToken = await authenticate();

        browser = await puppeteer.launch({
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-gpu',
            ],
        });

        var page = await browser.newPage();

        // Set sarah_IT's fresh session cookie on the main-app domain
        var mainAppHost = new URL(MAIN_APP_URL).hostname;
        await page.setCookie({
            name: 'session',
            value: sessionToken,
            domain: mainAppHost,
            path: '/',
            httpOnly: false,
            secure: false,
            sameSite: 'Lax',
        });

        await page.goto(url, {
            waitUntil: 'networkidle0',
            timeout: 10000,
        });

        await new Promise(function(r) { setTimeout(r, 5000); });

        await browser.close();
        console.log('[Bot] Done visiting: ' + url);
    } catch (err) {
        console.error('[Bot] Error visiting URL:', err.message);
        if (browser) {
            try { await browser.close(); } catch (e) {}
        }
    } finally {
        visiting = false;
    }
});

app.get('/health', function(req, res) {
    res.json({ status: 'ok', busy: visiting });
});

// Start the bot
waitForMainApp()
    .then(function() {
        // Verify credentials work
        return authenticate();
    })
    .then(function(token) {
        console.log('[Bot] Authenticated as ' + BOT_USERNAME + ' (verified)');
        app.listen(3000, function() {
            console.log('[Bot] Listening on port 3000');
        });
    })
    .catch(function(err) {
        console.error('[Bot] Failed to initialize:', err);
        process.exit(1);
    });
