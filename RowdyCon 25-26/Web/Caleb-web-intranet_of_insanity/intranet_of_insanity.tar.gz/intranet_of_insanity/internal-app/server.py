"""
RowdyCon Systems - Program Launcher Service
(c) 1998 RowdyCon Systems, Inc.

Windows 98 Start > Run dialog service.
Allows execution of approved programs on the system.

Developed by: Dave from IT
NOTE: This service is INTERNAL ONLY. Do not expose to the internet.
"""

from flask import Flask, request, jsonify
import subprocess
import os

app = Flask(__name__)

FLAG = os.environ.get('FLAG', 'RCCTF{test_flag}')

ALLOWED_PROGRAMS = {
    'calc': 'Calculator',
    'notepad': 'Notepad',
    'explorer': 'Windows Explorer',
    'regedit': 'Registry Editor',
    'cmd': 'Command Prompt',
    'mspaint': 'Paint',
    'winver': 'About Windows',
    'dir': 'Directory Listing',
    'whoami': 'Current User',
    'hostname': 'System Hostname',
    'id': 'User ID',
}


@app.route('/')
def index():
    return jsonify({
        'service': 'RowdyCon Systems - Program Launcher',
        'version': '1.0',
        'description': 'Windows 98 Start > Run service. Execute programs on the system.',
        'usage': 'GET /run?cmd=<program_name>',
        'available_programs': ALLOWED_PROGRAMS,
        'note': 'Type the name of a program and it will be launched.',
        'security_note': 'Special characters are blocked for your protection. Only standard program names are allowed.',
    })


@app.route('/run')
def run_program():
    cmd = request.args.get('cmd', '')

    if not cmd:
        return jsonify({'error': 'No program specified. Usage: /run?cmd=<program>'}), 400

    # Security: Block dangerous characters to prevent command injection
    # Dave says piping and chaining commands is "too dangerous"
    blocked_chars = [';', '|', '&', '`', '$', '(', ')', '{', '}', '<', '>']

    for char in blocked_chars:
        if char in cmd:
            return jsonify({
                'error': 'Invalid character detected: "{}". Only program names are allowed.'.format(char),
                'blocked_characters': blocked_chars,
                'hint': 'Try one of the available programs: ' + ', '.join(ALLOWED_PROGRAMS.keys()),
            }), 400

    # Execute the program
    try:
        result = subprocess.check_output(
            'echo "Launching: {}" && {}'.format(cmd, cmd),
            shell=True,
            stderr=subprocess.STDOUT,
            timeout=5,
        )
        return jsonify({
            'program': cmd,
            'output': result.decode('utf-8', errors='replace'),
            'status': 'OK',
        })
    except subprocess.CalledProcessError as e:
        return jsonify({
            'program': cmd,
            'output': e.output.decode('utf-8', errors='replace'),
            'status': 'ERROR',
            'return_code': e.returncode,
        })
    except subprocess.TimeoutExpired:
        return jsonify({
            'program': cmd,
            'status': 'TIMEOUT',
            'output': 'Program took too long to respond.',
        })
    except Exception as e:
        return jsonify({
            'program': cmd,
            'status': 'ERROR',
            'output': str(e),
        })


if __name__ == '__main__':
    # Write the flag to /flag.txt on startup
    with open('/flag.txt', 'w') as f:
        f.write(FLAG + '\n')

    print('\n'
          '    +==============================================+\n'
          '    |     RowdyCon Program Launcher Service        |\n'
          '    |     Version 1.0                              |\n'
          '    |     (c) 1998 RowdyCon Systems, Inc.          |\n'
          '    |                                              |\n'
          '    |     Running on port 5000                     |\n'
          '    |     INTERNAL USE ONLY                        |\n'
          '    +==============================================+\n')

    app.run(host='0.0.0.0', port=5000)
