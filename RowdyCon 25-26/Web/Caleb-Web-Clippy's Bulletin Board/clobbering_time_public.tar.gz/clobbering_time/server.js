const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const puppeteer = require('puppeteer-core');

const app = express();
const PORT = process.env.PORT;
const FLAG = process.env.FLAG;

if (!PORT || !FLAG) {
  console.error('ERROR: PORT and FLAG environment variables are required.');
  console.error('Run via: docker compose up --build');
  process.exit(1);
}

// Default seed posts
const DEFAULT_POSTS = [
  {
    id: 1,
    author: 'Dave (IT Department)',
    content: '<b>Welcome to the new bulletin board!</b><br>Please keep posts professional. HTML formatting is allowed but sanitized for your safety. <i>- Dave</i>',
    date: '10/23/1998'
  },
  {
    id: 2,
    author: 'Susan (HR)',
    content: 'Reminder: <u>Company picnic</u> this Friday at noon!<br>Please RSVP by Wednesday. Bring your own floppy disks!',
    date: '10/23/1998'
  },
  {
    id: 3,
    author: 'Bob (Accounting)',
    content: 'Has anyone seen my <b>TPS reports</b>? I left them by the printer on the 3rd floor. <br><i>Thanks, Bob</i>',
    date: '10/24/1998'
  }
];

// Per-session post storage (each user gets their own post list)
const sessionPosts = new Map();
const MAX_SESSIONS = 1000;

// Wipe all sessions every 2 minutes (server-side global BSOD)
setInterval(() => sessionPosts.clear(), 120000);

// Report cooldowns (sessionId -> last report timestamp)
const reportCooldowns = new Map();
const REPORT_COOLDOWN_MS = 30000;

const indexHtml = fs.readFileSync(path.join(__dirname, 'public', 'index.html'), 'utf8');

function isValidUUID(str) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);
}

function getSessionId(req) {
  const cookieHeader = req.headers.cookie || '';
  const match = cookieHeader.split('; ').find(c => c.startsWith('session_id='));
  return match ? match.split('=')[1] : null;
}

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Session middleware — assign each visitor a unique session
app.use((req, res, next) => {
  let sessionId = getSessionId(req);
  if (!sessionId || !isValidUUID(sessionId)) {
    sessionId = crypto.randomUUID();
    res.cookie('session_id', sessionId, {
      httpOnly: true,
      sameSite: 'strict',
      path: '/'
    });
  }
  if (!sessionPosts.has(sessionId)) {
    // Evict oldest session if at capacity
    if (sessionPosts.size >= MAX_SESSIONS) {
      const oldest = sessionPosts.keys().next().value;
      sessionPosts.delete(oldest);
    }
    sessionPosts.set(sessionId, []);
  }
  req.sessionId = sessionId;
  next();
});

app.get('/', (req, res) => {
  res.type('html').send(indexHtml);
});

app.use(express.static(path.join(__dirname, 'public')));

// Serve DOMPurify browser bundle from node_modules
app.use('/vendor', express.static(path.join(__dirname, 'node_modules', 'dompurify', 'dist')));

// Get all posts (defaults + this session's posts)
app.get('/api/posts', (req, res) => {
  const userPosts = sessionPosts.get(req.sessionId) || [];
  res.json([...DEFAULT_POSTS, ...userPosts]);
});

// Create a new post (stored per-session)
app.post('/api/post', (req, res) => {
  const { author, content } = req.body;

  if (!author || !content) {
    return res.status(400).json({ error: 'Name and message are required' });
  }

  const post = {
    id: Date.now(),
    author: author.substring(0, 50),
    content: content.substring(0, 5000),
    date: new Date().toLocaleDateString('en-US', {
      month: '2-digit',
      day: '2-digit',
      year: 'numeric'
    })
  };

  const userPosts = sessionPosts.get(req.sessionId);
  if (userPosts) {
    userPosts.push(post);
  }
  res.json({ success: true, post });
});

// JSONP callback endpoint — Dave forgot to sanitize the callback parameter
app.get('/api/callback', (req, res) => {
  const cb = req.query.cb || 'callback';
  res.set('Content-Type', 'application/javascript');
  res.set('X-Content-Type-Options', 'nosniff');
  res.send(`${cb}({"status":"ok"})`);
});

// Admin bot
async function visitAsAdmin(sessionId) {
  let browser;
  try {
    browser = await puppeteer.launch({
      executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || '/usr/bin/chromium',
      headless: 'new',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-gpu'
      ]
    });

    const page = await browser.newPage();

    // Set cookies before navigating
    await page.setCookie(
      {
        name: 'session_id',
        value: sessionId,
        domain: 'localhost',
        path: '/',
        httpOnly: true,
        sameSite: 'Strict'
      },
      {
        name: 'flag',
        value: FLAG,
        domain: 'localhost',
        path: '/',
        httpOnly: false,
        sameSite: 'Strict'
      }
    );

    await page.goto(`http://localhost:${PORT}/`, {
      waitUntil: 'networkidle0',
      timeout: 10000
    });

    await new Promise(resolve => setTimeout(resolve, 3000));

    await browser.close();
    console.log(`[Admin Bot] Visited page for session ${sessionId.substring(0, 8)}...`);
  } catch (err) {
    console.error('[Admin Bot] Error:', err.message);
    if (browser) await browser.close().catch(() => {});
  }
}

// Report page to admin
app.post('/api/report', (req, res) => {
  const now = Date.now();
  const lastReport = reportCooldowns.get(req.sessionId) || 0;
  const remaining = REPORT_COOLDOWN_MS - (now - lastReport);

  if (remaining > 0) {
    const seconds = Math.ceil(remaining / 1000);
    return res.status(429).json({
      error: `Admin is busy. Please wait ${seconds} seconds before reporting again.`
    });
  }

  reportCooldowns.set(req.sessionId, now);

  // Launch bot asynchronously — don't block the response
  visitAsAdmin(req.sessionId);

  res.json({
    message: 'Report submitted! An admin will review the page shortly...'
  });
});

// Reset board - triggered by BSOD "reboot" (clears this session only)
app.post('/api/reset', (req, res) => {
  sessionPosts.set(req.sessionId, []);
  res.json({ message: 'System rebooted. Board restored to defaults.' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`
    +==============================================+
    |     Clippy's Bulletin Board v3.2.1           |
    |     (c) 1998 RowdyCon Systems, Inc.          |
    |                                              |
    |     Running on port ${PORT}                    |
    |     http://localhost:${PORT}                    |
    +==============================================+
  `);
});
