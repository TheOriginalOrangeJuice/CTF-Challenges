from flask import Flask, request, render_template_string, g
import sqlite3
import os

app = Flask(__name__)

DB_PATH = "rowdycon_users.db"
FLAG_PATH = "flag.txt"

# --- Helper: DB ---
def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DB_PATH)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

# Initialize DB if missing
def init_db():
    if not os.path.exists(DB_PATH):
        conn = sqlite3.connect(DB_PATH)
        cur = conn.cursor()
        cur.execute("""
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT
        );
        """)
        # Admin account for the conference portal
        cur.execute("INSERT INTO users (username, password) VALUES (?,?)", ("admin", "rowdy_backend_2026"))
        # Regular volunteer account
        cur.execute("INSERT INTO users (username, password) VALUES (?,?)", ("volunteer", "birdsup"))
        conn.commit()
        conn.close()

# Ensure DB exists at startup
init_db()

# Create flag file if missing
def init_flag():
    if not os.path.exists(FLAG_PATH):
        with open(FLAG_PATH, "w") as f:
            f.write("RCCTF{r0wdyc0n_p0rtal_sql1_breach}")

init_flag()

# --- Templates ---
INDEX_HTML = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>UTSA RowdyCon Staff Portal</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Inter:wght@400;600&display=swap');

    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #0a0f1f, #10192e, #0a0f1f);
      color: #f3f4f6;
      margin: 0;
      padding: 0;
    }

    .hero {
      text-align: center;
      padding: 3rem 1rem 2rem;
      background: linear-gradient(90deg, rgba(0,40,85,0.95), rgba(232,117,17,0.18));
      border-bottom: 2px solid #e87511;
      box-shadow: 0 0 30px rgba(232,117,17,0.15);
    }

    h1 {
      font-family: 'Orbitron', sans-serif;
      color: #e87511;
      font-size: 2.8rem;
      margin: 0 0 0.5rem;
      letter-spacing: 1px;
      text-shadow: 0 0 12px rgba(232,117,17,0.35);
    }

    .subtitle {
      color: #d1d5db;
      font-size: 1rem;
      max-width: 760px;
      margin: 0 auto;
    }

    .card {
      max-width: 760px;
      margin: 2rem auto;
      background: rgba(15, 23, 42, 0.92);
      border: 1px solid rgba(232,117,17,0.35);
      padding: 1.75rem;
      border-radius: 14px;
      box-shadow: 0 14px 40px rgba(0,0,0,0.45);
    }

    label {
      display: block;
      margin: 0.75rem 0 0.3rem;
      color: #f3f4f6;
      font-weight: 600;
    }

    input[type=text], input[type=password] {
      width: 100%;
      padding: 0.7rem;
      border-radius: 8px;
      border: 1px solid #334155;
      background: #020617;
      color: #f8fafc;
      box-sizing: border-box;
    }

    input:focus {
      outline: none;
      border-color: #e87511;
      box-shadow: 0 0 0 3px rgba(232,117,17,0.15);
    }

    button {
      background: #e87511;
      color: #111827;
      padding: 0.75rem 1.1rem;
      border: none;
      border-radius: 8px;
      font-weight: 800;
      cursor: pointer;
      margin-top: 1rem;
      font-family: 'Orbitron', sans-serif;
    }

    button:hover {
      background: #ff8f2f;
    }

    .note {
      font-size: 0.95rem;
      color: #cbd5e1;
      margin-top: 0.5rem;
    }

    .badge-board {
      background: #020617;
      padding: 0.85rem;
      border-radius: 8px;
      margin-top: 1.25rem;
      font-family: monospace;
      color: #93c5fd;
      border-left: 4px solid #e87511;
    }

    footer {
      margin: 1.5rem 0 2rem;
      text-align: center;
      color: #94a3b8;
      font-size: 0.92rem;
    }
  </style>
</head>
<body>
  <div class="hero">
    <h1>UTSA RowdyCon Staff Portal</h1>
    <p class="subtitle">
      Internal access only for conference organizers, speakers, and volunteers.
      The portal was rushed before kickoff, and some of the backend checks may be a little too trusting...
    </p>
  </div>

  <div class="card">
    <form action="/login" method="get">
      <label>Username</label>
      <input type="text" name="username" autocomplete="off" />

      <label>Password</label>
      <input type="password" name="password" autocomplete="off" />

      <button>Access Portal</button>
    </form>

    <p class="note">
      Speaker badges and volunteer schedules are managed here. Only authorized staff should proceed.
    </p>

    <div class="badge-board">
      # RowdyCon Ops Note: volunteer "volunteer" checked in booth packet at 08:15
    </div>
  </div>

  <footer>UTSA RowdyCon CTF Challenge • Birds Up 🤘</footer>
</body>
</html>
"""

# --- Vulnerable login handler: unsafe string concatenation into SQL
@app.route("/login")
def login():
    u = request.args.get("username", "")
    p = request.args.get("password", "")

    # Vulnerable query: intentionally unsafe for challenge purposes
    query = "SELECT username FROM users WHERE username = '{}' AND password = '{}';".format(u, p)

    app.logger.debug("SQL: %s", query)

    conn = get_db()
    cur = conn.cursor()
    try:
        cur.execute(query)
        row = cur.fetchone()
    except Exception:
        return "<p>RowdyCon portal error: credential parsing failed. Try different input.</p>"

    if row:
        if os.path.exists(FLAG_PATH):
            with open(FLAG_PATH, "r") as f:
                flag = f.read().strip()
            return f"<h2>Welcome {row[0]}</h2><p>RowdyCon admin secret: {flag}</p>"
        else:
            return "<p>Welcome organizer. (Flag missing on server.)</p>"

    return "<p>Access denied.</p>"

@app.route("/")
def index():
    return render_template_string(INDEX_HTML)

if __name__ == "__main__":
    app.run(debug=True)