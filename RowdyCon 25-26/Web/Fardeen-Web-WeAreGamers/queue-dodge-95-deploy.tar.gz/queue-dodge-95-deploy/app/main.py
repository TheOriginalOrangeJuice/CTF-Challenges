from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import os
import random
import secrets
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from fastapi import Cookie, FastAPI, HTTPException, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent
SESSION_COOKIE = "summoner_sid"
WM_COMMAND = 273
BTN_ACCEPT = 0x95A1
BTN_DECLINE = 0x95D1
FLAG = os.getenv("FLAG", "RCC{L0sers_Queue_is_A_M1ndset}")
SECRET_KEY = os.getenv("SECRET_KEY", "replace-me-in-production")

QUEUE_POP_RANGE = (4.0, 6.0)
BONZAI_TRIGGER_RANGE = (0.145, 0.185)
READY_CHECK_DURATION_MS = 1800
LANE_DELAYS = {
    "ui": (0.285, 0.405),
    "legacy": (0.015, 0.065),
    "malware": (0.018, 0.055),
}


@dataclass
class QueueState:
    queue_id: str
    created_at: float
    status: str = "queued"
    ticket: str | None = None
    legacy_nonce: str | None = None
    ready_at: float | None = None
    resolved_action: str | None = None
    resolved_by: str | None = None
    lane: str | None = None
    audit_log: list[dict[str, Any]] = field(default_factory=list)


@dataclass
class SessionState:
    sid: str
    active_queue: QueueState | None = None
    sockets: set[WebSocket] = field(default_factory=set)


class UIButtonAction(BaseModel):
    ticket: str
    action: str


class WindowProcAction(BaseModel):
    ticket: str
    msg: int
    wparam: int
    lparam: int


app = FastAPI(title="Queue Dodge 95")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
sessions: dict[str, SessionState] = {}


def get_or_create_session(sid: str) -> SessionState:
    session = sessions.get(sid)
    if session is None:
        session = SessionState(sid=sid)
        sessions[sid] = session
    return session


def issue_ticket(session_id: str, queue: QueueState) -> str:
    payload = {
        "sid": session_id,
        "qid": queue.queue_id,
        "exp": int(time.time()) + 120,
    }
    encoded = base64.urlsafe_b64encode(json.dumps(payload, separators=(",", ":")).encode()).decode().rstrip("=")
    signature = hmac.new(SECRET_KEY.encode(), encoded.encode(), hashlib.sha256).hexdigest()
    return f"{encoded}.{signature}"


def parse_ticket(ticket: str) -> dict[str, Any]:
    try:
        encoded, signature = ticket.split(".", 1)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Malformed ticket") from exc

    expected = hmac.new(SECRET_KEY.encode(), encoded.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(signature, expected):
        raise HTTPException(status_code=403, detail="Bad ticket signature")

    padded = encoded + "=" * (-len(encoded) % 4)
    payload = json.loads(base64.urlsafe_b64decode(padded.encode()))
    if payload.get("exp", 0) < int(time.time()):
        raise HTTPException(status_code=403, detail="Expired ready check ticket")
    return payload


def fnv1a32(text: str) -> int:
    value = 0x811C9DC5
    for byte in text.encode():
        value ^= byte
        value = (value * 0x01000193) & 0xFFFFFFFF
    return value


def expected_windowproc_proof(ticket: str, legacy_nonce: str, button_id: int) -> int:
    return fnv1a32(f"{legacy_nonce}:{button_id}:{ticket}")


def build_status_payload(queue: QueueState) -> dict[str, Any]:
    return {
        "queue_id": queue.queue_id,
        "status": queue.status,
        "resolved_action": queue.resolved_action,
        "resolved_by": queue.resolved_by,
        "lane": queue.lane,
    }


def ready_check_remaining_ms(queue: QueueState) -> int:
    if queue.ready_at is None:
        return READY_CHECK_DURATION_MS
    elapsed_ms = int((time.time() - queue.ready_at) * 1000)
    return max(0, READY_CHECK_DURATION_MS - elapsed_ms)


def build_ready_payload(queue: QueueState) -> dict[str, Any]:
    return {
        "type": "ready-check",
        "message": "Match found: Ranked Solo/Duo on Summoner's Rift",
        "ticket": queue.ticket,
        "legacy_nonce": queue.legacy_nonce,
        "countdown_ms": ready_check_remaining_ms(queue),
        "mode": "Ranked Solo/Duo",
        "map": "Summoner's Rift",
        "build": "4.20.95",
        **build_status_payload(queue),
    }


def build_resolution_payload(queue: QueueState) -> dict[str, Any]:
    if queue.resolved_action == "accept":
        return {
            "type": "queue-win",
            "message": "Ready check locked before Bonzai Buddy could dodge.",
            "flag": FLAG,
            **build_status_payload(queue),
        }

    return {
        "type": "queue-loss",
        "message": "Bonzai Buddy clicked DECLINE before the visible client stack landed.",
        **build_status_payload(queue),
    }


def get_live_ready_queue(session: SessionState, ticket: str) -> QueueState:
    payload = parse_ticket(ticket)
    queue = session.active_queue
    if queue is None:
        raise HTTPException(status_code=404, detail="No active queue")
    if payload.get("sid") != session.sid or payload.get("qid") != queue.queue_id:
        raise HTTPException(status_code=403, detail="Ticket/session mismatch")
    if queue.ticket != ticket or queue.status != "ready":
        raise HTTPException(status_code=409, detail="Ready check is no longer active")
    return queue


async def broadcast(session: SessionState, payload: dict[str, Any]) -> None:
    stale: list[WebSocket] = []
    for socket in list(session.sockets):
        try:
            await socket.send_json(payload)
        except Exception:
            stale.append(socket)
    for socket in stale:
        session.sockets.discard(socket)


async def complete_queue(session: SessionState, queue: QueueState, action: str, actor: str, lane: str) -> dict[str, Any]:
    queue.resolved_action = action
    queue.resolved_by = actor
    queue.lane = lane
    queue.status = "accepted" if action == "accept" else "declined"
    queue.audit_log.append(
        {
            "event": "resolve",
            "action": action,
            "actor": actor,
            "lane": lane,
            "ts": time.time(),
        }
    )

    payload = build_resolution_payload(queue)
    await broadcast(session, payload)
    return payload


async def process_click(session: SessionState, queue: QueueState, action: str, actor: str, lane: str) -> dict[str, Any]:
    queue.audit_log.append(
        {
            "event": "click-arrival",
            "action": action,
            "actor": actor,
            "lane": lane,
            "ts": time.time(),
        }
    )

    await asyncio.sleep(random.uniform(*LANE_DELAYS[lane]))

    if queue.status != "ready" or queue.resolved_action is not None:
        return {
            "status": queue.status,
            "message": "The queue already resolved.",
            **build_status_payload(queue),
        }

    result = await complete_queue(session, queue, action, actor, lane)
    return {
        "status": queue.status,
        **result,
    }


async def bonzai_auto_decline(session: SessionState, queue: QueueState) -> None:
    await asyncio.sleep(random.uniform(*BONZAI_TRIGGER_RANGE))
    if session.active_queue is not queue or queue.status != "ready":
        return
    await process_click(session, queue, "decline", "bonzai-buddy.exe", "malware")


async def queue_lifecycle(session: SessionState, queue: QueueState) -> None:
    await asyncio.sleep(random.uniform(*QUEUE_POP_RANGE))
    if session.active_queue is not queue or queue.status != "queued":
        return

    queue.status = "ready"
    queue.ready_at = time.time()
    queue.legacy_nonce = secrets.token_hex(6)
    queue.ticket = issue_ticket(session.sid, queue)
    queue.audit_log.append({"event": "ready-check", "ts": queue.ready_at})
    await broadcast(session, build_ready_payload(queue))

    asyncio.create_task(bonzai_auto_decline(session, queue))


@app.get("/", response_class=HTMLResponse)
async def index(request: Request, summoner_sid: str | None = Cookie(default=None)) -> Response:
    session_id = summoner_sid or secrets.token_hex(16)
    get_or_create_session(session_id)
    response = templates.TemplateResponse("index.html", {"request": request, "session_id": session_id})
    if summoner_sid is None:
        response.set_cookie(SESSION_COOKIE, session_id, httponly=False, samesite="lax")
    return response


@app.get("/healthz")
async def healthcheck() -> JSONResponse:
    return JSONResponse({"ok": True})


@app.post("/api/queue/start")
async def queue_start(summoner_sid: str | None = Cookie(default=None)) -> JSONResponse:
    if not summoner_sid:
        raise HTTPException(status_code=403, detail="Missing session cookie")

    session = get_or_create_session(summoner_sid)
    current = session.active_queue
    if current and current.status in {"queued", "ready"}:
        return JSONResponse(
            {
                "ok": True,
                "message": "Queue already active",
                **build_status_payload(current),
            }
        )

    queue = QueueState(queue_id=secrets.token_hex(4), created_at=time.time())
    session.active_queue = queue
    asyncio.create_task(queue_lifecycle(session, queue))

    await broadcast(
        session,
        {
            "type": "queue-started",
            "message": "Searching for Ranked Solo/Duo... please ignore bonzai-buddy.exe.",
            **build_status_payload(queue),
        },
    )

    return JSONResponse(
        {
            "ok": True,
            "message": "Queue entered",
            **build_status_payload(queue),
        }
    )


@app.get("/api/queue/status")
async def queue_status(summoner_sid: str | None = Cookie(default=None)) -> JSONResponse:
    if not summoner_sid:
        return JSONResponse({"ok": True, "status": "idle"})

    session = get_or_create_session(summoner_sid)
    queue = session.active_queue
    if queue is None:
        return JSONResponse({"ok": True, "status": "idle"})

    if queue.status == "queued":
        return JSONResponse(
            {
                "ok": True,
                "type": "queue-started",
                "message": "Searching for Ranked Solo/Duo... please ignore bonzai-buddy.exe.",
                **build_status_payload(queue),
            }
        )

    if queue.status == "ready" and queue.resolved_action is None:
        return JSONResponse({"ok": True, **build_ready_payload(queue)})

    if queue.resolved_action is not None:
        return JSONResponse({"ok": True, **build_resolution_payload(queue)})

    return JSONResponse({"ok": True, **build_status_payload(queue)})


@app.post("/api/ui/click")
async def ui_click(payload: UIButtonAction, summoner_sid: str | None = Cookie(default=None)) -> JSONResponse:
    if not summoner_sid:
        raise HTTPException(status_code=403, detail="Missing session cookie")
    if payload.action not in {"accept", "decline"}:
        raise HTTPException(status_code=400, detail="Unsupported UI action")

    session = get_or_create_session(summoner_sid)
    queue = get_live_ready_queue(session, payload.ticket)
    result = await process_click(session, queue, payload.action, "leagueclient-ui.dll", "ui")
    return JSONResponse(result)


@app.post("/api/legacy/windowproc")
async def legacy_windowproc(payload: WindowProcAction, summoner_sid: str | None = Cookie(default=None)) -> JSONResponse:
    if not summoner_sid:
        raise HTTPException(status_code=403, detail="Missing session cookie")

    session = get_or_create_session(summoner_sid)
    queue = get_live_ready_queue(session, payload.ticket)
    if payload.msg != WM_COMMAND:
        raise HTTPException(status_code=400, detail="Unexpected window message")

    if payload.wparam == BTN_ACCEPT:
        action = "accept"
    elif payload.wparam == BTN_DECLINE:
        action = "decline"
    else:
        raise HTTPException(status_code=400, detail="Unknown control id")

    expected = expected_windowproc_proof(payload.ticket, queue.legacy_nonce or "", payload.wparam)
    if payload.lparam != expected:
        raise HTTPException(status_code=403, detail="Window checksum mismatch")

    result = await process_click(session, queue, action, "legacy-client-windowproc", "legacy")
    return JSONResponse(result)


@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket) -> None:
    sid = websocket.cookies.get(SESSION_COOKIE)
    if not sid:
        await websocket.close(code=4401)
        return

    session = get_or_create_session(sid)
    await websocket.accept()
    session.sockets.add(websocket)

    await websocket.send_json(
        {
            "type": "hello",
            "message": "League Client 95 ready-check channel connected.",
            "session_suffix": sid[-6:],
        }
    )

    if session.active_queue is not None:
        queue = session.active_queue
        if queue.status == "queued":
            await websocket.send_json(
                {
                    "type": "state-sync",
                    "message": "Searching for Ranked Solo/Duo... please ignore bonzai-buddy.exe.",
                    **build_status_payload(queue),
                }
            )
        elif queue.status == "ready" and queue.resolved_action is None:
            await websocket.send_json(build_ready_payload(queue))
        elif queue.resolved_action is not None:
            await websocket.send_json(build_resolution_payload(queue))
        else:
            await websocket.send_json(
                {
                    "type": "state-sync",
                    **build_status_payload(queue),
                }
            )

    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        session.sockets.discard(websocket)
