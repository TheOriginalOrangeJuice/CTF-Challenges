#!/usr/bin/env python3
"""
FISH.EXE — Windows 95 CTF Challenge
=====================================================
Match the spinning fish direction for 60 consecutive
seconds (12 × randomised intervals) to reveal the flag.

Buttons start CONTINUOUS animation of the static fish.
If you don't correct direction within 0.5 s of a switch,
all progress is reset.

Every ~3-9 s there is a RANDOM CHANCE the direction
flips (it may stay the same).

API: http://localhost:8080/api/status  (GET)
     http://localhost:8080/api/rotate  (POST, {"direction": "cw"|"ccw"})
"""

import tkinter as tk
import threading
import time
import random
import os
import sys
import json
import queue
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.request import urlretrieve

# Cross-thread message queue: API thread → Tk main thread
_msg_queue: "queue.Queue[str]" = queue.Queue()

# Window visibility state (read by API thread, written by Tk thread)
_vis_lock  = threading.Lock()
_vis_state = {"spin": True, "ctrl": True}

try:
    from PIL import Image, ImageTk
    PIL_OK = True
except ImportError:
    PIL_OK = False

# ─────────────────────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────────────────────
GIF_URL          = "https://spinning.fish/fish.gif"
GIF_PATH         = "/tmp/fish_ctf.gif"
CTF_FLAG         = os.environ.get("CTF_FLAG", "CTF{4ut0m4t3_th3_sp1nn1ng_f1sh_m4st3r}")
INTERVALS_NEEDED = 12          # consecutive correct intervals to win
API_PORT         = int(os.environ.get("API_PORT", "8080"))
ANIM_SIZE        = (220, 220)  # fish display size in pixels

# Interval timing
INTERVAL_MIN     = 3.0         # shortest possible interval (s)
INTERVAL_MAX     = 9.0         # longest possible interval (s)
FLIP_CHANCE      = 0.66        # probability direction FLIPS at each interval boundary
GRACE_PERIOD     = 0.5         # seconds to correct direction after a flip

# ─────────────────────────────────────────────────────────────
# WIN95 COLOUR PALETTE + WIDGET HELPERS
# ─────────────────────────────────────────────────────────────
W = {
    "bg":         "#c0c0c0",
    "title":      "#000080",
    "title_text": "#ffffff",
    "btn":        "#c0c0c0",
    "white":      "#ffffff",
    "black":      "#000000",
    "shadow":     "#808080",
    "navy":       "#000080",
    "desktop":    "#008080",
    "inset":      "#ffffff",
    "progress":   "#000080",
    "green":      "#008800",
    "red":        "#cc0000",
    "orange":     "#cc6600",
    "font":       ("Helvetica", 9),
    "font_sm":    ("Helvetica", 8),
    "font_bold":  ("Helvetica", 9, "bold"),
    "font_mono":  ("Courier", 9),
    "font_xl":    ("Helvetica", 18, "bold"),
}


def btn(parent, text, cmd, width=None, **kw):
    return tk.Button(
        parent, text=text, command=cmd,
        bg=W["btn"], activebackground=W["btn"],
        fg=W["black"], activeforeground=W["black"],
        relief="raised", bd=2, font=W["font"],
        cursor="arrow",
        **({} if width is None else {"width": width}),
        **kw,
    )


def lbl(parent, text="", font=None, fg=None, bg=None, **kw):
    return tk.Label(
        parent, text=text,
        bg=bg or W["bg"], fg=fg or W["black"],
        font=font or W["font"], **kw,
    )


def groove_frame(parent, **kw):
    return tk.Frame(parent, relief="groove", bd=2, bg=W["bg"], **kw)


def sunken_frame(parent, bg=None, **kw):
    return tk.Frame(parent, relief="sunken", bd=2, bg=bg or W["inset"], **kw)


# ─────────────────────────────────────────────────────────────
# CHALLENGE STATE  (thread-safe)
# ─────────────────────────────────────────────────────────────
class ChallengeState:
    """
    Direction changes at random intervals (INTERVAL_MIN–INTERVAL_MAX).
    At each boundary there is a FLIP_CHANCE the direction reverses;
    otherwise it stays the same.
    Player must be continuously animating the static fish in the correct
    direction. A 0.5-second grace period is allowed after a flip.
    Failing to correct within the grace period resets all progress.
    """

    def __init__(self):
        self._lock    = threading.RLock()
        self._rng     = random.Random()        # unseeded → truly random
        self._direction      = self._rng.choice(["cw", "ccw"])
        self._interval_dur   = self._rand_dur()
        self._interval_start = time.time()
        self._player_dir     = None            # what player is currently doing
        self._grace_dl       = None            # grace deadline (float) or None
        self._consecutive    = 0
        self._flag_unlocked  = False

        self._on_tick_cbs  = []
        self._on_flag_cbs  = []

    # ── helpers ───────────────────────────────────────────────
    def _rand_dur(self):
        return self._rng.uniform(INTERVAL_MIN, INTERVAL_MAX)

    # ── public properties ─────────────────────────────────────
    @property
    def direction(self):
        with self._lock:
            return self._direction

    @property
    def consecutive(self):
        with self._lock:
            return self._consecutive

    @property
    def flag_unlocked(self):
        with self._lock:
            return self._flag_unlocked

    def time_remaining(self):
        with self._lock:
            return max(0.0, self._interval_dur - (time.time() - self._interval_start))

    def grace_remaining(self):
        with self._lock:
            if self._grace_dl is None:
                return None
            return max(0.0, self._grace_dl - time.time())

    # ── player action ─────────────────────────────────────────
    def set_player_direction(self, direction):
        """Called from API thread or GUI button."""
        with self._lock:
            self._player_dir = direction
            if direction == self._direction and self._grace_dl is not None:
                self._grace_dl = None   # corrected in time — cancel grace

    # ── callbacks ─────────────────────────────────────────────
    def on_tick(self, cb):   self._on_tick_cbs.append(cb)
    def on_flag(self, cb):   self._on_flag_cbs.append(cb)

    def _fire(self, cbs):
        for cb in cbs:
            try: cb()
            except Exception: pass

    # ── main tick (called from GUI main-thread every 100 ms) ──
    def tick(self):
        now = time.time()
        tick_needed = False
        flag_fired  = False

        with self._lock:
            # ── 1. Grace period expiry check ──────────────────
            if self._grace_dl is not None and now >= self._grace_dl:
                if self._player_dir != self._direction:
                    self._consecutive = 0   # reset — didn't correct in time
                    tick_needed = True
                self._grace_dl = None

            # ── 2. Interval boundary check ─────────────────────
            if now - self._interval_start >= self._interval_dur:
                # Evaluate current interval
                if self._player_dir == self._direction:
                    self._consecutive += 1
                else:
                    self._consecutive = 0

                # Advance interval
                old_dir = self._direction
                if self._rng.random() < FLIP_CHANCE:
                    self._direction = "ccw" if old_dir == "cw" else "cw"
                # else: direction stays the same

                self._interval_dur   = self._rand_dur()
                self._interval_start = now
                self._grace_dl       = None   # clear any stale grace

                # Start grace only if direction actually flipped
                if self._direction != old_dir:
                    self._grace_dl = now + GRACE_PERIOD

                if self._consecutive >= INTERVALS_NEEDED and not self._flag_unlocked:
                    self._flag_unlocked = True
                    flag_fired = True

                tick_needed = True

        if tick_needed:
            self._fire(self._on_tick_cbs)
        if flag_fired:
            self._fire(self._on_flag_cbs)

    # ── serialisable status (for API) ─────────────────────────
    def status(self):
        with self._lock:
            remaining = max(0.0, self._interval_dur - (time.time() - self._interval_start))
            grace_r   = None
            if self._grace_dl is not None:
                grace_r = round(max(0.0, self._grace_dl - time.time()), 2)
            with _vis_lock:
                spin_vis = _vis_state["spin"]
                ctrl_vis = _vis_state["ctrl"]
            return {
                "current_direction":     self._direction,
                "time_remaining":        round(remaining, 2),
                "grace_period_remaining": grace_r,
                "consecutive_correct":   self._consecutive,
                "needed_to_win":         INTERVALS_NEEDED,
                "last_player_direction": self._player_dir,
                "flag": CTF_FLAG if self._flag_unlocked else None,
                "spin_visible":          spin_vis,
                "ctrl_visible":          ctrl_vis,
            }


# ─────────────────────────────────────────────────────────────
# HTTP API SERVER
# ─────────────────────────────────────────────────────────────
class _APIHandler(BaseHTTPRequestHandler):

    def log_message(self, *_): pass

    def _json(self, data, code=200):
        body = json.dumps(data, indent=2).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(body))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        ch = self.server.challenge
        if self.path == "/api/status":
            self._json(ch.status())
        elif self.path in ("/", "/api"):
            self._json({
                "challenge": "FISH.EXE — Spinning Fish Automation",
                "objective": (
                    f"Keep the static fish rotating in the correct direction "
                    f"for {INTERVALS_NEEDED} consecutive intervals to get the flag."
                ),
                "rules": [
                    f"Direction may flip at each interval boundary ({FLIP_CHANCE*100:.0f}% chance)",
                    f"Random interval duration: {INTERVAL_MIN}s–{INTERVAL_MAX}s",
                    f"After a flip you have {GRACE_PERIOD}s to correct — or progress resets",
                    "POST /api/rotate continuously with the current direction to win",
                ],
                "endpoints": {
                    "GET  /api/status": "Current challenge state",
                    "POST /api/rotate": '{"direction": "cw" | "ccw"}',
                },
            })
        else:
            self._json({"error": "not found"}, 404)

    def do_POST(self):
        ch = self.server.challenge
        if self.path == "/api/window/show":
            _msg_queue.put("show_windows")
            self._json({"success": True, "message": "Windows shown"})
            return
        if self.path == "/api/window/toggle_spin":
            _msg_queue.put("toggle_spin")
            self._json({"success": True})
            return
        if self.path == "/api/window/toggle_ctrl":
            _msg_queue.put("toggle_ctrl")
            self._json({"success": True})
            return
        if self.path == "/api/rotate":
            try:
                length = int(self.headers.get("Content-Length", 0))
                body = json.loads(self.rfile.read(length)) if length else {}
                direction = str(body.get("direction", "")).lower()
                if direction not in ("cw", "ccw"):
                    self._json({"error": "direction must be 'cw' or 'ccw'"}, 400)
                    return
                ch.set_player_direction(direction)
                st = ch.status()
                self._json({
                    "success":                    True,
                    "direction_sent":             direction,
                    "current_challenge_direction": st["current_direction"],
                    "match":                      direction == st["current_direction"],
                    "consecutive_correct":        st["consecutive_correct"],
                    "grace_period_remaining":     st["grace_period_remaining"],
                    "flag":                       st["flag"],
                })
            except (json.JSONDecodeError, ValueError) as exc:
                self._json({"error": f"bad request: {exc}"}, 400)
        else:
            self._json({"error": "not found"}, 404)


def run_api(challenge: ChallengeState):
    srv = HTTPServer(("0.0.0.0", API_PORT), _APIHandler)
    srv.challenge = challenge
    srv.serve_forever()


# ─────────────────────────────────────────────────────────────
# GIF LOADING
# ─────────────────────────────────────────────────────────────
def fetch_gif():
    if os.path.exists(GIF_PATH) and os.path.getsize(GIF_PATH) > 512:
        print(f"[fish] Using cached GIF: {GIF_PATH}")
        return True
    try:
        print(f"[fish] Downloading {GIF_URL} …")
        urlretrieve(GIF_URL, GIF_PATH)
        print(f"[fish] Downloaded → {GIF_PATH}")
        return True
    except Exception as exc:
        print(f"[fish] Download failed: {exc}")
        return False


def load_frames():
    """Return (frames, delays) or (None, None). Requires root Tk to exist."""
    if not PIL_OK:
        return None, None
    try:
        gif = Image.open(GIF_PATH)
        raw, delays = [], []
        try:
            while True:
                frame = gif.copy().convert("RGBA")
                frame = frame.resize(ANIM_SIZE, Image.LANCZOS)
                raw.append(frame)
                delays.append(gif.info.get("duration", 60))
                gif.seek(gif.tell() + 1)
        except EOFError:
            pass
        if not raw:
            return None, None
        print(f"[fish] Loaded {len(raw)} frames")
        frames = [ImageTk.PhotoImage(f) for f in raw]
        return frames, delays
    except Exception as exc:
        print(f"[fish] Frame error: {exc}")
        return None, None


# ─────────────────────────────────────────────────────────────
# ANIMATED FISH CANVAS  (plays GIF forward or backward)
# ─────────────────────────────────────────────────────────────
class AnimatedFishCanvas(tk.Canvas):
    def __init__(self, parent, frames, delays, dir_fn, **kw):
        super().__init__(parent, **kw)
        self._frames  = frames
        self._delays  = delays
        self._dir_fn  = dir_fn
        self._idx     = 0
        self._img_id  = None
        self._running = True
        self._step()

    def _step(self):
        if not self._running:
            return
        n = len(self._frames)
        self._idx = (self._idx + 1) % n if self._dir_fn() == "cw" \
                    else (self._idx - 1) % n
        frame = self._frames[self._idx]
        if self._img_id is None:
            self._img_id = self.create_image(0, 0, anchor="nw", image=frame)
        else:
            self.itemconfig(self._img_id, image=frame)
        delay = self._delays[self._idx] if self._delays else 60
        self.after(delay, self._step)

    def stop(self): self._running = False


# ─────────────────────────────────────────────────────────────
# STATIC FISH CANVAS  (continuous animation, direction-settable)
# ─────────────────────────────────────────────────────────────
class StaticFishCanvas(tk.Canvas):
    """
    Continuously animates in whatever direction the player set.
    Call set_direction('cw' | 'ccw') to start / switch.
    """

    def __init__(self, parent, frames, delays, **kw):
        super().__init__(parent, **kw)
        self._frames    = frames
        self._delays    = delays
        self._idx       = 0
        self._img_id    = None
        self._dir       = None   # current playing direction
        self._animating = False
        self._render()

    @property
    def current_direction(self):
        return self._dir

    def set_direction(self, direction):
        """Start or switch continuous animation direction."""
        self._dir = direction
        if not self._animating:
            self._animating = True
            self._step()

    def _step(self):
        if self._dir is None:
            self._animating = False
            return
        n = len(self._frames)
        self._idx = (self._idx + 1) % n if self._dir == "cw" \
                    else (self._idx - 1) % n
        self._render()
        delay = self._delays[self._idx] if self._delays else 60
        self.after(delay, self._step)

    def _render(self):
        frame = self._frames[self._idx]
        if self._img_id is None:
            self._img_id = self.create_image(0, 0, anchor="nw", image=frame)
        else:
            self.itemconfig(self._img_id, image=frame)


# ─────────────────────────────────────────────────────────────
# PROGRESS BAR  (plain wrapper — avoids tk.Canvas subclass bug)
# ─────────────────────────────────────────────────────────────
class ProgressBar:
    def __init__(self, parent, width=220, height=14):
        self._pw = width
        self._ph = height
        self._canvas = tk.Canvas(
            parent, width=width, height=height,
            bg=W["btn"], highlightthickness=0,
        )

    def pack(self, **kw):
        self._canvas.pack(**kw)

    def set_value(self, value, maximum):
        c = self._canvas
        c.delete("bar")
        if maximum <= 0:
            return
        pct   = min(1.0, value / maximum)
        bar_w = int(self._pw * pct)
        if bar_w > 0:
            c.create_rectangle(0, 0, bar_w, self._ph,
                               fill=W["progress"], outline="", tags="bar")
        seg = self._pw / maximum
        for i in range(1, maximum):
            x = int(seg * i)
            c.create_line(x, 0, x, self._ph, fill=W["bg"], width=1, tags="bar")


# ─────────────────────────────────────────────────────────────
# SPINNING FISH WINDOW  (window 1 — the reference fish)
# ─────────────────────────────────────────────────────────────
class SpinningFishWindow:
    X, Y = 30, 60

    def __init__(self, root, frames, delays, challenge: ChallengeState):
        self._ch  = challenge
        self._win = tk.Toplevel(root)
        self._win.title("fish.exe")
        self._win.configure(bg=W["bg"])
        self._win.resizable(False, False)
        self._win.protocol("WM_DELETE_WINDOW", self._win.withdraw)
        self._win.geometry(f"+{self.X}+{self.Y}")
        self._build(frames, delays)

    def _build(self, frames, delays):
        w = self._win

        # menu bar
        menubar   = tk.Menu(w, bg=W["bg"], fg=W["black"],
                            activebackground=W["navy"], activeforeground=W["white"],
                            relief="flat", bd=0, font=W["font"])
        file_menu = tk.Menu(menubar, tearoff=0, bg=W["bg"], fg=W["black"],
                            activebackground=W["navy"], activeforeground=W["white"],
                            font=W["font"])
        file_menu.add_command(label="About…", command=self._about)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=lambda: None)
        menubar.add_cascade(label="File", menu=file_menu)
        w.config(menu=menubar)

        outer = tk.Frame(w, bg=W["bg"], padx=6, pady=6)
        outer.pack(fill="both", expand=True)

        lbl(outer, "The Spinning Fish", font=W["font_bold"]).pack(pady=(0, 4))

        fish_wrap = sunken_frame(outer, bg=W["black"])
        fish_wrap.pack()
        self._anim = AnimatedFishCanvas(
            fish_wrap, frames, delays,
            dir_fn=lambda: self._ch.direction,
            width=ANIM_SIZE[0], height=ANIM_SIZE[1],
            bg=W["black"], highlightthickness=0,
        )
        self._anim.pack(padx=2, pady=2)

        badge_f = tk.Frame(outer, bg=W["bg"])
        badge_f.pack(pady=(6, 0))
        lbl(badge_f, "Direction:", font=W["font_bold"]).pack(side="left")
        self._dir_var = tk.StringVar(value=self._dir_text())
        lbl(badge_f, textvariable=self._dir_var,
            font=W["font_bold"], fg=W["navy"]).pack(side="left", padx=4)

        self._timer_var = tk.StringVar(value="Changes in: ?.?s")
        lbl(outer, textvariable=self._timer_var,
            font=W["font_sm"], fg=W["shadow"]).pack()

        sb = sunken_frame(w, bg=W["bg"])
        sb.pack(fill="x", side="bottom", padx=2, pady=2)
        lbl(sb, "  Match direction in the Control Panel  |  API: localhost:8080",
            font=W["font_sm"], fg=W["shadow"], bg=W["bg"], anchor="w").pack(side="left")

    def _dir_text(self):
        return "CLOCKWISE  ↻" if self._ch.direction == "cw" \
               else "COUNTER-CLOCKWISE  ↺"

    def _about(self):
        win = tk.Toplevel(self._win)
        win.title("About fish.exe")
        win.configure(bg=W["bg"])
        win.resizable(False, False)
        f = tk.Frame(win, bg=W["bg"], padx=20, pady=16)
        f.pack()
        lbl(f, "fish.exe", font=W["font_xl"], fg=W["navy"]).pack()
        lbl(f, "CTF Challenge — Automate the fish!\n\n"
               f"Match {INTERVALS_NEEDED} consecutive intervals.\n"
               f"Flip chance per interval: {FLIP_CHANCE*100:.0f}%\n"
               f"Grace period after flip: {GRACE_PERIOD}s",
            font=W["font"]).pack(pady=4)
        btn(f, "OK", win.destroy, width=8).pack(pady=8)
        win.transient(self._win); win.grab_set()

    def update(self):
        self._dir_var.set(self._dir_text())

    def update_timer(self, remaining):
        self._timer_var.set(f"Changes in: {remaining:.1f}s")


# ─────────────────────────────────────────────────────────────
# CONTROL PANEL WINDOW  (window 2 — player interaction)
# ─────────────────────────────────────────────────────────────
class ControlPanelWindow:
    X, Y = 310, 60

    def __init__(self, root, frames, delays, challenge: ChallengeState):
        self._ch   = challenge
        self._win  = tk.Toplevel(root)
        self._win.title("fish.exe — Control Panel")
        self._win.configure(bg=W["bg"])
        self._win.resizable(False, False)
        self._win.protocol("WM_DELETE_WINDOW", self._win.withdraw)
        self._win.geometry(f"+{self.X}+{self.Y}")
        self._build(frames, delays)

    def _build(self, frames, delays):
        w = self._win

        outer = tk.Frame(w, bg=W["bg"], padx=6, pady=6)
        outer.pack(fill="both", expand=True)

        lbl(outer, "Fish Control Panel", font=W["font_bold"]).pack(pady=(0, 4))

        # Static fish
        fish_wrap = sunken_frame(outer, bg=W["black"])
        fish_wrap.pack()
        self._static = StaticFishCanvas(
            fish_wrap, frames, delays,
            width=ANIM_SIZE[0], height=ANIM_SIZE[1],
            bg=W["black"], highlightthickness=0,
        )
        self._static.pack(padx=2, pady=2)

        # Rotation buttons
        bf = tk.Frame(outer, bg=W["bg"])
        bf.pack(pady=8)
        self._ccw_btn = btn(bf, "◄◄  CCW", self._ccw, width=12)
        self._ccw_btn.pack(side="left", padx=6)
        self._cw_btn  = btn(bf, "CW  ►►",  self._cw,  width=12)
        self._cw_btn.pack(side="left", padx=6)

        # Status indicator
        ind_f = tk.Frame(outer, bg=W["bg"])
        ind_f.pack(pady=(0, 2))
        lbl(ind_f, "Status:", font=W["font_sm"]).pack(side="left")
        self._match_var = tk.StringVar(value="  ●  Waiting…")
        self._match_lbl = tk.Label(ind_f, textvariable=self._match_var,
                                    font=W["font_bold"], bg=W["bg"], fg=W["shadow"])
        self._match_lbl.pack(side="left")

        # Grace warning
        self._grace_var = tk.StringVar(value="")
        self._grace_lbl = lbl(outer, textvariable=self._grace_var,
                               font=W["font_bold"], fg=W["red"])
        self._grace_lbl.pack()

        # Challenge status group
        grp   = groove_frame(outer)
        grp.pack(fill="x", pady=4)
        inner = tk.Frame(grp, bg=W["bg"], padx=8, pady=6)
        inner.pack(fill="x")

        lbl(inner, "Challenge Status", font=W["font_bold"]).pack()

        r1 = tk.Frame(inner, bg=W["bg"])
        r1.pack(fill="x", pady=1)
        lbl(r1, "Score:",     font=W["font_sm"], width=10, anchor="w").pack(side="left")
        self._score_var = tk.StringVar(value=f"0 / {INTERVALS_NEEDED}")
        lbl(r1, textvariable=self._score_var, font=W["font_sm"]).pack(side="left")

        r2 = tk.Frame(inner, bg=W["bg"])
        r2.pack(fill="x", pady=1)
        lbl(r2, "Time left:", font=W["font_sm"], width=10, anchor="w").pack(side="left")
        self._time_var = tk.StringVar(value="?.?s")
        lbl(r2, textvariable=self._time_var, font=W["font_sm"]).pack(side="left")

        lbl(inner, "Progress:", font=W["font_sm"]).pack(anchor="w", pady=(4, 0))
        pb_wrap = sunken_frame(inner, bg=W["btn"])
        pb_wrap.pack(fill="x")
        self._pb = ProgressBar(pb_wrap, width=230, height=14)
        self._pb.pack(padx=1, pady=1)
        self._pb.set_value(0, INTERVALS_NEEDED)

        # API hint
        hint = groove_frame(outer)
        hint.pack(fill="x", pady=(6, 0))
        hi = tk.Frame(hint, bg=W["bg"], padx=8, pady=4)
        hi.pack(fill="x")
        lbl(hi, "Automation API", font=W["font_bold"]).pack(anchor="w")
        lbl(hi,
            f"GET  http://localhost:{API_PORT}/api/status\n"
            f"POST http://localhost:{API_PORT}/api/rotate\n"
            f'     Body: {{"direction": "cw" | "ccw"}}',
            font=W["font_mono"], justify="left", bg=W["bg"]).pack(anchor="w")

        self._action_var = tk.StringVar(value="Last action: none")
        lbl(outer, textvariable=self._action_var,
            font=W["font_sm"], fg=W["shadow"]).pack(pady=(4, 0))

    # ── button handlers ───────────────────────────────────────
    def _cw(self):
        self._static.set_direction("cw")
        self._ch.set_player_direction("cw")
        self._action_var.set("Last action: CW  ►")
        self._refresh_indicator()

    def _ccw(self):
        self._static.set_direction("ccw")
        self._ch.set_player_direction("ccw")
        self._action_var.set("Last action: ◄  CCW")
        self._refresh_indicator()

    # ── indicator update ──────────────────────────────────────
    def _refresh_indicator(self):
        st     = self._ch.status()
        player = st["last_player_direction"]
        chall  = st["current_direction"]
        grace  = st["grace_period_remaining"]

        if grace is not None:
            # Grace period active
            self._grace_var.set(f"  ⚠  SWITCH NOW!  ({grace:.1f}s left)  ⚠")
        else:
            self._grace_var.set("")

        if player is None:
            self._match_var.set("  ●  Waiting…")
            self._match_lbl.config(fg=W["shadow"])
        elif player == chall:
            self._match_var.set("  ●  MATCHING!")
            self._match_lbl.config(fg=W["green"])
        elif grace is not None:
            self._match_var.set("  ●  WRONG — correct fast!")
            self._match_lbl.config(fg=W["orange"])
        else:
            self._match_var.set("  ●  WRONG direction")
            self._match_lbl.config(fg=W["red"])

    # ── external update ───────────────────────────────────────
    def update(self):
        st    = self._ch.status()
        score = st["consecutive_correct"]
        self._score_var.set(f"{score} / {INTERVALS_NEEDED}")
        self._pb.set_value(score, INTERVALS_NEEDED)
        self._refresh_indicator()

    def update_timer(self, remaining):
        self._time_var.set(f"{remaining:.1f}s")


# ─────────────────────────────────────────────────────────────
# FLAG WINDOW
# ─────────────────────────────────────────────────────────────
def show_flag_window(root):
    win = tk.Toplevel(root)
    win.title("fish.exe — You Win!")
    win.configure(bg=W["bg"])
    win.resizable(False, False)
    win.lift(); win.focus_force()

    f = tk.Frame(win, bg=W["bg"], padx=24, pady=16)
    f.pack()

    lbl(f, "Congratulations!", font=W["font_xl"], fg=W["navy"]).pack(pady=(0, 6))
    lbl(f, "You automated the spinning fish!", font=W["font_bold"]).pack()
    lbl(f, f"Matched {INTERVALS_NEEDED} consecutive intervals.", font=W["font"]).pack(pady=(2, 10))
    lbl(f, "Your Flag:", font=W["font_bold"]).pack()

    flag_box = sunken_frame(f, bg=W["inset"])
    flag_box.pack(fill="x", pady=4)
    lbl(flag_box, CTF_FLAG, font=W["font_mono"],
        bg=W["inset"], fg=W["navy"]).pack(padx=12, pady=10)

    def copy_flag():
        win.clipboard_clear(); win.clipboard_append(CTF_FLAG)
        copy_btn.config(text="Copied!")
        win.after(2000, lambda: copy_btn.config(text="Copy Flag"))

    copy_btn = btn(f, "Copy Flag", copy_flag, width=12)
    copy_btn.pack(pady=(6, 2))
    btn(f, "Close", win.destroy, width=12).pack()
    win.transient(root)


# ─────────────────────────────────────────────────────────────
# APPLICATION ORCHESTRATOR
# ─────────────────────────────────────────────────────────────
class FishApp:
    def __init__(self, root, frames, delays, challenge: ChallengeState):
        self._root       = root
        self._ch         = challenge
        self._flag_shown = False

        root.withdraw()
        root.title("fish.exe")

        self._spin = SpinningFishWindow(root, frames, delays, challenge)
        self._ctrl = ControlPanelWindow(root, frames, delays, challenge)

        # Override close protocols to track visibility
        self._spin._win.protocol("WM_DELETE_WINDOW", self._close_spin)
        self._ctrl._win.protocol("WM_DELETE_WINDOW", self._close_ctrl)

        challenge.on_tick(self._on_tick)
        challenge.on_flag(self._on_flag)

        self._tick_loop()

    def _set_vis(self, which, value):
        with _vis_lock:
            _vis_state[which] = value

    def _close_spin(self):
        self._spin._win.withdraw()
        self._set_vis("spin", False)

    def _close_ctrl(self):
        self._ctrl._win.withdraw()
        self._set_vis("ctrl", False)

    def _show_spin(self):
        self._spin._win.deiconify()
        self._spin._win.lift()
        self._set_vis("spin", True)

    def _show_ctrl(self):
        self._ctrl._win.deiconify()
        self._ctrl._win.lift()
        self._set_vis("ctrl", True)

    def _toggle_spin(self):
        with _vis_lock:
            visible = _vis_state["spin"]
        if visible:
            self._close_spin()
        else:
            self._show_spin()

    def _toggle_ctrl(self):
        with _vis_lock:
            visible = _vis_state["ctrl"]
        if visible:
            self._close_ctrl()
        else:
            self._show_ctrl()

    def show_windows(self):
        """Bring all fish windows back to front."""
        self._show_spin()
        self._show_ctrl()

    def _tick_loop(self):
        # Drain cross-thread message queue
        try:
            while True:
                msg = _msg_queue.get_nowait()
                if msg == "show_windows":
                    self.show_windows()
                elif msg == "toggle_spin":
                    self._toggle_spin()
                elif msg == "toggle_ctrl":
                    self._toggle_ctrl()
        except queue.Empty:
            pass

        self._ch.tick()
        remaining = self._ch.time_remaining()
        self._spin.update_timer(remaining)
        self._ctrl.update_timer(remaining)

        # Grace indicator needs frequent refresh
        grace = self._ch.grace_remaining()
        if grace is not None:
            self._ctrl._refresh_indicator()

        self._root.after(100, self._tick_loop)

    def _on_tick(self):
        self._spin.update()
        self._ctrl.update()

    def _on_flag(self):
        if not self._flag_shown:
            self._flag_shown = True
            self._root.after(0, lambda: show_flag_window(self._root))


# ─────────────────────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────────────────────
def main():
    if not PIL_OK:
        print("[fish] ERROR: Pillow (PIL) is required.")
        sys.exit(1)

    if not fetch_gif():
        print("[fish] ERROR: Could not obtain fish.gif.")
        sys.exit(1)

    # Root window MUST exist before ImageTk.PhotoImage is created
    root = tk.Tk()
    root.option_add("*tearOff", False)

    frames, delays = load_frames()
    if not frames:
        print("[fish] ERROR: Could not decode GIF frames.")
        sys.exit(1)

    challenge = ChallengeState()

    api_thread = threading.Thread(target=run_api, args=(challenge,), daemon=True)
    api_thread.start()
    print(f"[fish] API → http://localhost:{API_PORT}/api/status")

    FishApp(root, frames, delays, challenge)
    root.mainloop()


if __name__ == "__main__":
    main()
