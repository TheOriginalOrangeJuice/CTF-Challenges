#!/bin/bash
# ─────────────────────────────────────────────────────────────
# fish.exe CTF — container entrypoint
# ─────────────────────────────────────────────────────────────

echo "╔══════════════════════════════════════════════╗"
echo "║           FISH.EXE CTF CHALLENGE             ║"
echo "╠══════════════════════════════════════════════╣"
echo "║  Desktop:  http://localhost:6080             ║"
echo "║  API:      http://localhost:8080/api/status  ║"
echo "╚══════════════════════════════════════════════╝"

# ── Ensure GIF is cached ──────────────────────────────────────
if [ ! -s /tmp/fish_ctf.gif ]; then
    echo "[start] Downloading fish GIF…"
    curl -sL "https://spinning.fish/fish.gif" -o /tmp/fish_ctf.gif || true
fi

# ── Clean up stale Xvfb lock (container restart) ──────────────
rm -f /tmp/.X1-lock /tmp/.X11-unix/X1 2>/dev/null || true

# ── Xvfb — virtual display ────────────────────────────────────
echo "[start] Starting Xvfb…"
Xvfb :1 -screen 0 1024x768x24 -nolisten tcp -ac &

# Wait until the display is accepting connections
for i in $(seq 1 40); do
    DISPLAY=:1 xdpyinfo > /dev/null 2>&1 && break
    sleep 0.25
done
echo "[start] Display :1 ready"
export DISPLAY=:1

# ── Desktop background (set early, before any windows) ────────
xsetroot -solid '#008080' 2>/dev/null || true

# ── Background window (full-screen teal — belt-and-suspenders) ─
echo "[start] Starting desktop background…"
python3 /opt/fish/desktop/background.py &
sleep 0.5

# ── Window manager ────────────────────────────────────────────
echo "[start] Starting Openbox…"
openbox --config-file /root/.config/openbox/rc.xml &
sleep 1

# ── Taskbar ───────────────────────────────────────────────────
echo "[start] Starting taskbar…"
python3 /opt/fish/desktop/startbar.py &
sleep 0.5

# ── VNC server ────────────────────────────────────────────────
echo "[start] Starting x11vnc…"
x11vnc -display :1 -forever -nopw -shared -noxdamage -rfbport 5900 -q &
sleep 1

# ── noVNC WebSocket proxy ─────────────────────────────────────
echo "[start] Starting noVNC on :6080…"
websockify --web=/usr/share/novnc 0.0.0.0:6080 localhost:5900 &
sleep 0.5

# ── Fish application (foreground) ─────────────────────────────
echo "[start] Launching fish.exe…"
exec python3 /opt/fish/app/fish_app.py
