#!/usr/bin/env python3
"""
Win95 teal desktop background.
Full-screen window kept at the bottom of the Z-order.
"""
import tkinter as tk
import os

root = tk.Tk()
root.configure(bg="#008080")
root.overrideredirect(True)   # no WM title bar / decorations

root.update_idletasks()
sw = root.winfo_screenwidth()
sh = root.winfo_screenheight()
root.geometry(f"{sw}x{sh}+0+0")

# Lower to bottom of Z-order once window is mapped
def _lower():
    root.lower()
    root.after(2000, _lower)   # keep re-lowering in case something pushes it up

root.after(100, _lower)

# Belt-and-suspenders: also set X root window colour
os.system("xsetroot -solid '#008080' 2>/dev/null")

root.mainloop()
