#!/usr/bin/env python3
"""
Win95-style Start Bar for the FISH.EXE CTF desktop.
Full-width · 28 px · pinned to bottom · always on top.

Task area tracks open windows and provides minimize/restore.
"""
import tkinter as tk
import time
import os
import subprocess
import threading
import urllib.request
import json

BG     = "#c0c0c0"
NAVY   = "#000080"
WHITE  = "#ffffff"
BLACK  = "#000000"
SHADOW = "#808080"
FONT   = ("Helvetica", 9)
FONTB  = ("Helvetica", 9, "bold")

API_PORT = os.environ.get("API_PORT", "8080")
APPS_DIR = "/opt/fish/desktop/apps"
ENV      = dict(os.environ, DISPLAY=":1")


# ─────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────
def _call_api(path, method="GET", body=None):
    try:
        url  = f"http://localhost:{API_PORT}{path}"
        data = json.dumps(body).encode() if body else None
        req  = urllib.request.Request(url, data=data, method=method,
                                      headers={"Content-Type": "application/json"})
        resp = urllib.request.urlopen(req, timeout=1)
        return json.loads(resp.read())
    except Exception:
        return None


def _call_api_bg(path, method="GET", body=None):
    """Fire-and-forget in background thread."""
    threading.Thread(target=_call_api, args=(path, method, body),
                     daemon=True).start()


def _xdotool_wids(pid):
    """Return list of X window IDs for a given PID."""
    try:
        r = subprocess.run(
            ["xdotool", "search", "--pid", str(pid)],
            capture_output=True, text=True, timeout=2, env=ENV,
        )
        return r.stdout.strip().split() if r.returncode == 0 else []
    except Exception:
        return []


def _xdotool_toggle(state_ref, pid):
    """Toggle minimize/restore for the X windows owned by pid."""
    wids = _xdotool_wids(pid)
    if not wids:
        return
    wid = wids[-1]
    try:
        if state_ref[0] == "raised":
            subprocess.run(["xdotool", "windowminimize", wid],
                           env=ENV, timeout=2)
            state_ref[0] = "minimized"
        else:
            subprocess.run(["xdotool", "windowactivate", "--sync", wid],
                           env=ENV, timeout=2)
            state_ref[0] = "raised"
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────
# INLINE CALCULATOR  (Toplevel — no subprocess)
# ─────────────────────────────────────────────────────────────
class CalcWindow:
    def __init__(self, parent, on_close):
        self._on_close = on_close
        self.win = tk.Toplevel(parent)
        self.win.title("Calculator")
        self.win.configure(bg=BG)
        self.win.resizable(False, False)
        self.win.protocol("WM_DELETE_WINDOW", self._close)
        self._expr      = ""
        self._just_eval = False
        self._build()

    def _close(self):
        self.win.destroy()
        self.win = None
        self._on_close()

    def _build(self):
        r = self.win
        disp_frame = tk.Frame(r, relief="sunken", bd=2, bg=WHITE)
        disp_frame.grid(row=0, column=0, columnspan=4,
                        padx=6, pady=(6, 4), sticky="ew")
        self._disp = tk.StringVar(value="0")
        tk.Label(disp_frame, textvariable=self._disp,
                 font=("Courier", 16), bg=WHITE, fg=BLACK,
                 anchor="e", width=14).pack(padx=4, pady=2, fill="x")

        layout = [
            [("C",1,None), ("CE",1,None), ("⌫",1,None), ("/",1,None)],
            [("7",1,None), ("8",1,None),  ("9",1,None),  ("*",1,None)],
            [("4",1,None), ("5",1,None),  ("6",1,None),  ("-",1,None)],
            [("1",1,None), ("2",1,None),  ("3",1,None),  ("+",1,None)],
            [("±",1,None), ("0",1,None),  (".",1,None),  ("=",1,NAVY)],
        ]
        for row_idx, row in enumerate(layout, start=1):
            col = 0
            for text, span, color_bg in row:
                fg_col = WHITE if color_bg else BLACK
                bg_col = color_bg or BG
                tk.Button(
                    r, text=text,
                    font=("Helvetica", 11, "bold"),
                    width=4, height=2,
                    bg=bg_col, fg=fg_col,
                    activebackground=bg_col, activeforeground=fg_col,
                    relief="raised", bd=2,
                    command=lambda t=text: self._press(t),
                ).grid(row=row_idx, column=col, columnspan=span,
                       padx=2, pady=2, sticky="nsew")
                col += span

        r.bind("<Key>",       self._key)
        r.bind("<Return>",    lambda e: self._press("="))
        r.bind("<BackSpace>", lambda e: self._press("⌫"))
        r.bind("<Escape>",    lambda e: self._press("C"))

    def _press(self, key):
        if key == "C":
            self._expr = ""; self._disp.set("0"); self._just_eval = False
        elif key in ("CE", "⌫"):
            if not self._just_eval:
                self._expr = self._expr[:-1]
                self._disp.set(self._expr or "0")
            else:
                self._expr = ""; self._disp.set("0"); self._just_eval = False
        elif key == "±":
            try:
                val = eval(self._expr or "0")
                self._expr = str(-val) if val else "0"
                self._disp.set(self._expr)
            except Exception:
                pass
        elif key == "=":
            try:
                result = eval(self._expr.replace("×","*").replace("÷","/"))
                if isinstance(result, float) and result.is_integer():
                    result = int(result)
                self._expr = str(result); self._disp.set(self._expr)
                self._just_eval = True
            except Exception:
                self._disp.set("Error"); self._expr = ""; self._just_eval = False
        else:
            if self._just_eval and key in "0123456789.":
                self._expr = ""; self._just_eval = False
            elif self._just_eval and key in "+-*/":
                self._just_eval = False
            self._expr += key; self._disp.set(self._expr)

    def _key(self, event):
        if event.char in "0123456789.+-*/":
            self._press(event.char)

    def toggle(self):
        """Toggle visibility of the calc window."""
        if self.win is None:
            return
        if self.win.winfo_viewable():
            self.win.withdraw()
        else:
            self.win.deiconify()
            self.win.lift()


# ─────────────────────────────────────────────────────────────
# STARTBAR
# ─────────────────────────────────────────────────────────────
class StartBar:
    def __init__(self):
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.attributes("-topmost", True)
        self.root.configure(bg=BG)

        self.root.update_idletasks()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        self.root.geometry(f"{sw}x28+0+{sh - 28}")

        # Task tracking
        self._task_btns   = {}      # key → tk.Button
        self._calc        = None    # CalcWindow instance
        self._terms       = []      # list of (proc, state_ref, key)

        # Fish visibility cache
        self._fish_alive      = False
        self._fish_spin_vis   = True
        self._fish_ctrl_vis   = True

        self._build()
        self._clock_tick()
        self._poll_fish()
        self.root.mainloop()

    # ─────────────────────────────────────────────────────────
    def _build(self):
        r = self.root

        tk.Frame(r, height=2, bg=WHITE).pack(side="top", fill="x")
        bar = tk.Frame(r, bg=BG)
        bar.pack(fill="both", expand=True)

        # Start button
        self._start_btn = tk.Button(
            bar, text="  \u229e  Start  ", font=FONTB,
            bg=BG, activebackground=BG, fg=BLACK, activeforeground=BLACK,
            relief="raised", bd=2, command=self._start_menu,
        )
        self._start_btn.pack(side="left", padx=3, pady=2, ipady=1)

        # Separator
        tk.Frame(bar, width=2, bg=SHADOW).pack(side="left", fill="y", padx=(4,1), pady=3)
        tk.Frame(bar, width=1, bg=WHITE).pack(side="left",  fill="y", padx=(0,4), pady=3)

        # Task area (dynamic — between separators and clock)
        self._task_frame = tk.Frame(bar, bg=BG)
        self._task_frame.pack(side="left", fill="both", expand=True)

        # Clock
        clock_frame = tk.Frame(bar, relief="sunken", bd=2, bg=BG)
        clock_frame.pack(side="right", padx=5, pady=2)
        self._clock_var = tk.StringVar()
        tk.Label(clock_frame, textvariable=self._clock_var,
                 font=FONT, bg=BG).pack(padx=8, pady=1)

    # ─────────────────────────────────────────────────────────
    # Task button management
    # ─────────────────────────────────────────────────────────
    def _add_task_btn(self, key, label, cmd, sunken=False):
        if key in self._task_btns:
            return
        b = tk.Button(
            self._task_frame, text=label,
            font=("Helvetica", 8),
            bg=BG, activebackground=BG,
            fg=BLACK, activeforeground=BLACK,
            relief="sunken" if sunken else "raised", bd=2,
            width=14, anchor="w",
            command=cmd,
        )
        b.pack(side="left", padx=1, pady=2)
        self._task_btns[key] = b

    def _remove_task_btn(self, key):
        if key in self._task_btns:
            self._task_btns[key].destroy()
            del self._task_btns[key]

    def _set_task_btn_relief(self, key, sunken):
        if key in self._task_btns:
            self._task_btns[key].config(relief="sunken" if sunken else "raised")

    # ─────────────────────────────────────────────────────────
    # Clock
    # ─────────────────────────────────────────────────────────
    def _clock_tick(self):
        self._clock_var.set(time.strftime("%I:%M %p"))
        self.root.after(1000, self._clock_tick)

    # ─────────────────────────────────────────────────────────
    # Fish API polling
    # ─────────────────────────────────────────────────────────
    def _poll_fish(self):
        def _do_poll():
            data = _call_api("/api/status")
            self.root.after(0, lambda: self._on_fish_poll(data))

        threading.Thread(target=_do_poll, daemon=True).start()
        self.root.after(2000, self._poll_fish)

    def _on_fish_poll(self, data):
        if data is None:
            # Fish not alive
            if self._fish_alive:
                self._fish_alive = False
                self._remove_task_btn("fish_spin")
                self._remove_task_btn("fish_ctrl")
            return

        spin_vis = data.get("spin_visible", True)
        ctrl_vis = data.get("ctrl_visible", True)

        if not self._fish_alive:
            self._fish_alive = True
            self._add_task_btn("fish_spin", "🐟 fish-spinning.exe",
                               lambda: self._toggle_fish_win("spin"))
            self._add_task_btn("fish_ctrl", "🎮 controlpanel.exe",
                               lambda: self._toggle_fish_win("ctrl"))

        self._set_task_btn_relief("fish_spin", spin_vis)
        self._set_task_btn_relief("fish_ctrl", ctrl_vis)
        self._fish_spin_vis = spin_vis
        self._fish_ctrl_vis = ctrl_vis

    def _toggle_fish_win(self, which):
        endpoint = f"/api/window/toggle_{which}"
        _call_api_bg(endpoint, method="POST", body={})

    # ─────────────────────────────────────────────────────────
    # Start menu
    # ─────────────────────────────────────────────────────────
    def _start_menu(self):
        menu = tk.Menu(
            self.root, tearoff=0,
            bg=BG, fg=BLACK,
            activebackground=NAVY, activeforeground=WHITE,
            font=FONT, relief="raised", bd=2,
        )

        fish_sub = tk.Menu(menu, tearoff=0, bg=BG, fg=BLACK,
                           activebackground=NAVY, activeforeground=WHITE, font=FONT)
        fish_sub.add_command(label="  fish-spinning.exe",
                             font=FONTB, command=lambda: self._toggle_fish_win("spin"))
        fish_sub.add_command(label="  controlpanel.exe",
                             font=FONTB, command=lambda: self._toggle_fish_win("ctrl"))
        fish_sub.add_separator()
        fish_sub.add_command(label="  Relaunch fish.exe", command=self._relaunch_fish)
        menu.add_cascade(label="🐟  fish.exe  ►", menu=fish_sub)
        menu.add_separator()

        acc_sub = tk.Menu(menu, tearoff=0, bg=BG, fg=BLACK,
                          activebackground=NAVY, activeforeground=WHITE, font=FONT)
        acc_sub.add_command(label="  🖩  Calculator",    command=self._launch_calc)
        acc_sub.add_command(label="  💻  Command Prompt", command=self._launch_terminal)
        menu.add_cascade(label="📂  Accessories  ►", menu=acc_sub)
        menu.add_separator()

        menu.add_command(label="  ❓  Help / API Info",    command=self._show_help)
        menu.add_command(label="  ℹ️   About FISH.EXE CTF", command=self._show_about)
        menu.add_separator()
        menu.add_command(label="  🔌  Shut Down…", state="disabled")

        bx = self._start_btn.winfo_rootx()
        by = self._start_btn.winfo_rooty()
        menu.tk_popup(bx, by - 2)

    # ─────────────────────────────────────────────────────────
    # Fish window management
    # ─────────────────────────────────────────────────────────
    def _relaunch_fish(self):
        subprocess.run(["pkill", "-f", "fish_app.py"], env=ENV, check=False)
        self.root.after(500, lambda: subprocess.Popen(
            ["python3", "/opt/fish/app/fish_app.py"], env=ENV,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL))

    # ─────────────────────────────────────────────────────────
    # Calculator
    # ─────────────────────────────────────────────────────────
    def _launch_calc(self):
        if self._calc is not None and self._calc.win is not None:
            self._calc.toggle()
            self._set_task_btn_relief("calc",
                self._calc.win is not None and self._calc.win.winfo_viewable())
            return

        def on_calc_close():
            self._calc = None
            self._remove_task_btn("calc")

        self._calc = CalcWindow(self.root, on_calc_close)
        self._add_task_btn("calc", "🖩 Calculator",
                           self._toggle_calc, sunken=True)

    def _toggle_calc(self):
        if self._calc is None or self._calc.win is None:
            return
        self._calc.toggle()
        self._set_task_btn_relief("calc",
            self._calc.win is not None and self._calc.win.winfo_viewable())

    # ─────────────────────────────────────────────────────────
    # Terminal (xterm)
    # ─────────────────────────────────────────────────────────
    def _launch_terminal(self):
        proc = subprocess.Popen(
            ["xterm", "-fg", "white", "-bg", "black",
             "-fa", "Monospace", "-fs", "11",
             "-title", "Command Prompt", "-geometry", "80x24"],
            env=ENV, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        key       = f"term_{proc.pid}"
        state_ref = ["raised"]

        def toggle():
            threading.Thread(target=_xdotool_toggle,
                             args=(state_ref, proc.pid), daemon=True).start()

        self._add_task_btn(key, "💻 Command Prompt", toggle, sunken=True)

        def poll():
            if proc.poll() is not None:
                self._remove_task_btn(key)
            else:
                self.root.after(800, poll)

        self.root.after(800, poll)

    # ─────────────────────────────────────────────────────────
    # Help / About
    # ─────────────────────────────────────────────────────────
    def _show_help(self):
        win = tk.Toplevel(self.root)
        win.title("FISH.EXE — Help")
        win.configure(bg=BG)
        win.resizable(False, False)
        f = tk.Frame(win, bg=BG, padx=16, pady=12)
        f.pack()
        tk.Label(f, text="Automation API", font=FONTB, bg=BG, fg=NAVY).pack(anchor="w")
        tk.Label(f, text=(
            f"GET  http://localhost:{API_PORT}/api/status\n"
            f"POST http://localhost:{API_PORT}/api/rotate\n"
            f'     Body: {{"direction": "cw" | "ccw"}}\n\n'
            "• 66% chance to flip direction each interval (3–9 s)\n"
            "• 0.5 s grace period after a flip to correct\n"
            "• Miss the grace → all progress resets\n"
            "• 12 consecutive correct intervals = FLAG"
        ), font=("Courier", 9), bg=BG, justify="left").pack(anchor="w", pady=6)
        tk.Button(f, text="OK", command=win.destroy,
                  bg=BG, font=FONT, relief="raised", bd=2, width=8).pack()

    def _show_about(self):
        win = tk.Toplevel(self.root)
        win.title("About FISH.EXE CTF")
        win.configure(bg=BG)
        win.resizable(False, False)
        f = tk.Frame(win, bg=BG, padx=20, pady=16)
        f.pack()
        tk.Label(f, text="FISH.EXE", font=("Helvetica", 18, "bold"),
                 bg=BG, fg=NAVY).pack()
        tk.Label(f, text="Version 1.0\nA Windows 95 CTF Challenge\n\n"
                 "Automate the spinning fish rotation\nto reveal the hidden flag.",
                 font=FONT, bg=BG).pack(pady=8)
        tk.Button(f, text="OK", command=win.destroy,
                  bg=BG, font=FONT, relief="raised", bd=2, width=8).pack()


if __name__ == "__main__":
    StartBar()
