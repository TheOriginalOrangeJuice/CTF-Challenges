#!/usr/bin/env python3
"""
Win95-style Calculator for the FISH.EXE CTF desktop.
"""
import tkinter as tk

BG    = "#c0c0c0"
BTNBG = "#c0c0c0"
BLACK = "#000000"
NAVY  = "#000080"
WHITE = "#ffffff"


class Calculator:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Calculator")
        self.root.configure(bg=BG)
        self.root.resizable(False, False)

        self._expr      = ""
        self._just_eval = False   # track if last action was "="

        self._build()
        self.root.mainloop()

    def _build(self):
        r = self.root

        # ── Display ───────────────────────────────────────────
        disp_frame = tk.Frame(r, relief="sunken", bd=2, bg=WHITE)
        disp_frame.grid(row=0, column=0, columnspan=4,
                        padx=6, pady=(6, 4), sticky="ew")
        self._disp = tk.StringVar(value="0")
        tk.Label(
            disp_frame, textvariable=self._disp,
            font=("Courier", 16), bg=WHITE, fg=BLACK,
            anchor="e", width=14,
        ).pack(padx=4, pady=2, fill="x")

        # ── Buttons ───────────────────────────────────────────
        layout = [
            # text,  colspan, color_override
            [("C",1,None), ("CE",1,None), ("⌫",1,None), ("/",1,None)],
            [("7",1,None), ("8",1,None),  ("9",1,None),  ("*",1,None)],
            [("4",1,None), ("5",1,None),  ("6",1,None),  ("-",1,None)],
            [("1",1,None), ("2",1,None),  ("3",1,None),  ("+",1,None)],
            [("±",1,None), ("0",1,None),  (".",1,None),  ("=",1,NAVY)],
        ]

        for row_idx, row in enumerate(layout, start=1):
            col = 0
            for text, span, color_bg in row:
                fg_col = WHITE if color_bg else BLACK
                bg_col = color_bg or BTNBG
                tk.Button(
                    r, text=text,
                    font=("Helvetica", 11, "bold"),
                    width=4, height=2,
                    bg=bg_col, fg=fg_col,
                    activebackground=bg_col, activeforeground=fg_col,
                    relief="raised", bd=2,
                    command=lambda t=text: self._press(t),
                ).grid(row=row_idx, column=col, columnspan=span,
                       padx=2, pady=2, sticky="nsew")
                col += span

        # Keyboard bindings
        r.bind("<Key>", self._key)
        r.bind("<Return>", lambda e: self._press("="))
        r.bind("<BackSpace>", lambda e: self._press("⌫"))
        r.bind("<Escape>", lambda e: self._press("C"))

    def _press(self, key):
        if key == "C":
            self._expr = ""
            self._disp.set("0")
            self._just_eval = False

        elif key == "CE":
            if self._just_eval:
                self._expr = ""
                self._disp.set("0")
                self._just_eval = False
            else:
                self._expr = self._expr[:-1]
                self._disp.set(self._expr or "0")

        elif key == "⌫":
            if self._just_eval:
                pass   # do nothing after eval
            else:
                self._expr = self._expr[:-1]
                self._disp.set(self._expr or "0")

        elif key == "±":
            try:
                val = eval(self._expr or "0")
                self._expr = str(-val) if val else "0"
                self._disp.set(self._expr)
            except Exception:
                pass

        elif key == "=":
            try:
                result = eval(
                    self._expr.replace("×", "*").replace("÷", "/")
                )
                if isinstance(result, float) and result.is_integer():
                    result = int(result)
                self._expr = str(result)
                self._disp.set(self._expr)
                self._just_eval = True
            except Exception:
                self._disp.set("Error")
                self._expr = ""
                self._just_eval = False

        else:
            # digit or operator
            if self._just_eval and key in "0123456789.":
                # start fresh after eval if digit pressed
                self._expr = ""
                self._just_eval = False
            elif self._just_eval and key in "+-*/":
                # continue expression after eval with operator
                self._just_eval = False
            self._expr += key
            self._disp.set(self._expr)

    def _key(self, event):
        char = event.char
        if char in "0123456789.+-*/":
            self._press(char)


if __name__ == "__main__":
    Calculator()
