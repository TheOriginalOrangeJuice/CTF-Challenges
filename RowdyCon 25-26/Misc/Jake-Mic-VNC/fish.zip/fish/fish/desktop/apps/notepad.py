#!/usr/bin/env python3
"""
Win95-style Notepad for the FISH.EXE CTF desktop.
Pre-loaded with challenge help text; also editable.
"""
import tkinter as tk
from tkinter import filedialog, messagebox
import os

BG    = "#c0c0c0"
BLACK = "#000000"
WHITE = "#ffffff"
NAVY  = "#000080"

PORT  = os.environ.get("API_PORT", "8080")

HELP_TEXT = f"""\
FISH.EXE CTF — Challenge Notes
================================

OBJECTIVE
  Automate the static fish rotation to match the
  animated spinning fish for 12 consecutive intervals.

HOW IT WORKS
  • Every 3–9 seconds there is a random chance (55%)
    that the challenge direction flips (CW ↔ CCW).
  • You have 0.5 seconds to correct your direction
    after a flip or ALL progress is reset.
  • Match 12 intervals in a row to get the FLAG.

AUTOMATION API
  GET  http://localhost:{PORT}/api/status
  POST http://localhost:{PORT}/api/rotate
       Body: {{"direction": "cw" | "ccw"}}

SOLVE SCRIPT (Python)
  import requests, time
  API = "http://localhost:{PORT}"
  while True:
      st = requests.get(f"{{API}}/api/status").json()
      if st["flag"]:
          print("FLAG:", st["flag"])
          break
      requests.post(f"{{API}}/api/rotate",
                    json={{"direction": st["current_direction"]}})
      time.sleep(0.1)

STATUS FIELDS
  current_direction      — "cw" or "ccw"
  time_remaining         — seconds until next eval
  grace_period_remaining — seconds left in grace (or null)
  consecutive_correct    — streak count
  needed_to_win          — 12
  flag                   — null until you win

Good luck!
"""


class Notepad:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Notepad — challenge_notes.txt")
        self.root.configure(bg=BG)
        self.root.geometry("520x480")

        self._build()
        self._text.insert("1.0", HELP_TEXT)
        self.root.mainloop()

    def _build(self):
        r = self.root

        # ── Menu bar ──────────────────────────────────────────
        menubar = tk.Menu(r, bg=BG, fg=BLACK,
                          activebackground=NAVY, activeforeground=WHITE,
                          relief="flat", font=("Helvetica", 9))

        file_menu = tk.Menu(menubar, tearoff=0, bg=BG, fg=BLACK,
                             activebackground=NAVY, activeforeground=WHITE,
                             font=("Helvetica", 9))
        file_menu.add_command(label="New",  command=self._new)
        file_menu.add_command(label="Open…", command=self._open)
        file_menu.add_command(label="Save…", command=self._save)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=r.destroy)
        menubar.add_cascade(label="File", menu=file_menu)

        edit_menu = tk.Menu(menubar, tearoff=0, bg=BG, fg=BLACK,
                             activebackground=NAVY, activeforeground=WHITE,
                             font=("Helvetica", 9))
        edit_menu.add_command(label="Select All",
                              command=lambda: self._text.tag_add("sel", "1.0", "end"))
        edit_menu.add_command(label="Clear",
                              command=lambda: self._text.delete("1.0", "end"))
        menubar.add_cascade(label="Edit", menu=edit_menu)

        r.config(menu=menubar)

        # ── Text area ─────────────────────────────────────────
        frame = tk.Frame(r, bg=BG)
        frame.pack(fill="both", expand=True, padx=2, pady=2)

        scrollbar = tk.Scrollbar(frame)
        scrollbar.pack(side="right", fill="y")

        self._text = tk.Text(
            frame,
            font=("Courier", 10),
            bg=WHITE, fg=BLACK,
            relief="sunken", bd=2,
            wrap="word",
            yscrollcommand=scrollbar.set,
        )
        self._text.pack(fill="both", expand=True)
        scrollbar.config(command=self._text.yview)

        # ── Status bar ────────────────────────────────────────
        sb = tk.Frame(r, relief="sunken", bd=1, bg=BG)
        sb.pack(fill="x", side="bottom")
        tk.Label(sb, text=" challenge_notes.txt",
                 font=("Helvetica", 8), bg=BG, anchor="w").pack(side="left")

    def _new(self):
        self._text.delete("1.0", "end")

    def _open(self):
        path = filedialog.askopenfilename(
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if path:
            with open(path) as f:
                self._text.delete("1.0", "end")
                self._text.insert("1.0", f.read())
            self.root.title(f"Notepad — {os.path.basename(path)}")

    def _save(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if path:
            with open(path, "w") as f:
                f.write(self._text.get("1.0", "end"))


if __name__ == "__main__":
    Notepad()
