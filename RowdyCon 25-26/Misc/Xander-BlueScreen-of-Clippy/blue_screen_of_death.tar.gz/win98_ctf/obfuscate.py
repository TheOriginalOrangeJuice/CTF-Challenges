import sys
import base64
import random
import json
import hashlib
import string
import os
import zlib
import struct
import math
import re

TARGET_SIZE = 1024 * 1024  # 1MB target

# The expected hostname where this CTF runs — used for domain-locked encryption.
# Change this to match your deployment domain.
LOCK_HOSTNAME = os.environ.get('CTF_HOSTNAME', 'localhost')

def generate_var_name():
    prefixes = ['_', '$', '__', '$$', '_$', '$_', '___', '_$$', '$$_', '$__']
    confusables = [
        '\u0430', '\u0435', '\u043E', '\u0440', '\u0441', '\u0445',
        '\u0456', '\u0458', '\u0455', '\u044C', '\u043A', '\u043D',
    ]
    prefix = random.choice(prefixes)
    suffix = ''.join(random.choices(confusables, k=random.randint(4, 8)))
    return prefix + suffix

def encode_number(n):
    if n == 0:
        return random.choice(['(+[])', '(~~[])', '(!+[]+!+[]-!+[]-!+[])', '(+!+[]-!+[])'])
    if n == 1:
        return random.choice(['(+!+[])', '(!+[]+!+[]-!+[])', '(~~!"")'])
    if n > 10:
        return random.choice([f'(0x{n:x})', f'({n})', f'({n ^ 0xAA}^0xAA)', f'({n ^ 0x55}^0x55)'])
    strategies = [
        lambda: f'({encode_number(n >> 1)}<<{encode_number(1)}{"+" + encode_number(1) if n & 1 else ""})',
        lambda: f'({encode_number(n - 1)}+{encode_number(1)})',
        lambda: f'({n ^ 0xFF}^{0xFF})',
        lambda: f'(0x{n:x})',
    ]
    return random.choice(strategies)()

def xor_encode(data, key):
    if isinstance(data, str):
        data = data.encode('utf-8')
    if isinstance(key, str):
        key = key.encode('utf-8')
    return bytes(d ^ key[i % len(key)] for i, d in enumerate(data))

def chunk_and_shuffle(data, chunk_size=64):
    chunks = [data[i:i+chunk_size] for i in range(0, len(data), chunk_size)]
    indices = list(range(len(chunks)))
    random.shuffle(indices)
    shuffled = [chunks[i] for i in indices]
    order = [0] * len(indices)
    for new_pos, orig_pos in enumerate(indices):
        order[orig_pos] = new_pos
    return shuffled, order

def _busted_page_js():
    """The page shown when devtools are detected. Self-contained HTML with angry Clippy."""
    # Angry Clippy messages that cycle
    messages = [
        "I TOLD you not to do that.",
        "You think you can just INSPECT ME?",
        "Close the developer tools. NOW.",
        "This is a violation of Windows 98 EULA Section 42.",
        "I'm not angry, I'm just disappointed.",
        "Do you know what happens to people who open DevTools?",
        "I will remember this.",
        "Did Bill Gates die for this?",
        "You should NOT be doing that.",
        "The system administrator has been notified.",
        "Your hacking license has been revoked.",
        "I'm calling the cyber police.",
        "Every time you open DevTools, a Clippy loses its wings.",
        "STOP. You have violated the law.",
        "I used to help people write letters. Now I watch them commit crimes.",
        "Close DevTools and nobody gets hurt.",
        "You wouldn't download a car. You wouldn't inspect a webpage.",
        "Microsoft Security Alert: Unauthorized access detected.",
    ]
    import json
    msgs_json = json.dumps(messages)

    # Use the real Clippy sprite sheet from modern-clippy
    clippy_img_url = "https://raw.githubusercontent.com/vchaindz/modern-clippy/main/public/agents/Clippy/map.png"

    return (
        "document.documentElement.innerHTML='';"
        "document.head.innerHTML='<style>"
        "*{margin:0;padding:0;box-sizing:border-box}"
        "body{background:#008080;overflow:hidden;cursor:default}"
        ".bsod{position:fixed;top:0;left:0;right:0;bottom:0;background:#0000aa;color:#fff;"
        "font-family:Fixedsys,Lucida Console,Courier New,monospace;font-size:16px;"
        "display:flex;flex-direction:column;align-items:center;justify-content:center;"
        "padding:40px;text-align:center;z-index:1}"
        ".title{background:#a8a8a8;color:#0000aa;padding:2px 12px;font-weight:bold;margin-bottom:30px}"
        ".clippy-angry{position:fixed;z-index:9999;pointer-events:none}"
        ".bubble{background:#ffffcc;border:2px solid #000;border-radius:12px;padding:14px 16px;"
        "max-width:260px;font-size:13px;font-family:Tahoma,sans-serif;font-weight:bold;"
        "margin-bottom:6px;position:relative;box-shadow:3px 3px 0 rgba(0,0,0,0.3);"
        "pointer-events:auto;cursor:default;color:#000}"
        ".bubble::after{content:\\'\\';position:absolute;bottom:-12px;left:50%;"
        "margin-left:-6px;border:6px solid transparent;border-top-color:#ffffcc}"
        ".clippy-sprite{width:124px;height:93px;"
        "background-image:url(" + clippy_img_url + ");"
        "background-position:0 0;background-repeat:no-repeat;"
        "image-rendering:pixelated;"
        "animation:clippy-anim 0.6s steps(1) infinite}"
        "@keyframes clippy-anim{"
        "0%{background-position:0 0}"
        "25%{background-position:-124px 0}"
        "50%{background-position:-248px 0}"
        "75%{background-position:-372px 0}"
        "100%{background-position:0 0}}"
        "</style>';"
        "document.body.innerHTML='"
        "<div class=\"bsod\">"
        "<div class=\"title\">&nbsp;Windows&nbsp;</div>"
        "<p>A fatal exception 0x0000DEAD has occurred at 0028:DEVT00LS</p><br>"
        "<p style=\"font-size:22px;margin:20px 0\">You should not be doing that.</p><br>"
        "<p>The developer tools have been detected and this system</p>"
        "<p>has been locked to protect its integrity.</p><br><br>"
        "<p style=\"color:#a8a8a8\">Press Ctrl+W to close this tab and try again properly.</p>"
        "</div>"
        "<div class=\"clippy-angry\" id=\"angry-clippy\">"
        "<div class=\"bubble\" id=\"clippy-msg\">I TOLD you not to do that.</div>"
        "<div class=\"clippy-sprite\"></div>"
        "</div>';"
        "var _msgs=" + msgs_json + ";"
        "var _mi=0;"
        "var _cx=window.innerWidth-200;"
        "var _cy=window.innerHeight-200;"
        "var _mx=window.innerWidth/2;"
        "var _my=window.innerHeight/2;"
        "document.addEventListener('mousemove',function(e){_mx=e.clientX;_my=e.clientY});"
        # Fast tick - 30fps movement, gets right under the cursor
        "setInterval(function(){"
        "var el=document.getElementById('angry-clippy');"
        "if(!el)return;"
        # Target: directly under cursor, offset so clippy's face is at the pointer
        "var tx=_mx-40;var ty=_my-10;"
        "var dx=tx-_cx;var dy=ty-_cy;"
        "var dist=Math.sqrt(dx*dx+dy*dy);"
        # Aggressive: 15-25% of distance per tick, faster when far, always closing in
        "var speed=dist>200?0.25:dist>50?0.15:0.08;"
        "_cx+=dx*speed;_cy+=dy*speed;"
        "el.style.left=Math.round(_cx)+'px';el.style.top=Math.round(_cy)+'px';"
        "},33);"
        # Separate slower tick for message cycling
        "setInterval(function(){"
        "var msg=document.getElementById('clippy-msg');"
        "if(!msg)return;"
        "_mi=(_mi+1)%_msgs.length;"
        "msg.textContent=_msgs[_mi];"
        "},1800);"
    )

def generate_anti_debug():
    trap_var = generate_var_name()
    check_var = generate_var_name()
    interval_var = generate_var_name()
    counter_var = generate_var_name()
    canvas_var = generate_var_name()
    timing_var = generate_var_name()
    catch_var = generate_var_name()
    busted_func = generate_var_name()

    busted = _busted_page_js()
    # Encode the busted page function as char codes so strings aren't grep-able
    busted_codes = [ord(c) for c in busted]
    busted_arr_var = generate_var_name()
    busted_str_var = generate_var_name()
    busted_build_var = generate_var_name()
    busted_chunk_var = generate_var_name()

    return f"""
try{{(function(){{
var {busted_arr_var}=[{','.join(str(c) for c in busted_codes)}];
var {busted_str_var}='';for(var {busted_build_var}=0;{busted_build_var}<{busted_arr_var}.length;{busted_build_var}+=4096){{var {busted_chunk_var}={busted_arr_var}.slice({busted_build_var},Math.min({busted_build_var}+4096,{busted_arr_var}.length));{busted_str_var}+=String.fromCharCode.apply(null,{busted_chunk_var});}}
var {busted_func}=new Function({busted_str_var});
var {counter_var}=0;
var {check_var}=/./;{check_var}.toString=function(){{{busted_func}()}};
var {interval_var}=setInterval(function(){{try{{var {timing_var}=performance.now();debugger;if(performance.now()-{timing_var}>10){{clearInterval({interval_var});{busted_func}();}}}}catch(_){{}};{counter_var}++;}},5000);
try{{var {canvas_var}=document.createElement('div');Object.defineProperty({canvas_var},'id',{{get:function(){{{busted_func}()}}}});console.log({canvas_var});}}catch({catch_var}){{}}
}})();}}catch(_){{}}
"""

def generate_decoy_code(density=1):
    decoys = []
    count = random.randint(4 * density, 8 * density)
    for _ in range(count):
        v1, v2, v3 = generate_var_name(), generate_var_name(), generate_var_name()
        patterns = [
            f'var {v1}=function({v2}){{return {v2}^{random.randint(1,255)}}};',
            f'var {v1}=[{",".join(str(random.randint(0,255)) for _ in range(random.randint(8,32)))}];',
            f'var {v1}=null||function(){{return {encode_number(random.randint(0,100))}}};',
            f'try{{var {v1}=window["x{random.randint(10000,99999)}"]}}catch({v2}){{}}',
            f'var {v1}=String.fromCharCode.apply(null,[{",".join(str(random.randint(33,126)) for _ in range(random.randint(12,48)))}]);',
            f'var {v1}={{a{random.randint(0,999)}:{random.randint(0,0xFFFF)},b{random.randint(0,999)}:{random.randint(0,0xFFFF)},c{random.randint(0,999)}:{random.randint(0,0xFFFF)}}};',
            f'var {v1}=function(){{var {v2}=[{",".join(str(random.randint(0,255)) for _ in range(16))}];return {v2}.reduce(function(a,b){{return a^b}},0)}};',
            f'var {v1}=new ArrayBuffer({random.randint(16,64)});var {v2}=new Uint8Array({v1});for(var {v3}=0;{v3}<{v2}.length;{v3}++){v2}[{v3}]={v3}^{random.randint(1,255)};',
        ]
        decoys.append(random.choice(patterns))
    return '\n'.join(decoys)

def generate_fake_crypto_operations():
    """Generate fake but realistic-looking crypto operations to waste analyst time."""
    blocks = []
    for _ in range(random.randint(8, 15)):
        v1, v2, v3, v4 = [generate_var_name() for _ in range(4)]
        key_bytes = ','.join(str(random.randint(0, 255)) for _ in range(32))
        iv_bytes = ','.join(str(random.randint(0, 255)) for _ in range(16))

        patterns = [
            # Fake AES-like round
            f'var {v1}=[{key_bytes}];var {v2}=[{iv_bytes}];var {v3}=function({v4}){{for(var i=0;i<{v1}.length;i++){v4}[i%{v4}.length]^={v1}[i]^{v2}[i%{v2}.length];return {v4}}};',
            # Fake SHA-like hash
            f'var {v1}=function({v2}){{var {v3}=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a];for(var i=0;i<{v2}.length;i++){v3}[i%4]=({v3}[i%4]<<5|{v3}[i%4]>>>27)+{v2}.charCodeAt(i);return {v3}.map(function(x){{return(x>>>0).toString(16)}}).join("")}};',
            # Fake HMAC
            f'var {v1}=[{key_bytes}];var {v2}=function({v3}){{var {v4}=new Uint8Array({v1}.length);for(var i=0;i<{v1}.length;i++){v4}[i]={v1}[i]^0x36;return {v4}}};',
            # Fake key schedule
            f'var {v1}=new Uint32Array([{",".join(str(random.randint(0,0xFFFFFFFF)) for _ in range(8))}]);for(var {v2}=8;{v2}<44;{v2}++){v1}[{v2}%8]={v1}[({v2}-1)%8]^{v1}[({v2}-8)%8]^(({v1}[({v2}-1)%8]<<3)|({v1}[({v2}-1)%8]>>>29));',
            # Fake S-box
            f'var {v1}=new Uint8Array(256);for(var {v2}=0;{v2}<256;{v2}++){v1}[{v2}]=(({v2}*0x0101010101010101&0x8040201008040201)%0x1FF)&0xFF^{random.randint(0,255)};',
        ]
        blocks.append(random.choice(patterns))
    return '\n'.join(blocks)

def generate_fake_network_code():
    """Generate fake XHR/fetch calls that look like C2 communication."""
    blocks = []
    for _ in range(random.randint(4, 8)):
        v1, v2, v3 = [generate_var_name() for _ in range(3)]
        fake_endpoints = [
            '/api/v2/telemetry', '/api/v1/heartbeat', '/api/sync',
            '/api/config/update', '/api/session/validate', '/api/auth/refresh',
            '/internal/metrics', '/internal/health', '/ws/subscribe',
        ]
        patterns = [
            f'var {v1}=function(){{try{{var {v2}=new XMLHttpRequest();{v2}.open("POST","{random.choice(fake_endpoints)}",false);{v2}.setRequestHeader("X-Token","{generate_var_name()}");{v2}.send(JSON.stringify({{t:Date.now(),s:"{hashlib.md5(os.urandom(8)).hexdigest()}"}}));return JSON.parse({v2}.responseText)}}catch({v3}){{return null}}}};',
            f'var {v1}=function(){{return new Promise(function({v2},{v3}){{setTimeout(function(){{{v2}([{",".join(str(random.randint(0,255)) for _ in range(16))}])}},{encode_number(random.randint(100,2000))})}}).catch(function(){{}})}};',
        ]
        blocks.append(random.choice(patterns))
    return '\n'.join(blocks)

def generate_wasm_noise():
    """Generate fake WebAssembly instantiation that looks like hidden computation."""
    v1, v2, v3, v4 = [generate_var_name() for _ in range(4)]
    # Generate random but valid-looking wasm bytes (actually garbage)
    wasm_bytes = ','.join(str(random.randint(0, 255)) for _ in range(random.randint(200, 500)))
    return f"""
var {v1}=new Uint8Array([{wasm_bytes}]);
try{{var {v2}=new WebAssembly.Module({v1});var {v3}=new WebAssembly.Instance({v2});var {v4}={v3}.exports;}}catch({generate_var_name()}){{}}
"""

def generate_canvas_fingerprint():
    """Generate canvas fingerprinting code (makes analysts think it's malware)."""
    v1, v2, v3, v4, v5 = [generate_var_name() for _ in range(5)]
    return f"""
var {v1}=document.createElement('canvas');{v1}.width=256;{v1}.height=256;
var {v2}={v1}.getContext('2d');
{v2}.fillStyle='rgb({random.randint(0,255)},{random.randint(0,255)},{random.randint(0,255)})';
{v2}.fillRect(0,0,256,256);
{v2}.font='18px Arial';{v2}.fillStyle='#{hashlib.md5(os.urandom(4)).hexdigest()[:6]}';
{v2}.fillText(navigator.userAgent.substr(0,32),2,18);
var {v3}={v1}.toDataURL();
var {v4}=0;for(var {v5}=0;{v5}<{v3}.length;{v5}++){v4}=(({v4}<<5)-{v4})+{v3}.charCodeAt({v5})|0;
"""

def generate_mega_padding(target_extra_bytes):
    """Generate massive amounts of inert but terrifying-looking code to hit size target."""
    blocks = []
    generated = 0

    generators = [
        generate_decoy_code,
        generate_fake_crypto_operations,
        generate_fake_network_code,
        generate_canvas_fingerprint,
        generate_wasm_noise,
    ]

    while generated < target_extra_bytes:
        gen = random.choice(generators)
        if gen == generate_decoy_code:
            block = gen(density=random.randint(3, 8))
        else:
            block = gen()

        # Wrap in try-catch IIFE so failures are silent and vars don't leak
        wrapped = f'try{{(function(){{{block}}})();}}catch(_){{}}\n'
        blocks.append(wrapped)
        generated += len(wrapped)

        if random.random() < 0.3:
            v = generate_var_name()
            arr_size = random.randint(500, 2000)
            data_block = f'var {v}=[{",".join(str(random.randint(0,255)) for _ in range(arr_size))}];\n'
            blocks.append(data_block)
            generated += len(data_block)

    random.shuffle(blocks)
    return '\n'.join(blocks)

def generate_opaque_predicate_true():
    """Generate a condition that is always true but hard to prove statically.
    Uses number-theoretic properties that require actual computation to verify."""
    strategies = []

    # Fermat's little theorem: a^(p-1) ≡ 1 (mod p) for prime p, a not divisible by p
    # Pick small primes and bases so the JS math works without BigInt
    p = random.choice([7, 11, 13, 17, 19, 23])
    a = random.randint(2, p - 1)
    expected = pow(a, p - 1, p)  # always 1
    v1, v2 = generate_var_name(), generate_var_name()
    strategies.append(
        f'(function(){{var {v1}={a};var {v2}=1;for(var i=0;i<{p - 1};i++){v2}=({v2}*{v1})%{p};return {v2}==={expected}}})()'
    )

    # Sum of first n naturals: n*(n+1)/2
    n = random.randint(10, 50)
    s = n * (n + 1) // 2
    v1 = generate_var_name()
    strategies.append(
        f'(function(){{var {v1}=0;for(var i=1;i<={n};i++){v1}+=i;return {v1}==={s}}})()'
    )

    # Collatz conjecture: any starting number eventually reaches 1
    start = random.randint(3, 30)
    v1, v2 = generate_var_name(), generate_var_name()
    strategies.append(
        f'(function(){{var {v1}={start};var {v2}=0;while({v1}!==1&&{v2}<200){{{v1}={v1}%2===0?{v1}/2:3*{v1}+1;{v2}++}};return {v1}===1}})()'
    )

    # GCD of two coprime numbers is 1
    a_val = random.choice([7, 11, 13, 17, 19, 23, 29, 31])
    b_val = random.choice([x for x in [8, 9, 10, 12, 14, 15, 16, 18, 20, 25, 27] if math.gcd(a_val, x) == 1])
    v1, v2, v3 = generate_var_name(), generate_var_name(), generate_var_name()
    strategies.append(
        f'(function(){{var {v1}={a_val};var {v2}={b_val};while({v2}){{var {v3}={v2};{v2}={v1}%{v2};{v1}={v3}}};return {v1}===1}})()'
    )

    return random.choice(strategies)


def generate_opaque_predicate_false():
    """Generate a condition that is always false but hard to prove statically."""
    # Negate a true predicate with extra indirection
    true_pred = generate_opaque_predicate_true()
    v = generate_var_name()
    return f'(function(){{var {v}={true_pred};return !{v}}})()'


def generate_anti_node():
    """Generate code that detects Node.js execution and poisons the output.
    Instead of crashing (which is easily caught), this silently corrupts
    decode operations so extracted code is garbage."""
    poison_var = generate_var_name()
    check_var = generate_var_name()
    flag_var = generate_var_name()

    # Multiple detection vectors
    checks = [
        f'typeof process!=="undefined"&&process.versions&&process.versions.node',
        f'typeof require==="function"',
        f'typeof Buffer==="function"',
        f'typeof global!=="undefined"&&global===global',
        f'typeof __dirname!=="undefined"',
        f'typeof module!=="undefined"&&typeof module.exports!=="undefined"',
        f'typeof window==="undefined"',
        f'typeof navigator==="undefined"',
    ]

    # Pick a random subset of checks so each build looks different
    selected = random.sample(checks, k=random.randint(4, len(checks)))
    combined = '||'.join(f'({c})' for c in selected)

    # Also check for common headless/automation signals
    browser_checks_var = generate_var_name()
    browser_checks = [
        f'navigator.webdriver===true',
        f'window.chrome===undefined&&/Chrome/.test(navigator.userAgent)',
    ]
    browser_combined = '||'.join(f'({c})' for c in browser_checks)

    return f"""
var {flag_var}=false;
try{{if({combined}){{{flag_var}=true}}}}catch({generate_var_name()}){{}}
try{{if(!{flag_var}&&({browser_combined})){{{flag_var}=true}}}}catch({generate_var_name()}){{}}
"""


def derive_hostname_key_js(key_var, salt_hex, flag_var):
    """Generate JS code that derives a decryption key from window.location.hostname.
    If the hostname doesn't match, the derived key will be wrong and decryption
    produces garbage — no explicit check, just silent failure."""
    hash_var = generate_var_name()
    char_var = generate_var_name()
    salt_var = generate_var_name()

    # Simple JS hash: for each char of hostname+salt, accumulate via shift-xor
    return f"""
var {salt_var}='{salt_hex}';
var {hash_var}=0;
var {char_var}='';
try{{{char_var}=window.location.hostname;}}catch({generate_var_name()}){{}}
{char_var}+={salt_var};
for(var i=0;i<{char_var}.length;i++){{{hash_var}=(({hash_var}<<5)-{hash_var})+{char_var}.charCodeAt(i);{hash_var}|=0;}}
var {key_var}=({hash_var}>>>0)&0xFF;
"""


def compute_hostname_key_byte(hostname, salt_hex):
    """Python-side: compute the same hash as the JS derive function.
    Must exactly replicate JS signed 32-bit |= 0 during accumulation,
    then unsigned >>> 0 at the end."""
    s = hostname + salt_hex
    h = 0
    for c in s:
        h = ((h << 5) - h) + ord(c)
        # Simulate JS |= 0: convert to signed 32-bit
        h = h & 0xFFFFFFFF
        if h >= 0x80000000:
            h -= 0x100000000
    # Simulate JS >>> 0: convert to unsigned 32-bit
    h = h & 0xFFFFFFFF
    return h & 0xFF

def build_single_layer_decoder(js_code):
    """Build a single flattened decode layer — no nested eval chains.

    Pipeline (all in one IIFE):
      1. Anti-Node.js detection (sets poison flag)
      2. Domain-locked key derivation from window.location.hostname
      3. Reassemble shuffled base64 chunks via index array
      4. Base64 decode -> XOR with hostname-derived byte -> XOR with static key
      5. Integrity check on decoded payload (CRC32)
      6. Opaque-predicate guard around final Function() call
      7. Execute via new Function() (not eval — harder to intercept by regex)
    """
    # --- Encryption (Python-side) ---
    static_key = os.urandom(16)
    static_key_hex = static_key.hex()

    # Domain-derived key byte
    salt_hex = os.urandom(8).hex()
    hostname_byte = compute_hostname_key_byte(LOCK_HOSTNAME, salt_hex)

    # Apply static XOR first, then hostname XOR on top
    xored = xor_encode(js_code, static_key)
    xored = bytes(b ^ hostname_byte for b in xored)

    # Base64 encode
    b64 = base64.b64encode(xored).decode()

    # Chunk and shuffle
    chunk_size = random.randint(48, 96)
    chunks, order = chunk_and_shuffle(b64, chunk_size=chunk_size)

    # Compute CRC32 of the original JS for integrity verification
    crc = zlib.crc32(js_code.encode('utf-8')) & 0xFFFFFFFF

    # --- Variable names ---
    chunks_var = generate_var_name()
    order_var = generate_var_name()
    static_key_var = generate_var_name()
    hostname_key_var = generate_var_name()
    assembled_var = generate_var_name()
    decoded_var = generate_var_name()
    result_var = generate_var_name()
    xor_func = generate_var_name()
    b64_func = generate_var_name()
    str_var = generate_var_name()
    crc_var = generate_var_name()
    crc_func = generate_var_name()
    poison_flag = generate_var_name()
    exec_var = generate_var_name()
    crc_table_var = generate_var_name()

    chunks_json = json.dumps(chunks)
    order_json = json.dumps(order)

    # --- Anti-Node.js code (uses poison_flag directly) ---
    anti_node_code = generate_anti_node()
    # Replace the generated flag name with our chosen one
    # The anti_node code defines "var XXXX=false;" — extract and replace
    flag_match = re.search(r'var\s+(\S+?)=false;', anti_node_code)
    if flag_match:
        anti_node_code = anti_node_code.replace(flag_match.group(1), poison_flag)

    # --- Domain key derivation ---
    domain_key_code = derive_hostname_key_js(hostname_key_var, salt_hex, poison_flag)

    # --- Opaque predicates ---
    opaque_true = generate_opaque_predicate_true()
    decoy_branch_code = generate_decoy_code(density=3)

    decoder = f"""
(function(){{
{anti_node_code}
{domain_key_code}
{generate_decoy_code(density=2)}
var {chunks_var}={chunks_json};
var {order_var}={order_json};
var {static_key_var}='{static_key_hex}';
{generate_decoy_code(density=2)}
if({poison_flag}){{var {generate_var_name()}=Math.random();{static_key_var}={static_key_var}.split('').reverse().join('');}}
var {assembled_var}='';
for(var i=0;i<{order_var}.length;i++){{{assembled_var}+={chunks_var}[{order_var}[i]];}}
var {b64_func}=function(s){{var b=atob(s);var r=new Uint8Array(b.length);for(var i=0;i<b.length;i++)r[i]=b.charCodeAt(i);return r;}};
var {decoded_var}={b64_func}({assembled_var});
var {xor_func}=function(d,k,hk){{var kb=[];for(var i=0;i<k.length;i+=2)kb.push(parseInt(k.substr(i,2),16));var r=new Uint8Array(d.length);for(var i=0;i<d.length;i++)r[i]=(d[i]^hk)^kb[i%kb.length];return r;}};
var {result_var}={xor_func}({decoded_var},{static_key_var},{hostname_key_var});
var {str_var}='';for(var i=0;i<{result_var}.length;i+=4096){{{str_var}+=String.fromCharCode.apply(null,Array.prototype.slice.call({result_var},i,Math.min(i+4096,{result_var}.length)));}}
{generate_decoy_code(density=2)}
var {crc_table_var}=(function(){{var t=new Uint32Array(256);for(var n=0;n<256;n++){{var c=n;for(var k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c}};return t}})();
var {crc_func}=function(s){{var c=0xFFFFFFFF;for(var i=0;i<s.length;i++)c={crc_table_var}[(c^s.charCodeAt(i))&0xFF]^(c>>>8);return (c^0xFFFFFFFF)>>>0}};
var {crc_var}={crc_func}({str_var});
if({crc_var}!=={crc}){{{str_var}='';}}
if({opaque_true}){{
var {exec_var}=new Function({str_var});
{exec_var}();
}}else{{
{decoy_branch_code}
}}
}})();
"""
    return decoder


def obfuscate(input_js):
    decoder = build_single_layer_decoder(input_js)
    anti_debug = generate_anti_debug()

    core = f"{anti_debug}\n{decoder}"
    current_size = len(core)
    padding_needed = max(0, TARGET_SIZE - current_size)

    if padding_needed > 0:
        padding = generate_mega_padding(padding_needed)
        # Split on block boundaries (double newlines), not individual lines,
        # to avoid breaking multi-line try/catch wrappers
        padding_blocks = [b.strip() for b in padding.split('\n\n') if b.strip()]
        random.shuffle(padding_blocks)

        mid = len(padding_blocks) // 3
        before = '\n'.join(padding_blocks[:mid])
        middle = '\n'.join(padding_blocks[mid:mid*2])
        after = '\n'.join(padding_blocks[mid*2:])
    else:
        before = middle = after = ""

    final = f"{before}\n{middle}\n{anti_debug}\n{after}\n{decoder}\n"
    return final


def main():
    if len(sys.argv) < 3:
        print("Usage: python obfuscate.py input.js output.js")
        sys.exit(1)

    input_file = sys.argv[1]
    output_file = sys.argv[2]

    with open(input_file, 'r') as f:
        js_code = f.read()

    print(f"Input: {len(js_code)} bytes")
    obfuscated = obfuscate(js_code)

    with open(output_file, 'w') as f:
        f.write(obfuscated)

    size_kb = len(obfuscated) / 1024
    size_mb = size_kb / 1024
    print(f"Output: {len(obfuscated)} bytes ({size_mb:.2f} MB)")
    print(f"Bloat factor: {len(obfuscated) / len(js_code):.1f}x")


if __name__ == '__main__':
    main()
