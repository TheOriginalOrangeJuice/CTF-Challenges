import hashlib, hmac
import requests

def crc8(data):
    crc = 0
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ 0x07) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc

g1 = "16000"    # 1+6 = 7 ✓
g2 = "OEM98"    # fixed
g3 = "GBCRD"    # G^0x37=p, B^0x37=u, C^0x37=t, R^0x37=e, D^0x37=s
                # reversed: "setup" → uppercase match ✓

s = requests.Session()
combined = f"{g1}-{g2}-{g3}"
crc = crc8(combined.encode())
g4 = format(crc, '02X').zfill(5)[:5]   # "0002B"

hmac_input = f"{g1}-{g2}-{g3}-{g4}"
g5 = hmac.new(b"MICROSOFT_WINDOWS_98_SE",
              hmac_input.encode(), hashlib.md5).hexdigest()[:5].upper()

key = f"{g1}-{g2}-{g3}-{g4}-{g5}"
print(key)  # 16000-OEM98-GBCRD-0002B-7D68F


#**Submitting the key (requires CAPTCHA):**

# 1. Get visual CAPTCHA
resp = s.get('http://localhost:9898/api/activate/captcha')
with open('captcha.svg', 'wb') as f:
    f.write(resp.content)

# 2. Open captcha.svg in a browser/viewer and read the 6-character code
#    The SVG has distorted text with noise — must be read by a human
verification_code = input("Enter the 6-char code from captcha.svg: ")

# 3. Submit
resp = s.post('http://localhost:9898/api/activate', json={
    'product_key': '16000-OEM98-GBCRD-0002B-7D68F',
    'verification_code': verification_code
})
print(resp.json())
