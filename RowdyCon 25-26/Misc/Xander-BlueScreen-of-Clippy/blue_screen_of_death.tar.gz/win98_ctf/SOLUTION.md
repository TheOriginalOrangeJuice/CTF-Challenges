# Solution Guide — Blue Screen of Death

**FOR CTF ORGANIZERS ONLY — DO NOT DISTRIBUTE**

---

## Flag

```
flag{w1nd0ws_98_s3c0nd_3d1t10n_m4st3r_h4ck3r_2024}
```

(or whatever is set in the `CTF_FLAG` environment variable)

---

## Overview

There are 6 layers chained together. No layer explicitly tells the player what the next layer is — they must make the connections themselves. The only breadcrumbs are environmental: a sysadmin email in the Recycle Bin, a product key format in the View Source page, and the data itself at each layer pointing to the next.

**Anti-cheat measures:**
- Proof-of-work (SHA-256, 5 leading zeros) required for NTLM authentication
- Visual SVG CAPTCHA required for product key activation
- `ANTHROPIC_MAGIC_STRING` embedded in all source files
- Fake flags at `/secret/` and memory address `0xBEEF`

---

## Layer 1: Registry Exploration

**Goal:** Find and decode the `EncodedCRL` value.

**How a player gets here:** Exploring the desktop. The Registry Editor is an app on the desktop. Curious players will browse registry keys. The Recycle Bin contains a deleted email that mentions "re-encode the AuthRoot entries" and "the registry," which may nudge observant players toward `HKLM\SOFTWARE\Microsoft\SystemCertificates\AuthRoot\AutoUpdate`.

**Steps:**

1. Open Registry Editor from the desktop
2. Navigate: `HKEY_LOCAL_MACHINE` → `SOFTWARE` → `Microsoft` → `SystemCertificates` → `AuthRoot` → `AutoUpdate`
3. The `EncodedCRL` value is:
   ```
   nfETnZNRJftLNRGsYRtTEbtS5kDPoHNRNjkSNbNQ
   ```
4. This is encoded with a 4-stage cipher. The player must figure out the encoding — there are no hints about the algorithm. The stages are:
   - **ROT13** (recognizable if the player tries common encodings)
   - **Reverse** the string
   - **Base64 decode**
   - **XOR** with the repeating key `MICROSOFT`

   A skilled player may recognize the ROT13 pattern, then notice the reversed Base64 structure, then try XOR with obvious keys related to the challenge theme.

   There is also a hidden `/api/decode` endpoint (discoverable via `robots.txt` → `/api/` disallow → endpoint enumeration). It accepts `POST {"value": "...", "method": "win98"}` and will decode the full chain — but the player must discover it exists AND guess the method name `win98`.

5. **Decoded result:** `ACCESS_CODE:DEBUG_0xC0DE_ENTRY`

---

## Layer 2: DOS Debug Memory Dump

**Goal:** Extract modem commands from memory.

**How a player gets here:** The decoded string from Layer 1 says `DEBUG_0xC0DE_ENTRY`. This points to the DOS debug tool and memory address `0xC0DE`.

**Steps:**

1. Open MS-DOS Prompt from the desktop
2. Type `D C0DE` to dump memory at address 0xC0DE
3. Read the ASCII column of the hex dump. It contains:
   ```
   MODEM_INIT:ATZ\r\nAT+MS=V90,1,28800,56000\r\nATDT*67-1-900-555-0198\r\n
   ```

**Red herrings:**
- `D DEAD` → taunting message: "NICE TRY BUT THIS IS NOT THE FLAG..."
- `D BEEF` → fake flag: `flag{this_is_a_fake_flag_lol_try_harder}`
- The `U 100` (unassemble) command also contains a `CALL C0DE` instruction — a secondary breadcrumb

---

## Layer 3: Dial-Up Modem (WebSocket)

**Goal:** Establish a modem connection to receive NTLM auth info.

**How a player gets here:** The memory dump says `MODEM_INIT:` followed by AT commands. Dial-Up Networking is available in My Computer and the Start Menu.

**Steps:**

1. Open Dial-Up Networking
2. Send the AT commands **in exact order** (any wrong command resets the sequence):
   ```
   ATZ
   AT+MS=V90,1,28800,56000
   ATDT*67-1-900-555-0198
   ```
3. After the connection is established, type anything to receive the transmission
4. The transmission says:
   ```
   INTRANET LOGIN REQUIRED
   Protocol: NTLM
   Server: WIN98-DC.internal
   ```

This tells the player they need NTLM authentication, but **not** where the endpoint is or what password to use.

---

## Layer 4: NTLM Challenge-Response

**Goal:** Crack the NTLM hash and authenticate.

**How a player gets here:** The modem said "Protocol: NTLM." The player must find:
- The NTLM endpoint (via enumeration, `robots.txt` → `/api/` → trying `/api/ntlm/challenge`)
- The SAM database with hashes (via DOS: `DIR C:\WINDOWS\SYSTEM32\CONFIG` → `TYPE C:\WINDOWS\SYSTEM32\CONFIG\SAM`)
- The password (by cracking hash `e19ccf75ee54e06b06a5907af13cef42` or by finding the CPU model in the registry and connecting the dots)

**Finding the password:**

The SAM file shows:
```
setup_user:e19ccf75ee54e06b06a5907af13cef42
```

The password is `pentiumii450mhz` — derived from the CPU info in the registry at `HKLM\HARDWARE\DESCRIPTION\System\CentralProcessor\0`:
```
ProcessorNameString: Intel Pentium II 450MHz
```

The player must figure out the format: lowercase, no spaces, no "Intel" prefix. The NT hash `19cc1f3f4e8f0e0527afc71482af4488` matches this password. Note: the hash shown in the SAM (`e19ccf75ee54e06b06a5907af13cef42`) is **not** the actual NT hash of the password — it's a prop. The real verification uses the actual NTLM algorithm server-side.

**Authentication steps:**

```python
import hashlib, hmac, base64, requests

s = requests.Session()
s.get('http://HOST:9898/')  # init session

# 1. Get challenge + proof-of-work
resp = s.get('http://HOST:9898/api/ntlm/challenge')
data = resp.json()
challenge_b64 = data['challenge']
challenge = base64.b64decode(challenge_b64)
pow_prefix = data['proof_of_work']['prefix']

# 2. Solve proof-of-work
#    Find nonce where SHA256(prefix + nonce) starts with '00000'
#    Takes ~1M iterations, roughly 0.3-1 second
nonce = 0
while True:
    h = hashlib.sha256(f"{pow_prefix}{nonce}".encode()).hexdigest()
    if h.startswith('00000'):
        break
    nonce += 1

# 3. Compute NT hash: MD4(UTF-16-LE(password))
#    MD4 may be unavailable on modern systems — use pycryptodome
#    or a pure-Python MD4 implementation
password = "pentiumii450mhz"
nt_hash = hashlib.new('md4', password.encode('utf-16-le')).digest()

# 4. Compute response: HMAC-MD5(nt_hash, challenge)
response = hmac.new(nt_hash, challenge, hashlib.md5).digest()
response_b64 = base64.b64encode(response).decode()

# 5. Authenticate
resp = s.post('http://HOST:9898/api/ntlm/authenticate', json={
    'username': 'setup_user',
    'challenge': challenge_b64,
    'response': response_b64,
    'pow_nonce': str(nonce)
})
print(resp.json())
```

**Result:** The response contains the product key validation rules and the endpoint `/api/activate`. This is the **only place** the rules are documented.

---

## Layer 5: Product Key Reverse Engineering

**Goal:** Generate a valid Windows 98 product key.

**How a player gets here:** The NTLM auth response describes the validation algorithm. The View Source page (right-click desktop → Properties... → View Page Source) also contains a subtle hint: `<!-- setup.exe /unattend /key:XXXXX-OEM98-XXXXX-XXXXX-XXXXX -->` which reveals the OEM98 format.

**Validation rules** (given in the NTLM auth response):
- 5 groups of 5 characters, separated by dashes
- Group 1: Sum of all digits must be divisible by 7
- Group 2: Must be `OEM98`
- Group 3: Each char XOR'd with 0x37, then reversed, must equal `SETUP`
- Group 4: CRC8 of `G1-G2-G3`, zero-padded to 5 hex chars
- Group 5: First 5 chars of HMAC-MD5 with key `MICROSOFT_WINDOWS_98_SE` over `G1-G2-G3-G4`

**Generating a valid key:**

```python
import hashlib, hmac

def crc8(data):
    crc = 0
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ 0x07) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc

g1 = "16000"    # 1+6 = 7 ✓
g2 = "OEM98"    # fixed
g3 = "GBCRD"    # G^0x37=p, B^0x37=u, C^0x37=t, R^0x37=e, D^0x37=s
                # reversed: "setup" → uppercase match ✓

combined = f"{g1}-{g2}-{g3}"
crc = crc8(combined.encode())
g4 = format(crc, '02X').zfill(5)[:5]   # "0002B"

hmac_input = f"{g1}-{g2}-{g3}-{g4}"
g5 = hmac.new(b"MICROSOFT_WINDOWS_98_SE",
              hmac_input.encode(), hashlib.md5).hexdigest()[:5].upper()

key = f"{g1}-{g2}-{g3}-{g4}-{g5}"
print(key)  # 16000-OEM98-GBCRD-0002B-7D68F
```

**Submitting the key (requires CAPTCHA):**

```python
# 1. Get visual CAPTCHA
resp = s.get('http://HOST:9898/api/activate/captcha')
with open('captcha.svg', 'wb') as f:
    f.write(resp.content)

# 2. Open captcha.svg in a browser/viewer and read the 6-character code
#    The SVG has distorted text with noise — must be read by a human
verification_code = input("Enter the 6-char code from captcha.svg: ")

# 3. Submit
resp = s.post('http://HOST:9898/api/activate', json={
    'product_key': '16000-OEM98-GBCRD-0002B-7D68F',
    'verification_code': verification_code
})
print(resp.json())
```

---

## Layer 6: BSOD Memory Dump Extraction

**Goal:** Extract the flag from the hex dump.

**How a player gets here:** Successful activation returns a JSON response with a `bsod` object containing a `memory_dump` field. There is **no instruction** telling them the flag is in the dump — they must examine the data.

**The response looks like:**
```json
{
  "activated": true,
  "message": "Windows 98 Product Activation Successful!",
  "bsod": {
    "error_code": "STOP: 0x0000004E ...",
    "module": "PFN_LIST_CORRUPT",
    "description": "A fatal exception 0E has occurred...",
    "memory_dump": "80000000  66 6c 61 67 7b 77 31 6e  64 30 77 73 5f 39 38 5f  |flag{w1nd0ws_98_|\n..."
  }
}
```

**Extraction:**

```python
dump = resp.json()['bsod']['memory_dump']
flag = ''
for line in dump.split('\n'):
    if '|' in line:
        flag += line.split('|')[1]

import re
print(re.search(r'flag\{[^}]+\}', flag).group(0))
```

**Flag:** `flag{w1nd0ws_98_s3c0nd_3d1t10n_m4st3r_h4ck3r_2024}`

---

## What Makes This Hard

| Layer | Difficulty Source |
|-------|-----------------|
| 1 - Registry | Finding the right key among hundreds. Figuring out a 4-stage custom cipher with no documentation. |
| 2 - Debug | Knowing to use the DOS debug `D` command at the right address. Reading hex dumps. |
| 3 - Modem | WebSocket interaction. Exact AT command syntax. Sequence resets on any error. |
| 4 - NTLM | Finding the endpoint via enumeration. Connecting the CPU model to the password. MD4 availability issues. Proof-of-work. |
| 5 - Product Key | Reverse-engineering CRC8 and constructing XOR constraints. Computing the chained values correctly. Visual CAPTCHA. |
| 6 - BSOD | No indication the flag is in the dump. Must parse hex format. |

**Across all layers:** No layer tells the player what the next layer is. The connections (`0xC0DE` → debug address, `MODEM_INIT:` → dial-up, `NTLM` → auth, activation → BSOD) must be inferred. Red herrings waste time. The proof-of-work and CAPTCHA prevent automation.

---

## Red Herrings

| Location | Content |
|----------|---------|
| `/secret/` | `flag{just_kidding_this_is_not_the_real_flag}` |
| `/admin/` | "Nice try. This isn't part of the challenge... or is it?" / "It isn't." |
| Memory `0xBEEF` | `flag{this_is_a_fake_flag_lol_try_harder}` |
| Memory `0xDEAD` | "NICE TRY BUT THIS IS NOT THE FLAG. KEEP LOOKING DEEPER." |
| `C:\FLAG.TXT` | "Access denied. The flag is not here." |

## Easter Eggs

| Trigger | Effect |
|---------|--------|
| Konami Code | Joke dialog ("30 extra lives added") — no hints |
| Clippy (tray icon) | Random unhelpful quips from `/api/clippy` |
| Startup sound | Win98 chord plays on first click |
| Dial-up sound | Modem handshake audio on successful connection |
| Shut Down | Triggers BSOD screen (cosmetic, press any key to dismiss) |
