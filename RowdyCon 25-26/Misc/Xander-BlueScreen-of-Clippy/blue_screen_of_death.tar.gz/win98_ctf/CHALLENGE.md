# Blue Screen of Death

**Category:** Web / Crypto / Forensics / Reversing
**Difficulty:** Insane
**Points:** 1000
**Flag Format:** `flag{...}`

---

## Description

*It's 1999. You've just booted up your brand new Pentium II 450MHz machine running Windows 98 Second Edition. The internet is dialing up, Clippy is being unhelpful, and somewhere deep in this system lies a secret that Microsoft never wanted you to find.*

*Navigate the nostalgic Windows 98 desktop environment, explore every application, crack every cipher, and survive the Blue Screen of Death to capture the flag.*

**Warning:** This challenge has **6 layers**. Each layer must be completed to unlock the next. There are red herrings. There are fake flags. Trust nothing.

---

## Connection

```
http://CHALLENGE_HOST:9898
```

---

## Hints

- Hint 1 (100 pts): *"The registry knows all. But not all registry values are what they seem."*
- Hint 2 (200 pts): *"DEBUG.EXE can read memory. Some addresses are more interesting than others."*
- Hint 3 (300 pts): *"The modem speaks in AT commands. Initialize, configure V.90, then dial."*
- Hint 4 (400 pts): *"The CPU model is the key to the kingdom. But which kingdom?"*
- Hint 5 (500 pts): *"XOR with MICROSOFT, Base64, Reverse, ROT13. Now undo it."*

---

## Requirements

- Web browser with JavaScript enabled
- WebSocket support (for the modem layer)
- Knowledge of: Registry structure, DOS debugging, modem AT commands, NTLM authentication, CRC8, HMAC-MD5
- Patience. Lots of patience.
