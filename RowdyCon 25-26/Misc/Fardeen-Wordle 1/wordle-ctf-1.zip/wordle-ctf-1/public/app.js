const ROWS = 6;
const COLS = 5;

const boardEl = document.getElementById('board');
const keyboardEl = document.getElementById('keyboard');
const messageEl = document.getElementById('message');
const toggleEl = document.getElementById('theme-toggle');
const pageEl = document.querySelector('.page');

let currentRow = 0;
let currentCol = 0;
let isRevealing = false;
let gameOver = false;

const boardRows = [];

function setMessage(text, tone) {
  messageEl.textContent = text;
  if (tone) {
    messageEl.dataset.tone = tone;
  } else {
    delete messageEl.dataset.tone;
  }
}

function buildBoard() {
  for (let r = 0; r < ROWS; r += 1) {
    const row = document.createElement('div');
    row.className = 'row';
    const tiles = [];
    for (let c = 0; c < COLS; c += 1) {
      const tile = document.createElement('div');
      tile.className = 'tile';
      row.appendChild(tile);
      tiles.push(tile);
    }
    boardEl.appendChild(row);
    boardRows.push(tiles);
  }
}

function buildKeyboard() {
  const layout = [
    ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
    ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
    ['enter', 'z', 'x', 'c', 'v', 'b', 'n', 'm', 'back'],
  ];

  layout.forEach((rowKeys) => {
    const row = document.createElement('div');
    row.className = 'key-row';

    rowKeys.forEach((key) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'key';
      btn.textContent = key === 'back' ? 'Del' : key;
      if (key === 'enter' || key === 'back') {
        btn.classList.add('wide');
      }
      btn.dataset.key = key;
      row.appendChild(btn);
    });

    keyboardEl.appendChild(row);
  });
}

function shakeRow(index) {
  const row = boardEl.children[index];
  if (!row) {
    return;
  }
  row.classList.remove('shake');
  void row.offsetWidth;
  row.classList.add('shake');
}

function addLetter(letter) {
  if (currentCol >= COLS || currentRow >= ROWS) {
    return;
  }
  const tile = boardRows[currentRow][currentCol];
  tile.textContent = letter;
  tile.classList.add('filled');
  currentCol += 1;
}

function removeLetter() {
  if (currentCol === 0) {
    return;
  }
  currentCol -= 1;
  const tile = boardRows[currentRow][currentCol];
  tile.textContent = '';
  tile.classList.remove('filled');
}

function currentGuess() {
  return boardRows[currentRow].map((tile) => tile.textContent).join('').toLowerCase();
}

function revealRow(statuses) {
  return new Promise((resolve) => {
    statuses.forEach((status, index) => {
      const tile = boardRows[currentRow][index];
      setTimeout(() => {
        tile.classList.add('flip');
        setTimeout(() => {
          tile.classList.add(status);
        }, 150);
      }, index * 350);
    });

    const total = statuses.length * 350 + 600;
    setTimeout(() => {
      statuses.forEach((_, index) => {
        boardRows[currentRow][index].classList.remove('flip');
      });
      resolve();
    }, total);
  });
}

async function submitGuess() {
  if (isRevealing || gameOver) {
    return;
  }

  if (currentCol < COLS) {
    setMessage('Not enough letters.', 'loss');
    shakeRow(currentRow);
    return;
  }

  isRevealing = true;
  setMessage('');

  try {
    const res = await fetch('/api/guess', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ guess: currentGuess() }),
    });
    const data = await res.json();

    if (!res.ok || !data.ok) {
      setMessage(data.error || 'Invalid guess.', 'loss');
      shakeRow(currentRow);
      isRevealing = false;
      return;
    }

    await revealRow(data.statuses);

    if (data.win) {
      let winMessage = `Flag: ${data.flag}`;
      setMessage(winMessage, 'win');
      gameOver = true;
      isRevealing = false;
      return;
    }

    if (data.message) {
      const normalized = String(data.message).toLowerCase();
      const tone = normalized === 'no words left' ? 'danger' : data.over ? 'loss' : undefined;
      setMessage(data.message, tone);
    }

    if (data.over) {
      if (!data.message) {
        if (data.answer) {
          setMessage(`Out of guesses. Word was ${String(data.answer).toUpperCase()}.`, 'loss');
        } else {
          setMessage('Out of guesses. Refresh to try again.', 'loss');
        }
      }
      gameOver = true;
      isRevealing = false;
      return;
    }

    currentRow += 1;
    currentCol = 0;
    isRevealing = false;
  } catch (err) {
    setMessage('Server error. Try again.', 'loss');
    isRevealing = false;
  }
}

function handleKey(key) {
  if (gameOver || isRevealing) {
    return;
  }
  if (key === 'enter') {
    submitGuess();
    return;
  }
  if (key === 'back') {
    removeLetter();
    return;
  }
  if (/^[a-z]$/.test(key)) {
    addLetter(key.toUpperCase());
  }
}

function bindEvents() {
  document.addEventListener('keydown', (event) => {
    const key = event.key.toLowerCase();
    if (key === 'enter') {
      handleKey('enter');
    } else if (key === 'backspace') {
      handleKey('back');
    } else if (/^[a-z]$/.test(key)) {
      handleKey(key);
    }
  });

  keyboardEl.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) {
      return;
    }
    const key = target.dataset.key;
    if (key) {
      handleKey(key);
    }
  });

  toggleEl.addEventListener('click', () => {
    const nextTheme = pageEl.dataset.theme === 'dark' ? 'light' : 'dark';
    pageEl.dataset.theme = nextTheme;
    toggleEl.textContent = nextTheme === 'dark' ? 'Dark' : 'Light';
    toggleEl.setAttribute('aria-pressed', nextTheme === 'dark' ? 'true' : 'false');
  });

}

buildBoard();
buildKeyboard();
bindEvents();

async function resetGameSession() {
  try {
    await fetch('/api/reset', { method: 'POST' });
  } catch (err) {
    // Ignore reset failures; gameplay will error if server is unreachable.
  }
}

resetGameSession();
