const ROWS = 6;
const COLS = 5;

const boardEl = document.getElementById('board');
const keyboardEl = document.getElementById('keyboard');
const messageEl = document.getElementById('message');
const toggleEl = document.getElementById('theme-toggle');
const pageEl = document.querySelector('.page');

const LETTERS = 'abcdefghijklmnopqrstuvwxyz';
let allowedChars = new Set(LETTERS.split(''));

let currentRow = 0;
let currentCol = 0;
let isRevealing = false;
let gameOver = false;

const boardRows = [];

function setMessage(text, tone) {
  messageEl.textContent = text;
  if (tone) {
    messageEl.dataset.tone = tone;
  } else {
    delete messageEl.dataset.tone;
  }
}

function buildBoard() {
  for (let r = 0; r < ROWS; r += 1) {
    const row = document.createElement('div');
    row.className = 'row';
    const tiles = [];
    for (let c = 0; c < COLS; c += 1) {
      const tile = document.createElement('div');
      tile.className = 'tile';
      row.appendChild(tile);
      tiles.push(tile);
    }
    boardEl.appendChild(row);
    boardRows.push(tiles);
  }
}

function chunkKeys(keys, size) {
  const rows = [];
  for (let i = 0; i < keys.length; i += size) {
    rows.push(keys.slice(i, i + size));
  }
  return rows;
}

function keyLabel(key) {
  if (key === 'back') {
    return 'Del';
  }
  if (key === 'enter') {
    return 'Enter';
  }
  if (/^[a-z]$/.test(key)) {
    return key.toUpperCase();
  }
  return key;
}

function buildKeyboard() {
  keyboardEl.innerHTML = '';
  const letterSet = new Set(LETTERS.split(''));
  const rows = [];
  const baseRows = [
    ['q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'],
    ['a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l'],
    ['enter', 'z', 'x', 'c', 'v', 'b', 'n', 'm', 'back'],
  ];

  baseRows.forEach((rowKeys) => {
    const filtered = rowKeys.filter(
      (key) => key === 'enter' || key === 'back' || allowedChars.has(key),
    );
    if (filtered.length) {
      rows.push(filtered);
    }
  });

  const extras = Array.from(allowedChars)
    .filter((ch) => !letterSet.has(ch))
    .sort();
  chunkKeys(extras, 10).forEach((row) => rows.push(row));

  rows.forEach((rowKeys) => {
    const row = document.createElement('div');
    row.className = 'key-row';

    rowKeys.forEach((key) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'key';
      btn.textContent = keyLabel(key);
      if (key === 'enter' || key === 'back') {
        btn.classList.add('wide');
      }
      btn.dataset.key = key;
      row.appendChild(btn);
    });

    keyboardEl.appendChild(row);
  });
}

function shakeRow(index) {
  const row = boardEl.children[index];
  if (!row) {
    return;
  }
  row.classList.remove('shake');
  void row.offsetWidth;
  row.classList.add('shake');
}

function addLetter(letter) {
  if (currentCol >= COLS || currentRow >= ROWS) {
    return;
  }
  const tile = boardRows[currentRow][currentCol];
  tile.textContent = letter;
  tile.classList.add('filled');
  currentCol += 1;
}

function removeLetter() {
  if (currentCol === 0) {
    return;
  }
  currentCol -= 1;
  const tile = boardRows[currentRow][currentCol];
  tile.textContent = '';
  tile.classList.remove('filled');
}

function currentGuess() {
  return boardRows[currentRow].map((tile) => tile.textContent).join('').toLowerCase();
}

function revealRow(statuses) {
  return new Promise((resolve) => {
    statuses.forEach((status, index) => {
      const tile = boardRows[currentRow][index];
      setTimeout(() => {
        tile.classList.add('flip');
        setTimeout(() => {
          tile.classList.add(status);
        }, 150);
      }, index * 350);
    });

    const total = statuses.length * 350 + 600;
    setTimeout(() => {
      statuses.forEach((_, index) => {
        boardRows[currentRow][index].classList.remove('flip');
      });
      resolve();
    }, total);
  });
}

async function submitGuess() {
  if (isRevealing || gameOver) {
    return;
  }

  if (currentCol < COLS) {
    setMessage('Not enough letters.', 'loss');
    shakeRow(currentRow);
    return;
  }

  isRevealing = true;
  setMessage('');

  try {
    const res = await fetch('/api/guess', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ guess: currentGuess() }),
    });
    const data = await res.json();

    if (!res.ok || !data.ok) {
      setMessage(data.error || 'Invalid guess.', 'loss');
      shakeRow(currentRow);
      isRevealing = false;
      return;
    }

    await revealRow(data.statuses);

    if (data.win) {
      let winMessage = `Flag: ${data.flag}`;
      setMessage(winMessage, 'win');
      gameOver = true;
      isRevealing = false;
      return;
    }

    if (data.message) {
      const normalized = String(data.message).toLowerCase();
      const tone = normalized === 'no words left' ? 'danger' : data.over ? 'loss' : undefined;
      setMessage(data.message, tone);
    }

    if (data.over) {
      if (!data.message) {
        if (data.answer) {
          setMessage(`Out of guesses. Word was ${String(data.answer).toUpperCase()}.`, 'loss');
        } else {
          setMessage('Out of guesses. Refresh to try again.', 'loss');
        }
      }
      gameOver = true;
      isRevealing = false;
      return;
    }

    currentRow += 1;
    currentCol = 0;
    isRevealing = false;
  } catch (err) {
    setMessage('Server error. Try again.', 'loss');
    isRevealing = false;
  }
}

function handleKey(key) {
  if (gameOver || isRevealing) {
    return;
  }
  if (key === 'enter') {
    submitGuess();
    return;
  }
  if (key === 'back') {
    removeLetter();
    return;
  }
  if (key.length === 1 && allowedChars.has(key)) {
    addLetter(key.toUpperCase());
  }
}

function bindEvents() {
  document.addEventListener('keydown', (event) => {
    const key = event.key.toLowerCase();
    if (key === 'enter') {
      handleKey('enter');
    } else if (key === 'backspace') {
      handleKey('back');
    } else if (key.length === 1) {
      handleKey(key);
    }
  });

  keyboardEl.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) {
      return;
    }
    const key = target.dataset.key;
    if (key) {
      handleKey(key);
    }
  });

  toggleEl.addEventListener('click', () => {
    const nextTheme = pageEl.dataset.theme === 'dark' ? 'light' : 'dark';
    pageEl.dataset.theme = nextTheme;
    toggleEl.textContent = nextTheme === 'dark' ? 'Dark' : 'Light';
    toggleEl.setAttribute('aria-pressed', nextTheme === 'dark' ? 'true' : 'false');
  });

}

async function loadCharset() {
  try {
    const res = await fetch('/api/charset');
    const data = await res.json();
    if (res.ok && data.ok && Array.isArray(data.chars) && data.chars.length) {
      allowedChars = new Set(data.chars);
    }
  } catch (err) {
    // Keep default charset on failure.
  }
}

async function resetGameSession() {
  try {
    await fetch('/api/reset', { method: 'POST' });
  } catch (err) {
    // Ignore reset failures; gameplay will error if server is unreachable.
  }
}

async function init() {
  buildBoard();
  await loadCharset();
  buildKeyboard();
  bindEvents();
  await resetGameSession();
}

init();
