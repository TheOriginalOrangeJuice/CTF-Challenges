const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const express = require('express');
const dotenv = require('dotenv');

dotenv.config();

const WORDS_PATH = path.join(__dirname, 'valid-wordle-words.txt');
const FLAG = process.env.FLAG || 'FLAG_NOT_SET';
const PORT = process.env.PORT || 3000;
const LETTERS = 'abcdefghijklmnopqrstuvwxyz';
const ALLOWED_SYMBOLS = '!@#$%^&*+=?~-_';
const ALLOWED_CHARS = new Set([...LETTERS, ...ALLOWED_SYMBOLS]);
const CHAR_CLASS = Array.from(ALLOWED_CHARS)
  .map((ch) => ch.replace(/[\\\-\]\^]/g, '\\$&'))
  .join('');
const ALLOWED_REGEX = new RegExp(`^[${CHAR_CLASS}]{5}$`);

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

function loadWords() {
  const contents = fs.readFileSync(WORDS_PATH, 'utf8');
  const seen = new Set();
  const words = [];
  for (const line of contents.split(/\r?\n/)) {
    const word = line.trim().toLowerCase();
    if (word.length !== 5 || /\s/.test(word)) {
      continue;
    }
    if (!ALLOWED_REGEX.test(word)) {
      continue;
    }
    if (!seen.has(word)) {
      seen.add(word);
      words.push(word);
    }
  }
  if (!words.length) {
    throw new Error('No valid words loaded.');
  }
  return { words, wordSet: seen };
}

const { words: WORDS, wordSet: WORD_SET } = loadWords();
const CHARSET = [...LETTERS, ...ALLOWED_SYMBOLS];

function randomChoice(list) {
  return list[Math.floor(Math.random() * list.length)];
}

function randomWord(exclude) {
  if (!exclude) {
    return randomChoice(WORDS);
  }
  if (WORDS.length <= 1) {
    return WORDS[0];
  }
  let word = randomChoice(WORDS);
  while (word === exclude) {
    word = randomChoice(WORDS);
  }
  return word;
}

function parseCookies(req) {
  const header = req.headers.cookie;
  const cookies = {};
  if (!header) {
    return cookies;
  }
  const pairs = header.split(';');
  for (const pair of pairs) {
    const idx = pair.indexOf('=');
    if (idx === -1) {
      continue;
    }
    const key = pair.slice(0, idx).trim();
    const value = pair.slice(idx + 1).trim();
    cookies[key] = value;
  }
  return cookies;
}

const sessions = new Map();

function createSession() {
  return {
    target: randomWord(),
    guesses: [],
    over: false,
    won: false,
    forbiddenPositions: Array.from({ length: 5 }, () => new Set()),
    requiredCounts: {},
  };
}

function startNewSession(res) {
  const sid = crypto.randomUUID();
  const session = createSession();
  sessions.set(sid, session);
  res.setHeader('Set-Cookie', `sid=${sid}; Path=/; HttpOnly; SameSite=Lax`);
  return session;
}

function getSession(req, res) {
  const cookies = parseCookies(req);
  let sid = cookies.sid;
  if (sid && sessions.has(sid)) {
    return sessions.get(sid);
  }
  return startNewSession(res);
}

function scoreGuess(guess, target) {
  const result = Array(5).fill('absent');
  const targetArr = target.split('');
  const guessArr = guess.split('');
  const used = Array(5).fill(false);

  for (let i = 0; i < 5; i += 1) {
    if (guessArr[i] === targetArr[i]) {
      result[i] = 'correct';
      used[i] = true;
    }
  }

  const counts = {};
  for (let i = 0; i < 5; i += 1) {
    if (!used[i]) {
      const letter = targetArr[i];
      counts[letter] = (counts[letter] || 0) + 1;
    }
  }

  for (let i = 0; i < 5; i += 1) {
    if (result[i] === 'correct') {
      continue;
    }
    const letter = guessArr[i];
    if (counts[letter]) {
      result[i] = 'present';
      counts[letter] -= 1;
    }
  }

  return result;
}

function wordRespectsForbidden(word, forbiddenPositions) {
  for (let i = 0; i < 5; i += 1) {
    if (forbiddenPositions[i].has(word[i])) {
      return false;
    }
  }
  return true;
}

function wordHasRequiredCounts(word, requiredCounts) {
  const counts = {};
  for (const letter of word) {
    counts[letter] = (counts[letter] || 0) + 1;
  }
  for (const letter in requiredCounts) {
    if ((counts[letter] || 0) < requiredCounts[letter]) {
      return false;
    }
  }
  return true;
}

function mutateTarget(currentTarget, forbiddenPositions, requiredCounts) {
  const eligible = [];

  for (const word of WORDS) {
    if (word === currentTarget) {
      continue;
    }
    if (!wordRespectsForbidden(word, forbiddenPositions)) {
      continue;
    }
    if (!wordHasRequiredCounts(word, requiredCounts)) {
      continue;
    }
    eligible.push(word);
  }

  if (!eligible.length) {
    return { noWordsLeft: true };
  }

  return { target: randomChoice(eligible) };
}

app.post('/api/guess', (req, res) => {
  const session = getSession(req, res);

  if (session.over) {
    return res.status(400).json({ ok: false, error: 'Game over. Refresh to play again.' });
  }

  const rawGuess = (req.body && req.body.guess) || '';
  const guess = String(rawGuess).trim().toLowerCase();

  if (guess.length !== 5 || /\s/.test(guess) || !ALLOWED_REGEX.test(guess)) {
    return res.status(400).json({ ok: false, error: 'Guess must be 5 characters.' });
  }

  if (!WORD_SET.has(guess)) {
    return res.status(400).json({ ok: false, error: 'Not in word list.' });
  }

  const target = session.target;
  const statuses = scoreGuess(guess, target);
  const greenTiles = [];
  const greenCounts = {};
  let wouldHaveBeen = null;
  let wouldHaveBeenMessage = null;

  statuses.forEach((status, index) => {
    if (status === 'correct') {
      greenTiles.push({ index, letter: guess[index] });
    }
  });

  session.guesses.push({ guess, statuses });

  if (guess === target) {
    session.over = true;
    session.won = true;
    return res.json({ ok: true, win: true, statuses, flag: FLAG });
  }

  if (greenTiles.length) {
    greenTiles.forEach((tile) => {
      session.forbiddenPositions[tile.index].add(tile.letter);
      greenCounts[tile.letter] = (greenCounts[tile.letter] || 0) + 1;
    });

    Object.keys(greenCounts).forEach((letter) => {
      const nextCount = greenCounts[letter];
      const currentCount = session.requiredCounts[letter] || 0;
      session.requiredCounts[letter] = Math.max(currentCount, nextCount);
    });

    if (session.guesses.length < 6) {
      const mutation = mutateTarget(session.target, session.forbiddenPositions, session.requiredCounts);
      if (mutation.noWordsLeft) {
        session.over = true;
        return res.json({
          ok: true,
          win: false,
          statuses,
          over: true,
          message: 'No Words Avaiable',
          remaining: Math.max(0, 6 - session.guesses.length),
        });
      }
      session.target = mutation.target;
    } else if (session.guesses.length === 6) {
      const mutation = mutateTarget(session.target, session.forbiddenPositions, session.requiredCounts);
      if (mutation.noWordsLeft) {
        wouldHaveBeenMessage = 'No Words Avaiable';
      } else {
        wouldHaveBeen = mutation.target;
      }
    }
  }

  if (session.guesses.length >= 6) {
    session.over = true;
  }

  return res.json({
    ok: true,
    win: false,
    statuses,
    over: session.over,
    remaining: Math.max(0, 6 - session.guesses.length),
    answer: session.over ? session.target : undefined,
    wouldHaveBeen: session.over ? wouldHaveBeen : undefined,
    wouldHaveBeenMessage: session.over ? wouldHaveBeenMessage : undefined,
  });
});

app.post('/api/reset', (req, res) => {
  startNewSession(res);
  res.json({ ok: true });
});

app.get('/api/charset', (req, res) => {
  res.json({ ok: true, chars: CHARSET });
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`Wordle CTF server running on port ${PORT}`);
});
