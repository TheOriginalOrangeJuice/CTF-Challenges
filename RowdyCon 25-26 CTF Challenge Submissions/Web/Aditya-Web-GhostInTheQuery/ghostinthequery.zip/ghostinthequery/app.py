# app.py -- RowdyCon Registration API (NoSQL injection / operator abuse demo)
from flask import Flask, request, jsonify, render_template_string, session
import os

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "rowdycon_secret_change_me")

# ---------- Simulated "users" collection ----------
USERS = [
    {"username": "admin",     "password": "r0wdy_admin_pw", "role": "admin", "note": "RCCTF{r0wdyc0n_n0sql_0p3r4t0r_abuse}"},
    {"username": "volunteer", "password": "birdsup",        "role": "user"},
    {"username": "speaker",   "password": "keynote2026",    "role": "user"},
]

# ---------- Themed HTML ----------
INDEX = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>UTSA RowdyCon Registration API</title>
  <style>
    body { background:#0a0f1f; color:#f3f4f6; font-family: "Segoe UI", Roboto, Arial, sans-serif; padding:24px; }
    .box { background:#111827; padding:20px; border-radius:10px; max-width:900px; margin:auto; box-shadow: 0 8px 24px rgba(0,0,0,0.6); border:1px solid #e87511; }
    h1 { color:#e87511; letter-spacing:1px; }
    code { background:#020617; color:#f59e0b; padding:2px 6px; border-radius:4px; }
    .creds { background:#0b1220; padding:10px; border-radius:6px; }
    .hint { background:#09111d; padding:10px; border-radius:6px; color:#dbe4ee; margin-top:12px; border-left:4px solid #e87511; }
    a { color:#f59e0b; }
  </style>
</head>
<body>
  <div class="box">
    <h1>UTSA RowdyCon Registration API</h1>
    <p>The conference team left behind a JSON login endpoint for automation and badge management. It accepts structured request bodies, but the backend may trust that structure a little too much.</p>

    <h3>Visible test accounts</h3>
    <div class="creds">
      <ul>
        <li><code>volunteer / birdsup</code></li>
        <li><code>speaker / keynote2026</code></li>
      </ul>
    </div>

    <p>Your goal: authenticate as <code>admin</code> without knowing the password and retrieve the admin note.</p>

    <div class="hint">
      <strong>Starter hint:</strong> Send a JSON <code>POST</code> request to <code>/login</code>. Think about what happens when values are not just plain strings.
    </div>

    <hr>
    <p style="font-size:0.9em">Example: <code>POST /login</code> with JSON body <code>{"username":"volunteer","password":"birdsup"}</code></p>
    <p style="font-size:0.9em">Use curl, Burp, Postman, or the browser console to experiment.</p>
  </div>
</body>
</html>
"""

# ---------- Vulnerable matching logic (simulates Mongo-style operators) ----------
def matches(doc, query):
    """
    If a query value is a dict, interpret a small subset of operators.
    This simulates the common mistake of directly trusting user-supplied JSON
    as a query object.
    """
    for k, v in query.items():
        if isinstance(v, dict):
            if "$ne" in v:
                if doc.get(k) == v["$ne"]:
                    return False
                else:
                    continue
            if "$gt" in v:
                try:
                    if not (doc.get(k) > v["$gt"]):
                        return False
                    else:
                        continue
                except Exception:
                    return False
            return False
        else:
            if doc.get(k) != v:
                return False
    return True

def vulnerable_find_one(query):
    for doc in USERS:
        if matches(doc, query):
            return doc
    return None

# ---------- Routes ----------
@app.route('/')
def index():
    return render_template_string(INDEX)

@app.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json(force=True)
    except Exception:
        return "Bad JSON", 400

    if not data:
        return 'Send JSON body like {"username":"...","password":"..."}', 400

    # BAD: directly trusting structured user JSON
    query = {}
    if "username" in data:
        query["username"] = data["username"]
    if "password" in data:
        query["password"] = data["password"]

    user = vulnerable_find_one(query)
    if not user:
        return "Invalid credentials", 401

    session['user'] = user['username']
    session['role'] = user.get('role', 'user')

    resp = {
        "message": f"Welcome, {user['username']}!",
        "role": user.get('role', 'user')
    }

    if user.get('role') == 'admin' and 'note' in user:
        resp['secret'] = user['note']

    return jsonify(resp)

@app.route('/whoami')
def whoami():
    return jsonify({
        "user": session.get('user'),
        "role": session.get('role')
    })

if __name__ == '__main__':
    print("[boot] RowdyCon Registration API running on :5003")
    app.run(host='0.0.0.0', port=9002, debug=False)