import { ScarletPracticeGame } from "./game.js";

const state = {
  bootstrap: null,
  flagBlob: null,
};

function $(id) {
  return document.getElementById(id);
}

function pretty(value) {
  return JSON.stringify(value, null, 2);
}

function formatNumber(value) {
  return new Intl.NumberFormat("en-US").format(value);
}

function updateClock() {
  const now = new Date();
  const clock = document.querySelector(".clock");
  if (!clock) {
    return;
  }
  clock.textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function focusWindow(win) {
  document.querySelectorAll(".window").forEach((item) => item.classList.remove("is-focused"));
  win.classList.add("is-focused");
}

function openWindow(win) {
  win.classList.remove("is-hidden");
  focusWindow(win);
  if (win.id === "game-window") {
    $("game-canvas").focus();
  }
}

function initWindows() {
  let dragState = null;

  document.querySelectorAll(".window").forEach((win) => {
    const bar = win.querySelector(".title-bar");
    const close = win.querySelector(".window-button");

    win.addEventListener("pointerdown", () => {
      if (!win.classList.contains("is-hidden")) {
        focusWindow(win);
      }
    });

    if (window.innerWidth > 1200) {
      bar.addEventListener("pointerdown", (event) => {
        if (event.target === close) {
          return;
        }
        focusWindow(win);
        dragState = {
          win,
          startX: event.clientX,
          startY: event.clientY,
          left: win.offsetLeft,
          top: win.offsetTop,
        };
      });
    }

    close.addEventListener("click", () => {
      win.classList.add("is-hidden");
      win.classList.remove("is-focused");
      if (win.contains(document.activeElement)) {
        document.activeElement.blur();
      }
    });
  });

  document.addEventListener("pointermove", (event) => {
    if (!dragState) {
      return;
    }
    const x = dragState.left + (event.clientX - dragState.startX);
    const y = dragState.top + (event.clientY - dragState.startY);
    dragState.win.style.left = `${Math.max(0, x)}px`;
    dragState.win.style.top = `${Math.max(0, y)}px`;
  });

  document.addEventListener("pointerup", () => {
    dragState = null;
  });

  document.querySelectorAll(".desktop-icon").forEach((icon) => {
    icon.addEventListener("click", () => {
      openWindow($(icon.dataset.target));
    });
  });
}

async function fetchBootstrap() {
  const response = await fetch("/api/bootstrap");
  const payload = await response.json();
  state.bootstrap = payload;

  $("target-score-note").textContent = formatNumber(payload.targetScore);
  $("game-target").textContent = formatNumber(payload.targetScore);

  const helpList = $("route-help-list");
  helpList.innerHTML = "";
  payload.routeHelp.forEach((line) => {
    const li = document.createElement("li");
    li.textContent = line;
    helpList.append(li);
  });

  $("route-editor").value = pretty(payload.routeTemplate);
}

async function fetchFlagBlob() {
  const response = await fetch(state.bootstrap.blobPath);
  state.flagBlob = await response.json();
}

function setRouteStatus(message) {
  $("route-status").textContent = message;
}

function setDecryptStatus(message) {
  $("decrypt-status").textContent = message;
}

async function decryptBlob(password) {
  const output = $("decrypt-output");
  if (!password) {
    output.value = "";
    setDecryptStatus("Missing password");
    return;
  }

  try {
    const encoder = new TextEncoder();
    const passwordKey = await crypto.subtle.importKey(
      "raw",
      encoder.encode(password),
      "PBKDF2",
      false,
      ["deriveKey"],
    );

    const salt = Uint8Array.from(atob(state.flagBlob.salt), (ch) => ch.charCodeAt(0));
    const iv = Uint8Array.from(atob(state.flagBlob.iv), (ch) => ch.charCodeAt(0));
    const ciphertext = Uint8Array.from(atob(state.flagBlob.ciphertext), (ch) => ch.charCodeAt(0));

    const key = await crypto.subtle.deriveKey(
      {
        name: "PBKDF2",
        hash: "SHA-256",
        salt,
        iterations: state.flagBlob.iterations,
      },
      passwordKey,
      {
        name: "AES-GCM",
        length: 256,
      },
      false,
      ["decrypt"],
    );

    const plaintext = await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv,
        additionalData: new TextEncoder().encode("rensen95"),
      },
      key,
      ciphertext,
    );

    output.value = new TextDecoder().decode(plaintext);
    setDecryptStatus("Unlocked");
  } catch (error) {
    output.value = "";
    setDecryptStatus("Bad password");
  }
}

async function verifyRoute() {
  setRouteStatus("Submitting route...");
  let payload;
  try {
    payload = JSON.parse($("route-editor").value);
  } catch (error) {
    $("route-output").textContent = `Invalid JSON:\n${error.message}`;
    setRouteStatus("JSON parse error");
    return;
  }

  const response = await fetch("/api/verify-route", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
  const result = await response.json();

  if (!response.ok) {
    $("route-output").textContent = `Verifier error:\n${pretty(result)}`;
    setRouteStatus("Verifier rejected the payload");
    return;
  }

  $("route-output").textContent = pretty(result);
  setRouteStatus(result.accepted ? "Route accepted" : "Route rejected");

  if (result.recoveryPassword) {
    $("password-input").value = result.recoveryPassword;
    openWindow($("decrypt-window"));
    setDecryptStatus("Password received from daemon");
    await decryptBlob(result.recoveryPassword);
  }
}

async function submitPracticeRun(payload) {
  const response = await fetch(state.bootstrap.submitRunPath, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  const result = await response.json();
  if (!response.ok) {
    throw new Error(result.error || "Replay verification failed");
  }

  if (result.recoveryPassword) {
    $("password-input").value = result.recoveryPassword;
    $("route-output").textContent = pretty(result);
    setRouteStatus("Live clear verified");
    openWindow($("decrypt-window"));
    await decryptBlob(result.recoveryPassword);
    return {
      accepted: true,
      password: result.recoveryPassword,
      result,
    };
  }

  return {
    accepted: false,
    result,
  };
}

function initRouteUi() {
  $("load-template").addEventListener("click", () => {
    $("route-editor").value = pretty(state.bootstrap.routeTemplate);
    setRouteStatus("Template loaded");
  });

  $("verify-route").addEventListener("click", () => {
    verifyRoute().catch((error) => {
      $("route-output").textContent = `Unexpected verifier failure:\n${error.message}`;
      setRouteStatus("Verifier crashed");
    });
  });
}

function initDecryptUi() {
  $("decrypt-button").addEventListener("click", () => {
    decryptBlob($("password-input").value).catch(() => {
      setDecryptStatus("Decrypt failed");
    });
  });

  $("clear-password").addEventListener("click", () => {
    $("password-input").value = "";
    $("decrypt-output").value = "";
    setDecryptStatus("Locked");
  });
}

async function initGame() {
  const game = new ScarletPracticeGame({
    canvas: $("game-canvas"),
    scoreEl: $("game-score"),
    recoveryEl: $("game-recovery"),
    phaseEl: $("game-phase"),
    statusEl: $("game-status"),
    targetEl: $("game-target"),
    bombsEl: $("game-bombs"),
    optionsEl: $("game-options"),
    grazeEl: $("game-graze"),
    submitRun: submitPracticeRun,
  });

  $("game-reset").addEventListener("click", () => {
    game.reset();
    $("game-canvas").focus();
  });

  await game.load();
}

async function main() {
  initWindows();
  updateClock();
  window.setInterval(updateClock, 1000);

  await fetchBootstrap();
  await fetchFlagBlob();

  initRouteUi();
  initDecryptUi();
  await initGame();
}

main().catch((error) => {
  $("route-output").textContent = `Startup failure:\n${error.message}`;
});
