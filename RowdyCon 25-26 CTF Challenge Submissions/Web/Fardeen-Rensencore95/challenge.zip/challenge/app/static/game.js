const WIDTH = 640;
const HEIGHT = 480;
const TARGET_SCORE = 67000000;

const PLAYER_FRAME_WIDTH = 32;
const PLAYER_FRAME_HEIGHT = 48;
const PLAYER_SCALE = 2;
const PLAYER_DRAW_WIDTH = PLAYER_FRAME_WIDTH * PLAYER_SCALE;
const PLAYER_DRAW_HEIGHT = PLAYER_FRAME_HEIGHT * PLAYER_SCALE;

const SHOT_FRAME_WIDTH = 16;
const SHOT_FRAME_HEIGHT = 32;
const HIT_SCORE = 200;
const GRAZE_SCORE = 25;

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function formatNumber(value) {
  return new Intl.NumberFormat("en-US").format(value);
}

function formatPercent(value) {
  const percent = value * 100;
  return percent >= 10 ? `${percent.toFixed(1)}%` : `${percent.toFixed(3)}%`;
}

export class ScarletPracticeGame {
  constructor(options) {
    this.canvas = options.canvas;
    this.pixelRatio = window.devicePixelRatio || 1;
    this.canvas.width = Math.round(WIDTH * this.pixelRatio);
    this.canvas.height = Math.round(HEIGHT * this.pixelRatio);
    this.ctx = this.canvas.getContext("2d");
    this.ctx.setTransform(this.pixelRatio, 0, 0, this.pixelRatio, 0, 0);
    this.ctx.imageSmoothingEnabled = false;
    this.scoreEl = options.scoreEl;
    this.recoveryEl = options.recoveryEl;
    this.phaseEl = options.phaseEl;
    this.statusEl = options.statusEl;
    this.targetEl = options.targetEl;
    this.bombsEl = options.bombsEl;
    this.optionsEl = options.optionsEl;
    this.grazeEl = options.grazeEl;
    this.submitRun = options.submitRun;
    this.targetEl.textContent = formatNumber(TARGET_SCORE);

    this.keys = new Set();
    this.justPressed = new Set();
    this.replayEvents = [];
    this.images = {};
    this.audioReady = false;
    this.soundPools = {};
    this.soundCursor = {};
    this.music = null;
    this.lastTime = 0;
    this.accumulator = 0;
    this.lastShotSoundFrame = -999;
    this.runSubmissionStarted = false;

    this.handleKeyDown = (event) => {
      if (document.activeElement !== this.canvas) {
        return;
      }

      const control = this.toControlKey(event.key);
      if (!control) {
        return;
      }

      event.preventDefault();
      this.armAudio();
      if (!this.keys.has(control)) {
        this.keys.add(control);
        this.justPressed.add(control);
        this.replayEvents.push({ frame: this.state.frame, key: control, down: true });
      }
    };

    this.handleKeyUp = (event) => {
      const control = this.toControlKey(event.key);
      if (!control || !this.keys.has(control)) {
        return;
      }

      this.keys.delete(control);
      this.replayEvents.push({ frame: this.state.frame, key: control, down: false });
    };

    this.canvas.addEventListener("pointerdown", () => {
      this.canvas.focus();
      this.armAudio();
    });

    window.addEventListener("keydown", this.handleKeyDown);
    window.addEventListener("keyup", this.handleKeyUp);
    this.reset();
  }

  toControlKey(key) {
    switch (key) {
      case "ArrowLeft":
        return "left";
      case "ArrowRight":
        return "right";
      case "ArrowUp":
        return "up";
      case "ArrowDown":
        return "down";
      case "Shift":
        return "focus";
      case "z":
      case "Z":
        return "shoot";
      case "x":
      case "X":
        return "bomb";
      default:
        return null;
    }
  }

  async load() {
    await Promise.all([
      this.loadImage("bg", "/static/assets/img/title_bg.png"),
      this.loadImage("boss", "/static/assets/img/marisa_stand.png"),
      this.loadImage("playerSheet", "/static/assets/img/reimu.png"),
      this.loadImage("enemyBullet", "/static/assets/img/bullet.png"),
      this.loadImage("shot", "/static/assets/img/pl_shot.png"),
      this.loadImage("option", "/static/assets/img/reimu_option.png"),
      this.loadImage("scoreItem", "/static/assets/img/score_item.png"),
    ]);

    this.music = new Audio("/static/assets/audio/bgm.mp3");
    this.music.loop = true;
    this.music.volume = 0.17;
    this.music.preload = "auto";
    this.music.load();

    this.soundPools.shot = this.createSoundPool("/static/assets/audio/shot.wav", 0.18, 6);
    this.soundPools.graze = this.createSoundPool("/static/assets/audio/graze.wav", 0.1, 3);
    this.soundPools.dead = this.createSoundPool("/static/assets/audio/dead.wav", 0.36, 2);

    requestAnimationFrame((time) => this.frame(time));
  }

  async loadImage(key, src) {
    const image = new Image();
    image.src = src;
    await image.decode().catch(() => undefined);
    this.images[key] = image;
  }

  createSoundPool(src, volume, size) {
    const pool = [];
    for (let index = 0; index < size; index += 1) {
      const clip = new Audio(src);
      clip.preload = "auto";
      clip.volume = volume;
      clip.load();
      pool.push(clip);
    }
    return pool;
  }

  armAudio() {
    if (this.audioReady) {
      return;
    }
    this.audioReady = true;
    this.statusEl.textContent = "Audio armed. Scarlet practice is live.";
    this.music?.play().catch(() => undefined);
  }

  reset() {
    this.state = {
      frame: 0,
      score: 0,
      playerX: WIDTH / 2,
      playerY: HEIGHT - 78,
      bossX: WIDTH / 2,
      bossY: 94,
      bullets: [],
      shots: [],
      alive: true,
      status: "Endless Scarlet Survival",
      graze: 0,
      bombs: 3,
      bombCooldown: 0,
      bombFlash: 0,
      options: 1,
      bossPulse: 0,
      recovery: "Below Target",
    };
    this.keys.clear();
    this.justPressed.clear();
    this.replayEvents = [];
    this.runSubmissionStarted = false;
    this.statusEl.textContent = "Practice ready. Click the field or press a key to arm audio.";
    this.renderHud();
  }

  frame(time) {
    const delta = Math.min(40, time - this.lastTime || 16.67);
    this.lastTime = time;
    this.accumulator += delta;

    while (this.accumulator >= 1000 / 60) {
      this.step();
      this.accumulator -= 1000 / 60;
    }

    this.draw();
    requestAnimationFrame((nextTime) => this.frame(nextTime));
  }

  step() {
    const s = this.state;
    if (!s.alive) {
      this.justPressed.clear();
      return;
    }

    s.bossX = (WIDTH / 2) + Math.sin(s.frame / 70) * 176 + Math.sin(s.frame / 23) * 18;

    this.movePlayer();
    s.options = Math.min(4, 1 + Math.floor(s.score / 250000));
    this.spawnDanmaku();
    this.spawnShots();
    this.applyShotScoring();

    if (this.justPressed.has("bomb") && s.bombs > 0 && s.bombCooldown <= 0) {
      s.bombs -= 1;
      s.bombCooldown = 160;
      s.bombFlash = 42;
      s.bullets = [];
      this.statusEl.textContent = `Bomb deployed. ${s.bombs} remaining.`;
    }

    this.updateShots();
    this.updateBullets();

    if (s.bombCooldown > 0) {
      s.bombCooldown -= 1;
    }
    if (s.bombFlash > 0) {
      s.bombFlash -= 1;
    }
    if (s.bossPulse > 0) {
      s.bossPulse -= 1;
    }

    s.frame += 1;

    if (s.score >= TARGET_SCORE && !this.runSubmissionStarted) {
      this.runSubmissionStarted = true;
      s.recovery = "Verifying Run";
      this.renderHud();
      this.statusEl.textContent = "Target reached. Submitting replay to the recovery daemon...";

      Promise.resolve(this.submitRun?.(this.buildReplayPayload()))
        .then((result) => {
          if (result?.accepted) {
            s.recovery = "Password Awarded";
            this.statusEl.textContent = "Verified clear accepted. Password released.";
          } else {
            s.recovery = "Daemon Rejected";
            this.statusEl.textContent = "Replay submitted, but the daemon rejected the clear.";
          }
          this.renderHud();
        })
        .catch((error) => {
          s.recovery = "Submit Failed";
          this.statusEl.textContent = `Replay submit failed: ${error.message}`;
          this.renderHud();
        });
    }

    this.renderHud();
    this.justPressed.clear();
  }

  buildReplayPayload() {
    return {
      mode: "replay",
      events: this.replayEvents,
    };
  }

  movePlayer() {
    const s = this.state;
    const focus = this.keys.has("focus");
    const speed = focus ? 2.35 : 4.6;
    if (this.keys.has("left")) {
      s.playerX -= speed;
    }
    if (this.keys.has("right")) {
      s.playerX += speed;
    }
    if (this.keys.has("up")) {
      s.playerY -= speed * 0.82;
    }
    if (this.keys.has("down")) {
      s.playerY += speed * 0.82;
    }

    s.playerX = clamp(s.playerX, 42, WIDTH - 42);
    s.playerY = clamp(s.playerY, 180, HEIGHT - 42);
  }

  spawnDanmaku() {
    const s = this.state;
    if (s.frame % 16 === 0) {
      for (const offset of [-3, -2, -1, 0, 1, 2, 3]) {
        s.bullets.push({
          x: s.bossX + offset * 13,
          y: s.bossY + 28,
          vx: offset * 0.56,
          vy: 2.6 + Math.abs(offset) * 0.12,
          grazed: false,
          spin: offset * 0.1,
        });
      }
    }

    if (s.frame % 60 === 0) {
      for (let index = 0; index < 11; index += 1) {
        const angle = (Math.PI / 2) + ((index - 5) * 0.16);
        s.bullets.push({
          x: s.bossX,
          y: s.bossY + 22,
          vx: Math.cos(angle) * 1.7,
          vy: Math.sin(angle) * 2.8,
          grazed: false,
          spin: (index - 5) * 0.08,
        });
      }
    }

    if (s.frame % 96 === 0) {
      const aim = clamp((s.playerX - s.bossX) / 140, -1.6, 1.6);
      for (const lane of [-2, -1, 0, 1, 2]) {
        s.bullets.push({
          x: s.bossX + lane * 16,
          y: s.bossY + 30,
          vx: aim + lane * 0.18,
          vy: 3.2,
          grazed: false,
          spin: lane * 0.06,
        });
      }
    }
  }

  spawnShots() {
    const s = this.state;
    if (!this.keys.has("shoot") || s.frame % 5 !== 0) {
      return;
    }

    const focus = this.keys.has("focus");
    const baseSpeed = focus ? -13 : -15;
    const addShot = (x, vx = 0) => {
      s.shots.push({
        x,
        y: s.playerY - 38,
        vx,
        vy: baseSpeed,
      });
    };

    addShot(s.playerX - 8, -0.08);
    addShot(s.playerX + 8, 0.08);
    for (const [offsetX] of this.getOptionOffsets(s.options)) {
      addShot(s.playerX + offsetX, offsetX * 0.02);
    }

    if (s.frame - this.lastShotSoundFrame >= 12) {
      this.lastShotSoundFrame = s.frame;
      this.playSound("shot");
    }
  }

  applyShotScoring() {
    const s = this.state;
    if (!this.keys.has("shoot") || s.frame % 5 !== 0) {
      return;
    }

    if (Math.abs(s.playerX - s.bossX) < 42) {
      s.score += HIT_SCORE * (2 + s.options);
      s.bossPulse = 6;
    }
  }

  updateShots() {
    const nextShots = [];
    for (const shot of this.state.shots) {
      shot.x += shot.vx;
      shot.y += shot.vy;
      if (shot.y < -48) {
        continue;
      }
      nextShots.push(shot);
    }
    this.state.shots = nextShots;
  }

  updateBullets() {
    const s = this.state;
    const nextBullets = [];
    for (const bullet of s.bullets) {
      bullet.x += bullet.vx;
      bullet.y += bullet.vy;
      bullet.spin += 0.06;

      if (bullet.y > HEIGHT + 24 || bullet.x < -24 || bullet.x > WIDTH + 24) {
        continue;
      }

      const dx = Math.abs(bullet.x - s.playerX);
      const dy = Math.abs(bullet.y - s.playerY);
      if (s.bombFlash <= 0 && dx < 11 && dy < 12) {
        s.alive = false;
        s.recovery = "Run Failed";
        this.statusEl.textContent = `Practice failed at frame ${s.frame}. Restart to try again.`;
        this.playSound("dead");
        break;
      }

      if (!bullet.grazed && dx < 30 && dy < 22) {
        bullet.grazed = true;
        s.score += GRAZE_SCORE;
        s.graze += 1;
        this.playSound("graze");
      }

      nextBullets.push(bullet);
    }

    this.state.bullets = s.bombFlash > 0 ? [] : nextBullets;
  }

  getOptionOffsets(optionCount) {
    const offsets = [
      [-28, -24],
      [28, -24],
      [-52, -10],
      [52, -10],
    ];
    return offsets.slice(0, optionCount);
  }

  playSound(name) {
    if (!this.audioReady || !this.soundPools[name]?.length) {
      return;
    }

    const cursor = this.soundCursor[name] ?? 0;
    const clip = this.soundPools[name][cursor];
    this.soundCursor[name] = (cursor + 1) % this.soundPools[name].length;

    try {
      clip.pause();
      clip.currentTime = 0;
    } catch {
      // Some browsers can throw if the clip has not fully initialized yet.
    }

    clip.play().catch(() => undefined);
  }

  renderHud() {
    const s = this.state;
    this.scoreEl.textContent = formatNumber(s.score);
    this.recoveryEl.textContent = s.recovery;
    this.phaseEl.textContent = s.status;
    this.bombsEl.textContent = s.bombs;
    this.optionsEl.textContent = s.options;
    this.grazeEl.textContent = formatNumber(s.graze);
  }

  draw() {
    const ctx = this.ctx;
    ctx.clearRect(0, 0, WIDTH, HEIGHT);
    this.drawBackground();
    this.drawBoss();
    this.drawShots();
    this.drawBullets();
    this.drawOptions();
    this.drawPlayer();
    this.drawBombAura();
    this.drawOverlay();
  }

  drawBackground() {
    const ctx = this.ctx;
    const bg = this.images.bg;
    if (bg?.complete) {
      ctx.globalAlpha = 0.18;
      ctx.drawImage(bg, 0, 0, bg.width, bg.height, 0, 0, WIDTH, HEIGHT);
      ctx.globalAlpha = 1;
    }

    ctx.fillStyle = "rgba(6, 8, 24, 0.9)";
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    const frame = this.state.frame;
    for (let index = 0; index < 22; index += 1) {
      const y = ((index * 26) + (frame * 0.9)) % HEIGHT;
      ctx.fillStyle = index % 2 === 0 ? "rgba(145, 221, 255, 0.08)" : "rgba(255, 96, 145, 0.07)";
      ctx.fillRect(0, y, WIDTH, 1);
    }

    ctx.fillStyle = "rgba(255, 255, 255, 0.05)";
    ctx.fillRect(18, 18, WIDTH - 36, HEIGHT - 36);
    ctx.clearRect(24, 24, WIDTH - 48, HEIGHT - 48);
  }

  drawBoss() {
    const ctx = this.ctx;
    const boss = this.images.boss;
    const s = this.state;
    if (boss?.complete) {
      ctx.globalAlpha = 0.92;
      ctx.drawImage(boss, s.bossX - 58, s.bossY - 44, 116, 174);
      ctx.globalAlpha = 1;
    } else {
      ctx.fillStyle = "#ffd8ff";
      ctx.fillRect(s.bossX - 32, s.bossY - 18, 64, 74);
    }

    const barWidth = 252;
    const barHeight = 18;
    const barX = WIDTH - barWidth - 24;
    const barY = 22;
    const trueProgress = clamp(s.score / TARGET_SCORE, 0, 1);
    const visibleProgress = trueProgress > 0
      ? Math.log10(1 + (trueProgress * 999)) / 3
      : 0;
    const innerWidth = barWidth - 4;
    const visibleFill = trueProgress > 0
      ? Math.max(6, Math.round(innerWidth * visibleProgress))
      : 0;
    const actualMarkerX = barX + 2 + Math.round(innerWidth * trueProgress);

    ctx.fillStyle = "rgba(0, 0, 0, 0.62)";
    ctx.fillRect(barX, barY, barWidth, barHeight);
    ctx.fillStyle = "#4f1830";
    ctx.fillRect(barX + 2, barY + 2, innerWidth, barHeight - 4);
    ctx.fillStyle = "#ff7cb6";
    ctx.fillRect(barX + 2, barY + 2, visibleFill, barHeight - 4);

    ctx.save();
    ctx.beginPath();
    ctx.rect(barX + 2, barY + 2, visibleFill, barHeight - 4);
    ctx.clip();
    for (let stripe = -18; stripe < visibleFill + 18; stripe += 18) {
      ctx.fillStyle = "rgba(255, 214, 234, 0.28)";
      ctx.fillRect(barX + stripe, barY + 2, 7, barHeight - 4);
    }
    ctx.restore();

    if (trueProgress > 0) {
      ctx.fillStyle = "#fff4c7";
      ctx.fillRect(actualMarkerX - 1, barY + 1, 2, barHeight - 2);
    }

    ctx.strokeStyle = "rgba(255,255,255,0.42)";
    ctx.strokeRect(barX, barY, barWidth, barHeight);
    ctx.fillStyle = "#f7dbe2";
    ctx.font = "bold 12px Tahoma, sans-serif";
    ctx.fillText("Spell Card: Endless Scarlet Recovery", barX - 18, 15);
    ctx.fillStyle = "#fff6dc";
    ctx.font = "bold 11px Tahoma, sans-serif";
    ctx.fillText(formatPercent(trueProgress), barX + 6, barY + 13);
    ctx.fillText(`${formatNumber(s.score)} / ${formatNumber(TARGET_SCORE)}`, barX + 74, barY + 13);

    if (s.bossPulse > 0) {
      ctx.strokeStyle = `rgba(255, 220, 120, ${s.bossPulse / 8})`;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(s.bossX, s.bossY + 18, 38 + s.bossPulse * 3, 0, Math.PI * 2);
      ctx.stroke();
      ctx.lineWidth = 1;
    }
  }

  drawShots() {
    const ctx = this.ctx;
    const shotImage = this.images.shot;
    for (const shot of this.state.shots) {
      if (shotImage?.complete) {
        ctx.drawImage(
          shotImage,
          0,
          0,
          SHOT_FRAME_WIDTH,
          SHOT_FRAME_HEIGHT,
          shot.x - 7,
          shot.y - 18,
          14,
          30,
        );
      } else {
        ctx.fillStyle = "#fff59f";
        ctx.fillRect(shot.x - 1, shot.y - 16, 3, 16);
      }
    }
  }

  drawBullets() {
    const ctx = this.ctx;
    const bulletImg = this.images.enemyBullet;
    for (const bullet of this.state.bullets) {
      ctx.save();
      ctx.translate(bullet.x, bullet.y);
      ctx.rotate(bullet.spin);
      if (bulletImg?.complete) {
        ctx.drawImage(bulletImg, 0, 0, 16, 16, -9, -9, 18, 18);
      } else {
        ctx.fillStyle = "#7ad7ff";
        ctx.beginPath();
        ctx.arc(0, 0, 6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  drawOptions() {
    const ctx = this.ctx;
    const optionImage = this.images.option;
    for (const [offsetX, offsetY] of this.getOptionOffsets(this.state.options)) {
      const x = this.state.playerX + offsetX;
      const y = this.state.playerY + offsetY;
      if (optionImage?.complete) {
        ctx.drawImage(optionImage, x - 13, y - 13, 26, 26);
      } else {
        ctx.fillStyle = "rgba(255, 245, 170, 0.85)";
        ctx.fillRect(x - 6, y - 6, 12, 12);
      }
    }
  }

  drawPlayer() {
    const ctx = this.ctx;
    const spriteSheet = this.images.playerSheet;
    const movingLeft = this.keys.has("left") && !this.keys.has("right");
    const movingRight = this.keys.has("right") && !this.keys.has("left");
    const row = movingLeft ? 1 : movingRight ? 2 : 0;
    const minColumn = row === 0 ? 0 : 4;
    const frameCount = row === 0 ? 8 : 4;
    const column = minColumn + (Math.floor(this.state.frame / 6) % frameCount);

    if (spriteSheet?.complete) {
      ctx.drawImage(
        spriteSheet,
        column * PLAYER_FRAME_WIDTH,
        row * PLAYER_FRAME_HEIGHT,
        PLAYER_FRAME_WIDTH,
        PLAYER_FRAME_HEIGHT,
        this.state.playerX - (PLAYER_DRAW_WIDTH / 2),
        this.state.playerY - (PLAYER_DRAW_HEIGHT / 2) - 8,
        PLAYER_DRAW_WIDTH,
        PLAYER_DRAW_HEIGHT,
      );
    } else {
      ctx.fillStyle = "#ffe6e6";
      ctx.fillRect(this.state.playerX - 18, this.state.playerY - 24, 36, 48);
    }

    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.arc(this.state.playerX, this.state.playerY + 8, 3.1, 0, Math.PI * 2);
    ctx.fill();
  }

  drawBombAura() {
    const s = this.state;
    if (s.bombFlash <= 0) {
      return;
    }

    const ctx = this.ctx;
    const alpha = s.bombFlash / 42;
    ctx.save();
    ctx.strokeStyle = `rgba(255, 233, 171, ${alpha})`;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(s.playerX, s.playerY, 58 + ((42 - s.bombFlash) * 2.8), 0, Math.PI * 2);
    ctx.stroke();
    ctx.strokeStyle = `rgba(255, 132, 132, ${alpha * 0.75})`;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(s.playerX, s.playerY, 34 + ((42 - s.bombFlash) * 1.5), 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();
  }

  drawOverlay() {
    const ctx = this.ctx;
    const s = this.state;

    ctx.fillStyle = "rgba(4, 6, 20, 0.76)";
    ctx.fillRect(10, 10, 244, 54);
    ctx.strokeStyle = "rgba(255,255,255,0.28)";
    ctx.strokeRect(10, 10, 244, 54);

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 15px Tahoma, sans-serif";
    ctx.fillText(`Score ${formatNumber(s.score)}`, 20, 31);
    ctx.font = "13px Tahoma, sans-serif";
    ctx.fillText(`Target ${formatNumber(TARGET_SCORE)}`, 20, 50);

    const infoWidth = 198;
    const infoHeight = 30;
    const infoX = WIDTH - infoWidth - 18;
    const infoY = HEIGHT - infoHeight - 18;
    ctx.fillStyle = "rgba(4, 6, 20, 0.76)";
    ctx.fillRect(infoX, infoY, infoWidth, infoHeight);
    ctx.strokeStyle = "rgba(255,255,255,0.24)";
    ctx.strokeRect(infoX, infoY, infoWidth, infoHeight);
    ctx.fillStyle = "#fff3db";
    ctx.font = "bold 12px Tahoma, sans-serif";
    ctx.fillText(s.alive ? "Legacy Practice Build" : "Practice Run Failed", infoX + 12, infoY + 19);
  }
}
