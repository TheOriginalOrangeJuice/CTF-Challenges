from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app import FLAG_BLOB_PATH, SECRET_PATH, build_flag_blob  # noqa: E402


def main() -> None:
    secrets = json.loads(SECRET_PATH.read_text(encoding="utf-8"))
    blob = build_flag_blob(secrets["flag"], secrets["recovery_password"])
    FLAG_BLOB_PATH.parent.mkdir(parents=True, exist_ok=True)
    FLAG_BLOB_PATH.write_text(json.dumps(blob, indent=2), encoding="utf-8")
    print(f"wrote {FLAG_BLOB_PATH}")


if __name__ == "__main__":
    main()
