from __future__ import annotations

import base64
import json
import math
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from flask import Flask, jsonify, render_template, request


BASE_DIR = Path(__file__).resolve().parent
INSTANCE_DIR = BASE_DIR / "instance"
STATIC_DIR = BASE_DIR / "app" / "static"
DOWNLOAD_DIR = STATIC_DIR / "assets" / "downloads"
SECRET_PATH = INSTANCE_DIR / "challenge_secrets.json"
FLAG_BLOB_PATH = DOWNLOAD_DIR / "flag.r95"

DEFAULT_SECRETS = {
    "flag": "RCC{4ll_T0uh0u_S0ng5_4r3_th3_S4m3}",
    "recovery_password": "SCARLET-BARRIER-95-0E74-ROUTE-LOCK",
    "target_score": 67000000,
}


def derive_key(password: str, salt: bytes, iterations: int) -> bytes:
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=iterations,
    )
    return kdf.derive(password.encode("utf-8"))


def build_flag_blob(flag_text: str, password: str) -> dict[str, Any]:
    salt = os.urandom(16)
    iv = os.urandom(12)
    iterations = 180_000
    key = derive_key(password, salt, iterations)
    aes = AESGCM(key)
    ciphertext = aes.encrypt(iv, flag_text.encode("utf-8"), b"rensen95")
    return {
        "format": "R95-AESGCM",
        "salt": base64.b64encode(salt).decode("ascii"),
        "iv": base64.b64encode(iv).decode("ascii"),
        "iterations": iterations,
        "ciphertext": base64.b64encode(ciphertext).decode("ascii"),
    }


def ensure_instance_files() -> dict[str, Any]:
    INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

    if not SECRET_PATH.exists():
        SECRET_PATH.write_text(json.dumps(DEFAULT_SECRETS, indent=2), encoding="utf-8")

    secrets = json.loads(SECRET_PATH.read_text(encoding="utf-8"))
    blob = build_flag_blob(secrets["flag"], secrets["recovery_password"])
    FLAG_BLOB_PATH.write_text(json.dumps(blob, indent=2), encoding="utf-8")
    return secrets


@dataclass
class Bullet:
    x: float
    y: float
    vx: float
    vy: float
    grazed: bool = False
    spin: float = 0.0


@dataclass
class FrameState:
    frame: int = 0
    score: int = 0
    player_x: float = 320.0
    player_y: float = 402.0
    boss_x: float = 320.0
    boss_y: float = 94.0
    alive: bool = True
    death_reason: str | None = None
    graze: int = 0
    bombs: int = 3
    bomb_cooldown: int = 0
    options: int = 1
    bullets: list[Bullet] = field(default_factory=list)


class PracticeCore:
    CONTROL_KEYS = ("left", "right", "up", "down", "focus", "shoot", "bomb")
    WIDTH = 640
    HEIGHT = 480
    MAX_FRAMES = 500_000
    HIT_SCORE = 200
    GRAZE_SCORE = 25

    def __init__(self, target_score: int) -> None:
        self.target_score = target_score

    def create_state(self) -> FrameState:
        return FrameState()

    def _option_count(self, score: int) -> int:
        return min(4, 1 + (score // 250_000))

    def _update_boss_position(self, state: FrameState) -> None:
        state.boss_x = (
            (self.WIDTH / 2)
            + math.sin(state.frame / 70.0) * 176.0
            + math.sin(state.frame / 23.0) * 18.0
        )

    def _move_player(self, state: FrameState, actions: dict[str, bool]) -> None:
        speed = 2.35 if actions["focus"] else 4.6
        if actions["left"]:
            state.player_x -= speed
        if actions["right"]:
            state.player_x += speed
        if actions["up"]:
            state.player_y -= speed * 0.82
        if actions["down"]:
            state.player_y += speed * 0.82

        state.player_x = min(self.WIDTH - 42.0, max(42.0, state.player_x))
        state.player_y = min(self.HEIGHT - 42.0, max(180.0, state.player_y))

    def _spawn_bullets(self, state: FrameState) -> None:
        if state.frame % 16 == 0:
            for offset in (-3, -2, -1, 0, 1, 2, 3):
                state.bullets.append(
                    Bullet(
                        x=state.boss_x + offset * 13,
                        y=state.boss_y + 28,
                        vx=offset * 0.56,
                        vy=2.6 + abs(offset) * 0.12,
                        spin=offset * 0.1,
                    )
                )

        if state.frame % 60 == 0:
            for index in range(11):
                angle = (math.pi / 2) + ((index - 5) * 0.16)
                state.bullets.append(
                    Bullet(
                        x=state.boss_x,
                        y=state.boss_y + 22,
                        vx=math.cos(angle) * 1.7,
                        vy=math.sin(angle) * 2.8,
                        spin=(index - 5) * 0.08,
                    )
                )

        if state.frame % 96 == 0:
            aim = min(1.6, max(-1.6, (state.player_x - state.boss_x) / 140.0))
            for lane in (-2, -1, 0, 1, 2):
                state.bullets.append(
                    Bullet(
                        x=state.boss_x + lane * 16,
                        y=state.boss_y + 30,
                        vx=aim + lane * 0.18,
                        vy=3.2,
                        spin=lane * 0.06,
                    )
                )

    def _apply_bomb(self, state: FrameState, bomb_pressed: bool) -> None:
        if bomb_pressed and state.bombs > 0 and state.bomb_cooldown <= 0:
            state.bombs -= 1
            state.bomb_cooldown = 160
            state.bullets.clear()

    def _apply_shot_logic(self, state: FrameState, actions: dict[str, bool]) -> None:
        if not actions["shoot"] or state.frame % 5 != 0:
            return

        if abs(state.player_x - state.boss_x) < 42.0:
            state.score += self.HIT_SCORE * (2 + state.options)

    def _update_bullets(self, state: FrameState) -> None:
        remaining: list[Bullet] = []
        for bullet in state.bullets:
            bullet.x += bullet.vx
            bullet.y += bullet.vy
            bullet.spin += 0.06

            if bullet.y > self.HEIGHT + 24 or bullet.x < -24 or bullet.x > self.WIDTH + 24:
                continue

            dx = abs(bullet.x - state.player_x)
            dy = abs(bullet.y - state.player_y)
            if dx < 11 and dy < 12:
                state.alive = False
                state.death_reason = f"hit by danmaku at frame {state.frame}"
                break

            if not bullet.grazed and dx < 30 and dy < 22:
                bullet.grazed = True
                state.score += self.GRAZE_SCORE
                state.graze += 1

            remaining.append(bullet)

        state.bullets = remaining

    def _tick_cooldowns(self, state: FrameState) -> None:
        if state.bomb_cooldown > 0:
            state.bomb_cooldown -= 1

    def _metrics(self, state: FrameState) -> dict[str, Any]:
        bullets_near = 0
        for bullet in state.bullets:
            if abs(bullet.x - state.player_x) < 42 and abs(bullet.y - state.player_y) < 34:
                bullets_near += 1

        return {
            "bullets_near": bullets_near,
            "danger": min(9, bullets_near),
            "bombs": state.bombs,
            "graze": state.graze,
            "options": state.options,
        }

    def _run_frame(
        self,
        state: FrameState,
        actions: dict[str, bool],
        bomb_pressed: bool,
    ) -> None:
        self._update_boss_position(state)
        self._move_player(state, actions)
        state.options = self._option_count(state.score)
        self._spawn_bullets(state)
        self._apply_bomb(state, bomb_pressed)
        self._apply_shot_logic(state, actions)
        self._update_bullets(state)
        self._tick_cooldowns(state)

    def make_json_safe(self, value: Any) -> Any:
        if isinstance(value, (str, int, float, bool)) or value is None:
            return value
        if isinstance(value, (list, tuple)):
            return [self.make_json_safe(item) for item in value[:8]]
        if isinstance(value, dict):
            limited: dict[str, Any] = {}
            for index, (key, item) in enumerate(value.items()):
                if index >= 8:
                    break
                limited[str(key)] = self.make_json_safe(item)
            return limited
        return repr(value)


class ReplayVerifier(PracticeCore):
    MAX_EVENTS = 50_000

    def _normalize_events(self, events: Any) -> list[dict[str, Any]]:
        if events is None:
            return []
        if not isinstance(events, list):
            raise ValueError("events must be a JSON array")
        if len(events) > self.MAX_EVENTS:
            raise ValueError("too many replay events")

        normalized: list[dict[str, Any]] = []
        for index, item in enumerate(events):
            if not isinstance(item, dict):
                raise ValueError(f"events[{index}] must be an object")

            frame = item.get("frame")
            key = item.get("key")
            down = item.get("down")
            if not isinstance(frame, int) or frame < 0 or frame >= self.MAX_FRAMES:
                raise ValueError(f"events[{index}].frame is invalid")
            if key not in self.CONTROL_KEYS:
                raise ValueError(f"events[{index}].key is invalid")
            if not isinstance(down, bool):
                raise ValueError(f"events[{index}].down must be boolean")

            normalized.append({"frame": frame, "key": key, "down": down})

        normalized.sort(key=lambda item: (item["frame"], item["key"], item["down"]))
        return normalized

    def verify(self, payload: dict[str, Any]) -> dict[str, Any]:
        events = self._normalize_events(payload.get("events"))

        state = self.create_state()
        held = {key: False for key in self.CONTROL_KEYS}
        event_index = 0

        for frame in range(self.MAX_FRAMES):
            state.frame = frame
            pressed_this_frame: set[str] = set()

            while event_index < len(events) and events[event_index]["frame"] == frame:
                event = events[event_index]
                held[event["key"]] = event["down"]
                if event["down"]:
                    pressed_this_frame.add(event["key"])
                event_index += 1

            actions = {key: held[key] for key in self.CONTROL_KEYS}
            self._run_frame(state, actions, bomb_pressed="bomb" in pressed_this_frame)

            if state.alive and state.score >= self.target_score:
                return {
                    "accepted": True,
                    "mode": "replay",
                    "score": state.score,
                    "frameReached": frame,
                    "graze": state.graze,
                    "bombsLeft": state.bombs,
                    "message": "Verified gameplay clear. The recovery daemon gives up.",
                }

            if not state.alive:
                break

        return {
            "accepted": False,
            "mode": "replay",
            "score": state.score,
            "frameReached": state.frame,
            "graze": state.graze,
            "bombsLeft": state.bombs,
            "deathReason": state.death_reason,
            "message": "Replay clear rejected.",
        }


class TelemetrySink:
    def __init__(self, verifier: "LegacyMacroVerifier", state: FrameState) -> None:
        self.verifier = verifier
        self.state = state
        self.records: list[dict[str, Any]] = []

    def probe(self, label: str, value: Any) -> Any:
        if len(self.records) < 64:
            self.records.append(
                {
                    "frame": self.state.frame,
                    "label": str(label)[:32],
                    "value": self.verifier.make_json_safe(value),
                }
            )
        return value


class LegacyMacroVerifier(PracticeCore):
    MAX_FORMULA_LEN = 280
    MAX_TELEMETRY_FIELDS = 6

    def _normalize_controls(self, controls: Any) -> dict[str, str]:
        if controls is None:
            controls = {}
        if not isinstance(controls, dict):
            raise ValueError("controls must be a JSON object")

        normalized: dict[str, str] = {}
        for key in self.CONTROL_KEYS:
            value = controls.get(key, "False")
            if not isinstance(value, str):
                raise ValueError(f"controls.{key} must be a string expression")
            if len(value) > self.MAX_FORMULA_LEN:
                raise ValueError(f"controls.{key} exceeds formula length limit")
            normalized[key] = value
        return normalized

    def _normalize_telemetry(self, telemetry: Any) -> dict[str, str]:
        if telemetry is None:
            return {}
        if not isinstance(telemetry, dict):
            raise ValueError("telemetry must be a JSON object")
        if len(telemetry) > self.MAX_TELEMETRY_FIELDS:
            raise ValueError("too many telemetry expressions")

        normalized: dict[str, str] = {}
        for key, value in telemetry.items():
            if not isinstance(key, str) or not key.isidentifier():
                raise ValueError("telemetry keys must be simple identifiers")
            if not isinstance(value, str):
                raise ValueError(f"telemetry.{key} must be a string expression")
            if len(value) > self.MAX_FORMULA_LEN:
                raise ValueError(f"telemetry.{key} exceeds formula length limit")
            normalized[key] = value
        return normalized

    def _build_context(
        self,
        state: FrameState,
        metrics: dict[str, Any],
        telemetry_sink: TelemetrySink,
    ) -> dict[str, Any]:
        return {
            "frame": state.frame,
            "score": state.score,
            "target": self.target_score,
            "player_x": state.player_x,
            "player_y": state.player_y,
            "boss_x": state.boss_x,
            "boss_y": state.boss_y,
            "bullets_near": metrics["bullets_near"],
            "danger": metrics["danger"],
            "bombs": metrics["bombs"],
            "graze": metrics["graze"],
            "options": metrics["options"],
            "phase": 0,
            "calibration": False,
            "stable": 0,
            "probe": telemetry_sink.probe,
            "abs": abs,
            "min": min,
            "max": max,
            "round": round,
        }

    def _evaluate_controls(
        self,
        controls: dict[str, str],
        context: dict[str, Any],
    ) -> dict[str, bool]:
        actions: dict[str, bool] = {}
        for key, expression in controls.items():
            try:
                actions[key] = bool(eval(expression, {"__builtins__": {}}, context))
            except Exception as exc:
                raise ValueError(f"control '{key}' failed: {exc}") from exc
        return actions

    def _evaluate_telemetry(
        self,
        telemetry: dict[str, str],
        context: dict[str, Any],
    ) -> dict[str, Any]:
        snapshot: dict[str, Any] = {}
        for key, expression in telemetry.items():
            try:
                value = eval(expression, {"__builtins__": {}}, context)
            except Exception as exc:
                raise ValueError(f"telemetry '{key}' failed: {exc}") from exc
            snapshot[key] = self.make_json_safe(value)
        return snapshot

    def verify(self, payload: dict[str, Any]) -> dict[str, Any]:
        controls = self._normalize_controls(payload.get("controls"))
        telemetry = self._normalize_telemetry(payload.get("telemetry"))

        state = self.create_state()
        telemetry_sink = TelemetrySink(self, state)
        telemetry_samples: list[dict[str, Any]] = []
        previous_actions = {key: False for key in self.CONTROL_KEYS}

        for frame in range(self.MAX_FRAMES):
            state.frame = frame
            metrics = self._metrics(state)
            control_context = self._build_context(state, metrics, telemetry_sink)
            actions = self._evaluate_controls(controls, control_context)
            bomb_pressed = actions["bomb"] and not previous_actions["bomb"]

            self._run_frame(state, actions, bomb_pressed=bomb_pressed)

            telemetry_context = self._build_context(state, self._metrics(state), telemetry_sink)
            telemetry_snapshot = self._evaluate_telemetry(telemetry, telemetry_context)
            if telemetry_snapshot and frame % 120 == 0 and len(telemetry_samples) < 18:
                telemetry_samples.append({"frame": frame, "values": telemetry_snapshot})

            if state.alive and state.score >= self.target_score:
                return {
                    "accepted": True,
                    "mode": "route",
                    "score": state.score,
                    "frameReached": frame,
                    "graze": state.graze,
                    "bombsLeft": state.bombs,
                    "deathReason": None,
                    "telemetry": telemetry_samples,
                    "probeLog": telemetry_sink.records,
                    "message": "Scarlet score target acknowledged.",
                }

            if not state.alive:
                break

            previous_actions = actions

        return {
            "accepted": False,
            "mode": "route",
            "score": state.score,
            "frameReached": state.frame,
            "graze": state.graze,
            "bombsLeft": state.bombs,
            "deathReason": state.death_reason,
            "telemetry": telemetry_samples,
            "probeLog": telemetry_sink.records,
            "message": "Recovery daemon rejected the route.",
        }


def create_app() -> Flask:
    secrets = ensure_instance_files()
    app = Flask(__name__, static_folder="app/static", template_folder="app/templates")
    app.config.update(
        TARGET_SCORE=int(secrets["target_score"]),
        RECOVERY_PASSWORD=secrets["recovery_password"],
    )

    @app.get("/")
    def index() -> str:
        return render_template("index.html")

    @app.get("/api/bootstrap")
    def bootstrap() -> Any:
        return jsonify(
            {
                "challengeName": "Rensencore 95",
                "targetScore": app.config["TARGET_SCORE"],
                "blobPath": "/static/assets/downloads/flag.r95",
                "submitRunPath": "/api/submit-run",
                "routeTemplate": {
                    "name": "scarlet-practice-route",
                    "controls": {
                        "left": "boss_x < player_x - 20",
                        "right": "boss_x > player_x + 20",
                        "up": "danger > 6",
                        "down": "danger < 2 and player_y < 390",
                        "focus": "danger > 3",
                        "shoot": "True",
                        "bomb": "False",
                    },
                    "telemetry": {
                        "delta": "target - score",
                        "panic": "danger",
                    },
                },
                "routeHelp": [
                    "Expressions run once per frame on the recovery daemon.",
                    "Available names: frame, score, target, player_x, player_y, boss_x, boss_y, bullets_near, danger, bombs, graze, options.",
                    "Helpers: abs, min, max, round, probe(label, value).",
                    "A verified live clear also grants the password. Reimu says impossible scores only look impossible before the route settles down.",
                ],
            }
        )

    @app.post("/api/verify-route")
    def verify_route() -> Any:
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"error": "route body must be JSON"}), 400

        verifier = LegacyMacroVerifier(app.config["TARGET_SCORE"])
        try:
            result = verifier.verify(payload)
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400

        if result["accepted"]:
            result["recoveryPassword"] = app.config["RECOVERY_PASSWORD"]

        return jsonify(result)

    @app.post("/api/submit-run")
    def submit_run() -> Any:
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            return jsonify({"error": "replay body must be JSON"}), 400

        verifier = ReplayVerifier(app.config["TARGET_SCORE"])
        try:
            result = verifier.verify(payload)
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400

        if result["accepted"]:
            result["recoveryPassword"] = app.config["RECOVERY_PASSWORD"]

        return jsonify(result)

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")))
