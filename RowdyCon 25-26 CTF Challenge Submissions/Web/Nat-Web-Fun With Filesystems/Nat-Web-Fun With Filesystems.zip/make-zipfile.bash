#!/bin/bash

zip -r Nat-Web-Fun\ With\ Filesystems.zip ./docker/ ./mock-brightness-dir/ ./src/ ./stevens-desktop/ ./docker-compose.yml ./*.bash ./README
