#!/bin/bash
sudo chmod 755 ./src
sudo chmod 644 ./src/*.php
sudo chmod 755 ./src/public-files
sudo chmod 644 ./src/public-files/*
sudo chmod -R 755 ./mock-brightness-dir
sudo chmod 644 ./mock-brightness-dir/backlight/amdgpu_bl0/*
sudo chmod 644 ./mock-brightness-dir/backlight/acpi_video0/*
sudo chmod 644 ./mock-brightness-dir/backlight/intel_backlight/*
