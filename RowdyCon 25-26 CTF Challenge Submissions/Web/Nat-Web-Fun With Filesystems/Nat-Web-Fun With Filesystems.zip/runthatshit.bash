#!/bin/bash

echo "Cleaning up any existing containers with the name php83_app..."
# This will stop and remove the container if it exists, and ignore errors if it doesn't
sudo docker rm -f php83_app 2>/dev/null || true
sudo docker rm -f nginx_app 2>/dev/null || true

echo setting up file permissions...
bash ./setup-file-perms.bash
echo "to visit application once its running, go to localhost:8080"
echo "bringing docker stuff down..."
sudo docker compose down -v --remove-orphans
echo "bringing docker stuff up..."
sudo docker compose up --build --force-recreate
