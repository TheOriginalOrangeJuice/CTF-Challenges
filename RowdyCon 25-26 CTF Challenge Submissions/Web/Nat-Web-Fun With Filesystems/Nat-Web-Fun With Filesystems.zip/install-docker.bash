#!/bin/bash


echo "this script assumes youre on a linux machine of some kind, and also installs docker. make sure thats what you want, you have 10s to ctrl+C ..."
sleep 10s

echo "DOWNLOADING DOCKER..."
echo --------------------------------------------------------------------------------
curl -fsSL https://get.docker.com -o /tmp/get-docker.sh
sudo sh /tmp/get-docker.sh

echo STARTING DOCKER SERVICE
echo --------------------------------------------------------------------------------
sudo systemctl start docker
sudo systemctl enable docker

echo ADDING USER TO DOCKER GROUP THING
echo --------------------------------------------------------------------------------
sudo usermod -aG docker $USER
newgrp docker
