<h2>Thank you for using the VSFTP&trade;&copy;&reg;!</h2>
Your requested file is available below <hr/>
<?php
if ($_GET['filename'] === "secret_backdoor_password_483f555cd3aa16d707c9513f16") {
	echo "<br/><b>welcome to the secret backdoor</b><br/>";
	echo "enjoy an environment variable for your troubles<br/>";
	echo getenv('SECRET_FLAG');
	echo "<br/><br/><br/><small>fun fact, I was going to make you have to read this by reading /proc/self/environ, but php-fpm permissions were making it hard because they're like, secure by default or whatever, and scrub environment variables from child processes, and its actually kinda hard to turn off, and I didn't want to switch to a whole new php thing this far in, so, you're welcome</small>";
} else if (str_ends_with($_GET['filename'], "/proc/self/environ")) {
	echo "<br/><b>nice try dog</b><br/>";
	echo "unfortunately for you, php-fpm security settings make it hard to get the challenge working with this as the solution. But, for your troubles, I'll give you a hint: find the source code for this file. the one I'm typing this into. right here. then read through that and see what you can find";
} else if (str_ends_with($_GET['filename'], ":)")) {
	echo "I too enjoy CVE-2011-2523<br/>";
	echo "However, thats not actually the solution<br/>";
	echo "This is an AFR challenge, which is different from LFI because the files are read not included<br/>";
	echo "hope that helps!<br/>";
} else {
	print(file_get_contents($_GET['filename']));
}
?>
