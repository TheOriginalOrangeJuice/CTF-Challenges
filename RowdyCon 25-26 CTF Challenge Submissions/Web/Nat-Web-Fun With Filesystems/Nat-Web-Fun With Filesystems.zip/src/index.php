<style>
html {
    box-sizing: border-box;
    max-width: 70ch;
    margin: auto;
    font-size: 1.25em;
    color: #333;
    line-height: 1.4;
}

* {
    box-sizing: inherit;
}

h1, h2, h3, h4, h5, h6 {
    font-family: sans-serif;
}

img {
    max-width: 100%;
    height: auto;
}

a:link {
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}
</style>
<h1>Very Secure File Transferring Page (VSFTP&trade;&copy;&reg;)</h1>
<h4>Your one-stop-shop for all of your file-sharing needs (as long as your file-sharing needs involve reading one of our many files listed below)</h4>

<p>Please click one of the following links to view one of our many fabulous files</p>

<?php
$files = scandir("./public-files", SCANDIR_SORT_ASCENDING, null);
for ($i = 0; $i < count($files) ; $i++) {
	if ($files[$i] === "." || $files[$i] === ".."){
		continue;
	}
	echo "<a href=./readfile.php?filename=./public-files/" . $files[$i] . ">" . $files[$i] . "</a><br/>";
}
?>
