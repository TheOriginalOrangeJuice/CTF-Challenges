"""
Restricted Unpickler for MSN Messenger Session Management
==========================================================
Security module that limits pickle deserialization to safe types only.
Prevents arbitrary code execution via pickle payloads by whitelisting
allowed classes.

Version: 1.0.2
Last updated: 10/15/1998
Author: Dave (IT Department)
"""

import pickle
import io
from collections import namedtuple

# Session data structure for authenticated users
UserSession = namedtuple('UserSession', ['username', 'display_name', 'login_time'])

# Whitelist of allowed classes for deserialization
ALLOWED_CLASSES = {
    ('builtins', 'tuple'),
    ('builtins', 'dict'),
    ('builtins', 'list'),
    ('builtins', 'str'),
    ('builtins', 'int'),
    ('builtins', 'bool'),
    ('collections', 'OrderedDict'),
    ('restricted_unpickler', 'UserSession'),
}


class RestrictedUnpickler(pickle.Unpickler):
    """
    A restricted unpickler that only allows deserialization of whitelisted
    classes. This prevents attackers from executing arbitrary code through
    crafted pickle payloads.

    Blocked modules include: os, subprocess, sys, importlib, etc.
    Only basic Python types and our UserSession namedtuple are permitted.
    """

    def find_class(self, module, name):
        if (module, name) in ALLOWED_CLASSES:
            return super().find_class(module, name)
        raise pickle.UnpicklingError(
            f"Deserialization of '{module}.{name}' is not allowed. "
            f"Nice try! Only approved types are permitted."
        )


def restricted_loads(data):
    """Safely deserialize a pickle payload using the restricted unpickler."""
    return RestrictedUnpickler(io.BytesIO(data)).load()
