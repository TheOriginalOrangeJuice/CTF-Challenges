/*
 * MSN Messenger Web Client
 * RowdyCon Systems Intranet Messaging Service
 *
 * Version: 4.7.3
 * (c) 1999 RowdyCon Systems, Inc.
 *
 * Best viewed in Internet Explorer 4.0 at 800x600
 */

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

var currentUser = null;       // { username, display_name }
var currentBuddy = null;      // username of open chat buddy
var selectedBuddy = null;     // username of selected buddy in list
var chatPollTimer = null;

// ---------------------------------------------------------------------------
// Clock
// ---------------------------------------------------------------------------

function updateClock() {
    var el = document.getElementById('clock');
    if (el) {
        var now = new Date();
        var h = now.getHours();
        var m = now.getMinutes();
        var ampm = h >= 12 ? 'PM' : 'AM';
        h = h % 12 || 12;
        m = m < 10 ? '0' + m : m;
        el.textContent = h + ':' + m + ' ' + ampm;
    }
}
setInterval(updateClock, 15000);
updateClock();

// ---------------------------------------------------------------------------
// Auth: Login
// ---------------------------------------------------------------------------

function doLogin() {
    var username = document.getElementById('signin-username').value.trim();
    var password = document.getElementById('signin-password').value;
    var status = document.getElementById('signin-status');

    if (!username || !password) {
        status.textContent = 'Please enter your screen name and password.';
        status.className = 'signin-status error';
        return;
    }

    status.textContent = 'Signing in...';
    status.className = 'signin-status signing-in signing-in-anim';
    document.getElementById('signin-btn').disabled = true;

    fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username, password: password })
    })
    .then(function(res) { return res.json().then(function(data) { return { ok: res.ok, data: data }; }); })
    .then(function(result) {
        document.getElementById('signin-btn').disabled = false;
        if (result.ok) {
            currentUser = {
                username: result.data.username,
                display_name: result.data.display_name
            };
            onSignedIn();
        } else {
            status.textContent = result.data.error || 'Sign-in failed.';
            status.className = 'signin-status error';
        }
    })
    .catch(function() {
        document.getElementById('signin-btn').disabled = false;
        status.textContent = 'Connection error. Is the server running?';
        status.className = 'signin-status error';
    });
}

// ---------------------------------------------------------------------------
// Auth: Signup
// ---------------------------------------------------------------------------

function showSignup() {
    document.getElementById('signup-dialog').classList.add('visible');
}

function hideSignup() {
    document.getElementById('signup-dialog').classList.remove('visible');
    document.getElementById('signup-status').textContent = '';
}

function doSignup() {
    var username = document.getElementById('signup-username').value.trim();
    var password = document.getElementById('signup-password').value;
    var displayName = document.getElementById('signup-displayname').value.trim() || username;
    var status = document.getElementById('signup-status');

    if (!username || !password) {
        status.textContent = 'Screen name and password are required.';
        status.className = 'signin-status error';
        return;
    }

    fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            username: username,
            password: password,
            display_name: displayName
        })
    })
    .then(function(res) { return res.json().then(function(data) { return { ok: res.ok, data: data }; }); })
    .then(function(result) {
        if (result.ok) {
            currentUser = {
                username: result.data.username,
                display_name: result.data.display_name
            };
            hideSignup();
            onSignedIn();
        } else {
            status.textContent = result.data.error || 'Signup failed.';
            status.className = 'signin-status error';
        }
    })
    .catch(function() {
        status.textContent = 'Connection error.';
        status.className = 'signin-status error';
    });
}

// ---------------------------------------------------------------------------
// Auth: Logout
// ---------------------------------------------------------------------------

function doLogout() {
    fetch('/api/logout', { method: 'POST' })
    .then(function() {
        currentUser = null;
        currentBuddy = null;
        selectedBuddy = null;
        if (chatPollTimer) clearInterval(chatPollTimer);

        document.getElementById('messenger-window').style.display = 'none';
        document.getElementById('chat-window').style.display = 'none';
        document.querySelector('.signin-window').style.display = 'flex';
        document.querySelector('.signin-window').style.flexDirection = 'column';
        document.getElementById('signin-status').textContent = 'Signed out.';
        document.getElementById('signin-status').className = 'signin-status';
        document.getElementById('signin-password').value = '';
    });
}

// ---------------------------------------------------------------------------
// Signed in — show messenger
// ---------------------------------------------------------------------------

function onSignedIn() {
    // Hide sign-in, show messenger
    document.querySelector('.signin-window').style.display = 'none';

    var mw = document.getElementById('messenger-window');
    mw.style.display = 'flex';
    mw.style.flexDirection = 'column';

    document.getElementById('my-display-name').textContent = currentUser.display_name;
    document.getElementById('messenger-title').textContent =
        currentUser.display_name + ' - MSN Messenger';

    // Update taskbar
    document.getElementById('taskbar-msn').innerHTML =
        '&#x1F98B; ' + escapeHtml(currentUser.display_name);

    loadBuddyList();

    // Play sign-in "sound" (visual flash)
    document.getElementById('messenger-statusbar').textContent =
        'You have signed in as ' + currentUser.display_name;
    setTimeout(function() {
        document.getElementById('messenger-statusbar').textContent = 'Online';
    }, 3000);
}

// ---------------------------------------------------------------------------
// Buddy list
// ---------------------------------------------------------------------------

function loadBuddyList() {
    fetch('/api/buddies')
    .then(function(res) { return res.json(); })
    .then(function(buddies) {
        var container = document.getElementById('buddy-list');
        var html = '';

        html += '<div class="buddy-category" onclick="toggleCategory(this)">Online (' + buddies.length + ')</div>';

        buddies.forEach(function(b) {
            html += '<div class="buddy-entry" '
                + 'data-username="' + escapeAttr(b.username) + '" '
                + 'onclick="selectBuddy(this, \'' + escapeAttr(b.username) + '\')" '
                + 'ondblclick="openChat(\'' + escapeAttr(b.username) + '\', \'' + escapeAttr(b.display_name) + '\')">'
                + '<div class="online-dot"></div>'
                + '<div class="buddy-icon">\u{1F464}</div>'
                + '<div class="buddy-details">'
                + '<div class="buddy-name">' + escapeHtml(b.display_name) + '</div>'
                + '<div class="buddy-status-msg">' + escapeHtml(b.status) + '</div>'
                + '</div>'
                + '</div>';
        });

        container.innerHTML = html;
    });
}

function toggleCategory(el) {
    el.classList.toggle('collapsed');
    var next = el.nextElementSibling;
    while (next && !next.classList.contains('buddy-category')) {
        next.style.display = el.classList.contains('collapsed') ? 'none' : 'flex';
        next = next.nextElementSibling;
    }
}

function selectBuddy(el, username) {
    selectedBuddy = username;
    var entries = document.querySelectorAll('.buddy-entry');
    entries.forEach(function(e) { e.classList.remove('selected'); });
    el.classList.add('selected');
}

function openChatWithSelected() {
    if (!selectedBuddy) {
        alert('Select a buddy from the list first!');
        return;
    }
    var el = document.querySelector('.buddy-entry[data-username="' + selectedBuddy + '"]');
    var name = el ? el.querySelector('.buddy-name').textContent : selectedBuddy;
    openChat(selectedBuddy, name);
}

// ---------------------------------------------------------------------------
// Chat
// ---------------------------------------------------------------------------

function openChat(username, displayName) {
    currentBuddy = username;

    var cw = document.getElementById('chat-window');
    cw.style.display = 'flex';
    cw.style.flexDirection = 'column';

    document.getElementById('chat-title').textContent = displayName + ' - Conversation';
    document.getElementById('chat-messages').innerHTML = '';
    document.getElementById('chat-typing').textContent = '';
    document.getElementById('chat-statusbar').textContent = 'Connected to ' + displayName;

    loadMessages();

    // Poll for new messages
    if (chatPollTimer) clearInterval(chatPollTimer);
    chatPollTimer = setInterval(loadMessages, 3000);
}

function closeChat() {
    document.getElementById('chat-window').style.display = 'none';
    currentBuddy = null;
    if (chatPollTimer) {
        clearInterval(chatPollTimer);
        chatPollTimer = null;
    }
}

function loadMessages() {
    if (!currentBuddy) return;

    fetch('/api/messages?buddy=' + encodeURIComponent(currentBuddy))
    .then(function(res) { return res.json(); })
    .then(function(messages) {
        var container = document.getElementById('chat-messages');
        var wasAtBottom = container.scrollHeight - container.scrollTop <= container.clientHeight + 30;
        var html = '';

        messages.forEach(function(msg) {
            var isMe = msg.from === currentUser.username;
            var senderName = isMe ? currentUser.display_name : msg.from;
            var senderClass = isMe ? 'me' : 'them';

            html += '<div class="chat-message">'
                + '<span class="sender ' + senderClass + '">'
                + escapeHtml(senderName) + '</span> says:'
                + '<span class="msg-text"> ' + escapeHtml(msg.content) + '</span>'
                + '</div>';
        });

        if (messages.length === 0) {
            html = '<div style="color:#808080; font-style:italic; padding:10px; text-align:center;">'
                + 'No messages yet. Say hi!</div>';
        }

        container.innerHTML = html;

        if (wasAtBottom) {
            container.scrollTop = container.scrollHeight;
        }
    });
}

function sendEmoji(emoji) {
    if (!currentBuddy) return;

    fetch('/api/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ to: currentBuddy, content: emoji })
    })
    .then(function(res) { return res.json(); })
    .then(function() {
        loadMessages();
    });
}

function sendNudge() {
    if (!currentBuddy) return;

    var chatWindow = document.getElementById('chat-window');
    chatWindow.classList.add('nudge');
    setTimeout(function() { chatWindow.classList.remove('nudge'); }, 600);

    // Add nudge message to chat display
    var container = document.getElementById('chat-messages');
    container.innerHTML += '<div class="chat-message" style="color:#808080; font-style:italic;">'
        + '\u{1F4A5} You sent a nudge!</div>';
    container.scrollTop = container.scrollHeight;

    // Also send as a message
    fetch('/api/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ to: currentBuddy, content: '** NUDGE **' })
    });
}

// ---------------------------------------------------------------------------
// Profile card (triggers vulnerable endpoint)
// ---------------------------------------------------------------------------

function viewMyProfile() {
    document.getElementById('profile-overlay').classList.add('visible');

    // Reset fields
    document.getElementById('profile-display-name').textContent = 'Loading...';
    document.getElementById('profile-username').textContent = '-';
    document.getElementById('profile-displayname').textContent = '-';
    document.getElementById('profile-status').textContent = '-';
    document.getElementById('profile-joined').textContent = '-';
    document.getElementById('profile-msgcount').textContent = '-';

    fetch('/api/profile')
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if (data.error) {
            document.getElementById('profile-display-name').textContent = 'Error';
            document.getElementById('profile-username').textContent = data.error;
            return;
        }

        document.getElementById('profile-display-name').textContent =
            data.display_name || data.username;
        document.getElementById('profile-username').textContent =
            data.username || '-';
        document.getElementById('profile-displayname').textContent =
            data.display_name || '-';
        document.getElementById('profile-status').textContent =
            data.status || '-';
        document.getElementById('profile-joined').textContent =
            data.joined || '-';
        document.getElementById('profile-msgcount').textContent =
            data.messages_sent != null ? data.messages_sent : '-';
    })
    .catch(function() {
        document.getElementById('profile-display-name').textContent = 'Error';
        document.getElementById('profile-username').textContent = 'Could not load profile.';
    });
}

function closeProfile() {
    document.getElementById('profile-overlay').classList.remove('visible');
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function escapeHtml(str) {
    if (!str) return '';
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function escapeAttr(str) {
    return escapeHtml(str);
}

// ---------------------------------------------------------------------------
// Keyboard shortcut: Enter to sign in
// ---------------------------------------------------------------------------

document.getElementById('signin-password').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        doLogin();
    }
});

document.getElementById('signin-username').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        document.getElementById('signin-password').focus();
    }
});
