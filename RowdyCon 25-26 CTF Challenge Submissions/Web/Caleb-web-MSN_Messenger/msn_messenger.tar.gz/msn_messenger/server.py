"""
MSN Messenger Web Client - Backend Server
==========================================
RowdyCon Systems Intranet Messaging Service

Version: 4.7.3
(c) 1999 RowdyCon Systems, Inc.
"""

import os
import sys
import re
import sqlite3
import pickle
import base64
import threading
from datetime import datetime

from flask import Flask, request, jsonify, send_from_directory, make_response

from restricted_unpickler import UserSession, restricted_loads

app = Flask(__name__, static_folder='public', static_url_path='')

PORT = os.environ.get('PORT')
FLAG = os.environ.get('FLAG')

if not PORT or not FLAG:
    print('ERROR: PORT and FLAG environment variables are required.')
    print('Run via: docker compose up --build')
    sys.exit(1)

PORT = int(PORT)

SEED_USERNAMES = {'clippy98', 'xX_BonziBuddy_Xx', 'dave_IT', 'SmarterChild'}
CLEANUP_INTERVAL = 120  # seconds

# ---------------------------------------------------------------------------
# Database setup
# ---------------------------------------------------------------------------

def get_db():
    """Get a database connection for the current context."""
    if not hasattr(get_db, '_connection'):
        get_db._connection = sqlite3.connect(':memory:', check_same_thread=False)
        get_db._connection.row_factory = sqlite3.Row
        init_db(get_db._connection)
    return get_db._connection


def init_db(conn):
    """Initialize database schema and seed data."""
    cursor = conn.cursor()

    cursor.executescript('''
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            display_name TEXT,
            status_message TEXT DEFAULT 'Available',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_user TEXT NOT NULL,
            to_user TEXT NOT NULL,
            content TEXT NOT NULL,
            sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE admin_secrets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT NOT NULL,
            value TEXT NOT NULL
        );
    ''')

    cursor.execute(
        'INSERT INTO admin_secrets (key, value) VALUES (?, ?)',
        ('flag', FLAG)
    )

    buddies = [
        ('clippy98', 'paperclip', '~*Clippy*~',
         'It looks like youre trying to hack! Need help?'),
        ('xX_BonziBuddy_Xx', 'banana', 'Bonzi Buddy',
         'Expand your desktop! Explore the internet!'),
        ('dave_IT', 'password1', 'Dave (IT Dept)',
         'Session cookies are just base64 pickled objects btw'),
        ('SmarterChild', 'away', 'SmarterChild',
         'Ask me anything! I know ALL the secrets...'),
    ]
    for uname, pwd, dname, status in buddies:
        cursor.execute(
            'INSERT INTO users (username, password, display_name, status_message) '
            'VALUES (?, ?, ?, ?)',
            (uname, pwd, dname, status),
        )

    seed_messages = [
        ('SmarterChild', 'clippy98',
         'Hey Clippy, did you know the session system uses pickle? '
         'Dave said it was fine because of the RestrictedUnpickler.'),
        ('clippy98', 'SmarterChild',
         'It looks like you\'re trying to deserialize untrusted data! '
         'Would you like help with that?'),
        ('dave_IT', 'clippy98',
         'Guys relax. I whitelisted only safe types. There\'s no way '
         'anyone can run os.system or subprocess through the unpickler.'),
        ('SmarterChild', 'dave_IT',
         'Sure Dave, but what about the data INSIDE those safe types? '
         'A UserSession is just a namedtuple with string fields...'),
        ('dave_IT', 'SmarterChild',
         'The username field comes from our database. '
         'It\'s always clean. The profile query is totally safe.'),
        ('xX_BonziBuddy_Xx', 'dave_IT',
         'Has anyone checked what happens if the username in a session '
         'isn\'t actually from the database? Asking for a friend.'),
    ]
    for from_u, to_u, content in seed_messages:
        cursor.execute(
            'INSERT INTO messages (from_user, to_user, content) VALUES (?, ?, ?)',
            (from_u, to_u, content),
        )

    conn.commit()


# ---------------------------------------------------------------------------
# Session helpers
# ---------------------------------------------------------------------------

def create_session(user):
    """Create a base64-encoded pickled session cookie from a user record."""
    session = UserSession(
        username=user['username'],
        display_name=user['display_name'],
        login_time=datetime.now().strftime('%m/%d/%Y %I:%M %p'),
    )
    return base64.b64encode(pickle.dumps(session)).decode()


def load_session(cookie_value):
    """
    Deserialize a session cookie.
    Uses RestrictedUnpickler to prevent arbitrary code execution.
    """
    data = base64.b64decode(cookie_value)
    return restricted_loads(data)


def get_current_user():
    """Extract user from session cookie, or return None."""
    cookie = request.cookies.get('msn_session')
    if not cookie:
        return None
    try:
        return load_session(cookie)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Static files
# ---------------------------------------------------------------------------

@app.route('/')
def index():
    return send_from_directory('public', 'index.html')


# ---------------------------------------------------------------------------
# Auth routes
# ---------------------------------------------------------------------------

@app.route('/api/signup', methods=['POST'])
def signup():
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid request'}), 400

    username = (data.get('username') or '').strip()
    password = data.get('password') or ''
    display_name = (data.get('display_name') or username).strip()

    if not username or not password:
        return jsonify({'error': 'Username and password are required'}), 400

    if len(username) > 50 or len(password) > 100 or len(display_name) > 100:
        return jsonify({'error': 'Input too long'}), 400

    if not re.match(r'^[a-zA-Z0-9_]+$', username):
        return jsonify({'error': 'Screen name can only contain letters, numbers, and underscores'}), 400

    db = get_db()
    try:
        db.execute(
            'INSERT INTO users (username, password, display_name) VALUES (?, ?, ?)',
            (username, password, display_name),
        )
        db.commit()
    except sqlite3.IntegrityError:
        return jsonify({'error': 'That screen name is already taken!'}), 409

    user = db.execute(
        'SELECT * FROM users WHERE username = ?', (username,)
    ).fetchone()

    resp = make_response(jsonify({
        'success': True,
        'username': user['username'],
        'display_name': user['display_name'],
    }))
    resp.set_cookie('msn_session', create_session(user), httponly=True, samesite='Lax')
    return resp


@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid request'}), 400

    username = (data.get('username') or '').strip()
    password = data.get('password') or ''

    if not username or not password:
        return jsonify({'error': 'Username and password are required'}), 400

    db = get_db()
    user = db.execute(
        'SELECT * FROM users WHERE username = ? AND password = ?',
        (username, password),
    ).fetchone()

    if not user:
        return jsonify({'error': 'Invalid screen name or password'}), 401

    resp = make_response(jsonify({
        'success': True,
        'username': user['username'],
        'display_name': user['display_name'],
    }))
    resp.set_cookie('msn_session', create_session(user), httponly=True, samesite='Lax')
    return resp


@app.route('/api/logout', methods=['POST'])
def logout():
    resp = make_response(jsonify({'success': True}))
    resp.delete_cookie('msn_session')
    return resp


# ---------------------------------------------------------------------------
# Buddy list
# ---------------------------------------------------------------------------

@app.route('/api/buddies')
def buddies():
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Not signed in'}), 401

    db = get_db()
    rows = db.execute(
        'SELECT username, display_name, status_message FROM users '
        'WHERE username != ? ORDER BY display_name',
        (user.username,),
    ).fetchall()

    buddy_list = [
        {
            'username': r['username'],
            'display_name': r['display_name'],
            'status': r['status_message'],
        }
        for r in rows
    ]
    return jsonify(buddy_list)


# ---------------------------------------------------------------------------
# Messaging
# ---------------------------------------------------------------------------

@app.route('/api/messages')
def messages():
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Not signed in'}), 401

    buddy = request.args.get('buddy', '')
    if not buddy:
        return jsonify({'error': 'Buddy parameter required'}), 400

    db = get_db()
    rows = db.execute(
        'SELECT from_user, to_user, content, sent_at FROM messages '
        'WHERE (from_user = ? AND to_user = ?) OR (from_user = ? AND to_user = ?) '
        'ORDER BY sent_at ASC',
        (user.username, buddy, buddy, user.username),
    ).fetchall()

    msgs = [
        {
            'from': r['from_user'],
            'to': r['to_user'],
            'content': r['content'],
            'time': r['sent_at'],
        }
        for r in rows
    ]
    return jsonify(msgs)


@app.route('/api/send', methods=['POST'])
def send_message():
    user = get_current_user()
    if not user:
        return jsonify({'error': 'Not signed in'}), 401

    data = request.get_json()
    if not data:
        return jsonify({'error': 'Invalid request'}), 400

    to_user = (data.get('to') or '').strip()
    content = (data.get('content') or '').strip()

    if not to_user or not content:
        return jsonify({'error': 'Recipient and message are required'}), 400

    # Only allow predefined emoticons
    ALLOWED_EMOJIS = {
        ':)', ':D', ';)', ':P', ':(', ':O',
        '<3', '>:(', 'B)', ':$', ':|', 'XD',
        '** NUDGE **',
    }
    if content not in ALLOWED_EMOJIS:
        return jsonify({'error': 'Only emoticons are allowed'}), 400

    db = get_db()

    # Verify recipient exists
    recipient = db.execute(
        'SELECT username FROM users WHERE username = ?', (to_user,)
    ).fetchone()
    if not recipient:
        return jsonify({'error': 'Buddy not found'}), 404

    db.execute(
        'INSERT INTO messages (from_user, to_user, content) VALUES (?, ?, ?)',
        (user.username, to_user, content),
    )
    db.commit()

    return jsonify({'success': True})


# ---------------------------------------------------------------------------
# Profile endpoint
# ---------------------------------------------------------------------------

@app.route('/api/profile')
def profile():
    """
    Fetch the current user's profile card.
    Reads username from the deserialized session cookie.
    """
    cookie = request.cookies.get('msn_session')
    if not cookie:
        return jsonify({'error': 'Not signed in'}), 401

    try:
        session = load_session(cookie)
    except Exception:
        return jsonify({'error': 'Invalid or corrupted session cookie'}), 401

    profile_data = get_user_profile(session.username)
    if profile_data:
        return jsonify(profile_data)
    return jsonify({'error': 'User not found'}), 404


def get_user_profile(username):
    """
    Fetch user profile with their message count for the profile card.
    """
    db = get_db()

    query = f"""
        SELECT
            u.username,
            u.display_name,
            u.status_message,
            u.created_at,
            (SELECT COUNT(*) FROM messages m WHERE m.from_user = u.username) as msg_count
        FROM users u
        WHERE u.username = '{username}'"""

    try:
        cursor = db.execute(query)
        row = cursor.fetchone()
    except Exception:
        return None

    if row:
        return {
            'username': row[0],
            'display_name': row[1],
            'status': row[2],
            'joined': row[3],
            'messages_sent': row[4],
        }
    return None


# ---------------------------------------------------------------------------
# Periodic cleanup - Ignore this part
# ---------------------------------------------------------------------------

def cleanup_users():
    """Delete non-seed users and their messages every CLEANUP_INTERVAL seconds."""
    while True:
        threading.Event().wait(CLEANUP_INTERVAL)
        try:
            db = get_db()
            placeholders = ','.join('?' for _ in SEED_USERNAMES)
            seeds = list(SEED_USERNAMES)

            db.execute(
                f'DELETE FROM messages WHERE from_user NOT IN ({placeholders}) '
                f'OR to_user NOT IN ({placeholders})',
                seeds + seeds,
            )
            db.execute(
                f'DELETE FROM users WHERE username NOT IN ({placeholders})',
                seeds,
            )
            db.commit()
            print('CLEANUP: purged non-seed users and messages, ignore this')
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Start server
# ---------------------------------------------------------------------------

if __name__ == '__main__':
    # Initialize database on startup
    get_db()

    # Start cleanup thread
    cleanup_thread = threading.Thread(target=cleanup_users, daemon=True)
    cleanup_thread.start()

    print(f'''
    +================================================+
    |     MSN Messenger Web Client v4.7.3            |
    |     (c) 1999 RowdyCon Systems, Inc.            |
    |                                                |
    |     Running on port {PORT}                       |
    |     http://localhost:{PORT}                       |
    +================================================+
    ''')

    app.run(host='0.0.0.0', port=PORT, debug=False)
