# app.py - IDOR: RowdyCon Gear Locker (CTF)

from flask import Flask, request, session, redirect, render_template_string, jsonify
import os

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "rowdy_secret_change_me")

# -------------------------
# Visible creds (CTF)
# -------------------------
USERS = {
    "volunteer": {"password": "birdsup", "id": "3001"},
    "speaker":   {"password": "keynote", "id": "3002"},
    "staff":     {"password": "rowdycrew", "id": "3003"},
}

# Lockers (RowdyCon gear)
LOCKERS = {
    "ROWDY3000": {"owner_id": "3000", "contents": "RCCTF{r0wdyc0n_1d0r_l0ck3r_br34ch}"},
    "ROWDY3001": {"owner_id": "3001", "contents": "Volunteer badge + t-shirt"},
    "ROWDY3002": {"owner_id": "3002", "contents": "Speaker badge + schedule"},
    "ROWDY3003": {"owner_id": "3003", "contents": "Staff access kit"},
}

# -------------------------
# Pages
# -------------------------
INDEX_PAGE = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>UTSA RowdyCon — Gear Lockers</title>
  <style>
    body { background:#0a0f1f; color:#f3f4f6; font-family: sans-serif; padding:20px; }
    .box { background:#111827; border:1px solid #e87511; padding:15px; border-radius:8px; max-width:800px; }
    a, code { color:#e87511; }
    h1 { color:#e87511; }
    .creds { background:#020617; padding:10px; border-radius:6px; }
  </style>
</head>
<body>
  <h1>UTSA RowdyCon — Gear Locker Portal</h1>
  <div class="box">
    <p>Welcome to the RowdyCon staff portal. Volunteers and speakers can access their assigned gear lockers here.</p>
    <p>The system was rushed before the conference — some access controls might not be fully enforced...</p>

    <h3>Test credentials:</h3>
    <div class="creds">
      <ul>
        <li><b>volunteer</b> / <code>birdsup</code> (id: 3001)</li>
        <li><b>speaker</b> / <code>keynote</code>   (id: 3002)</li>
        <li><b>staff</b> / <code>rowdycrew</code>   (id: 3003)</li>
      </ul>
    </div>

    <p>API access: <code>GET /locker?locker_id=ROWDY3001</code></p>

    {% if user %}
      <p>Logged in as <b>{{ user }}</b> — <a href="/logout">Logout</a></p>
      <p>Open your locker: <a href="/locker?locker_id=ROWDY{{ session.id }}">Open my locker</a></p>
    {% else %}
      <p><a href="/login">Login</a> to continue.</p>
    {% endif %}
  </div>
</body>
</html>
"""

LOGIN_PAGE = """
<!doctype html>
<html>
<head>
  <title>RowdyCon Login</title>
  <style>body { background:#0a0f1f; color:#f3f4f6; font-family:sans-serif; padding:20px }</style>
</head>
<body>
  <h1>Login</h1>
  <form method="post">
    <input name="user" placeholder="Username"><br><br>
    <input type="password" name="pass" placeholder="Password"><br><br>
    <button>Login</button>
  </form>
</body>
</html>
"""

LOCKER_FORM = """
<h3>Open a locker</h3>
<form action="/locker" method="get">
  <input name="locker_id" placeholder="Locker ID (e.g. ROWDY3001)">
  <button>Open</button>
</form>
"""

# -------------------------
# Routes
# -------------------------
@app.route('/')
def index():
    return render_template_string(INDEX_PAGE, user=session.get('user'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'GET':
        return render_template_string(LOGIN_PAGE)

    u = request.form.get('user')
    p = request.form.get('pass')

    profile = USERS.get(u)
    if profile and profile['password'] == p:
        session['user'] = u
        session['id'] = profile['id']
        return redirect('/')

    return "Invalid credentials", 401

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

# 🔥 Vulnerable endpoint (IDOR)
@app.route('/locker')
def locker():
    locker_id = request.args.get('locker_id') or ''
    if locker_id == '':
        return LOCKER_FORM

    rec = LOCKERS.get(locker_id)
    if not rec:
        return "Locker not found", 404

    # INTENTIONAL VULN: no ownership check
    return jsonify({
        "locker_id": locker_id,
        "owner_id": rec["owner_id"],
        "contents": rec["contents"]
    })

if __name__ == "__main__":
    print("[boot] RowdyCon Gear Locker running on :9001")
    app.run(host="0.0.0.0", port=9001)